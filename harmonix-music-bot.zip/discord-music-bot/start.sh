#!/usr/bin/env bash
# Harmonix one-click launcher for macOS/Linux.
cd "$(dirname "$0")"
exec node run.js "$@"
