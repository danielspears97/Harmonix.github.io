﻿# Harmonix tray launcher - runs the bot silently with a system-tray icon.
# Start it with start-silent.vbs (no window) or:
#   powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File tray.ps1
#
# Tray menu: Show live logs - Open dashboard - Restart bot - Exit (stop bot)
# The bot's output streams to logs\bot.log; the log window is safe to close
# at any time - it's just a viewer, the bot keeps running in the background.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
New-Item -ItemType Directory -Force -Path (Join-Path $root 'logs') | Out-Null
$log = Join-Path $root 'logs\bot.log'

function Start-Bot {
    if (Test-Path $log) { Move-Item -Force $log (Join-Path $root 'logs\bot-prev.log') }
    # cmd handles the output redirection; hidden window = fully silent.
    $script:bot = Start-Process -FilePath 'cmd.exe' `
        -ArgumentList "/c node run.js >> `"$log`" 2>&1" `
        -WorkingDirectory $root -WindowStyle Hidden -PassThru
}

function Stop-Bot {
    if ($script:bot -and -not $script:bot.HasExited) {
        # /T kills the whole tree (node + cloudflared). Lavalink is a detached
        # Docker container and keeps running; stop it with: docker compose down
        taskkill /PID $($script:bot.Id) /T /F | Out-Null
    }
}

function Get-DashboardUrl {
    # Permanent named-tunnel address from .env wins (dash.harmonixbot.xyz).
    $envFile = Join-Path $root '.env'
    if (Test-Path $envFile) {
        $pub = Select-String -Path $envFile -Pattern '^\s*PUBLIC_URL\s*=\s*(\S+)' | Select-Object -First 1
        if ($pub) { return $pub.Matches[0].Groups[1].Value.Trim('"').Trim("'").TrimEnd('/') }
    }
    # Otherwise a throwaway tunnel URL from the log (only when run with --tunnel).
    if (Test-Path $log) {
        $m = Select-String -Path $log -Pattern 'https://[a-z0-9-]+\.trycloudflare\.com' -AllMatches |
             Select-Object -Last 1
        if ($m) { return $m.Matches[$m.Matches.Count - 1].Value }
    }
    $port = 3000
    if (Test-Path $envFile) {
        $line = Select-String -Path $envFile -Pattern '^\s*DASHBOARD_PORT\s*=\s*(\d+)' | Select-Object -First 1
        if ($line) { $port = [int]$line.Matches[0].Groups[1].Value }
    }
    return "http://localhost:$port"
}

function Show-Logs {
    Start-Process powershell -ArgumentList @(
        '-NoExit', '-Command',
        "`$host.UI.RawUI.WindowTitle = 'Harmonix logs (safe to close - the bot keeps running)'; Get-Content -Wait -Tail 80 -Path '$log'"
    )
}

Start-Bot

$icon = New-Object System.Windows.Forms.NotifyIcon
$icon.Icon = [System.Drawing.SystemIcons]::Application
$icon.Text = 'Harmonix - starting...'
$icon.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miLogs    = $menu.Items.Add('Show live logs')
$miDash    = $menu.Items.Add('Open dashboard')
[void]$menu.Items.Add('-')
$miRestart = $menu.Items.Add('Restart bot')
$miExit    = $menu.Items.Add('Exit (stop bot)')
$icon.ContextMenuStrip = $menu

$miLogs.add_Click({ Show-Logs })
$icon.add_DoubleClick({ Show-Logs })
$miDash.add_Click({ Start-Process (Get-DashboardUrl) })
$miRestart.add_Click({
    Stop-Bot
    Start-Sleep -Seconds 1
    Start-Bot
    $icon.ShowBalloonTip(2000, 'Harmonix', 'Bot restarted.', [System.Windows.Forms.ToolTipIcon]::Info)
})
$miExit.add_Click({
    Stop-Bot
    $icon.Visible = $false
    [System.Windows.Forms.Application]::Exit()
})

# Watchdog: reflect the bot's state in the tray tooltip.
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 5000
$timer.add_Tick({
    if ($script:bot -and $script:bot.HasExited) {
        $icon.Text = 'Harmonix - STOPPED (right-click to restart)'
    } else {
        $icon.Text = 'Harmonix - running'
    }
})
$timer.Start()

[System.Windows.Forms.Application]::Run()
