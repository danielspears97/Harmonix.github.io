@echo off
REM Harmonix one-click launcher for Windows.
REM Double-click this file, or run: start.bat
cd /d "%~dp0"
title Harmonix
node run.js %*
pause
