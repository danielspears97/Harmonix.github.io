'use strict';

/**
 * Harmonix — entrypoint.
 * Boots the Discord client, Lavalink manager, command/event handlers,
 * the control-panel updater, persistence, and the web dashboard.
 */

require('dotenv').config();

const { config, validate } = require('./config');
const { createClient } = require('./src/bot/client');
const { createLavalink } = require('./src/bot/lavalink');
const { loadCommands } = require('./src/commands');
const { registerEvents } = require('./src/events');
const { attachPlayerEvents } = require('./src/lavalink/events');
const { attachPanelUpdates } = require('./src/handlers/controlPanel');
const persistence = require('./src/utils/persistence');
const { startDashboard } = require('./src/dashboard/server');

async function main() {
  // Fail fast on missing required env (DISCORD_TOKEN, CLIENT_ID, Lavalink host…).
  validate();

  // Restore per-guild settings (control channel, 24/7, autoplay, volume).
  persistence.load();

  const client = createClient();

  // Lavalink audio backend.
  client.lavalink = createLavalink(client);
  attachPlayerEvents(client);

  // Slash + button commands.
  const commands = loadCommands();
  for (const [name, command] of commands) client.commands.set(name, command);
  console.log(`[bot] loaded ${client.commands.size} commands`);

  // Live now-playing panel refreshes.
  attachPanelUpdates(client);

  // Gateway + interaction events.
  registerEvents(client);

  // Web dashboard (optional; controlled by DASHBOARD_ENABLED).
  startDashboard(client);

  // Surface async errors instead of dying silently.
  process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));
  process.on('uncaughtException', (err) => console.error('[uncaughtException]', err));

  await client.login(config.token);
  console.log(`[bot] logged in as ${client.user.tag}`);
}

main().catch((err) => {
  console.error('[fatal] failed to start Harmonix:', err);
  process.exit(1);
});
