' Harmonix silent launcher - double-click to start the bot in the system tray.
' No window appears; look for the Harmonix icon in the hidden-icons area.
Set sh = CreateObject("WScript.Shell")
dir = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\") - 1)
sh.CurrentDirectory = dir
sh.Run "powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File ""tray.ps1""", 0, False
