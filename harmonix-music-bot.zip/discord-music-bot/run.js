'use strict';

/**
 * Harmonix one-shot launcher.
 *
 *   node run.js                 # start everything
 *   node run.js --no-tunnel     # skip the Cloudflare tunnel
 *   node run.js --no-deploy     # skip registering slash commands
 *   node run.js --no-logs       # don't stream Lavalink logs
 *   node run.js --deploy global # force-global command deploy
 *
 * It will, in order:
 *   1. make sure the Docker engine is running (starts Docker Desktop on
 *      Windows/macOS and waits for it),
 *   2. bring up the Lavalink container (docker compose up -d) and wait until
 *      it accepts connections on its port,
 *   3. start a Cloudflare quick-tunnel and capture its public URL,
 *   4. register slash commands,
 *   5. start the bot — with PUBLIC_URL set to the tunnel URL so the dashboard
 *      and Discord OAuth use the correct address,
 *   6. stream Lavalink + bot + tunnel logs into one window.
 *
 * Ctrl+C stops the bot and the tunnel. Lavalink is left running (it's a
 * detached container); stop it with `docker compose down` when you're done.
 */

require('dotenv').config();
const { spawn, spawnSync } = require('child_process');
const net = require('net');
const os = require('os');

const args = process.argv.slice(2);
const has = (f) => args.includes(f);
const NO_TUNNEL = has('--no-tunnel');
const NO_DEPLOY = has('--no-deploy');
const NO_LOGS = has('--no-logs');
const deployIdx = args.indexOf('--deploy');
const DEPLOY_ARG = deployIdx !== -1 ? (args[deployIdx + 1] || '') : '';

const PORT = process.env.DASHBOARD_PORT || '3000';
const LAVA_HOST = process.env.LAVALINK_HOST || '127.0.0.1';
const LAVA_PORT = parseInt(process.env.LAVALINK_PORT || '2333', 10);

const children = [];
let shuttingDown = false;

// ── pretty prefixed logging ──────────────────────────────────────
const COLORS = { engine: '\x1b[36m', lavalink: '\x1b[35m', tunnel: '\x1b[33m', deploy: '\x1b[32m', bot: '\x1b[34m', error: '\x1b[31m' };
const RESET = '\x1b[0m';
function log(tag, msg) {
  const c = COLORS[tag] || '';
  for (const line of String(msg).split(/\r?\n/)) {
    if (line.trim() === '') continue;
    process.stdout.write(`${c}[${tag}]${RESET} ${line}\n`);
  }
}
function pipe(tag, child) {
  child.stdout && child.stdout.on('data', (d) => log(tag, d));
  child.stderr && child.stderr.on('data', (d) => log(tag, d));
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── docker helpers ───────────────────────────────────────────────
function dockerReady() {
  return spawnSync('docker', ['info'], { stdio: 'ignore' }).status === 0;
}
function composeCmd(extra) {
  // Prefer `docker compose` (v2); fall back to `docker-compose`.
  const v2 = spawnSync('docker', ['compose', 'version'], { stdio: 'ignore' }).status === 0;
  return v2 ? { cmd: 'docker', base: ['compose', ...extra] } : { cmd: 'docker-compose', base: extra };
}
function tryStartDockerEngine() {
  if (process.platform === 'win32') {
    log('engine', 'Docker not responding — launching Docker Desktop…');
    spawn('cmd', ['/c', 'start', '', 'C:\\Program Files\\Docker\\Docker\\Docker Desktop.exe'], { detached: true, stdio: 'ignore' }).unref();
  } else if (process.platform === 'darwin') {
    log('engine', 'Docker not responding — launching Docker Desktop…');
    spawn('open', ['-a', 'Docker'], { detached: true, stdio: 'ignore' }).unref();
  } else {
    log('engine', 'Docker not responding. Start it with: sudo systemctl start docker');
  }
}

async function ensureDockerEngine() {
  if (dockerReady()) { log('engine', 'Docker engine is running.'); return; }
  tryStartDockerEngine();
  const deadline = Date.now() + 150000; // 2.5 min
  while (Date.now() < deadline) {
    await sleep(3000);
    if (dockerReady()) { log('engine', 'Docker engine is ready.'); return; }
    log('engine', 'waiting for Docker to start…');
  }
  throw new Error('Docker engine did not start in time. Open Docker Desktop manually and retry.');
}

function portOpen(host, port, timeout = 1500) {
  return new Promise((resolve) => {
    const s = net.connect({ host, port }, () => { s.destroy(); resolve(true); });
    s.on('error', () => resolve(false));
    s.setTimeout(timeout, () => { s.destroy(); resolve(false); });
  });
}

async function startLavalink() {
  const { cmd, base } = composeCmd(['up', '-d']);
  log('lavalink', 'starting container (docker compose up -d)…');
  const r = spawnSync(cmd, base, { stdio: 'inherit' });
  if (r.status !== 0) throw new Error('docker compose up failed — is docker-compose.yml present?');
  const deadline = Date.now() + 90000;
  while (Date.now() < deadline) {
    if (await portOpen(LAVA_HOST, LAVA_PORT)) { log('lavalink', `up on ${LAVA_HOST}:${LAVA_PORT}.`); return; }
    log('lavalink', 'waiting for Lavalink to accept connections…');
    await sleep(3000);
  }
  throw new Error('Lavalink did not become reachable — check `docker compose logs`.');
}

function streamLavalinkLogs() {
  if (NO_LOGS) return;
  const { cmd, base } = composeCmd(['logs', '-f', '--tail', '5']);
  const child = spawn(cmd, base);
  children.push(child);
  pipe('lavalink', child);
}

// ── cloudflare quick-tunnel ──────────────────────────────────────
function startTunnel() {
  return new Promise((resolve) => {
    if (NO_TUNNEL) return resolve(null);
    if (spawnSync('cloudflared', ['--version'], { stdio: 'ignore' }).status !== 0) {
      log('tunnel', 'cloudflared not found — skipping tunnel. (Install it or use --no-tunnel.)');
      return resolve(null);
    }
    log('tunnel', `starting Cloudflare tunnel → http://localhost:${PORT}…`);
    const child = spawn('cloudflared', ['tunnel', '--url', `http://localhost:${PORT}`]);
    children.push(child);
    let url = null;
    const onData = (d) => {
      const text = String(d);
      log('tunnel', text);
      const m = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
      if (m && !url) { url = m[0]; resolve(url); }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);
    child.on('exit', () => { if (!url) resolve(null); });
    setTimeout(() => { if (!url) { log('tunnel', 'no URL captured yet — continuing without it.'); resolve(null); } }, 20000);
  });
}

function deployCommands() {
  if (NO_DEPLOY) return;
  const cmdArgs = ['deploy-commands.js'];
  if (DEPLOY_ARG) cmdArgs.push(DEPLOY_ARG);
  log('deploy', `registering slash commands${DEPLOY_ARG ? ` (${DEPLOY_ARG})` : ''}…`);
  const r = spawnSync('node', cmdArgs, { stdio: 'inherit' });
  if (r.status !== 0) log('deploy', 'command deploy failed (continuing to start the bot anyway).');
}

function startBot(tunnelUrl) {
  const env = { ...process.env };
  if (tunnelUrl) {
    env.PUBLIC_URL = tunnelUrl;
    log('bot', `PUBLIC_URL set to ${tunnelUrl}`);
    log('bot', `\x1b[1mOAuth redirect to register in the Discord portal: ${tunnelUrl}/auth/callback\x1b[0m`);
  }
  const child = spawn('node', ['index.js'], { env });
  children.push(child);
  pipe('bot', child);
  child.on('exit', (code) => {
    if (!shuttingDown) { log('bot', `bot exited (code ${code}). Shutting down.`); shutdown(); }
  });
}

function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  process.stdout.write('\n');
  log('engine', 'stopping bot & tunnel… (Lavalink stays up — `docker compose down` to stop it)');
  for (const c of children) { try { c.kill('SIGTERM'); } catch { /* ignore */ } }
  setTimeout(() => process.exit(0), 1500);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

(async () => {
  try {
    log('engine', `Harmonix launcher — platform ${os.platform()}`);
    await ensureDockerEngine();
    await startLavalink();
    streamLavalinkLogs();
    const tunnelUrl = await startTunnel();
    deployCommands();
    startBot(tunnelUrl);
    log('engine', 'all systems go. Press Ctrl+C to stop the bot and tunnel.');
  } catch (err) {
    log('error', err.message || String(err));
    shutdown();
  }
})();
