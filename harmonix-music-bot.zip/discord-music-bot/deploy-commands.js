'use strict';

/**
 * Registers Harmonix's slash commands with Discord.
 *
 *   npm run deploy            # global if no GUILD_ID, else that guild (see note)
 *   npm run deploy:global     # FORCE global (all servers) + clear the test guild
 *   npm run deploy:guild      # FORCE the GUILD_ID guild only (instant, for dev)
 *   npm run deploy:clear      # remove ALL commands (global + the GUILD_ID guild)
 *
 * GLOBAL vs GUILD — important:
 *   • Global commands appear in EVERY server the bot is in, but take up to ~1
 *     hour to propagate the first time.
 *   • Guild commands appear instantly but ONLY in that one guild. If GUILD_ID is
 *     left set in .env, `deploy` registers to just that server and no other
 *     server ever sees the commands. For production, use `deploy:global` (or
 *     unset GUILD_ID).
 */

require('dotenv').config();

const { REST, Routes } = require('discord.js');
const { config, validate } = require('./config');
const { loadCommands } = require('./src/commands');

const arg = (process.argv[2] || '').replace(/^--/, '').toLowerCase();

async function main() {
  validate();

  const rest = new REST({ version: '10' }).setToken(config.token);
  const commands = loadCommands();
  const body = [...commands.values()].map((c) => c.data.toJSON());

  // ── clear everything ───────────────────────────────────────────
  if (arg === 'clear') {
    await rest.put(Routes.applicationCommands(config.clientId), { body: [] });
    console.log('[deploy] cleared all GLOBAL commands.');
    if (config.guildId) {
      await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: [] });
      console.log(`[deploy] cleared all commands in guild ${config.guildId}.`);
    }
    return;
  }

  // Decide scope: explicit arg wins, else fall back to the GUILD_ID heuristic.
  const scope = arg === 'global' ? 'global'
    : arg === 'guild' ? 'guild'
      : (config.guildId ? 'guild' : 'global');

  if (scope === 'guild') {
    if (!config.guildId) throw new Error('deploy:guild needs GUILD_ID set in .env');
    await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body });
    console.log(`[deploy] ${body.length} command(s) registered to guild ${config.guildId} (instant, that server only).`);
    console.log('[deploy] NOTE: other servers will NOT see these. Use `npm run deploy:global` for all servers.');
  } else {
    await rest.put(Routes.applicationCommands(config.clientId), { body });
    console.log(`[deploy] ${body.length} command(s) registered GLOBALLY — every server, ~1h to propagate the first time.`);
    // Avoid duplicates: a test guild that still has guild-scoped copies would
    // show each command twice. Clear them when going global.
    if (config.guildId) {
      await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: [] });
      console.log(`[deploy] cleared old guild-scoped copies in ${config.guildId} to prevent duplicates.`);
    }
  }
}

main().catch((err) => {
  console.error('[deploy] failed:', err);
  process.exit(1);
});
