'use strict';
require('dotenv').config();

function bool(v, fallback = false) {
  if (v === undefined || v === null || v === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());
}

function int(v, fallback) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : fallback;
}

const config = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID || null,

  // Music-only mode: load only the music commands and skip non-music event
  // handlers/schedulers. Run a second bot instance with MUSIC_ONLY=true, its
  // own DISCORD_TOKEN/CLIENT_ID and a separate DATABASE_PATH to get an
  // independent "Harmonix2" with its own music-request channel.
  musicOnly: bool(process.env.MUSIC_ONLY, false),

  lavalink: {
    host: process.env.LAVALINK_HOST || '127.0.0.1',
    port: int(process.env.LAVALINK_PORT, 2333),
    authorization: process.env.LAVALINK_PASSWORD || 'youshallnotpass',
    secure: bool(process.env.LAVALINK_SECURE, false),
    id: 'main-node',
  },

  dashboard: {
    enabled: bool(process.env.DASHBOARD_ENABLED, true),
    port: int(process.env.DASHBOARD_PORT, 3000),
    password: process.env.DASHBOARD_PASSWORD || '',
    // Discord OAuth2. When clientSecret + redirectUri are set the dashboard
    // requires "Login with Discord" and scopes access to the servers each user
    // can manage. Otherwise it runs in local mode (optional password gate).
    oauth: {
      clientId: process.env.CLIENT_ID,
      clientSecret: process.env.CLIENT_SECRET || '',
      redirectUri:
        process.env.OAUTH_REDIRECT_URI ||
        (process.env.PUBLIC_URL
          ? `${process.env.PUBLIC_URL.replace(/\/+$/, '')}/auth/callback`
          : `http://localhost:${int(process.env.DASHBOARD_PORT, 3000)}/auth/callback`),
    },
    sessionSecret: process.env.SESSION_SECRET || '',
    // Public address the dashboard is reached at (e.g. https://bot.example.com),
    // when exposed over the internet via a tunnel/reverse proxy. Used for links
    // and to enable secure cookies. OAuth still uses OAUTH_REDIRECT_URI.
    publicUrl: process.env.PUBLIC_URL || '',
  },

  defaultVolume: Math.min(100, Math.max(1, int(process.env.DEFAULT_VOLUME, 60))),
  leaveTimeoutMs: int(process.env.LEAVE_TIMEOUT_SECONDS, 60) * 1000,

  // Cosmetic
  brand: {
    name: 'Harmonix',
    color: 0x8b5cf6, // accent used in embeds
    successColor: 0x22c55e,
    errorColor: 0xef4444,
  },
};

function validate() {
  const missing = [];
  if (!config.token) missing.push('DISCORD_TOKEN');
  if (!config.clientId) missing.push('CLIENT_ID');
  if (missing.length) {
    console.error(`\n[config] Missing required environment variables: ${missing.join(', ')}`);
    console.error('[config] Copy .env.example to .env and fill it in.\n');
    process.exit(1);
  }
}

module.exports = { config, validate };
