'use strict';

const { EmbedBuilder } = require('discord.js');
const { getDb } = require('../db');
const fg = require('./freeGames');

const POLL_MS = 15 * 60 * 1000; // every 15 minutes

const KIND_META = {
  keep: { label: 'Free to keep', color: 0x57f287, emoji: '🎁' },
  timed: { label: 'Free to play', color: 0xfee75c, emoji: '⏳' },
  discount: { label: 'Steep discount', color: 0xeb459e, emoji: '🏷️' },
};
const TYPE_LABEL = { games: 'Game', dlc: 'DLC', earlyaccess: 'Early access' };

/** GamerPower ships "2026-07-30 23:59:00" (UTC) — turn it into a Discord
 *  timestamp so every reader sees it in their own zone. */
function endTimestamp(raw) {
  if (!raw || raw === 'N/A') return null;
  const t = Date.parse(`${String(raw).replace(' ', 'T')}Z`);
  return Number.isNaN(t) ? null : Math.floor(t / 1000);
}

/** Their copy repeats words ("until  until July 30") and runs long; tidy it
 *  and cut on a sentence boundary so the embed doesn't end mid-word. */
function cleanDescription(raw) {
  let d = String(raw || '').replace(/\s+/g, ' ').trim();
  d = d.replace(/\b(\w+) \1\b/gi, '$1');
  if (d.length <= 220) return d;
  const cut = d.slice(0, 220);
  const stop = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '));
  return (stop > 120 ? cut.slice(0, stop + 1) : `${cut.trimEnd()}…`);
}

/** Their titles end with noise the embed already shows: "(Steam) Giveaway",
 *  "Key Giveaway", "Free Download". Strip it so the name reads cleanly. */
function cleanTitle(raw) {
  return String(raw || 'Free game')
    .replace(/\s*\((?:steam|epic games?|gog|itch\.io|drm-free|pc|xbox|playstation|switch|android|ios)[^)]*\)/gi, '')
    .replace(/\s*(?:steam |epic |cd |game )?key\s*giveaway\s*$/i, '')
    .replace(/\s*giveaway\s*$/i, '')
    .replace(/\s*free download\s*$/i, '')
    .replace(/\s{2,}/g, ' ')
    .trim()
    .slice(0, 240) || 'Free game';
}

function buildEmbed(g) {
  const kind = fg.offerKind(g);
  const meta = KIND_META[kind] || KIND_META.keep;
  const type = fg.contentType(g);
  const primary = fg.primaryPlatform(g);
  const store = fg.detectStore(g); // the actual shop this key comes from
  const plats = fg.platformKeysFor(g)
    .map((k) => (fg.PLATFORMS.find((p) => p.key === k) || {}).label)
    .filter(Boolean);

  const worth = parseFloat(String(g.worth || '').replace(/[^0-9.]/g, '')) || 0;
  const price = kind === 'discount'
    ? `~~${g.worth}~~ **heavily discounted**`
    : (worth > 0 ? `~~${g.worth}~~ **Free**` : '**Free**');

  const ends = endTimestamp(g.end_date);
  const claimUrl = g.open_giveaway_url || g.gamerpower_url;

  // Big, FreeStuff-style layout: headline price, description, then a row of
  // at-a-glance fields under it, with the artwork as a full-width banner.
  const lines = [`## ${price}`];
  const desc = cleanDescription(g.description);
  if (desc) lines.push(desc);
  // Discord sizes an embed to its widest line. U+2800 (blank braille) is
  // invisible but occupies width, so this pins the card to full width instead
  // of letting short entries render as a narrow sliver.
  lines.push('\u2800'.repeat(58));

  const embed = new EmbedBuilder()
    .setColor(meta.color)
    .setAuthor({
      name: `${meta.label}  \u00b7  ${TYPE_LABEL[type]}${store ? `  \u00b7  ${store.label}` : ''}`,
      iconURL: store?.icon || primary?.icon || undefined,
    })
    .setTitle(`${meta.emoji}  ${cleanTitle(g.title)}`)
    .setURL(claimUrl || null)
    .setDescription(lines.join('\n\n'))
    .addFields(
      { name: '\uD83D\uDD79\uFE0F Platforms', value: plats.join('\n') || (g.platforms || 'PC'), inline: true },
      { name: '\uD83D\uDCB0 Value', value: worth > 0 ? `~~${g.worth}~~\n**Free**` : '*not listed*', inline: true },
      { name: '\u23F0 Offer ends', value: ends ? `<t:${ends}:D>\n<t:${ends}:R>` : 'While supplies last', inline: true },
    );

  if (claimUrl) {
    embed.addFields({ name: '\u200b', value: `**[\u2192  Claim it${store ? ` on ${store.label}` : ''}](${claimUrl})**` });
  }

  // The storefront's own logo sits large in the top-right; game art runs
  // full-width along the bottom.
  const logo = store?.icon || primary?.icon;
  if (logo) embed.setThumbnail(logo);
  if (g.image || g.thumbnail) embed.setImage(g.image || g.thumbnail);
  const claims = Number(g.users) || 0;
  embed.setFooter({ text: claims > 0 ? `${claims.toLocaleString()} people have claimed this  ·  GamerPower` : 'GamerPower' });
  if (ends) embed.setTimestamp(ends * 1000);
  return embed;
}

// With many guilds a poll can outlast the interval; never run two at once.
let polling = false;

async function poll(client) {
  if (polling) return;
  polling = true;
  try {
    await runPoll(client);
  } finally {
    polling = false;
  }
}

async function runPoll(client) {
  let giveaways;
  try { giveaways = await fg.fetchGiveaways(); } catch (e) { console.warn('[freegames] fetch failed:', e.message); return; }

  const rows = getDb().prepare("SELECT guild_id FROM guild_config WHERE key = 'freegames'").all();
  for (const { guild_id: guildId } of rows) {
    const cfg = fg.getConfigFor(guildId);
    if (!cfg.enabled || !cfg.channelId) continue;
    const channel = await client.channels.fetch(cfg.channelId).catch(() => null);
    if (!channel || !channel.isTextBased?.()) continue;

    // oldest-first so a batch posts in a sensible order; cap per run
    const matches = giveaways
      .filter((g) => fg.matchesConfig(g, cfg) && !fg.alreadySeen(guildId, g.id))
      .slice(0, 8);

    for (const g of matches) {
      const ok = await channel.send({ embeds: [buildEmbed(g)] }).then(() => true).catch(() => false);
      if (ok) fg.markSeen(guildId, g.id);
    }
  }
  fg.pruneSeen();
}

function start(client) {
  setTimeout(() => poll(client).catch(() => {}), 20000);
  setInterval(() => poll(client).catch(() => {}), POLL_MS);
  console.log('[freegames] notifier started (every 15m)');
}

module.exports = { start, poll, buildEmbed };
