'use strict';

const Parser = require('rss-parser');
const { getDb } = require('../db');

const parser = new Parser({ timeout: 10000, headers: { 'User-Agent': 'Harmonix-Bot RSS' } });

function itemId(item) {
  return item.guid || item.id || item.link || item.title || '';
}
function itemTime(item) {
  const d = item.isoDate || item.pubDate;
  const t = d ? Date.parse(d) : NaN;
  return Number.isNaN(t) ? null : t;
}

async function fetchFeed(url) {
  return parser.parseURL(url);
}

function add(guildId, channelId, url, title, lastGuid, lastPublished) {
  const info = getDb()
    .prepare(
      `INSERT INTO feeds (guild_id, channel_id, url, title, last_guid, last_published, added_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(guildId, channelId, url, title || null, lastGuid || null, lastPublished || null, Date.now());
  return info.lastInsertRowid;
}

function remove(id, guildId) {
  return getDb().prepare('DELETE FROM feeds WHERE id = ? AND guild_id = ?').run(id, guildId).changes > 0;
}
function listForGuild(guildId) {
  return getDb().prepare('SELECT * FROM feeds WHERE guild_id = ? ORDER BY id ASC').all(guildId);
}
function all() {
  return getDb().prepare('SELECT * FROM feeds').all();
}
function updateState(id, lastGuid, lastPublished) {
  getDb().prepare('UPDATE feeds SET last_guid = ?, last_published = ? WHERE id = ?').run(lastGuid || null, lastPublished || null, id);
}

/**
 * Given a parsed feed and a stored feed row, return the list of *new* items
 * (oldest-first, capped) plus the new state to persist.
 */
function newItems(feed, row, cap = 5) {
  const items = feed.items || [];
  const fresh = [];
  for (const item of items) {
    if (row.last_guid && itemId(item) === row.last_guid) break;
    const t = itemTime(item);
    if (row.last_published && t && t <= row.last_published) break;
    fresh.push(item);
    if (fresh.length >= cap) break;
  }
  fresh.reverse(); // post oldest first
  const newest = items[0];
  const state = newest ? { lastGuid: itemId(newest), lastPublished: itemTime(newest) } : null;
  return { fresh, state };
}

module.exports = { parser, itemId, itemTime, fetchFeed, add, remove, listForGuild, all, updateState, newItems };
