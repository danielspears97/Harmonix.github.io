'use strict';

const { getDb } = require('../db');

function add(guildId, channelId, userId, text, remindAt) {
  const info = getDb()
    .prepare(
      `INSERT INTO reminders (guild_id, channel_id, user_id, text, remind_at, created_at, fired)
       VALUES (?, ?, ?, ?, ?, ?, 0)`
    )
    .run(guildId, channelId, userId, text, remindAt, Date.now());
  return info.lastInsertRowid;
}

function listForUser(guildId, userId) {
  return getDb()
    .prepare('SELECT * FROM reminders WHERE guild_id = ? AND user_id = ? AND fired = 0 ORDER BY remind_at ASC')
    .all(guildId, userId);
}

function cancel(id, userId) {
  const info = getDb().prepare('DELETE FROM reminders WHERE id = ? AND user_id = ? AND fired = 0').run(id, userId);
  return info.changes > 0;
}

function listDue(now = Date.now()) {
  return getDb().prepare('SELECT * FROM reminders WHERE fired = 0 AND remind_at <= ?').all(now);
}

function markFired(id) {
  getDb().prepare('UPDATE reminders SET fired = 1 WHERE id = ?').run(id);
}

module.exports = { add, listForUser, cancel, listDue, markFired };
