'use strict';

/**
 * Free-game notifier — data layer (GamerPower API, no key required).
 * Filters per guild by platform, content type (game / DLC-loot / early access),
 * and offer kind (keep vs timed free vs steep discount).
 */

const { getDb, getConfig, setConfig } = require('../db');

const API_URL = 'https://www.gamerpower.com/api/giveaways';
const UA = 'Harmonix-Discord-Bot (+https://harmonixbot.xyz)';

const ICON = (slug) => `https://img.icons8.com/color/240/${slug}.png`;

const PLATFORMS = [
  { key: 'steam', label: 'Steam', match: ['steam'], icon: ICON('steam') },
  { key: 'epic', label: 'Epic Games', match: ['epic'], icon: ICON('epic-games') },
  { key: 'gog', label: 'GOG', match: ['gog'], icon: ICON('gog-com') },
  { key: 'pc', label: 'Other PC / DRM-Free', match: ['pc', 'drm-free', 'itch', 'origin', 'ubisoft', 'battle.net'], icon: ICON('windows-11') },
  { key: 'playstation', label: 'PlayStation', match: ['playstation', 'ps4', 'ps5'], icon: ICON('play-station') },
  { key: 'xbox', label: 'Xbox', match: ['xbox'], icon: ICON('xbox') },
  { key: 'switch', label: 'Nintendo Switch', match: ['switch', 'nintendo'], icon: ICON('nintendo-switch') },
  { key: 'mobile', label: 'Mobile (iOS / Android)', match: ['android', 'ios'], icon: ICON('android-os') },
];
const PLATFORM_KEYS = PLATFORMS.map((p) => p.key);

// ── storefront detection ─────────────────────────────────────────
// GamerPower's `platforms` field is often just "PC"; the actual shop is named
// in the title ("(IndieGala)") or the claim URL. We match across all three and
// show that store's own logo. Majors use curated icons; the long tail falls
// back to the site's real favicon.
const FAVICON = (domain) => `https://www.google.com/s2/favicons?domain=${domain}&sz=128`;

const STORES = [
  { key: 'steam', label: 'Steam', icon: ICON('steam'), match: ['steam'] },
  { key: 'epic', label: 'Epic Games', icon: ICON('epic-games'), match: ['epic games', 'epicgames', 'epic'] },
  { key: 'gog', label: 'GOG', icon: ICON('gog-com'), match: ['gog'] },
  { key: 'itch', label: 'itch.io', icon: FAVICON('itch.io'), match: ['itch.io', 'itchio', 'itch'] },
  { key: 'indiegala', label: 'IndieGala', icon: FAVICON('indiegala.com'), match: ['indiegala'] },
  { key: 'fanatical', label: 'Fanatical', icon: FAVICON('fanatical.com'), match: ['fanatical'] },
  { key: 'humble', label: 'Humble Bundle', icon: FAVICON('humblebundle.com'), match: ['humble'] },
  { key: 'ubisoft', label: 'Ubisoft', icon: FAVICON('ubisoft.com'), match: ['ubisoft', 'uplay'] },
  { key: 'ea', label: 'EA', icon: FAVICON('ea.com'), match: ['origin', 'ea app', 'electronic arts'] },
  { key: 'battlenet', label: 'Battle.net', icon: FAVICON('battle.net'), match: ['battle.net', 'battlenet', 'blizzard'] },
  { key: 'prime', label: 'Prime Gaming', icon: FAVICON('amazon.com'), match: ['prime gaming', 'amazon'] },
  { key: 'alienware', label: 'Alienware Arena', icon: FAVICON('na.alienwarearena.com'), match: ['alienware'] },
  { key: 'stove', label: 'STOVE', icon: FAVICON('store.onstove.com'), match: ['stove'] },
  { key: 'rockstar', label: 'Rockstar', icon: FAVICON('rockstargames.com'), match: ['rockstar'] },
  { key: 'microsoft', label: 'Microsoft Store', icon: FAVICON('microsoft.com'), match: ['microsoft store', 'windows store'] },
  { key: 'playstation', label: 'PlayStation Store', icon: ICON('play-station'), match: ['playstation', 'ps4', 'ps5'] },
  { key: 'xbox', label: 'Xbox', icon: ICON('xbox'), match: ['xbox'] },
  { key: 'nintendo', label: 'Nintendo eShop', icon: ICON('nintendo-switch'), match: ['nintendo', 'switch'] },
  { key: 'googleplay', label: 'Google Play', icon: FAVICON('play.google.com'), match: ['google play', 'android'] },
  { key: 'appstore', label: 'App Store', icon: FAVICON('apps.apple.com'), match: ['app store', 'ios'] },
  { key: 'drmfree', label: 'DRM-Free', icon: ICON('windows-11'), match: ['drm-free'] },
];
// Generic buckets must lose to real storefronts when both appear.
STORES.sort((a, b) => {
  const generic = ['drmfree', 'microsoft', 'googleplay', 'appstore'];
  return (generic.indexOf(a.key) === -1 ? 0 : 1) - (generic.indexOf(b.key) === -1 ? 0 : 1);
});

/** Word-boundary match so "Deadswitch" doesn't count as "switch". */
function mentions(haystack, needle) {
  const esc = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^a-z0-9])${esc}([^a-z0-9]|$)`).test(haystack);
}

/** Which storefront is this giveaway actually from? Checks the title first
 *  (most reliable — "(IndieGala)"), then the platform field, the claim URL,
 *  and finally the description. */
function detectStore(g) {
  const zones = [g.title, g.platforms, g.open_giveaway_url, g.description]
    .map((z) => String(z || '').toLowerCase());
  for (const zone of zones) {
    for (const st of STORES) {
      if (st.match.some((m) => mentions(zone, m))) return st;
    }
  }
  return null;
}

const DEFAULTS = {
  enabled: false,
  channelId: null,
  platforms: PLATFORM_KEYS.slice(),
  keep: true,
  timed: false,
  discounts: false,
  games: true,
  dlc: false,
  earlyaccess: true,
};

function getConfigFor(guildId) {
  const c = getConfig(guildId, 'freegames', {}) || {};
  const b = (v, d) => (v === undefined ? d : !!v);
  return {
    enabled: !!c.enabled,
    channelId: c.channelId || null,
    platforms: Array.isArray(c.platforms) ? c.platforms.filter((p) => PLATFORM_KEYS.includes(p)) : DEFAULTS.platforms.slice(),
    keep: b(c.keep, DEFAULTS.keep),
    timed: b(c.timed, DEFAULTS.timed),
    discounts: b(c.discounts, DEFAULTS.discounts),
    games: b(c.games, DEFAULTS.games),
    dlc: b(c.dlc, DEFAULTS.dlc),
    earlyaccess: b(c.earlyaccess, DEFAULTS.earlyaccess),
  };
}
function setConfigFor(guildId, patch) {
  const next = { ...getConfigFor(guildId), ...patch };
  setConfig(guildId, 'freegames', next);
  return getConfigFor(guildId);
}

function contentType(g) {
  const t = String(g.type || '').toLowerCase();
  if (t.includes('dlc') || t.includes('loot') || t.includes('pack')) return 'dlc';
  if (t.includes('early')) return 'earlyaccess';
  return 'games';
}

function offerKind(g) {
  const worth = parseFloat(String(g.worth || '').replace(/[^0-9.]/g, '')) || 0;
  const text = `${g.title || ''} ${g.description || ''}`.toLowerCase();
  if (['free to play', 'free weekend', 'play for free', 'trial', 'free access', 'weekend'].some((t) => text.includes(t))) return 'timed';
  if (worth === 0 || /giveaway|keep|claim|free game|free dlc/.test(text)) return 'keep';
  return 'discount';
}

function platformKeysFor(g) {
  const raw = String(g.platforms || '').toLowerCase();
  return PLATFORMS.filter((p) => p.match.some((m) => raw.includes(m))).map((p) => p.key);
}
function primaryPlatform(g) {
  const keys = platformKeysFor(g);
  return PLATFORMS.find((p) => p.key === keys[0]) || null;
}

function matchesConfig(g, cfg) {
  const type = contentType(g);
  if (type === 'dlc' && !cfg.dlc) return false;
  if (type === 'games' && !cfg.games) return false;
  if (type === 'earlyaccess' && !cfg.earlyaccess) return false;
  const kind = offerKind(g);
  if (kind === 'keep' && !cfg.keep) return false;
  if (kind === 'timed' && !cfg.timed) return false;
  if (kind === 'discount' && !cfg.discounts) return false;
  const gKeys = platformKeysFor(g);
  if (!gKeys.length) return false;
  return gKeys.some((k) => cfg.platforms.includes(k));
}

let _cache = { at: 0, data: [] };
async function fetchGiveaways(force = false) {
  const now = Date.now();
  if (!force && now - _cache.at < 5 * 60 * 1000 && _cache.data.length) return _cache.data;
  const res = await fetch(API_URL, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error(`GamerPower HTTP ${res.status}`);
  const data = await res.json();
  _cache = { at: now, data: Array.isArray(data) ? data : [] };
  return _cache.data;
}

function alreadySeen(guildId, id) {
  return !!getDb().prepare('SELECT 1 FROM freegame_seen WHERE guild_id = ? AND giveaway_id = ?').get(guildId, id);
}
function markSeen(guildId, id) {
  getDb().prepare('INSERT OR IGNORE INTO freegame_seen (guild_id, giveaway_id, seen_at) VALUES (?, ?, ?)').run(guildId, id, Date.now());
}
function pruneSeen(days = 45) {
  getDb().prepare('DELETE FROM freegame_seen WHERE seen_at < ?').run(Date.now() - days * 86400000);
}

module.exports = {
  PLATFORMS, PLATFORM_KEYS, DEFAULTS,
  getConfigFor, setConfigFor,
  contentType, offerKind, platformKeysFor, primaryPlatform, matchesConfig,
  STORES, detectStore,
  fetchGiveaways, alreadySeen, markSeen, pruneSeen,
};
