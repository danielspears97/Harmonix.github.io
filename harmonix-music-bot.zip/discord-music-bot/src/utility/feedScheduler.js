'use strict';

const { EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const feeds = require('./feeds');

const POLL_MS = 5 * 60 * 1000; // 5 minutes

function itemEmbed(feed, item) {
  const embed = new EmbedBuilder()
    .setColor(config.brand.color)
    .setTitle((item.title || 'New item').slice(0, 250))
    .setAuthor({ name: (feed.title || 'RSS').slice(0, 250) });
  if (item.link) embed.setURL(item.link);
  const snippet = item.contentSnippet || item.summary || '';
  if (snippet) embed.setDescription(snippet.slice(0, 400));
  const t = feeds.itemTime(item);
  if (t) embed.setTimestamp(new Date(t));
  return embed;
}

async function pollFeed(client, row) {
  let parsed;
  try {
    parsed = await feeds.fetchFeed(row.url);
  } catch (err) {
    console.error(`[feeds] fetch failed (${row.url}):`, err.message);
    return;
  }
  const { fresh, state } = feeds.newItems(parsed, row);
  if (fresh.length) {
    const channel = await client.channels.fetch(row.channel_id).catch(() => null);
    if (channel && channel.isTextBased()) {
      for (const item of fresh) {
        await channel.send({ embeds: [itemEmbed(parsed, item)] }).catch(() => {});
      }
    }
  }
  if (state) feeds.updateState(row.id, state.lastGuid, state.lastPublished);
}

async function poll(client) {
  for (const row of feeds.all()) {
    await pollFeed(client, row);
  }
}

function start(client) {
  setTimeout(() => poll(client), 15000); // first poll shortly after startup
  setInterval(() => poll(client), POLL_MS);
  console.log('[feeds] scheduler started');
}

module.exports = { start, poll, pollFeed, itemEmbed };
