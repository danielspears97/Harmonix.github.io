'use strict';

const reminders = require('./reminders');

async function fire(client, row) {
  reminders.markFired(row.id);
  const content = `⏰ You asked me to remind you: **${row.text || '(no note)'}**`;
  // DM the user directly.
  const user = await client.users.fetch(row.user_id).catch(() => null);
  if (user) {
    const dm = await user.send(content).catch(() => null);
    if (dm) return;
  }
  // Fallback: post in the original channel if the DM couldn't be delivered.
  const channel = await client.channels.fetch(row.channel_id).catch(() => null);
  if (channel && channel.isTextBased()) {
    await channel.send({ content: `⏰ <@${row.user_id}>, ${content.replace('⏰ ', '')}`, allowedMentions: { users: [row.user_id] } }).catch(() => {});
  }
}

async function check(client) {
  try {
    for (const row of reminders.listDue()) await fire(client, row);
  } catch (err) {
    console.error('[reminders] scheduler error:', err.message);
  }
}

function start(client) {
  check(client);
  setInterval(() => check(client), 15000);
  console.log('[reminders] scheduler started');
}

module.exports = { start, fire, check };
