'use strict';

const { config } = require('../config');
const { notify } = require('./utils/bus');
const { getGuild, setGuild } = require('./utils/persistence');
const { sourceName, safeUrl } = require('./utils/format');

const VOLUME_MAX = 150;

/** Get the active player for a guild (or undefined). */
function getPlayer(client, guildId) {
  return client.lavalink.getPlayer(guildId);
}

/** A serialisable track snapshot for embeds / dashboard. */
function trackSnapshot(track) {
  if (!track) return null;
  const i = track.info || {};
  const rawArt = i.artworkUrl || track.pluginInfo?.artworkUrl || track.plugin?.artworkUrl || null;
  return {
    title: i.title || 'Unknown',
    author: i.author || 'Unknown',
    uri: safeUrl(i.uri),
    duration: i.duration ?? 0,
    isStream: !!i.isStream,
    artworkUrl: safeUrl(rawArt),
    sourceName: sourceName(track),
    requester: track.requester
      ? {
          id: track.requester.id,
          username: track.requester.username || track.requester.global_name || 'Unknown',
          avatar: track.requester.avatar || null,
        }
      : null,
  };
}

/** Build a full, serialisable snapshot of a guild's player state. */
function getState(client, guildId) {
  const settings = getGuild(guildId);
  const player = getPlayer(client, guildId);
  const guild = client.guilds.cache.get(guildId);

  const base = {
    guildId,
    guildName: guild?.name || guildId,
    guildIcon: guild?.iconURL?.({ extension: 'png', size: 128 }) || null,
    connected: false,
    playing: false,
    paused: false,
    volume: settings.volume ?? config.defaultVolume,
    repeatMode: 'off',
    autoplay: !!settings.autoplay,
    twentyFourSeven: !!settings.twentyFourSeven,
    current: null,
    position: 0,
    queue: [],
    previousCount: 0,
  };

  if (!player) return base;

  return {
    ...base,
    connected: !!player.connected,
    playing: !!player.playing,
    paused: !!player.paused,
    volume: player.volume ?? base.volume,
    repeatMode: player.repeatMode || 'off',
    current: trackSnapshot(player.queue.current),
    position: player.position || 0,
    queue: (player.queue.tracks || []).slice(0, 50).map(trackSnapshot),
    previousCount: (player.queue.previous || []).length,
  };
}

/** Ensure a player exists & is connected to the given voice channel. */
async function ensurePlayer(client, { guildId, voiceChannelId, textChannelId }) {
  let player = getPlayer(client, guildId);
  const settings = getGuild(guildId);
  if (!player) {
    player = client.lavalink.createPlayer({
      guildId,
      voiceChannelId,
      textChannelId,
      selfDeaf: true,
      selfMute: false,
      volume: settings.volume ?? config.defaultVolume,
    });
  }
  if (!player.connected) await player.connect();
  // Keep the bound text channel fresh.
  if (textChannelId) player.textChannelId = textChannelId;
  return player;
}

/**
 * Search + queue a query. Returns a result object describing what happened.
 * requester should be a plain { id, username, avatar } object.
 */
async function play(client, { guildId, voiceChannelId, textChannelId, query, requester, next = false }) {
  const player = await ensurePlayer(client, { guildId, voiceChannelId, textChannelId });
  player.set('stopped', false); // a fresh request reactivates autoplay/top-up
  player.set('lastRequester', requester);

  const res = await player.search({ query }, requester);
  if (!res || !res.tracks || res.tracks.length === 0) {
    return { ok: false, reason: 'no-results' };
  }

  const limits = require('./server/guildSettings').getMusicSettings(guildId);
  const current = player.queue.current;
  const tracks = player.queue.tracks || [];

  let added;
  if (res.loadType === 'playlist') {
    let toAdd = res.tracks;
    if (limits.maxQueue) {
      const room = Math.max(0, limits.maxQueue - tracks.length);
      if (room <= 0) return { ok: false, reason: 'queue-full', limit: limits.maxQueue };
      if (toAdd.length > room) toAdd = toAdd.slice(0, room);
    }
    await player.queue.add(toAdd);
    added = { type: 'playlist', name: res.playlist?.name || 'Playlist', count: toAdd.length, trimmed: toAdd.length < res.tracks.length };
  } else {
    const t = res.tracks[0];
    const info = t.info || {};
    const durSec = Math.round((info.duration || 0) / 1000);
    if (limits.maxSongSec && !info.isStream && durSec > limits.maxSongSec) {
      return { ok: false, reason: 'too-long', limit: limits.maxSongSec, durSec };
    }
    if (limits.maxQueue && tracks.length >= limits.maxQueue) {
      return { ok: false, reason: 'queue-full', limit: limits.maxQueue };
    }
    if (limits.maxPerUser && requester) {
      const mine = tracks.filter((x) => x.requester?.id === requester.id).length + (current?.requester?.id === requester.id ? 1 : 0);
      if (mine >= limits.maxPerUser) return { ok: false, reason: 'user-limit', limit: limits.maxPerUser };
    }
    const duplicate = (current && current.info?.uri && current.info.uri === info.uri) || tracks.some((x) => x.info?.uri && x.info.uri === info.uri);
    let etaMs = 0;
    if (current && !current.info?.isStream) etaMs += Math.max(0, (current.info?.duration || 0) - (player.position || 0));
    let position;
    if (next) {
      await player.queue.add(t, 0);
      position = current ? 2 : 1; // plays right after the current track
    } else {
      for (const x of tracks) if (!x.info?.isStream) etaMs += (x.info?.duration || 0);
      position = tracks.length + (current ? 1 : 0);
      await player.queue.add(t);
    }
    added = { type: 'track', track: trackSnapshot(t), duplicate, etaMs, position, next: !!next };
  }

  if (!player.playing && !player.paused) await player.play();
  notify(guildId);
  return { ok: true, added };
}

async function pause(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player || !player.queue.current) return { ok: false, reason: 'nothing-playing' };
  if (player.paused) return { ok: true, state: 'already-paused' };
  await player.pause();
  notify(guildId);
  return { ok: true, state: 'paused' };
}

async function resume(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player || !player.queue.current) return { ok: false, reason: 'nothing-playing' };
  if (!player.paused) return { ok: true, state: 'already-playing' };
  await player.resume();
  notify(guildId);
  return { ok: true, state: 'playing' };
}

async function togglePause(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player || !player.queue.current) return { ok: false, reason: 'nothing-playing' };
  if (player.paused) return resume(client, guildId);
  return pause(client, guildId);
}

async function skip(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player || !player.queue.current) return { ok: false, reason: 'nothing-playing' };
  const hasNext = player.queue.tracks.length > 0;
  try {
    await player.skip();
  } catch {
    // No next track to skip to; stop instead.
    await player.stopPlaying(false, false);
  }
  notify(guildId);
  return { ok: true, hadNext: hasNext };
}

async function previous(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'nothing-playing' };
  const prev = (player.queue.previous || [])[0];
  if (!prev) return { ok: false, reason: 'no-previous' };
  // Re-queue current at the front so it plays again after the previous track.
  if (player.queue.current) await player.queue.add(player.queue.current, 0);
  await player.play({ clientTrack: prev });
  notify(guildId);
  return { ok: true };
}

async function stop(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'nothing-playing' };
  player.set('stopped', true); // block autoplay refills (queueEnd / top-up)
  await player.stopPlaying(true, false); // stop current + clear queue, no autoplay
  const settings = getGuild(guildId);
  const stayConnected = settings.twentyFourSeven;
  if (!stayConnected) {
    await player.destroy('stopped').catch(() => {}); // leave voice
  }
  notify(guildId);
  return { ok: true, disconnected: !stayConnected };
}

async function disconnect(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'not-connected' };
  await player.destroy();
  notify(guildId);
  return { ok: true };
}

async function setVolume(client, guildId, volume) {
  const v = Math.min(VOLUME_MAX, Math.max(0, Math.round(volume)));
  const player = getPlayer(client, guildId);
  setGuild(guildId, { volume: v });
  if (player) await player.setVolume(v);
  notify(guildId);
  return { ok: true, volume: v };
}

async function volumeStep(client, guildId, delta) {
  const player = getPlayer(client, guildId);
  const settings = getGuild(guildId);
  const cur = player?.volume ?? settings.volume ?? config.defaultVolume;
  return setVolume(client, guildId, cur + delta);
}

async function cycleLoop(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'nothing-playing' };
  const order = ['off', 'track', 'queue'];
  const next = order[(order.indexOf(player.repeatMode || 'off') + 1) % order.length];
  await player.setRepeatMode(next);
  notify(guildId);
  return { ok: true, mode: next };
}

async function setLoop(client, guildId, mode) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'nothing-playing' };
  if (!['off', 'track', 'queue'].includes(mode)) return { ok: false, reason: 'bad-mode' };
  await player.setRepeatMode(mode);
  notify(guildId);
  return { ok: true, mode };
}

async function shuffle(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player || player.queue.tracks.length < 2) return { ok: false, reason: 'not-enough' };
  await player.queue.shuffle();
  notify(guildId);
  return { ok: true };
}

async function seek(client, guildId, positionMs) {
  const player = getPlayer(client, guildId);
  if (!player || !player.queue.current) return { ok: false, reason: 'nothing-playing' };
  if (player.queue.current.info.isStream) return { ok: false, reason: 'stream' };
  const pos = Math.min(player.queue.current.info.duration, Math.max(0, positionMs));
  await player.seek(pos);
  notify(guildId);
  return { ok: true, position: pos };
}

function toggleAutoplay(client, guildId) {
  const settings = getGuild(guildId);
  const next = !settings.autoplay;
  setGuild(guildId, { autoplay: next });
  const player = getPlayer(client, guildId);
  if (player) player.set('autoplay', next);
  notify(guildId);
  return { ok: true, autoplay: next };
}

function toggle247(client, guildId) {
  const settings = getGuild(guildId);
  const next = !settings.twentyFourSeven;
  setGuild(guildId, { twentyFourSeven: next });
  notify(guildId);
  return { ok: true, twentyFourSeven: next };
}

// NOTE: lavalink-client's queue.splice() is ASYNC and returns the track itself
// when one is removed (not an array). It was being used as if it were
// Array.prototype.splice, so `const [x] = queue.splice(...)` threw on the
// returned Promise — after the removal had already happened.
async function removeAt(client, guildId, index) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'nothing-playing' };
  if (index < 0 || index >= player.queue.tracks.length) return { ok: false, reason: 'bad-index' };
  const spliced = await player.queue.splice(index, 1);
  const removed = Array.isArray(spliced) ? spliced[0] : spliced;
  notify(guildId);
  return { ok: true, removed: removed ? trackSnapshot(removed) : null };
}

async function clearQueue(client, guildId) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'nothing-playing' };
  const count = player.queue.tracks.length;
  if (count) await player.queue.splice(0, count);
  notify(guildId);
  return { ok: true, count };
}

/** Move a queued track from one position to another (0-based, upcoming queue). */
async function move(client, guildId, from, to) {
  const player = getPlayer(client, guildId);
  if (!player) return { ok: false, reason: 'nothing-playing' };
  const len = player.queue.tracks.length;
  if (from < 0 || from >= len || to < 0 || to >= len) return { ok: false, reason: 'bad-index' };
  if (from === to) return { ok: true };

  const spliced = await player.queue.splice(from, 1);
  const track = Array.isArray(spliced) ? spliced[0] : spliced;
  if (!track) { notify(guildId); return { ok: false, reason: 'bad-index' }; }

  // Re-insert at the destination. Removing first shifts everything after it
  // left, so inserting at `to` lands the track at index `to` either direction.
  await player.queue.splice(to, 0, track);
  notify(guildId);
  return { ok: true, moved: trackSnapshot(track) };
}

function currentRequesterId(client, guildId) {
  const player = getPlayer(client, guildId);
  return player?.queue?.current?.requester?.id || null;
}

module.exports = {
  getPlayer,
  getState,
  currentRequesterId,
  ensurePlayer,
  trackSnapshot,
  play,
  pause,
  resume,
  togglePause,
  skip,
  previous,
  stop,
  disconnect,
  setVolume,
  volumeStep,
  cycleLoop,
  setLoop,
  shuffle,
  seek,
  toggleAutoplay,
  toggle247,
  removeAt,
  clearQueue,
  move,
  VOLUME_MAX,
};
