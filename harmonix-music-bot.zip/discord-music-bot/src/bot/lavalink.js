'use strict';

const { LavalinkManager } = require('lavalink-client');
const { config } = require('../../config');

function createLavalink(client) {
  const lavalink = new LavalinkManager({
    nodes: [
      {
        authorization: config.lavalink.authorization,
        host: config.lavalink.host,
        port: config.lavalink.port,
        secure: config.lavalink.secure,
        id: config.lavalink.id,
        retryAmount: 10,
        retryDelay: 5000,
      },
    ],
    sendToShard: (guildId, payload) =>
      client.guilds.cache.get(guildId)?.shard?.send(payload),
    client: {
      id: config.clientId,
      username: config.brand.name,
    },
    autoSkip: true,
    playerOptions: {
      defaultSearchPlatform: 'ytmsearch',
      clientBasedPositionUpdateInterval: 100,
      onDisconnect: {
        autoReconnect: true,
        destroyPlayer: false,
      },
      onEmptyQueue: {
        // We manage leaving manually (24/7 aware) in voiceStateUpdate + queueEnd.
        destroyAfterMs: undefined,
      },
    },
  });

  // Node lifecycle logging
  lavalink.nodeManager
    .on('connect', (node) => console.log(`[lavalink] node "${node.id}" connected`))
    .on('reconnecting', (node) =>
      console.warn(`[lavalink] node "${node.id}" reconnecting…`)
    )
    .on('disconnect', (node, reason) =>
      console.warn(`[lavalink] node "${node.id}" disconnected: ${reason?.reason || ''}`)
    )
    .on('error', (node, error) =>
      console.error(`[lavalink] node "${node.id}" error:`, error?.message || error)
    );

  return lavalink;
}

module.exports = { createLavalink };
