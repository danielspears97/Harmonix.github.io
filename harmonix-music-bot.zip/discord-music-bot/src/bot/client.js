'use strict';

const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');

function createClient() {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildVoiceStates,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent, // for the "type a song in the panel channel" request feature
      GatewayIntentBits.GuildMembers, // for welcome/goodbye + autorole (privileged — enable in the Dev Portal)
      GatewayIntentBits.GuildMessageReactions, // for the starboard
      GatewayIntentBits.GuildModeration, // for ban/unban logging
    ],
    partials: [Partials.Channel, Partials.Message, Partials.Reaction], // reactions on uncached messages arrive as partials
  });

  client.commands = new Collection();
  return client;
}

module.exports = { createClient };
