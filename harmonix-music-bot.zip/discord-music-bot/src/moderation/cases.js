'use strict';

/**
 * Moderation case store. Every mod action becomes a numbered case, scoped per
 * guild (Case #1, #2, … within each guild). Backed by the mod_cases table.
 */

const { getDb } = require('../db');

/**
 * Record a new case and return the stored row (including its case_number).
 * The next case number is computed and inserted inside a single transaction
 * so concurrent actions can't collide on the same number.
 */
function addCase(guildId, data) {
  const db = getDb();
  const tx = db.transaction((d) => {
    const row = db
      .prepare('SELECT COALESCE(MAX(case_number), 0) AS max FROM mod_cases WHERE guild_id = ?')
      .get(guildId);
    const caseNumber = row.max + 1;
    const info = db
      .prepare(
        `INSERT INTO mod_cases
           (guild_id, case_number, action, target_id, target_tag,
            moderator_id, moderator_tag, reason, duration_ms, created_at)
         VALUES (@guild_id, @case_number, @action, @target_id, @target_tag,
                 @moderator_id, @moderator_tag, @reason, @duration_ms, @created_at)`
      )
      .run({
        guild_id: guildId,
        case_number: caseNumber,
        action: d.action,
        target_id: d.targetId,
        target_tag: d.targetTag ?? null,
        moderator_id: d.moderatorId,
        moderator_tag: d.moderatorTag ?? null,
        reason: d.reason ?? null,
        duration_ms: d.durationMs ?? null,
        created_at: Date.now(),
      });
    return db.prepare('SELECT * FROM mod_cases WHERE id = ?').get(info.lastInsertRowid);
  });
  return tx(data);
}

function getCase(guildId, caseNumber) {
  return getDb()
    .prepare('SELECT * FROM mod_cases WHERE guild_id = ? AND case_number = ?')
    .get(guildId, caseNumber);
}

function setReason(guildId, caseNumber, reason) {
  const info = getDb()
    .prepare('UPDATE mod_cases SET reason = ? WHERE guild_id = ? AND case_number = ?')
    .run(reason, guildId, caseNumber);
  return info.changes > 0;
}

/** All cases for a target, newest first. Optionally filter by action. */
function getHistory(guildId, targetId, { action = null, limit = 25 } = {}) {
  if (action) {
    return getDb()
      .prepare(
        `SELECT * FROM mod_cases WHERE guild_id = ? AND target_id = ? AND action = ?
         ORDER BY case_number DESC LIMIT ?`
      )
      .all(guildId, targetId, action, limit);
  }
  return getDb()
    .prepare(
      `SELECT * FROM mod_cases WHERE guild_id = ? AND target_id = ?
       ORDER BY case_number DESC LIMIT ?`
    )
    .all(guildId, targetId, limit);
}

function countActions(guildId, targetId, action) {
  const row = getDb()
    .prepare('SELECT COUNT(*) AS n FROM mod_cases WHERE guild_id = ? AND target_id = ? AND action = ?')
    .get(guildId, targetId, action);
  return row.n;
}

function listRecent(guildId, { limit = 25 } = {}) {
  return getDb()
    .prepare('SELECT * FROM mod_cases WHERE guild_id = ? ORDER BY case_number DESC LIMIT ?')
    .all(guildId, limit);
}

module.exports = { addCase, getCase, setReason, getHistory, countActions, listRecent };
