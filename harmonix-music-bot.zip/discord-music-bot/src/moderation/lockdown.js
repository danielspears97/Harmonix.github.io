'use strict';

/**
 * Channel lockdown.
 *
 * Two things a naive lockdown gets wrong, both of which let members keep
 * talking:
 *
 *  1. Only text channels are touched, so voice is wide open. We deny Connect
 *     (and Speak) on voice/stage channels too.
 *
 *  2. Discord resolves an explicit ALLOW on a *role* overwrite ahead of a DENY
 *     on @everyone. Denying @everyone alone does nothing for anybody holding a
 *     role that has a green check for Send Messages / Connect in that channel.
 *     We therefore also clear those role-level allows while the lock is on.
 *
 * Everything we change is recorded first, so unlocking restores the channel
 * exactly as it was rather than blanket-wiping overwrites.
 */

const { ChannelType, PermissionFlagsBits: P } = require('discord.js');
const { getDb } = require('../db');

const TEXT_TYPES = [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum, ChannelType.GuildMedia].filter((t) => t !== undefined);
const VOICE_TYPES = [ChannelType.GuildVoice, ChannelType.GuildStageVoice];
const LOCKABLE = [...TEXT_TYPES, ...VOICE_TYPES];

const TEXT_PERMS = ['SendMessages', 'SendMessagesInThreads', 'CreatePublicThreads', 'CreatePrivateThreads', 'AddReactions'];
const VOICE_PERMS = ['Connect', 'Speak', 'SendMessages'];

function isLockable(ch) {
  return !!ch && LOCKABLE.includes(ch.type);
}
function permsFor(ch) {
  return VOICE_TYPES.includes(ch.type) ? VOICE_PERMS : TEXT_PERMS;
}

// ── stored state ─────────────────────────────────────────────────
function saveState(guildId, channelId, prev) {
  getDb().prepare(
    'INSERT OR REPLACE INTO channel_locks (guild_id, channel_id, prev, locked_at) VALUES (?, ?, ?, ?)'
  ).run(guildId, channelId, JSON.stringify(prev), Date.now());
}
function loadState(guildId, channelId) {
  const row = getDb().prepare('SELECT prev FROM channel_locks WHERE guild_id = ? AND channel_id = ?').get(guildId, channelId);
  if (!row) return null;
  try { return JSON.parse(row.prev); } catch { return null; }
}
function clearState(guildId, channelId) {
  getDb().prepare('DELETE FROM channel_locks WHERE guild_id = ? AND channel_id = ?').run(guildId, channelId);
}
function lockedChannels(guildId) {
  return getDb().prepare('SELECT channel_id FROM channel_locks WHERE guild_id = ?').all(guildId).map((r) => r.channel_id);
}

/** Read the current allow/deny state of `perms` for one overwrite. */
function snapshot(overwrite, perms) {
  const out = {};
  for (const p of perms) {
    if (overwrite.allow.has(P[p])) out[p] = true;
    else if (overwrite.deny.has(P[p])) out[p] = false;
    else out[p] = null;
  }
  return out;
}

/**
 * Lock one channel.
 * @returns {Promise<{ok: boolean, reason?: string, clearedRoles: number}>}
 */
async function lockChannel(channel, { reason, exemptRoleIds = [] } = {}) {
  if (!isLockable(channel)) return { ok: false, reason: 'type', clearedRoles: 0 };
  const guild = channel.guild;
  const me = guild.members.me;
  if (!channel.permissionsFor(me)?.has(P.ManageRoles)) return { ok: false, reason: 'perms', clearedRoles: 0 };

  const perms = permsFor(channel);
  const everyoneId = guild.roles.everyone.id;
  const prev = { everyone: null, roles: {} };

  // 1. remember and deny @everyone
  const everyoneOw = channel.permissionOverwrites.cache.get(everyoneId);
  prev.everyone = everyoneOw ? snapshot(everyoneOw, perms) : Object.fromEntries(perms.map((p) => [p, null]));

  const denyAll = Object.fromEntries(perms.map((p) => [p, false]));
  await channel.permissionOverwrites.edit(everyoneId, denyAll, { reason });

  // 2. clear role-level allows that would otherwise win over that deny
  let clearedRoles = 0;
  for (const ow of channel.permissionOverwrites.cache.values()) {
    if (ow.id === everyoneId) continue;
    if (ow.type !== 0) continue; // roles only; leave per-member overwrites alone
    if (exemptRoleIds.includes(ow.id)) continue;
    const role = guild.roles.cache.get(ow.id);
    if (!role) continue;
    if (role.permissions.has(P.Administrator)) continue; // admins bypass regardless
    if (me.roles.cache.has(ow.id)) continue;             // don't lock the bot out

    const allowed = perms.filter((p) => ow.allow.has(P[p]));
    if (!allowed.length) continue;

    prev.roles[ow.id] = snapshot(ow, perms);
    // set those allows back to "inherit" so @everyone's deny takes effect
    await channel.permissionOverwrites.edit(ow.id, Object.fromEntries(allowed.map((p) => [p, null])), { reason });
    clearedRoles += 1;
  }

  saveState(guild.id, channel.id, prev);
  return { ok: true, clearedRoles };
}

/** Unlock one channel, restoring exactly what was there before. */
async function unlockChannel(channel, { reason } = {}) {
  if (!isLockable(channel)) return { ok: false, reason: 'type' };
  const guild = channel.guild;
  const me = guild.members.me;
  if (!channel.permissionsFor(me)?.has(P.ManageRoles)) return { ok: false, reason: 'perms' };

  const perms = permsFor(channel);
  const everyoneId = guild.roles.everyone.id;
  const prev = loadState(guild.id, channel.id);

  if (prev) {
    await channel.permissionOverwrites.edit(everyoneId, prev.everyone, { reason });
    for (const [roleId, vals] of Object.entries(prev.roles || {})) {
      if (guild.roles.cache.has(roleId)) {
        await channel.permissionOverwrites.edit(roleId, vals, { reason }).catch(() => {});
      }
    }
    clearState(guild.id, channel.id);
  } else {
    // locked before we tracked state (or by hand) — just clear the denies
    await channel.permissionOverwrites.edit(everyoneId, Object.fromEntries(perms.map((p) => [p, null])), { reason });
  }
  return { ok: true };
}

module.exports = {
  LOCKABLE, TEXT_TYPES, VOICE_TYPES, TEXT_PERMS, VOICE_PERMS,
  isLockable, permsFor, lockChannel, unlockChannel, lockedChannels, loadState, saveState, clearState, snapshot,
};
