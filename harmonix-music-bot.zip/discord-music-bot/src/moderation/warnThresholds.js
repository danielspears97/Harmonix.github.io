'use strict';

const { getConfig, setConfig } = require('../db');
const modlog = require('./modlog');
const { userTag } = require('../utils/format');
const { humanizeDuration } = require('../utils/duration');

function list(guildId) {
  return getConfig(guildId, 'warn_thresholds', []) || [];
}
function save(guildId, arr) {
  setConfig(guildId, 'warn_thresholds', arr);
}
function add(guildId, count, action, durationMin = 0) {
  const arr = list(guildId).filter((t) => t.count !== count);
  arr.push({ count, action, durationMin });
  arr.sort((a, b) => a.count - b.count);
  save(guildId, arr);
  return arr;
}
function remove(guildId, count) {
  const arr = list(guildId).filter((t) => t.count !== count);
  save(guildId, arr);
  return arr;
}
/** A rule fires when the warn total lands exactly on its count. */
function matchFor(guildId, count) {
  return list(guildId).find((t) => t.count === count) || null;
}

/** Apply an auto-escalation rule; returns a human note (or null). */
async function apply(client, guild, target, member, rule) {
  const reason = `Auto-action: reached ${rule.count} warnings`;
  try {
    if (rule.action === 'timeout' && member) {
      const ms = (rule.durationMin || 10) * 60 * 1000;
      await member.timeout(ms, reason);
      await modlog.record(client, guild.id, { action: 'timeout', targetId: target.id, targetTag: userTag(target), moderatorId: client.user.id, moderatorTag: 'Auto-mod', reason, duration_ms: ms });
      return `⏳ Auto-timeout for ${humanizeDuration(ms)} (hit ${rule.count} warnings).`;
    }
    if (rule.action === 'kick' && member) {
      await member.kick(reason);
      await modlog.record(client, guild.id, { action: 'kick', targetId: target.id, targetTag: userTag(target), moderatorId: client.user.id, moderatorTag: 'Auto-mod', reason });
      return `👢 Auto-kicked (hit ${rule.count} warnings).`;
    }
    if (rule.action === 'ban') {
      await guild.members.ban(target.id, { reason });
      await modlog.record(client, guild.id, { action: 'ban', targetId: target.id, targetTag: userTag(target), moderatorId: client.user.id, moderatorTag: 'Auto-mod', reason });
      return `🔨 Auto-banned (hit ${rule.count} warnings).`;
    }
  } catch (err) {
    return `(auto-action failed: ${err.message})`;
  }
  return null;
}

module.exports = { list, add, remove, matchFor, apply };
