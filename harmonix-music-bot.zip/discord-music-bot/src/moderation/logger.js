'use strict';

const { getConfig, setConfig } = require('../db');
const logFeed = require('./logFeed');

const TYPES = ['messageDelete', 'messageEdit', 'memberJoin', 'memberLeave', 'memberUpdate', 'voice', 'bans'];
const DEFAULT_TYPES = Object.fromEntries(TYPES.map((t) => [t, true]));

function getSettings(guildId) {
  const s = getConfig(guildId, 'logging', null) || {};
  return { channelId: s.channelId || null, types: { ...DEFAULT_TYPES, ...(s.types || {}) } };
}
function saveSettings(guildId, settings) {
  setConfig(guildId, 'logging', { channelId: settings.channelId || null, types: { ...DEFAULT_TYPES, ...(settings.types || {}) } });
  return getSettings(guildId);
}
function setChannel(guildId, channelId) {
  const s = getSettings(guildId);
  s.channelId = channelId || null;
  return saveSettings(guildId, s);
}
function setType(guildId, type, on) {
  const s = getSettings(guildId);
  if (TYPES.includes(type)) s.types[type] = !!on;
  return saveSettings(guildId, s);
}
function isEnabled(guildId, type) {
  const s = getSettings(guildId);
  return !!s.channelId && s.types[type] !== false;
}

async function send(client, guildId, embed) {
  // Mirror to the dashboard live feed regardless of channel delivery.
  try {
    const d = embed.data || {};
    logFeed.push(guildId, { text: d.description || (d.title || 'Event'), color: d.color || null, at: Date.now() });
  } catch { /* ignore */ }
  const s = getSettings(guildId);
  if (!s.channelId) return;
  const channel = await client.channels.fetch(s.channelId).catch(() => null);
  if (channel && channel.isTextBased()) await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { TYPES, DEFAULT_TYPES, getSettings, saveSettings, setChannel, setType, isEnabled, send };
