'use strict';

const { getConfig, setConfig } = require('../db');
const logFeed = require('./logFeed');

const TYPES = ['messageDelete', 'messageEdit', 'memberJoin', 'memberLeave', 'memberUpdate', 'voice', 'bans'];
const DEFAULT_TYPES = Object.fromEntries(TYPES.map((t) => [t, true]));

function getSettings(guildId) {
  const s = getConfig(guildId, 'logging', null) || {};
  return {
    channelId: s.channelId || null,
    types: { ...DEFAULT_TYPES, ...(s.types || {}) },
    ignored: Array.isArray(s.ignored) ? s.ignored.filter((x) => typeof x === 'string') : [],
  };
}
function saveSettings(guildId, settings) {
  setConfig(guildId, 'logging', {
    channelId: settings.channelId || null,
    types: { ...DEFAULT_TYPES, ...(settings.types || {}) },
    ignored: Array.isArray(settings.ignored) ? [...new Set(settings.ignored)] : [],
  });
  return getSettings(guildId);
}

/** Channels whose activity is never logged (message edits/deletes, voice). */
function setIgnored(guildId, channelIds) {
  const s = getSettings(guildId);
  s.ignored = Array.isArray(channelIds) ? channelIds.filter(Boolean) : [];
  return saveSettings(guildId, s);
}
function ignoreChannel(guildId, channelId, on = true) {
  const s = getSettings(guildId);
  const set = new Set(s.ignored);
  if (on) set.add(channelId); else set.delete(channelId);
  s.ignored = [...set];
  return saveSettings(guildId, s);
}
/** True when this channel's events should be skipped. The log channel itself
 *  is always ignored so it can't log its own messages back to itself. */
function isIgnored(guildId, channelId) {
  if (!channelId) return false;
  const s = getSettings(guildId);
  if (s.channelId && channelId === s.channelId) return true;
  return s.ignored.includes(channelId);
}
function setChannel(guildId, channelId) {
  const s = getSettings(guildId);
  s.channelId = channelId || null;
  return saveSettings(guildId, s);
}
function setType(guildId, type, on) {
  const s = getSettings(guildId);
  if (TYPES.includes(type)) s.types[type] = !!on;
  return saveSettings(guildId, s);
}
function isEnabled(guildId, type) {
  const s = getSettings(guildId);
  return !!s.channelId && s.types[type] !== false;
}

/** Turn Discord's raw markup into names for the dashboard's live feed, which
 *  renders plain text — `<#123>` and `<@456>` would otherwise show as IDs. */
function humanise(client, guildId, text) {
  if (!text) return '';
  const guild = client.guilds?.cache?.get(guildId);
  return String(text)
    .replace(/<#(\d+)>/g, (_, id) => {
      const ch = guild?.channels?.cache?.get(id) || client.channels?.cache?.get(id);
      return ch ? `#${ch.name}` : '#unknown-channel';
    })
    .replace(/<@[!&]?(\d+)>/g, (m, id) => {
      const member = guild?.members?.cache?.get(id);
      if (member) return `@${member.displayName}`;
      const role = guild?.roles?.cache?.get(id);
      if (role) return `@${role.name}`;
      const user = client.users?.cache?.get(id);
      return user ? `@${user.globalName || user.username}` : '@unknown';
    })
    .replace(/\*\*/g, '');
}

async function send(client, guildId, embed) {
  // Mirror to the dashboard live feed regardless of channel delivery.
  try {
    const d = embed.data || {};
    let text = humanise(client, guildId, d.description || d.title || 'Event');
    // The embed's author is the member the event is about (e.g. whose message
    // was deleted) — the feed only had the description, so that was lost.
    const who = d.author?.name;
    if (who && !text.includes(who)) text = `${who} · ${text}`;
    logFeed.push(guildId, { text, color: d.color || null, at: Date.now() });
  } catch { /* ignore */ }
  const s = getSettings(guildId);
  if (!s.channelId) return;
  const channel = await client.channels.fetch(s.channelId).catch(() => null);
  if (channel && channel.isTextBased()) await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { TYPES, DEFAULT_TYPES, getSettings, saveSettings, setChannel, setType, isEnabled, send, setIgnored, ignoreChannel, isIgnored };
