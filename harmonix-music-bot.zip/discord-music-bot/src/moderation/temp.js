'use strict';

const { getDb } = require('../db');

function schedule(guildId, userId, type, expiresAt, roleId = null) {
  getDb()
    .prepare('INSERT INTO temp_actions (guild_id, user_id, type, role_id, expires_at, done) VALUES (?, ?, ?, ?, ?, 0)')
    .run(guildId, userId, type, roleId, expiresAt);
}
function getDue(now) {
  return getDb().prepare('SELECT * FROM temp_actions WHERE done = 0 AND expires_at <= ?').all(now);
}
function markDone(id) {
  getDb().prepare('UPDATE temp_actions SET done = 1 WHERE id = ?').run(id);
}
function cancel(guildId, userId, type) {
  getDb().prepare('UPDATE temp_actions SET done = 1 WHERE guild_id = ? AND user_id = ? AND type = ? AND done = 0').run(guildId, userId, type);
}

module.exports = { schedule, getDue, markDone, cancel };
