'use strict';

/**
 * AutoMod — lightweight, configurable message filtering.
 *
 * Detection logic (scanContent) is pure so it can be unit-tested without
 * Discord. Spam detection is stateful (a per-process sliding window) and lives
 * in checkSpam. Config is stored per-guild in guild_config under 'automod'.
 */

const { getConfig, setConfig } = require('../db');

const KEY = 'automod';

const RULES = ['invites', 'links', 'mentions', 'caps', 'words', 'spam'];

const DEFAULTS = {
  rules: { invites: false, links: false, mentions: false, caps: false, words: false, spam: false },
  exemptRoles: [],
  words: [],
  thresholds: { mentionLimit: 5, capsMinLen: 12, capsPct: 0.7, spamCount: 5, spamWindowMs: 7000 },
};

function getSettings(guildId) {
  const stored = getConfig(guildId, KEY, null);
  if (!stored) return structuredClone(DEFAULTS);
  // Merge so newly-added fields get defaults.
  return {
    rules: { ...DEFAULTS.rules, ...(stored.rules || {}) },
    exemptRoles: stored.exemptRoles || [],
    words: stored.words || [],
    thresholds: { ...DEFAULTS.thresholds, ...(stored.thresholds || {}) },
  };
}
function saveSettings(guildId, settings) {
  return setConfig(guildId, KEY, settings);
}

const INVITE_RE = /(?:https?:\/\/)?(?:www\.)?(?:discord(?:app)?\.com\/invite|discord\.(?:gg|io|me|li))\/[a-z0-9-]+/i;
const URL_RE = /(?:https?:\/\/|www\.)\S{2,}/i;

/**
 * Inspect a message's content. Returns { rule, reason } on the first rule that
 * trips, or null if clean. `mentionCount` is supplied by the caller (counted
 * from the Discord message), so this stays pure.
 */
function scanContent(content, { mentionCount = 0 } = {}, settings = DEFAULTS) {
  const text = String(content || '');
  const r = settings.rules || {};

  if (r.invites && INVITE_RE.test(text)) {
    return { rule: 'invites', reason: 'Posting Discord invite links' };
  }
  if (r.links && URL_RE.test(text)) {
    return { rule: 'links', reason: 'Posting links' };
  }
  if (r.mentions && mentionCount > settings.thresholds.mentionLimit) {
    return { rule: 'mentions', reason: `Too many mentions (${mentionCount})` };
  }
  if (r.caps) {
    const letters = text.replace(/[^a-zA-Z]/g, '');
    if (letters.length >= settings.thresholds.capsMinLen) {
      const uppers = text.replace(/[^A-Z]/g, '').length;
      if (uppers / letters.length >= settings.thresholds.capsPct) {
        return { rule: 'caps', reason: 'Excessive caps' };
      }
    }
  }
  if (r.words && settings.words.length) {
    const lower = text.toLowerCase();
    for (const w of settings.words) {
      if (!w) continue;
      const re = new RegExp(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
      if (re.test(lower)) return { rule: 'words', reason: 'Blocked word' };
    }
  }
  return null;
}

// ── spam (stateful sliding window) ───────────────────────────────
const buckets = new Map(); // `${guildId}:${userId}` -> number[] (timestamps)

function checkSpam(guildId, userId, settings = DEFAULTS, now = Date.now()) {
  if (!settings.rules || !settings.rules.spam) return null;
  const { spamCount, spamWindowMs } = settings.thresholds;
  const key = `${guildId}:${userId}`;
  const arr = (buckets.get(key) || []).filter((t) => now - t < spamWindowMs);
  arr.push(now);
  buckets.set(key, arr);
  if (arr.length >= spamCount) {
    buckets.set(key, []); // reset after tripping so we don't fire every message
    return { rule: 'spam', reason: `Sending messages too quickly (${arr.length} in ${Math.round(spamWindowMs / 1000)}s)` };
  }
  return null;
}

module.exports = { RULES, DEFAULTS, getSettings, saveSettings, scanContent, checkSpam, INVITE_RE, URL_RE };
