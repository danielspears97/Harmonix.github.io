'use strict';

/**
 * Mod-log: per-guild configurable channel where moderation cases are posted,
 * plus the embed builder and a record() convenience that writes the case and
 * posts it in one call.
 */

const { EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const { getConfig, setConfig, deleteConfig } = require('../db');
const cases = require('./cases');
const { humanizeDuration } = require('../utils/duration');

const MODLOG_KEY = 'modlog_channel';

const ACTION_META = {
  warn: { label: 'Warn', color: 0xf59e0b, emoji: '⚠️' },
  kick: { label: 'Kick', color: 0xf97316, emoji: '👢' },
  ban: { label: 'Ban', color: config.brand.errorColor, emoji: '🔨' },
  unban: { label: 'Unban', color: config.brand.successColor, emoji: '♻️' },
  timeout: { label: 'Timeout', color: 0xf59e0b, emoji: '⏳' },
  untimeout: { label: 'Remove Timeout', color: config.brand.successColor, emoji: '🔓' },
  tempban: { label: 'Temp-ban', color: config.brand.errorColor, emoji: '⏲️' },
  mute: { label: 'Mute', color: 0xf59e0b, emoji: '🔇' },
  unmute: { label: 'Unmute', color: config.brand.successColor, emoji: '🔊' },
};

function getModlogChannelId(guildId) {
  return getConfig(guildId, MODLOG_KEY, null);
}
function setModlogChannel(guildId, channelId) {
  return setConfig(guildId, MODLOG_KEY, channelId);
}
function disableModlog(guildId) {
  deleteConfig(guildId, MODLOG_KEY);
}

function buildCaseEmbed(caseRow) {
  const meta = ACTION_META[caseRow.action] || { label: caseRow.action, color: config.brand.color, emoji: '📝' };
  const fields = [
    { name: 'User', value: `<@${caseRow.target_id}>\n\`${caseRow.target_tag || caseRow.target_id}\``, inline: true },
    { name: 'Moderator', value: `<@${caseRow.moderator_id}>`, inline: true },
  ];
  if (caseRow.duration_ms) {
    fields.push({ name: 'Duration', value: humanizeDuration(caseRow.duration_ms), inline: true });
  }
  fields.push({ name: 'Reason', value: caseRow.reason || '*No reason provided*', inline: false });

  return new EmbedBuilder()
    .setColor(meta.color)
    .setAuthor({ name: `${meta.emoji} ${meta.label} • Case #${caseRow.case_number}` })
    .addFields(fields)
    .setFooter({ text: `User ID: ${caseRow.target_id}` })
    .setTimestamp(new Date(caseRow.created_at));
}

async function postCase(client, guildId, caseRow) {
  const channelId = getModlogChannelId(guildId);
  if (!channelId) return;
  try {
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (channel && channel.isTextBased()) {
      await channel.send({ embeds: [buildCaseEmbed(caseRow)] });
    }
  } catch (err) {
    console.error('[modlog] failed to post case:', err.message);
  }
}

/**
 * Record a case in the DB and post it to the mod-log (if configured).
 * Returns the stored case row.
 */
async function record(client, guildId, data) {
  const caseRow = cases.addCase(guildId, data);
  await postCase(client, guildId, caseRow);
  return caseRow;
}

module.exports = {
  getModlogChannelId,
  setModlogChannel,
  disableModlog,
  buildCaseEmbed,
  postCase,
  record,
  ACTION_META,
  MODLOG_KEY,
};
