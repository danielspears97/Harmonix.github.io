'use strict';

const { getConfig, setConfig } = require('../db');

function getSettings(guildId) {
  const s = getConfig(guildId, 'verification', null) || {};
  return { roleId: s.roleId || null, minAccountDays: s.minAccountDays || 0 };
}
function setSettings(guildId, patch) {
  setConfig(guildId, 'verification', { ...getSettings(guildId), ...patch });
  return getSettings(guildId);
}

module.exports = { getSettings, setSettings };
