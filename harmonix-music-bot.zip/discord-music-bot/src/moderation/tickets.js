'use strict';

const { getDb, getConfig, setConfig } = require('../db');

// ── per-guild settings ───────────────────────────────────────────
function getSettings(guildId) {
  const s = getConfig(guildId, 'tickets', null) || {};
  return {
    categoryId: s.categoryId || null,
    staffRoleId: s.staffRoleId || null,
    logChannelId: s.logChannelId || null,
    transcripts: s.transcripts !== false,
  };
}
function setSettings(guildId, patch) {
  const s = getSettings(guildId);
  setConfig(guildId, 'tickets', { ...s, ...patch });
  return getSettings(guildId);
}

// ── open-ticket records ──────────────────────────────────────────
function nextNumber(guildId) {
  const row = getDb().prepare('SELECT COALESCE(MAX(number), 0) + 1 AS n FROM tickets WHERE guild_id = ?').get(guildId);
  return row.n;
}
function create(guildId, channelId, userId, number) {
  getDb()
    .prepare('INSERT INTO tickets (guild_id, channel_id, user_id, number, open, created_at) VALUES (?, ?, ?, ?, 1, ?)')
    .run(guildId, channelId, userId, number, Date.now());
}
function getByChannel(channelId) {
  return getDb().prepare('SELECT * FROM tickets WHERE channel_id = ?').get(channelId);
}
function getOpenByUser(guildId, userId) {
  return getDb().prepare('SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND open = 1').get(guildId, userId);
}
function claim(channelId, staffId) {
  getDb().prepare('UPDATE tickets SET claimed_by = ? WHERE channel_id = ?').run(staffId, channelId);
}
function markClosed(channelId) {
  getDb().prepare('UPDATE tickets SET open = 0 WHERE channel_id = ?').run(channelId);
}
function listOpen(guildId) {
  return getDb().prepare('SELECT * FROM tickets WHERE guild_id = ? AND open = 1 ORDER BY number').all(guildId);
}

module.exports = { getSettings, setSettings, nextNumber, create, getByChannel, getOpenByUser, claim, markClosed, listOpen };
