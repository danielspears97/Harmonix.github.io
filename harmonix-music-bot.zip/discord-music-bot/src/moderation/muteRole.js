'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { getConfig, setConfig } = require('../db');

function getRoleId(guildId) {
  return getConfig(guildId, 'mute_role', null);
}
function setRoleId(guildId, roleId) {
  setConfig(guildId, 'mute_role', roleId);
}

/** Get the configured mute role, creating and configuring one if needed. */
async function ensure(guild) {
  const id = getRoleId(guild.id);
  let role = id ? guild.roles.cache.get(id) : null;
  if (role) return role;

  role = await guild.roles.create({ name: 'Muted', color: 0x607d8b, reason: 'Harmonix mute role', permissions: [] });
  setRoleId(guild.id, role.id);

  // Deny talking everywhere. Categories cascade to synced children; we still
  // try each channel so unsynced ones are covered.
  for (const channel of guild.channels.cache.values()) {
    if (!channel.permissionOverwrites) continue;
    await channel.permissionOverwrites
      .edit(role, { SendMessages: false, AddReactions: false, SendMessagesInThreads: false, CreatePublicThreads: false, CreatePrivateThreads: false, Speak: false })
      .catch(() => {});
  }
  return role;
}

module.exports = { getRoleId, setRoleId, ensure, MUTE_DENY: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.AddReactions, PermissionFlagsBits.Speak] };
