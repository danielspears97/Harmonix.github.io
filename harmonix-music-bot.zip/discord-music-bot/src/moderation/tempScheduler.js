'use strict';

const temp = require('./temp');
const modlog = require('./modlog');

const POLL_MS = 30 * 1000;

// markDone() runs after the API calls, so two overlapping ticks could both
// claim the same expiry and write duplicate mod-log entries.
let ticking = false;

async function tick(client) {
  if (ticking) return;
  ticking = true;
  try {
    await runTick(client);
  } finally {
    ticking = false;
  }
}

async function runTick(client) {
  const due = temp.getDue(Date.now());
  for (const row of due) {
    try {
      const guild = await client.guilds.fetch(row.guild_id).catch(() => null);
      if (guild) {
        if (row.type === 'unban') {
          await guild.bans.remove(row.user_id, 'Temp-ban expired').catch(() => {});
          await modlog.record(client, guild.id, {
            action: 'unban', targetId: row.user_id, targetTag: row.user_id,
            moderatorId: client.user.id, moderatorTag: 'Harmonix (auto)', reason: 'Temp-ban expired',
          }).catch(() => {});
        } else if (row.type === 'unmute' && row.role_id) {
          const member = await guild.members.fetch(row.user_id).catch(() => null);
          if (member) await member.roles.remove(row.role_id, 'Temp-mute expired').catch(() => {});
        }
      }
    } catch (err) {
      console.error('[temp] failed to process action', row.id, err.message);
    } finally {
      temp.markDone(row.id);
    }
  }
}

function start(client) {
  tick(client).catch(() => {});
  setInterval(() => tick(client).catch(() => {}), POLL_MS);
  console.log('[temp] timed-punishment scheduler started');
}

module.exports = { start, tick };
