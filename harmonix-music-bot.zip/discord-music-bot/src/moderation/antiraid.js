'use strict';

const { getConfig, setConfig } = require('../db');

const DEFAULTS = { enabled: false, threshold: 8, windowSec: 10, action: 'kick', minAccountDays: 0, timeoutMin: 10, alertChannelId: null };
const RAID_COOLDOWN_MS = 60 * 1000;

function getSettings(guildId) {
  return { ...DEFAULTS, ...(getConfig(guildId, 'antiraid', null) || {}) };
}
function setSettings(guildId, patch) {
  setConfig(guildId, 'antiraid', { ...getSettings(guildId), ...patch });
  return getSettings(guildId);
}

const joinLog = new Map(); // guildId -> [timestamps]
const raidUntil = new Map(); // guildId -> epoch ms

/** Record a join and report whether the rate now exceeds the threshold. */
function recordJoin(guildId, windowSec, threshold) {
  const now = Date.now();
  const arr = (joinLog.get(guildId) || []).filter((t) => now - t < windowSec * 1000);
  arr.push(now);
  joinLog.set(guildId, arr);
  return arr.length >= threshold;
}
function inRaid(guildId) {
  return (raidUntil.get(guildId) || 0) > Date.now();
}
function startRaid(guildId) {
  raidUntil.set(guildId, Date.now() + RAID_COOLDOWN_MS);
}
function clearRaid(guildId) {
  raidUntil.delete(guildId);
}

module.exports = { DEFAULTS, RAID_COOLDOWN_MS, getSettings, setSettings, recordJoin, inRaid, startRaid, clearRaid };
