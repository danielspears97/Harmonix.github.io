'use strict';

const { EventEmitter } = require('events');

const events = new EventEmitter();
events.setMaxListeners(0);
const buffers = new Map(); // guildId -> entries[]
const CAP = 50;

function push(guildId, entry) {
  const arr = buffers.get(guildId) || [];
  arr.push(entry);
  while (arr.length > CAP) arr.shift();
  buffers.set(guildId, arr);
  events.emit('entry', guildId, entry);
}
function recent(guildId) {
  return buffers.get(guildId) || [];
}

module.exports = { events, push, recent };
