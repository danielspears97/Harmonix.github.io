'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const { userTag } = require('../../utils/format');

const C = config.brand.color;
const ts = (date) => `<t:${Math.floor(new Date(date).getTime() / 1000)}:D>`;

const userinfo = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Show info about a member')
    .setDMPermission(false)
    .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(false)),
  async execute(client, interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    const embed = new EmbedBuilder()
      .setColor(member?.displayColor || C)
      .setAuthor({ name: userTag(user), iconURL: user.displayAvatarURL() })
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: 'ID', value: user.id, inline: true },
        { name: 'Account created', value: ts(user.createdAt), inline: true }
      );
    if (member) {
      embed.addFields({ name: 'Joined server', value: member.joinedAt ? ts(member.joinedAt) : '—', inline: true });
      const roles = member.roles.cache.filter((r) => r.id !== interaction.guild.id).map((r) => `<@&${r.id}>`);
      embed.addFields({ name: `Roles (${roles.length})`, value: roles.slice(0, 20).join(' ') || 'None' });
    }
    return interaction.reply({ embeds: [embed] });
  },
};

const serverinfo = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('Show info about this server').setDMPermission(false),
  async execute(client, interaction) {
    const g = interaction.guild;
    const owner = await g.fetchOwner().catch(() => null);
    const embed = new EmbedBuilder()
      .setColor(C)
      .setTitle(g.name)
      .setThumbnail(g.iconURL({ size: 256 }))
      .addFields(
        { name: 'Owner', value: owner ? `<@${owner.id}>` : '—', inline: true },
        { name: 'Members', value: String(g.memberCount), inline: true },
        { name: 'Created', value: ts(g.createdAt), inline: true },
        { name: 'Channels', value: String(g.channels.cache.size), inline: true },
        { name: 'Roles', value: String(g.roles.cache.size), inline: true },
        { name: 'Boosts', value: `${g.premiumSubscriptionCount || 0} (tier ${g.premiumTier})`, inline: true }
      )
      .setFooter({ text: `Server ID: ${g.id}` });
    return interaction.reply({ embeds: [embed] });
  },
};

const roleinfo = {
  data: new SlashCommandBuilder()
    .setName('roleinfo')
    .setDescription('Show info about a role')
    .setDMPermission(false)
    .addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true)),
  async execute(client, interaction) {
    const r = interaction.options.getRole('role');
    const embed = new EmbedBuilder()
      .setColor(r.color || C)
      .setTitle(`Role: ${r.name}`)
      .addFields(
        { name: 'ID', value: r.id, inline: true },
        { name: 'Members', value: String(r.members.size), inline: true },
        { name: 'Color', value: r.hexColor, inline: true },
        { name: 'Mentionable', value: r.mentionable ? 'Yes' : 'No', inline: true },
        { name: 'Hoisted', value: r.hoist ? 'Yes' : 'No', inline: true },
        { name: 'Created', value: ts(r.createdAt), inline: true }
      );
    return interaction.reply({ embeds: [embed] });
  },
};

const avatar = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Show a user’s avatar')
    .setDMPermission(false)
    .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(false)),
  async execute(client, interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const url = user.displayAvatarURL({ size: 1024 });
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setTitle(userTag(user)).setImage(url).setURL(url)] });
  },
};

const membercount = {
  data: new SlashCommandBuilder().setName('membercount').setDescription('Show the member count').setDMPermission(false),
  async execute(client, interaction) {
    return interaction.reply({ content: `👥 **${interaction.guild.memberCount}** members.` });
  },
};

module.exports = [userinfo, serverinfo, roleinfo, avatar, membercount];
