'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const afk = require('../../community/afk');
const snipeStore = require('../../community/snipeStore');
const { userTag } = require('../../utils/format');

const afkCommand = {
  data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Set yourself as AFK')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('reason').setDescription('Why you’re away').setRequired(false)),
  async execute(client, interaction) {
    const reason = interaction.options.getString('reason') || 'AFK';
    afk.set(interaction.guildId, interaction.user.id, reason);
    return interaction.reply({ content: `🌙 You’re now AFK: **${reason}**`, ephemeral: true });
  },
};

const snipeCommand = {
  data: new SlashCommandBuilder().setName('snipe').setDescription('Show the last deleted message here').setDMPermission(false),
  async execute(client, interaction) {
    const s = snipeStore.recall(interaction.channel.id);
    if (!s) return interaction.reply({ content: 'Nothing to snipe — no recently deleted message.', ephemeral: true });
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setAuthor({ name: s.authorTag, iconURL: s.avatar || undefined })
      .setDescription(s.content || '*[no text content]*')
      .setFooter({ text: 'Deleted' })
      .setTimestamp(new Date(s.at));
    if (s.image) embed.setImage(s.image);
    return interaction.reply({ embeds: [embed] });
  },
};

module.exports = [afkCommand, snipeCommand];
