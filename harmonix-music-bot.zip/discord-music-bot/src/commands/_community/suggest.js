'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const suggestions = require('../../community/suggestions');
const { userTag } = require('../../utils/format');

const suggest = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit a suggestion')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('text').setDescription('Your suggestion').setRequired(true)),
  async execute(client, interaction) {
    const text = interaction.options.getString('text');
    const channelId = suggestions.getChannel(interaction.guildId) || interaction.channel.id;
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel || !channel.isTextBased()) {
      return interaction.reply({ content: 'The suggestions channel isn’t set up correctly. Ask an admin to run `/community suggestions set`.', ephemeral: true });
    }
    const msg = await channel
      .send({ embeds: [suggestions.buildEmbed(userTag(interaction.user), text, { up: 0, down: 0 })], components: suggestions.buildComponents() })
      .catch(() => null);
    if (!msg) return interaction.reply({ content: 'I couldn’t post there — check my permissions.', ephemeral: true });
    suggestions.create(interaction.guildId, channel.id, msg.id, interaction.user.id, text);
    return interaction.reply({ content: `✅ Suggestion submitted in ${channel}.`, ephemeral: true });
  },
};

const suggestionsConfig = {
  data: new SlashCommandBuilder()
    .setName('suggestions')
    .setDescription('Configure the suggestions channel')
    .setDMPermission(false)
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s.setName('set').setDescription('Set the suggestions channel').addChannelOption((o) => o.setName('channel').setDescription('Channel').addChannelTypes(ChannelType.GuildText).setRequired(true))
    )
    .addSubcommand((s) => s.setName('disable').setDescription('Clear the suggestions channel')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    if (interaction.options.getSubcommand() === 'set') {
      const channel = interaction.options.getChannel('channel');
      suggestions.setChannel(interaction.guildId, channel.id);
      return interaction.reply({ content: `💡 Suggestions will be posted in ${channel}.`, ephemeral: true });
    }
    suggestions.disable(interaction.guildId);
    return interaction.reply({ content: 'Suggestions channel cleared (will use the current channel).', ephemeral: true });
  },
};

module.exports = [suggest, suggestionsConfig];
