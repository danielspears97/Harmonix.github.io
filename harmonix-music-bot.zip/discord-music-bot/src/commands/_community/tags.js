'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const tags = require('../../community/tags');

const MANAGE = PermissionFlagsBits.ManageMessages;

const command = {
  data: new SlashCommandBuilder()
    .setName('tag')
    .setDescription('Saved snippets the server can recall')
    .setDMPermission(false)
    .addSubcommand((s) =>
      s.setName('get').setDescription('Show a tag').addStringOption((o) => o.setName('name').setDescription('Tag name').setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Create or update a tag (Manage Messages)')
        .addStringOption((o) => o.setName('name').setDescription('Tag name').setRequired(true))
        .addStringOption((o) => o.setName('content').setDescription('Tag content').setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName('delete').setDescription('Delete a tag (Manage Messages)').addStringOption((o) => o.setName('name').setDescription('Tag name').setRequired(true))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List all tags')),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const gid = interaction.guildId;

    if (sub === 'get') {
      const name = interaction.options.getString('name');
      const tag = tags.get(gid, name);
      if (!tag) return interaction.reply({ content: `No tag named **${name}**.`, ephemeral: true });
      tags.use(gid, name);
      return interaction.reply({ content: tag.content, allowedMentions: { parse: [] } });
    }
    if (sub === 'list') {
      const names = tags.list(gid);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(config.brand.color).setTitle('🏷️ Tags').setDescription(names.length ? names.map((n) => `\`${n}\``).join(', ') : 'No tags yet.')],
        ephemeral: true,
      });
    }
    // add / delete require Manage Messages
    if (!interaction.memberPermissions.has(MANAGE)) {
      return interaction.reply({ content: 'You need the **Manage Messages** permission to manage tags.', ephemeral: true });
    }
    if (sub === 'add') {
      const name = interaction.options.getString('name').toLowerCase();
      if (name.length > 50) return interaction.reply({ content: 'Tag name too long.', ephemeral: true });
      tags.set(gid, name, interaction.options.getString('content'), interaction.user.id);
      return interaction.reply({ content: `✅ Saved tag **${name}**.`, ephemeral: true });
    }
    // delete
    const name = interaction.options.getString('name');
    return interaction.reply({ content: tags.del(gid, name) ? `Deleted tag **${name}**.` : `No tag named **${name}**.`, ephemeral: true });
  },
};

module.exports = command;
