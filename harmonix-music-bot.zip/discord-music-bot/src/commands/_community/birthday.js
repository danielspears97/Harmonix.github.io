'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const birthdays = require('../../community/birthdays');

const MONTH_CHOICES = birthdays.MONTHS.slice(1).map((name, i) => ({ name, value: i + 1 }));

const birthday = {
  data: new SlashCommandBuilder()
    .setName('birthday')
    .setDescription('Birthday tracking & announcements')
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Set your birthday')
        .addIntegerOption((o) => o.setName('month').setDescription('Month').setRequired(true).addChoices(...MONTH_CHOICES))
        .addIntegerOption((o) => o.setName('day').setDescription('Day of month').setRequired(true).setMinValue(1).setMaxValue(31))
        .addIntegerOption((o) => o.setName('year').setDescription('Year (optional, kept private)').setMinValue(1900).setMaxValue(2025).setRequired(false))
    )
    .addSubcommand((s) => s.setName('remove').setDescription('Remove your birthday'))
    .addSubcommand((s) => s.setName('show').setDescription('Show a birthday').addUserOption((o) => o.setName('user').setDescription('Whose birthday').setRequired(false)))
    .addSubcommand((s) => s.setName('list').setDescription('Upcoming birthdays'))
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Set the announcement channel and optional birthday role (admin)')
        .addChannelOption((o) => o.setName('channel').setDescription('Announcement channel').addChannelTypes(ChannelType.GuildText).setRequired(false))
        .addRoleOption((o) => o.setName('role').setDescription('Role given on someone’s birthday').setRequired(false))
    ),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const gid = interaction.guildId;

    if (sub === 'set') {
      const month = interaction.options.getInteger('month');
      const day = interaction.options.getInteger('day');
      const year = interaction.options.getInteger('year');
      if (!birthdays.validDate(month, day)) return interaction.reply({ content: 'That isn’t a valid date.', ephemeral: true });
      birthdays.set(gid, interaction.user.id, month, day, year);
      return interaction.reply({ content: `🎂 Saved your birthday: **${birthdays.fmt({ month, day, year })}**.`, ephemeral: true });
    }
    if (sub === 'remove') {
      const ok = birthdays.remove(gid, interaction.user.id);
      return interaction.reply({ content: ok ? 'Your birthday was removed.' : 'You didn’t have one saved.', ephemeral: true });
    }
    if (sub === 'show') {
      const user = interaction.options.getUser('user') || interaction.user;
      const b = birthdays.get(gid, user.id);
      return interaction.reply({ content: b ? `🎂 ${user} — **${birthdays.fmt(b)}**` : `No birthday saved for ${user}.`, ephemeral: true });
    }
    if (sub === 'list') {
      const all = birthdays.forGuild(gid);
      if (!all.length) return interaction.reply({ content: 'No birthdays saved yet. Add yours with `/community birthday set`.', ephemeral: true });
      const now = new Date();
      const key = (b) => { const d = (b.month - (now.getMonth() + 1)) * 31 + (b.day - now.getDate()); return d < 0 ? d + 372 : d; };
      const upcoming = all.sort((a, b) => key(a) - key(b)).slice(0, 15);
      const lines = upcoming.map((b) => `<@${b.user_id}> — ${birthdays.MONTHS[b.month]} ${b.day}`);
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(config.brand.color).setTitle('🎂 Upcoming birthdays').setDescription(lines.join('\n'))] });
    }
    // config
    if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ content: 'You need **Manage Server** to configure birthdays.', ephemeral: true });
    const channel = interaction.options.getChannel('channel');
    const role = interaction.options.getRole('role');
    const patch = {};
    if (channel) patch.channelId = channel.id;
    if (role) patch.roleId = role.id;
    const next = birthdays.setCfg(gid, patch);
    return interaction.reply({ content: `🎂 Birthday announcements: ${next.channelId ? `<#${next.channelId}>` : '*no channel set*'}${next.roleId ? ` • role <@&${next.roleId}>` : ''}.`, ephemeral: true });
  },
};

module.exports = birthday;
