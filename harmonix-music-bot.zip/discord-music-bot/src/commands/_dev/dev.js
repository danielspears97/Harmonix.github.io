'use strict';

const crypto = require('crypto');
const { EmbedBuilder } = require('discord.js');
const { create, all } = require('mathjs');
const figlet = require('figlet');
const { config } = require('../../../config');
const { parseDuration } = require('../../utils/duration');
const { buildGroup } = require('../../utils/group');

const C = config.brand.color;
const math = create(all, {});
math.import({ import: function () { throw new Error('disabled'); }, createUnit: function () { throw new Error('disabled'); } }, { override: true });

const items = [
  {
    name: 'timestamp',
    description: 'Generate Discord timestamp codes',
    setup: (s) => s.addStringOption((o) => o.setName('when').setDescription('e.g. "in 2h" or 2026-12-25 18:00').setRequired(true)),
    run: async (client, interaction) => {
      const input = interaction.options.getString('when').trim();
      let date;
      const rel = parseDuration(input.replace(/^in\s+/i, ''));
      if (rel && /^(in\s+)?[\d\s]*[wdhms]/i.test(input)) date = new Date(Date.now() + rel);
      else { const p = Date.parse(input); date = Number.isNaN(p) ? null : new Date(p); }
      if (!date) return interaction.reply({ content: 'Couldn’t parse that. Try `in 2h` or `2026-12-25 18:00`.', ephemeral: true });
      const u = Math.floor(date.getTime() / 1000);
      const lines = ['t', 'T', 'd', 'D', 'f', 'F', 'R'].map((st) => `\`<t:${u}:${st}>\` → <t:${u}:${st}>`).join('\n');
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setTitle('🕒 Timestamp codes').setDescription(lines)], ephemeral: true });
    },
  },
  {
    name: 'math',
    description: 'Evaluate a math expression',
    setup: (s) => s.addStringOption((o) => o.setName('expression').setDescription('e.g. (5+3)*2, sqrt(144), 5 km to m').setRequired(true)),
    run: async (client, interaction) => {
      const expr = interaction.options.getString('expression');
      try { return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setDescription(`\`${expr}\` = **${String(math.evaluate(expr))}**`)] }); }
      catch { return interaction.reply({ content: 'Couldn’t evaluate that expression.', ephemeral: true }); }
    },
  },
  {
    name: 'base64',
    description: 'Encode or decode Base64',
    setup: (s) => s
      .addStringOption((o) => o.setName('mode').setDescription('encode or decode').setRequired(true).addChoices({ name: 'encode', value: 'encode' }, { name: 'decode', value: 'decode' }))
      .addStringOption((o) => o.setName('text').setDescription('Text').setRequired(true)),
    run: async (client, interaction) => {
      const mode = interaction.options.getString('mode');
      const text = interaction.options.getString('text');
      try {
        const out = mode === 'encode' ? Buffer.from(text, 'utf8').toString('base64') : Buffer.from(text, 'base64').toString('utf8');
        return interaction.reply({ content: `\`\`\`\n${out.slice(0, 1900)}\n\`\`\``, ephemeral: true });
      } catch { return interaction.reply({ content: 'Couldn’t process that input.', ephemeral: true }); }
    },
  },
  {
    name: 'hash',
    description: 'Hash text',
    setup: (s) => s
      .addStringOption((o) => o.setName('algorithm').setDescription('Algorithm').setRequired(true).addChoices({ name: 'md5', value: 'md5' }, { name: 'sha1', value: 'sha1' }, { name: 'sha256', value: 'sha256' }, { name: 'sha512', value: 'sha512' }))
      .addStringOption((o) => o.setName('text').setDescription('Text to hash').setRequired(true)),
    run: async (client, interaction) => {
      const algo = interaction.options.getString('algorithm');
      const digest = crypto.createHash(algo).update(interaction.options.getString('text')).digest('hex');
      return interaction.reply({ content: `**${algo}**: \`${digest}\``, ephemeral: true });
    },
  },
  {
    name: 'password',
    description: 'Generate a random password',
    setup: (s) => s.addIntegerOption((o) => o.setName('length').setDescription('Length (8-128, default 20)').setMinValue(8).setMaxValue(128)),
    run: async (client, interaction) => {
      const len = interaction.options.getInteger('length') || 20;
      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*-_=+';
      const bytes = crypto.randomBytes(len);
      let pw = '';
      for (let i = 0; i < len; i++) pw += chars[bytes[i] % chars.length];
      return interaction.reply({ content: `🔐 ||\`${pw}\`||`, ephemeral: true });
    },
  },
  {
    name: 'color',
    description: 'Preview a hex color',
    setup: (s) => s.addStringOption((o) => o.setName('hex').setDescription('e.g. #8b5cf6').setRequired(true)),
    run: async (client, interaction) => {
      let hex = interaction.options.getString('hex').replace('#', '').trim();
      if (!/^[0-9a-fA-F]{6}$/.test(hex)) return interaction.reply({ content: 'Give a 6-digit hex like `#8b5cf6`.', ephemeral: true });
      const r = parseInt(hex.slice(0, 2), 16), g = parseInt(hex.slice(2, 4), 16), b = parseInt(hex.slice(4, 6), 16);
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(parseInt(hex, 16)).setTitle(`#${hex.toLowerCase()}`).setDescription(`**RGB:** ${r}, ${g}, ${b}`).setThumbnail(`https://singlecolorimage.com/get/${hex}/200x200`)] });
    },
  },
  {
    name: 'choose',
    description: 'Pick a random option',
    setup: (s) => s.addStringOption((o) => o.setName('options').setDescription('Options separated by | or commas').setRequired(true)),
    run: async (client, interaction) => {
      const raw = interaction.options.getString('options');
      const opts = raw.split(raw.includes('|') ? '|' : ',').map((x) => x.trim()).filter(Boolean);
      if (opts.length < 2) return interaction.reply({ content: 'Give at least 2 options separated by `|`.', ephemeral: true });
      return interaction.reply({ content: `🤔 I choose: **${opts[Math.floor(Math.random() * opts.length)]}**` });
    },
  },
  {
    name: 'mock',
    description: 'sPoNgEbOb-ify text',
    setup: (s) => s.addStringOption((o) => o.setName('text').setDescription('Text').setRequired(true)),
    run: async (client, interaction) => interaction.reply({ content: interaction.options.getString('text').split('').map((c, i) => (i % 2 ? c.toUpperCase() : c.toLowerCase())).join('').slice(0, 2000), allowedMentions: { parse: [] } }),
  },
  {
    name: 'emojify',
    description: 'Turn text into regional-indicator emoji',
    setup: (s) => s.addStringOption((o) => o.setName('text').setDescription('Text (letters)').setRequired(true)),
    run: async (client, interaction) => interaction.reply({ content: interaction.options.getString('text').toLowerCase().split('').map((c) => (c >= 'a' && c <= 'z' ? `:regional_indicator_${c}:` : c === ' ' ? '   ' : c)).join('').slice(0, 2000), allowedMentions: { parse: [] } }),
  },
  {
    name: 'ascii',
    description: 'Make ASCII-art text',
    setup: (s) => s.addStringOption((o) => o.setName('text').setDescription('Short text').setRequired(true)),
    run: async (client, interaction) => {
      const text = interaction.options.getString('text').slice(0, 20);
      try {
        const art = figlet.textSync(text);
        if (art.length > 1990) return interaction.reply({ content: 'Too long — try fewer characters.', ephemeral: true });
        return interaction.reply({ content: `\`\`\`\n${art}\n\`\`\`` });
      } catch { return interaction.reply({ content: 'Couldn’t render that.', ephemeral: true }); }
    },
  },
  {
    name: 'reverse',
    description: 'Reverse text',
    setup: (s) => s.addStringOption((o) => o.setName('text').setDescription('Text').setRequired(true)),
    run: async (client, interaction) => interaction.reply({ content: [...interaction.options.getString('text')].reverse().join('').slice(0, 2000), allowedMentions: { parse: [] } }),
  },
];

module.exports = buildGroup('tools', 'Handy text & dev utilities', items);
