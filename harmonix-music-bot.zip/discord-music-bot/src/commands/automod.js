'use strict';
// /automod — kept top-level (its internal exempt/words groups can't nest deeper)
module.exports = require('./_moderation/automod');
