'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const dj = require('../music/dj');

const MANAGE = PermissionFlagsBits.ManageGuild;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dj')
    .setDescription('Restrict disruptive music controls to a DJ role')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addSubcommand((s) => s.setName('set').setDescription('Set the DJ role').addRoleOption((o) => o.setName('role').setDescription('DJ role').setRequired(true)))
    .addSubcommand((s) => s.setName('clear').setDescription('Clear the DJ role (open controls to everyone)'))
    .addSubcommand((s) => s.setName('status').setDescription('Show the current DJ role')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const sub = interaction.options.getSubcommand();
    if (sub === 'set') {
      const role = interaction.options.getRole('role');
      dj.setRole(interaction.guildId, role.id);
      return interaction.reply({ content: `🎧 DJ role set to <@&${role.id}>. Skip/stop/clear/filter now require it (admins always allowed; everyone can \`/voteskip\`).`, ephemeral: true });
    }
    if (sub === 'clear') {
      dj.setRole(interaction.guildId, null);
      return interaction.reply({ content: 'DJ role cleared — music controls are open to everyone.', ephemeral: true });
    }
    const id = dj.getRole(interaction.guildId);
    return interaction.reply({ content: id ? `Current DJ role: <@&${id}>.` : 'No DJ role set — controls are open to everyone.', ephemeral: true });
  },
};
