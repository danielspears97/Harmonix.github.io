'use strict';

const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} = require('discord.js');

const { setGuild, getGuild } = require('../utils/persistence');
const { ensurePanelMessage } = require('../handlers/controlPanel');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Create (or designate) the dedicated music control channel with live buttons.')
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Use an existing text channel instead of creating a new one.')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(client, interaction) {
    await interaction.deferReply({ ephemeral: true });

    let channel = interaction.options.getChannel('channel');

    try {
      if (!channel) {
        channel = await interaction.guild.channels.create({
          name: '🎵-music',
          type: ChannelType.GuildText,
          topic: 'Type a song name or link here to play it. Use the buttons to control playback.',
          reason: `Music control channel set up by ${interaction.user.tag}`,
        });
      }
    } catch (err) {
      return interaction.editReply(
        '❌ I could not create a channel. Please check my **Manage Channels** permission, or run `/setup channel:#existing-channel`.'
      );
    }

    setGuild(interaction.guildId, {
      controlChannelId: channel.id,
      controlMessageId: null,
    });

    const message = await ensurePanelMessage(client, interaction.guildId);
    if (!message) {
      return interaction.editReply(
        `⚠️ Set the control channel to <#${channel.id}>, but I could not post the panel. Check that I can **View Channel**, **Send Messages**, and **Embed Links** there.`
      );
    }

    return interaction.editReply(
      [
        `✅ Music control channel is ready: <#${channel.id}>`,
        '',
        '• **Type any song name or link** in that channel to play it (your message is tidied up automatically).',
        '• Use the **buttons** on the panel to pause, skip, loop, shuffle, toggle autoplay / 24-7 and more.',
        '• The panel updates itself as the music changes.',
      ].join('\n')
    );
  },
};
