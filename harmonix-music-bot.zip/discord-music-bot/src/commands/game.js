'use strict';
// /game — all games consolidated
const { composeCategory } = require('../utils/compose');
const simple = require('./_games/games');     // [8ball, rps, coinflip, roll, draw]
const pokemon = require('./_games/pokemon');   // plain
const hangman = require('./_games/hangman');   // group
const whosthat = require('./_engagement/whosthat'); // plain
const scramble = require('./_engagement/scramble'); // plain (module.exports = command)
const wordle = require('./_engagement/wordle');     // group
const trivia = require('./_engagement/trivia');     // plain
module.exports = composeCategory('game', 'Games', [...simple, pokemon, whosthat, scramble, trivia, hangman, wordle]);
