'use strict';
// /lookup — reference & info APIs
const { composeCategory } = require('../utils/compose');
const reference = require('./_reference/reference'); // [define, country, convert, crypto, wiki, forecast]
const geeky = require('./_geeky/geeky');             // [mcstatus, github, anime, qr]
module.exports = composeCategory('lookup', 'Dictionary, country, currency, wiki & more', [...reference, ...geeky]);
