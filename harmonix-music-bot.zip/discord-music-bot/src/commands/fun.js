'use strict';
// /fun — jokes, facts, food, pictures & random fun (see _fun/fun.js)
module.exports = require('./_fun/fun');
