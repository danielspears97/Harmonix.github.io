'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const { getJson } = require('../../utils/fetchJson');

const C = config.brand.color;

// ── /mcstatus ────────────────────────────────────────────────────
const mcstatus = {
  data: new SlashCommandBuilder()
    .setName('mcstatus')
    .setDescription('Check a Minecraft server’s status')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('address').setDescription('Server address (e.g. play.example.net)').setRequired(true)),
  async execute(client, interaction) {
    const addr = interaction.options.getString('address').trim();
    await interaction.deferReply();
    try {
      const d = await getJson(`https://api.mcsrvstat.us/3/${encodeURIComponent(addr)}`);
      const embed = new EmbedBuilder().setColor(d.online ? config.brand.successColor : config.brand.errorColor).setTitle(`⛏️ ${addr}`);
      if (d.online) {
        embed.addFields(
          { name: 'Status', value: '🟢 Online', inline: true },
          { name: 'Players', value: `${d.players?.online ?? 0} / ${d.players?.max ?? '?'}`, inline: true },
          { name: 'Version', value: String(d.version || '—'), inline: true }
        );
        if (d.motd?.clean?.length) embed.setDescription(d.motd.clean.join('\n'));
      } else {
        embed.setDescription('🔴 Offline or unreachable.');
      }
      return interaction.editReply({ embeds: [embed] });
    } catch {
      return interaction.editReply({ content: 'Couldn’t reach the status service. Try again shortly.' });
    }
  },
};

// ── /github ──────────────────────────────────────────────────────
const github = {
  data: new SlashCommandBuilder()
    .setName('github')
    .setDescription('Look up a GitHub user or repo')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('query').setDescription('username or owner/repo').setRequired(true)),
  async execute(client, interaction) {
    const q = interaction.options.getString('query').trim();
    await interaction.deferReply();
    try {
      if (q.includes('/')) {
        const r = await getJson(`https://api.github.com/repos/${q}`, { headers: { Accept: 'application/vnd.github+json' } });
        const embed = new EmbedBuilder()
          .setColor(C)
          .setTitle(r.full_name)
          .setURL(r.html_url)
          .setDescription(r.description || '*No description*')
          .addFields(
            { name: '⭐ Stars', value: String(r.stargazers_count), inline: true },
            { name: '🍴 Forks', value: String(r.forks_count), inline: true },
            { name: '🐛 Issues', value: String(r.open_issues_count), inline: true },
            { name: 'Language', value: r.language || '—', inline: true },
            { name: 'Updated', value: `<t:${Math.floor(Date.parse(r.pushed_at) / 1000)}:R>`, inline: true }
          );
        if (r.owner?.avatar_url) embed.setThumbnail(r.owner.avatar_url);
        return interaction.editReply({ embeds: [embed] });
      }
      const u = await getJson(`https://api.github.com/users/${encodeURIComponent(q)}`, { headers: { Accept: 'application/vnd.github+json' } });
      const embed = new EmbedBuilder()
        .setColor(C)
        .setTitle(u.login + (u.name ? ` (${u.name})` : ''))
        .setURL(u.html_url)
        .setDescription(u.bio || '')
        .addFields(
          { name: 'Repos', value: String(u.public_repos), inline: true },
          { name: 'Followers', value: String(u.followers), inline: true },
          { name: 'Following', value: String(u.following), inline: true }
        );
      if (u.avatar_url) embed.setThumbnail(u.avatar_url);
      return interaction.editReply({ embeds: [embed] });
    } catch {
      return interaction.editReply({ content: `Couldn’t find **${q}** on GitHub (or the API is rate-limited).` });
    }
  },
};

// ── /anime ───────────────────────────────────────────────────────
const anime = {
  data: new SlashCommandBuilder()
    .setName('anime')
    .setDescription('Look up an anime')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('title').setDescription('Anime title').setRequired(true)),
  async execute(client, interaction) {
    const title = interaction.options.getString('title').trim();
    await interaction.deferReply();
    try {
      const d = await getJson(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(title)}&limit=1&sfw`);
      const a = d.data?.[0];
      if (!a) throw new Error('not found');
      const embed = new EmbedBuilder()
        .setColor(C)
        .setTitle(a.title)
        .setURL(a.url)
        .setDescription((a.synopsis || '*No synopsis*').slice(0, 600))
        .addFields(
          { name: 'Score', value: a.score ? `⭐ ${a.score}` : '—', inline: true },
          { name: 'Episodes', value: String(a.episodes || '—'), inline: true },
          { name: 'Status', value: a.status || '—', inline: true }
        );
      if (a.images?.jpg?.image_url) embed.setThumbnail(a.images.jpg.image_url);
      return interaction.editReply({ embeds: [embed] });
    } catch {
      return interaction.editReply({ content: `Couldn’t find an anime called **${title}**.` });
    }
  },
};

// ── /qr ──────────────────────────────────────────────────────────
const qr = {
  data: new SlashCommandBuilder()
    .setName('qr')
    .setDescription('Generate a QR code')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('text').setDescription('Text or URL to encode').setRequired(true)),
  async execute(client, interaction) {
    const text = interaction.options.getString('text');
    const url = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(text)}`;
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setTitle('🔳 QR code').setImage(url)] });
  },
};

module.exports = [mcstatus, github, anime, qr];
