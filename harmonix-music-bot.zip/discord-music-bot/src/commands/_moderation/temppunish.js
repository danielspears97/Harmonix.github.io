'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const modlog = require('../../moderation/modlog');
const temp = require('../../moderation/temp');
const muteRole = require('../../moderation/muteRole');
const { actionable, notifyTarget } = require('../../utils/modGuards');
const { userTag } = require('../../utils/format');
const { parseDuration, humanizeDuration } = require('../../utils/duration');

const BAN = PermissionFlagsBits.BanMembers;
const MOD = PermissionFlagsBits.ModerateMembers;

// ── /mod tempban ─────────────────────────────────────────────────
const tempban = {
  data: new SlashCommandBuilder()
    .setName('tempban')
    .setDescription('Ban a member for a set duration, then auto-unban')
    .setDMPermission(false)
    .setDefaultMemberPermissions(BAN)
    .addUserOption((o) => o.setName('user').setDescription('Member to ban').setRequired(true))
    .addStringOption((o) => o.setName('duration').setDescription('e.g. 2h, 7d, 1w').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(BAN)) return interaction.reply({ content: 'You need the **Ban Members** permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    const ms = parseDuration(interaction.options.getString('duration'));
    if (!ms || ms < 60000) return interaction.reply({ content: 'Give a duration of at least 1 minute (e.g. `2h`, `7d`).', ephemeral: true });

    if (member) {
      const guard = actionable(interaction, member, 'ban');
      if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });
    }
    await interaction.deferReply();
    const dmed = member ? await notifyTarget(target, interaction.guild.name, `temporarily banned (${humanizeDuration(ms)})`, reason) : false;
    try {
      await interaction.guild.members.ban(target.id, { reason: `${userTag(interaction.user)}: ${reason || 'No reason'} (temp ${humanizeDuration(ms)})` });
    } catch (err) {
      return interaction.editReply({ content: `Failed to ban: ${err.message}` });
    }
    temp.cancel(interaction.guildId, target.id, 'unban');
    temp.schedule(interaction.guildId, target.id, 'unban', Date.now() + ms);
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'tempban', targetId: target.id, targetTag: userTag(target),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason, duration_ms: ms,
    });
    return interaction.editReply({
      embeds: [new EmbedBuilder().setColor(config.brand.successColor).setDescription(`⏲️ **Temp-banned ${userTag(target)}** for **${humanizeDuration(ms)}** • Case #${caseRow.case_number}\n**Reason:** ${reason || '*No reason provided*'}${member && !dmed ? '\n*Couldn’t DM the user.*' : ''}`)],
    });
  },
};

// ── /mod mute ────────────────────────────────────────────────────
const mute = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute a member for a set duration (managed role)')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addUserOption((o) => o.setName('user').setDescription('Member to mute').setRequired(true))
    .addStringOption((o) => o.setName('duration').setDescription('e.g. 30m, 2h, 1d').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    const ms = parseDuration(interaction.options.getString('duration'));
    if (!member) return interaction.reply({ content: 'That user isn’t in this server.', ephemeral: true });
    if (!ms || ms < 60000) return interaction.reply({ content: 'Give a duration of at least 1 minute (e.g. `30m`, `2h`).', ephemeral: true });

    const guard = actionable(interaction, member, 'mute');
    if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });

    const me = interaction.guild.members.me;
    if (!me.permissions.has(PermissionFlagsBits.ManageRoles)) return interaction.reply({ content: 'I need the **Manage Roles** permission.', ephemeral: true });

    await interaction.deferReply();
    let role;
    try {
      role = await muteRole.ensure(interaction.guild);
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t set up the mute role: ${err.message}` });
    }
    if (role.position >= me.roles.highest.position) return interaction.editReply({ content: 'My role must be **above** the Muted role. Move it up and try again.' });

    try {
      await member.roles.add(role.id, `${userTag(interaction.user)}: ${reason || 'No reason'}`);
    } catch (err) {
      return interaction.editReply({ content: `Failed to mute: ${err.message}` });
    }
    temp.cancel(interaction.guildId, target.id, 'unmute');
    temp.schedule(interaction.guildId, target.id, 'unmute', Date.now() + ms, role.id);
    const dmed = await notifyTarget(target, interaction.guild.name, `muted (${humanizeDuration(ms)})`, reason);
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'mute', targetId: target.id, targetTag: userTag(target),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason, duration_ms: ms,
    });
    return interaction.editReply({
      embeds: [new EmbedBuilder().setColor(0xf59e0b).setDescription(`🔇 **Muted ${userTag(target)}** for **${humanizeDuration(ms)}** • Case #${caseRow.case_number}\n**Reason:** ${reason || '*No reason provided*'}${!dmed ? '\n*Couldn’t DM the user.*' : ''}`)],
    });
  },
};

// ── /mod unmute ──────────────────────────────────────────────────
const unmute = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Remove a member’s mute')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addUserOption((o) => o.setName('user').setDescription('Member to unmute').setRequired(true)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const roleId = muteRole.getRoleId(interaction.guildId);
    if (!roleId) return interaction.reply({ content: 'No mute role is configured.', ephemeral: true });
    if (member) await member.roles.remove(roleId, `Unmuted by ${userTag(interaction.user)}`).catch(() => {});
    temp.cancel(interaction.guildId, target.id, 'unmute');
    await modlog.record(client, interaction.guildId, {
      action: 'unmute', targetId: target.id, targetTag: userTag(target),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason: null,
    });
    return interaction.reply({ content: `🔊 Unmuted **${userTag(target)}**.` });
  },
};

module.exports = [tempban, mute, unmute];
