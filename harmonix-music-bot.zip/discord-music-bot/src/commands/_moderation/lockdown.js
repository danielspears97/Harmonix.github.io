'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const lk = require('../../moderation/lockdown');

const MANAGE_CHANNELS = PermissionFlagsBits.ManageChannels;

async function run(interaction, lock) {
  if (!interaction.memberPermissions.has(MANAGE_CHANNELS)) {
    return interaction.reply({ content: 'You need **Manage Channels**.', ephemeral: true });
  }
  const me = interaction.guild.members.me;
  // Editing overwrites needs Manage Roles, not just Manage Channels — this is
  // the permission people usually forget, and without it every edit fails.
  if (!me || !me.permissions.has(PermissionFlagsBits.ManageRoles)) {
    return interaction.reply({
      content: 'I need the **Manage Roles** permission to change channel overwrites (Manage Channels alone isn’t enough).',
      ephemeral: true,
    });
  }

  const target = interaction.options.getChannel('channel');
  const exemptRole = interaction.options.getRole('exempt');
  const reason = interaction.options.getString('reason') || `${lock ? 'Lockdown' : 'Unlock'} by ${interaction.user.tag}`;
  const exemptRoleIds = exemptRole ? [exemptRole.id] : [];

  await interaction.deferReply();

  const apply = (ch) => (lock ? lk.lockChannel(ch, { reason, exemptRoleIds }) : lk.unlockChannel(ch, { reason }));

  // ── single channel ──
  if (target) {
    if (!lk.isLockable(target)) return interaction.editReply('That channel type can’t be locked.');
    const res = await apply(target).catch(() => ({ ok: false, reason: 'error' }));
    if (!res.ok) {
      return interaction.editReply(
        res.reason === 'perms'
          ? `I can’t edit permissions in ${target} — check my role is above the others and has **Manage Roles** there.`
          : `I couldn’t ${lock ? 'lock' : 'unlock'} ${target}.`
      );
    }
    const extra = lock && res.clearedRoles
      ? `\n🧹 Also cleared **Send Messages/Connect** allows on ${res.clearedRoles} role${res.clearedRoles === 1 ? '' : 's'} that would have overridden the lock.`
      : '';
    return interaction.editReply(
      `${lock ? '🔒' : '🔓'} ${target} is now **${lock ? 'locked' : 'unlocked'}**.${extra}\n📝 ${reason}`
    );
  }

  // ── server-wide ──
  const channels = [...interaction.guild.channels.cache.values()].filter(lk.isLockable);
  let done = 0;
  let failed = 0;
  let cleared = 0;
  let voice = 0;
  for (const ch of channels) {
    try {
      const res = await apply(ch);
      if (res.ok) {
        done += 1;
        cleared += res.clearedRoles || 0;
        if (lk.VOICE_TYPES.includes(ch.type)) voice += 1;
      } else failed += 1;
    } catch { failed += 1; }
  }

  const bits = [
    `${lock ? '🔒' : '🔓'} **Server-wide ${lock ? 'lockdown' : 'unlock'}** — ${done} channel${done === 1 ? '' : 's'} ${lock ? 'locked' : 'unlocked'} (${voice} voice)`,
    failed ? `⚠️ ${failed} skipped — I lack permission there` : '',
    lock && cleared ? `🧹 Cleared conflicting role allows in ${cleared} place${cleared === 1 ? '' : 's'}` : '',
    exemptRole ? `✅ ${exemptRole} kept access` : '',
    `📝 ${reason}`,
  ].filter(Boolean);
  return interaction.editReply(bits.join('\n'));
}

const lockdown = {
  data: new SlashCommandBuilder()
    .setName('lockdown')
    .setDescription('Lock channels so members can’t talk or join voice')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_CHANNELS)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel to lock (leave empty for every channel)').addChannelTypes(...lk.LOCKABLE).setRequired(false))
    .addRoleOption((o) => o.setName('exempt').setDescription('Role that keeps access (e.g. your mod role)').setRequired(false))
    .addStringOption((o) => o.setName('reason').setDescription('Reason (shown in the reply)').setMaxLength(300).setRequired(false)),
  execute: (client, interaction) => run(interaction, true),
};

const unlock = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock channels, restoring their previous permissions')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_CHANNELS)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel to unlock (leave empty for every channel)').addChannelTypes(...lk.LOCKABLE).setRequired(false))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(300).setRequired(false)),
  execute: (client, interaction) => run(interaction, false),
};

module.exports = [lockdown, unlock];
