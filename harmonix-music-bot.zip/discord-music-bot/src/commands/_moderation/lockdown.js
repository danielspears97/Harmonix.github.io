'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

const MANAGE_CHANNELS = PermissionFlagsBits.ManageChannels;
const LOCKABLE = [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum];

function isLockable(ch) {
  return LOCKABLE.includes(ch.type);
}

/** Apply SendMessages override for @everyone. value=false locks, null unlocks. */
async function setLock(channel, everyoneId, value, reason) {
  return channel.permissionOverwrites.edit(everyoneId, { SendMessages: value, SendMessagesInThreads: value, CreatePublicThreads: value }, { reason });
}

async function run(interaction, lock) {
  if (!interaction.memberPermissions.has(MANAGE_CHANNELS)) {
    return interaction.reply({ content: 'You need **Manage Channels**.', ephemeral: true });
  }
  const me = interaction.guild.members.me;
  if (!me || !me.permissions.has(MANAGE_CHANNELS)) {
    return interaction.reply({ content: 'I need the **Manage Channels** permission to do that.', ephemeral: true });
  }

  const target = interaction.options.getChannel('channel');
  const reason = interaction.options.getString('reason') || `${lock ? 'Lockdown' : 'Unlock'} by ${interaction.user.tag}`;
  const everyoneId = interaction.guild.roles.everyone.id;
  const value = lock ? false : null;

  await interaction.deferReply();

  // Single channel
  if (target) {
    if (!isLockable(target)) return interaction.editReply('That channel type can’t be locked.');
    try {
      await setLock(target, everyoneId, value, reason);
      return interaction.editReply(`${lock ? '🔒' : '🔓'} ${target} is now **${lock ? 'locked' : 'unlocked'}**.${reason ? `\n📝 ${reason}` : ''}`);
    } catch {
      return interaction.editReply(`I couldn’t ${lock ? 'lock' : 'unlock'} ${target} — check my role position and permissions.`);
    }
  }

  // Server-wide: every lockable channel
  const channels = [...interaction.guild.channels.cache.values()].filter(isLockable);
  let done = 0;
  let failed = 0;
  for (const ch of channels) {
    try { await setLock(ch, everyoneId, value, reason); done += 1; } catch { failed += 1; }
  }
  return interaction.editReply(
    `${lock ? '🔒' : '🔓'} **Server-wide ${lock ? 'lockdown' : 'unlock'}** — ${done} channel${done === 1 ? '' : 's'} ${lock ? 'locked' : 'unlocked'}${failed ? `, ${failed} skipped (permissions)` : ''}.${reason ? `\n📝 ${reason}` : ''}`
  );
}

const lockdown = {
  data: new SlashCommandBuilder()
    .setName('lockdown')
    .setDescription('Lock a channel (or the whole server) so members can’t send messages')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_CHANNELS)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel to lock (leave empty to lock every channel)').addChannelTypes(...LOCKABLE).setRequired(false))
    .addStringOption((o) => o.setName('reason').setDescription('Reason (shown in the channel)').setMaxLength(300).setRequired(false)),
  execute: (client, interaction) => run(interaction, true),
};

const unlock = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock a previously locked channel (or the whole server)')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_CHANNELS)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel to unlock (leave empty to unlock every channel)').addChannelTypes(...LOCKABLE).setRequired(false))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setMaxLength(300).setRequired(false)),
  execute: (client, interaction) => run(interaction, false),
};

module.exports = [lockdown, unlock];
