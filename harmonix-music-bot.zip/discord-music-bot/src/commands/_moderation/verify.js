'use strict';

const {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
} = require('discord.js');
const verification = require('../../moderation/verification');
const { config } = require('../../../config');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const verifyCmd = {
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Member verification gate')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('setup')
        .setDescription('Set the verified role and post a verify panel')
        .addRoleOption((o) => o.setName('role').setDescription('Role granted on verification').setRequired(true))
        .addChannelOption((o) => o.setName('channel').setDescription('Where to post the panel (defaults to here)').addChannelTypes(ChannelType.GuildText).setRequired(false))
        .addIntegerOption((o) => o.setName('min_account_days').setDescription('Minimum account age in days').setMinValue(0).setMaxValue(365).setRequired(false))
        .addStringOption((o) => o.setName('message').setDescription('Custom panel message').setRequired(false))
    )
    .addSubcommand((s) => s.setName('disable').setDescription('Turn off verification'))
    .addSubcommand((s) => s.setName('status').setDescription('Show verification settings')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const sub = interaction.options.getSubcommand();

    if (sub === 'setup') {
      const role = interaction.options.getRole('role');
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      const minDays = interaction.options.getInteger('min_account_days') || 0;
      const message = interaction.options.getString('message') || 'Click the button below to verify and gain access to the server.';
      verification.setSettings(interaction.guildId, { roleId: role.id, minAccountDays: minDays });
      const embed = new EmbedBuilder().setColor(config.brand.color).setTitle('✅ Verification').setDescription(message);
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('verify:go').setLabel('Verify').setEmoji('✅').setStyle(ButtonStyle.Success)
      );
      await channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ content: `✅ Verification set to <@&${role.id}>${minDays ? ` (min account age ${minDays}d)` : ''}. Panel posted in ${channel}.`, ephemeral: true });
    }
    if (sub === 'disable') {
      verification.setSettings(interaction.guildId, { roleId: null });
      return interaction.reply({ content: 'Verification disabled.', ephemeral: true });
    }
    // status
    const s = verification.getSettings(interaction.guildId);
    return interaction.reply({ content: s.roleId ? `Verified role: <@&${s.roleId}>${s.minAccountDays ? ` • min account age ${s.minAccountDays}d` : ''}.` : 'Verification isn’t set up. Use `/mod verify setup`.', ephemeral: true });
  },
};

module.exports = verifyCmd;
