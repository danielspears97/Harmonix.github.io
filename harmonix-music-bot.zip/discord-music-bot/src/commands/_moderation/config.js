'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const modlog = require('../../moderation/modlog');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const modlogCmd = {
  data: new SlashCommandBuilder()
    .setName('modlog')
    .setDescription('Configure the moderation log channel')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Set the channel where moderation cases are posted')
        .addChannelOption((o) =>
          o.setName('channel').setDescription('Target channel').addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
    )
    .addSubcommand((s) => s.setName('disable').setDescription('Stop posting moderation cases'))
    .addSubcommand((s) => s.setName('status').setDescription('Show the current mod-log channel')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();
    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel');
      modlog.setModlogChannel(interaction.guildId, channel.id);
      return interaction.reply({ content: `📋 Moderation cases will now be posted in ${channel}.`, ephemeral: true });
    }
    if (sub === 'disable') {
      modlog.disableModlog(interaction.guildId);
      return interaction.reply({ content: 'Mod-log disabled. Cases are still recorded and viewable with `/case`.', ephemeral: true });
    }
    // status
    const id = modlog.getModlogChannelId(interaction.guildId);
    return interaction.reply({
      content: id ? `Mod-log is set to <#${id}>.` : 'No mod-log channel is set. Use `/mod modlog set`.',
      ephemeral: true,
    });
  },
};

module.exports = modlogCmd;
