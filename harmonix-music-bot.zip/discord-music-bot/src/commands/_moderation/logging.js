'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');
const logger = require('../../moderation/logger');
const { config } = require('../../../config');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const TYPE_CHOICES = [
  { name: 'Message deletions', value: 'messageDelete' },
  { name: 'Message edits', value: 'messageEdit' },
  { name: 'Member joins', value: 'memberJoin' },
  { name: 'Member leaves', value: 'memberLeave' },
  { name: 'Nickname / role changes', value: 'memberUpdate' },
  { name: 'Voice activity', value: 'voice' },
  { name: 'Bans / unbans', value: 'bans' },
];
const LABEL = Object.fromEntries(TYPE_CHOICES.map((c) => [c.value, c.name]));

const loggingCmd = {
  data: new SlashCommandBuilder()
    .setName('logging')
    .setDescription('Configure the server event log')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Set the channel where server events are logged')
        .addChannelOption((o) => o.setName('channel').setDescription('Log channel').addChannelTypes(ChannelType.GuildText).setRequired(true))
    )
    .addSubcommand((s) => s.setName('disable').setDescription('Turn off the event log'))
    .addSubcommand((s) =>
      s
        .setName('toggle')
        .setDescription('Enable or disable a specific event type')
        .addStringOption((o) => o.setName('type').setDescription('Event type').setRequired(true).addChoices(...TYPE_CHOICES))
        .addBooleanOption((o) => o.setName('enabled').setDescription('On or off').setRequired(true))
    )
    .addSubcommand((s) => s.setName('status').setDescription('Show current logging settings')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel');
      logger.setChannel(interaction.guildId, channel.id);
      return interaction.reply({ content: `📋 Server events will now be logged in ${channel}.`, ephemeral: true });
    }
    if (sub === 'disable') {
      logger.setChannel(interaction.guildId, null);
      return interaction.reply({ content: 'Event logging disabled.', ephemeral: true });
    }
    if (sub === 'toggle') {
      const type = interaction.options.getString('type');
      const on = interaction.options.getBoolean('enabled');
      logger.setType(interaction.guildId, type, on);
      return interaction.reply({ content: `${on ? '✅ Enabled' : '🚫 Disabled'} logging for **${LABEL[type]}**.`, ephemeral: true });
    }

    // status
    const s = logger.getSettings(interaction.guildId);
    const lines = logger.TYPES.map((t) => `${s.types[t] !== false ? '✅' : '🚫'} ${LABEL[t]}`);
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setTitle('📋 Event Logging')
      .setDescription(s.channelId ? `Logging to <#${s.channelId}>` : 'No log channel set — use `/mod logging set`.')
      .addFields({ name: 'Event types', value: lines.join('\n') });
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

module.exports = loggingCmd;
