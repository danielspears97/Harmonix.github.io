'use strict';

const {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
} = require('discord.js');
const tickets = require('../../moderation/tickets');
const { closeTicket } = require('../../handlers/tickets');
const { config } = require('../../../config');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const ticketCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Support ticket system')
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName('setup')
        .setDescription('Configure the ticket system')
        .addChannelOption((o) => o.setName('category').setDescription('Category new tickets are created under').addChannelTypes(ChannelType.GuildCategory).setRequired(false))
        .addRoleOption((o) => o.setName('staffrole').setDescription('Role that can see & claim tickets').setRequired(false))
        .addChannelOption((o) => o.setName('logchannel').setDescription('Channel that receives closed-ticket transcripts').addChannelTypes(ChannelType.GuildText).setRequired(false))
    )
    .addSubcommand((s) =>
      s
        .setName('panel')
        .setDescription('Post a ticket panel with an Open button')
        .addChannelOption((o) => o.setName('channel').setDescription('Where to post (defaults to here)').addChannelTypes(ChannelType.GuildText).setRequired(false))
        .addStringOption((o) => o.setName('message').setDescription('Custom panel message').setRequired(false))
    )
    .addSubcommand((s) => s.setName('close').setDescription('Close the current ticket'))
    .addSubcommand((s) => s.setName('add').setDescription('Add a user to the current ticket').addUserOption((o) => o.setName('user').setDescription('User to add').setRequired(true)))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove a user from the current ticket').addUserOption((o) => o.setName('user').setDescription('User to remove').setRequired(true))),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const settings = tickets.getSettings(interaction.guildId);

    if (sub === 'setup') {
      if (!interaction.memberPermissions.has(MANAGE_GUILD)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
      const category = interaction.options.getChannel('category');
      const staff = interaction.options.getRole('staffrole');
      const log = interaction.options.getChannel('logchannel');
      const patch = {};
      if (category) patch.categoryId = category.id;
      if (staff) patch.staffRoleId = staff.id;
      if (log) patch.logChannelId = log.id;
      const next = tickets.setSettings(interaction.guildId, patch);
      const embed = new EmbedBuilder()
        .setColor(config.brand.color)
        .setTitle('🎟️ Ticket settings')
        .addFields(
          { name: 'Category', value: next.categoryId ? `<#${next.categoryId}>` : 'None (tickets created at top level)', inline: true },
          { name: 'Staff role', value: next.staffRoleId ? `<@&${next.staffRoleId}>` : 'None (Manage Messages only)', inline: true },
          { name: 'Transcript log', value: next.logChannelId ? `<#${next.logChannelId}>` : 'None (opener DM only)', inline: true }
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'panel') {
      if (!interaction.memberPermissions.has(MANAGE_GUILD)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      const message = interaction.options.getString('message') || 'Need help? Click the button below to open a private support ticket with the team.';
      const embed = new EmbedBuilder().setColor(config.brand.color).setTitle('🎟️ Support Tickets').setDescription(message);
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket:open').setLabel('Open a ticket').setEmoji('🎟️').setStyle(ButtonStyle.Primary)
      );
      await channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ content: `✅ Panel posted in ${channel}.`, ephemeral: true });
    }

    if (sub === 'close') {
      return closeTicket(client, interaction, settings);
    }

    // add / remove a user
    const ticket = tickets.getByChannel(interaction.channelId);
    if (!ticket) return interaction.reply({ content: 'Run this inside a ticket channel.', ephemeral: true });
    const isStaff = (settings.staffRoleId && interaction.member.roles.cache.has(settings.staffRoleId)) || interaction.memberPermissions.has(PermissionFlagsBits.ManageMessages);
    if (!isStaff) return interaction.reply({ content: 'Only staff can manage ticket members.', ephemeral: true });
    const user = interaction.options.getUser('user');

    if (sub === 'add') {
      await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true }).catch(() => {});
      return interaction.reply({ content: `➕ Added <@${user.id}> to the ticket.` });
    }
    if (sub === 'remove') {
      await interaction.channel.permissionOverwrites.delete(user.id).catch(() => {});
      return interaction.reply({ content: `➖ Removed <@${user.id}> from the ticket.` });
    }
  },
};

module.exports = ticketCmd;
