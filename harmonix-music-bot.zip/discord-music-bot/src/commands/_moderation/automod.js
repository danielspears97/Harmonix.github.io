'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const automod = require('../../moderation/automod');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const RULE_LABELS = {
  invites: 'Discord invite links',
  links: 'All links',
  mentions: 'Mention spam',
  caps: 'Excessive caps',
  words: 'Blocked words',
  spam: 'Fast message spam',
};

const command = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Configure automatic message moderation')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) => s.setName('status').setDescription('Show current automod settings'))
    .addSubcommand((s) =>
      s
        .setName('rule')
        .setDescription('Enable or disable a filter')
        .addStringOption((o) =>
          o
            .setName('name')
            .setDescription('Which filter')
            .setRequired(true)
            .addChoices(...automod.RULES.map((r) => ({ name: r, value: r })))
        )
        .addBooleanOption((o) => o.setName('enabled').setDescription('On or off').setRequired(true))
    )
    .addSubcommandGroup((g) =>
      g
        .setName('exempt')
        .setDescription('Roles that bypass automod')
        .addSubcommand((s) =>
          s.setName('add').setDescription('Add an exempt role').addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('remove').setDescription('Remove an exempt role').addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true))
        )
    )
    .addSubcommandGroup((g) =>
      g
        .setName('words')
        .setDescription('Manage the blocked-word list')
        .addSubcommand((s) =>
          s.setName('add').setDescription('Block a word').addStringOption((o) => o.setName('word').setDescription('Word to block').setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('remove').setDescription('Unblock a word').addStringOption((o) => o.setName('word').setDescription('Word to unblock').setRequired(true))
        )
        .addSubcommand((s) => s.setName('list').setDescription('Show blocked words'))
        .addSubcommand((s) => s.setName('clear').setDescription('Clear the blocked-word list'))
    ),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const gid = interaction.guildId;
    const settings = automod.getSettings(gid);
    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();

    // /automod rule
    if (!group && sub === 'rule') {
      const name = interaction.options.getString('name');
      const enabled = interaction.options.getBoolean('enabled');
      settings.rules[name] = enabled;
      automod.saveSettings(gid, settings);
      let extra = '';
      if (name === 'words' && enabled && settings.words.length === 0) {
        extra = '\n*Tip: add words with `/automod words add`.*';
      }
      return interaction.reply({
        content: `🛡️ **${RULE_LABELS[name]}** filter is now **${enabled ? 'ON' : 'OFF'}**.${extra}`,
        ephemeral: true,
      });
    }

    // /automod exempt add|remove
    if (group === 'exempt') {
      const role = interaction.options.getRole('role');
      const set = new Set(settings.exemptRoles);
      if (sub === 'add') set.add(role.id);
      else set.delete(role.id);
      settings.exemptRoles = [...set];
      automod.saveSettings(gid, settings);
      return interaction.reply({
        content: sub === 'add' ? `${role} is now exempt from automod.` : `${role} is no longer exempt.`,
        ephemeral: true,
      });
    }

    // /automod words ...
    if (group === 'words') {
      if (sub === 'add') {
        const word = interaction.options.getString('word').toLowerCase().trim();
        if (!settings.words.includes(word)) settings.words.push(word);
        automod.saveSettings(gid, settings);
        return interaction.reply({ content: `Added a blocked word. (${settings.words.length} total)`, ephemeral: true });
      }
      if (sub === 'remove') {
        const word = interaction.options.getString('word').toLowerCase().trim();
        settings.words = settings.words.filter((w) => w !== word);
        automod.saveSettings(gid, settings);
        return interaction.reply({ content: `Removed. (${settings.words.length} remaining)`, ephemeral: true });
      }
      if (sub === 'clear') {
        settings.words = [];
        automod.saveSettings(gid, settings);
        return interaction.reply({ content: 'Blocked-word list cleared.', ephemeral: true });
      }
      // list
      return interaction.reply({
        content: settings.words.length ? `Blocked words: ${settings.words.map((w) => `\`${w}\``).join(', ')}` : 'No blocked words set.',
        ephemeral: true,
      });
    }

    // /automod status
    const lines = automod.RULES.map((r) => `${settings.rules[r] ? '🟢' : '⚪'} **${RULE_LABELS[r]}**`);
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setTitle('🛡️ AutoMod settings')
      .setDescription(lines.join('\n'))
      .addFields(
        { name: 'Exempt roles', value: settings.exemptRoles.length ? settings.exemptRoles.map((id) => `<@&${id}>`).join(' ') : 'None', inline: false },
        { name: 'Blocked words', value: String(settings.words.length), inline: true }
      )
      .setFooter({ text: 'Members with Manage Messages always bypass automod.' });
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

module.exports = command;
