'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');
const antiraid = require('../../moderation/antiraid');
const { config } = require('../../../config');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const antiraidCmd = {
  data: new SlashCommandBuilder()
    .setName('antiraid')
    .setDescription('Raid protection')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) => s.setName('enable').setDescription('Turn raid protection on'))
    .addSubcommand((s) => s.setName('disable').setDescription('Turn raid protection off'))
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Tune raid-protection thresholds')
        .addIntegerOption((o) => o.setName('threshold').setDescription('Joins that trigger a raid').setMinValue(3).setMaxValue(50).setRequired(false))
        .addIntegerOption((o) => o.setName('window').setDescription('Time window in seconds').setMinValue(3).setMaxValue(120).setRequired(false))
        .addStringOption((o) => o.setName('action').setDescription('What to do to raiders').addChoices({ name: 'kick', value: 'kick' }, { name: 'timeout', value: 'timeout' }).setRequired(false))
        .addIntegerOption((o) => o.setName('min_account_days').setDescription('Block accounts younger than this many days (0 = off)').setMinValue(0).setMaxValue(365).setRequired(false))
        .addChannelOption((o) => o.setName('alert_channel').setDescription('Where to post raid alerts (defaults to log channel)').addChannelTypes(ChannelType.GuildText).setRequired(false))
    )
    .addSubcommand((s) => s.setName('status').setDescription('Show raid-protection settings')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const sub = interaction.options.getSubcommand();

    if (sub === 'enable') { antiraid.setSettings(interaction.guildId, { enabled: true }); return interaction.reply({ content: '🛡️ Raid protection **enabled**.', ephemeral: true }); }
    if (sub === 'disable') { antiraid.setSettings(interaction.guildId, { enabled: false }); antiraid.clearRaid(interaction.guildId); return interaction.reply({ content: 'Raid protection **disabled**.', ephemeral: true }); }

    if (sub === 'config') {
      const patch = {};
      const threshold = interaction.options.getInteger('threshold');
      const window = interaction.options.getInteger('window');
      const action = interaction.options.getString('action');
      const minDays = interaction.options.getInteger('min_account_days');
      const alert = interaction.options.getChannel('alert_channel');
      if (threshold != null) patch.threshold = threshold;
      if (window != null) patch.windowSec = window;
      if (action) patch.action = action;
      if (minDays != null) patch.minAccountDays = minDays;
      if (alert) patch.alertChannelId = alert.id;
      antiraid.setSettings(interaction.guildId, patch);
    }

    const s = antiraid.getSettings(interaction.guildId);
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setTitle('🛡️ Anti-raid')
      .setDescription(s.enabled ? 'Protection is **on**.' : 'Protection is **off**.')
      .addFields(
        { name: 'Trigger', value: `${s.threshold} joins / ${s.windowSec}s`, inline: true },
        { name: 'Action', value: s.action === 'timeout' ? `timeout ${s.timeoutMin}m` : 'kick', inline: true },
        { name: 'Min account age', value: s.minAccountDays ? `${s.minAccountDays}d` : 'off', inline: true },
        { name: 'Alerts', value: s.alertChannelId ? `<#${s.alertChannelId}>` : 'log channel (if set)', inline: true }
      );
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

module.exports = antiraidCmd;
