'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const modlog = require('../../moderation/modlog');
const { actionable, notifyTarget } = require('../../utils/modGuards');
const { userTag } = require('../../utils/format');

const KICK = PermissionFlagsBits.KickMembers;
const BAN = PermissionFlagsBits.BanMembers;

function confirm(action, target, caseNumber, reason, note) {
  return new EmbedBuilder()
    .setColor(config.brand.successColor)
    .setDescription(
      `${action} **${userTag(target)}** • Case #${caseNumber}\n` +
        `**Reason:** ${reason || '*No reason provided*'}` +
        (note ? `\n*${note}*` : '')
    );
}

// ── /kick ────────────────────────────────────────────────────────
const kick = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .setDMPermission(false)
    .setDefaultMemberPermissions(KICK)
    .addUserOption((o) => o.setName('user').setDescription('Member to kick').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(KICK)) {
      return interaction.reply({ content: 'You need the **Kick Members** permission.', ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    if (!member) return interaction.reply({ content: 'That user isn’t in this server.', ephemeral: true });

    const guard = actionable(interaction, member, 'kick');
    if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });

    await interaction.deferReply();
    const dmed = await notifyTarget(target, interaction.guild.name, 'kicked', reason);
    try {
      await member.kick(`${userTag(interaction.user)}: ${reason || 'No reason'}`);
    } catch (err) {
      return interaction.editReply({ content: `Failed to kick: ${err.message}` });
    }
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'kick', targetId: target.id, targetTag: userTag(target),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason,
    });
    return interaction.editReply({
      embeds: [confirm('👢 Kicked', target, caseRow.case_number, reason, dmed ? null : 'Couldn’t DM the user.')],
    });
  },
};

// ── /ban ─────────────────────────────────────────────────────────
const ban = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user (works even if they’ve left)')
    .setDMPermission(false)
    .setDefaultMemberPermissions(BAN)
    .addUserOption((o) => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(false))
    .addIntegerOption((o) =>
      o.setName('delete_days').setDescription('Delete this many days of their messages (0-7)').setMinValue(0).setMaxValue(7)
    ),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(BAN)) {
      return interaction.reply({ content: 'You need the **Ban Members** permission.', ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    const days = interaction.options.getInteger('delete_days') ?? 0;

    // Guard whether the target is in the guild or not.
    if (member) {
      const guard = actionable(interaction, member, 'ban');
      if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });
    } else {
      if (target.id === interaction.user.id) return interaction.reply({ content: 'You can’t ban yourself.', ephemeral: true });
      if (target.id === client.user.id) return interaction.reply({ content: 'I can’t ban myself.', ephemeral: true });
      if (target.id === interaction.guild.ownerId) return interaction.reply({ content: 'I can’t ban the server owner.', ephemeral: true });
    }

    await interaction.deferReply();
    const dmed = member ? await notifyTarget(target, interaction.guild.name, 'banned', reason) : false;
    try {
      await interaction.guild.members.ban(target.id, {
        deleteMessageSeconds: days * 86400,
        reason: `${userTag(interaction.user)}: ${reason || 'No reason'}`,
      });
    } catch (err) {
      return interaction.editReply({ content: `Failed to ban: ${err.message}` });
    }
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'ban', targetId: target.id, targetTag: userTag(target),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason,
    });
    return interaction.editReply({
      embeds: [confirm('🔨 Banned', target, caseRow.case_number, reason, member && !dmed ? 'Couldn’t DM the user.' : null)],
    });
  },
};

// ── /unban ───────────────────────────────────────────────────────
const unban = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by ID')
    .setDMPermission(false)
    .setDefaultMemberPermissions(BAN)
    .addStringOption((o) => o.setName('user_id').setDescription('The ID of the banned user').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(BAN)) {
      return interaction.reply({ content: 'You need the **Ban Members** permission.', ephemeral: true });
    }
    const id = interaction.options.getString('user_id').trim();
    const reason = interaction.options.getString('reason');
    if (!/^\d{16,20}$/.test(id)) {
      return interaction.reply({ content: 'That doesn’t look like a valid user ID.', ephemeral: true });
    }
    await interaction.deferReply();

    const existing = await interaction.guild.bans.fetch(id).catch(() => null);
    if (!existing) return interaction.editReply({ content: 'That user isn’t banned here.' });

    try {
      await interaction.guild.bans.remove(id, `${userTag(interaction.user)}: ${reason || 'No reason'}`);
    } catch (err) {
      return interaction.editReply({ content: `Failed to unban: ${err.message}` });
    }
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'unban', targetId: id, targetTag: userTag(existing.user),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason,
    });
    return interaction.editReply({
      embeds: [confirm('♻️ Unbanned', existing.user, caseRow.case_number, reason, null)],
    });
  },
};

module.exports = [kick, ban, unban];
