'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

const MANAGE_MSG = PermissionFlagsBits.ManageMessages;
const MANAGE_CH = PermissionFlagsBits.ManageChannels;

// ── /purge ───────────────────────────────────────────────────────
const purge = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Bulk-delete recent messages in this channel')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_MSG)
    .addIntegerOption((o) =>
      o.setName('amount').setDescription('How many messages (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)
    )
    .addUserOption((o) => o.setName('user').setDescription('Only delete messages from this user').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_MSG)) {
      return interaction.reply({ content: 'You need the **Manage Messages** permission.', ephemeral: true });
    }
    const amount = interaction.options.getInteger('amount');
    const user = interaction.options.getUser('user');
    await interaction.deferReply({ ephemeral: true });

    let deleted;
    try {
      if (user) {
        const fetched = await interaction.channel.messages.fetch({ limit: 100 });
        const mine = [...fetched.filter((m) => m.author.id === user.id).values()].slice(0, amount);
        deleted = await interaction.channel.bulkDelete(mine, true);
      } else {
        deleted = await interaction.channel.bulkDelete(amount, true);
      }
    } catch (err) {
      return interaction.editReply({ content: `Failed to purge: ${err.message}` });
    }
    const n = deleted.size;
    const note = n < amount ? ' (older messages can’t be bulk-deleted after 14 days)' : '';
    return interaction.editReply({
      content: `🧹 Deleted **${n}** message${n === 1 ? '' : 's'}${user ? ` from ${user}` : ''}.${note}`,
    });
  },
};

// ── /slowmode ────────────────────────────────────────────────────
const slowmode = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set this channel’s slowmode delay')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_CH)
    .addIntegerOption((o) =>
      o.setName('seconds').setDescription('Delay in seconds (0 to disable, max 21600)').setRequired(true).setMinValue(0).setMaxValue(21600)
    )
    .addChannelOption((o) =>
      o.setName('channel').setDescription('Channel (defaults to here)').addChannelTypes(ChannelType.GuildText).setRequired(false)
    ),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_CH)) {
      return interaction.reply({ content: 'You need the **Manage Channels** permission.', ephemeral: true });
    }
    const seconds = interaction.options.getInteger('seconds');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    try {
      await channel.setRateLimitPerUser(seconds, `Set by ${interaction.user.username}`);
    } catch (err) {
      return interaction.reply({ content: `Failed to set slowmode: ${err.message}`, ephemeral: true });
    }
    const msg = seconds === 0 ? `Slowmode disabled in ${channel}.` : `Slowmode in ${channel} set to **${seconds}s**.`;
    return interaction.reply({ content: `🐌 ${msg}`, ephemeral: true });
  },
};

module.exports = [purge, slowmode];
