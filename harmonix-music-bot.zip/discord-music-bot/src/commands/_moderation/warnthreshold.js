'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const warnThresholds = require('../../moderation/warnThresholds');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const warnthreshold = {
  data: new SlashCommandBuilder()
    .setName('warnthreshold')
    .setDescription('Auto-escalation rules based on warning count')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Add or replace a rule at a warning count')
        .addIntegerOption((o) => o.setName('count').setDescription('Warning count that triggers it').setRequired(true).setMinValue(1).setMaxValue(50))
        .addStringOption((o) => o.setName('action').setDescription('Action to take').setRequired(true).addChoices({ name: 'timeout', value: 'timeout' }, { name: 'kick', value: 'kick' }, { name: 'ban', value: 'ban' }))
        .addIntegerOption((o) => o.setName('timeout_minutes').setDescription('Timeout length (for the timeout action)').setMinValue(1).setMaxValue(40320).setRequired(false))
    )
    .addSubcommand((s) => s.setName('remove').setDescription('Remove the rule at a warning count').addIntegerOption((o) => o.setName('count').setDescription('Warning count').setRequired(true).setMinValue(1)))
    .addSubcommand((s) => s.setName('list').setDescription('List all auto-escalation rules')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const count = interaction.options.getInteger('count');
      const action = interaction.options.getString('action');
      const mins = interaction.options.getInteger('timeout_minutes') || (action === 'timeout' ? 10 : 0);
      warnThresholds.add(interaction.guildId, count, action, mins);
      return interaction.reply({ content: `✅ At **${count}** warning(s) → **${action}**${action === 'timeout' ? ` for ${mins}m` : ''}.`, ephemeral: true });
    }
    if (sub === 'remove') {
      const count = interaction.options.getInteger('count');
      warnThresholds.remove(interaction.guildId, count);
      return interaction.reply({ content: `Removed any rule at **${count}** warning(s).`, ephemeral: true });
    }
    // list
    const rules = warnThresholds.list(interaction.guildId);
    if (!rules.length) return interaction.reply({ content: 'No auto-escalation rules set. Add one with `/mod warnthreshold add`.', ephemeral: true });
    const lines = rules.map((r) => `• **${r.count}** warns → ${r.action}${r.action === 'timeout' ? ` (${r.durationMin}m)` : ''}`);
    const embed = new EmbedBuilder().setColor(config.brand.color).setTitle('⚖️ Warn auto-escalation').setDescription(lines.join('\n'));
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

module.exports = warnthreshold;
