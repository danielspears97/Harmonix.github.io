'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const modlog = require('../../moderation/modlog');
const { actionable, notifyTarget } = require('../../utils/modGuards');
const { userTag } = require('../../utils/format');
const { parseDuration, humanizeDuration } = require('../../utils/duration');

const MOD = PermissionFlagsBits.ModerateMembers;
const MAX_TIMEOUT = 28 * 24 * 60 * 60 * 1000; // Discord hard limit

const timeout = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Temporarily mute a member (Discord timeout)')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addUserOption((o) => o.setName('user').setDescription('Member to time out').setRequired(true))
    .addStringOption((o) =>
      o.setName('duration').setDescription('e.g. 10m, 1h, 1d (max 28d)').setRequired(true)
    )
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) {
      return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    if (!member) return interaction.reply({ content: 'That user isn’t in this server.', ephemeral: true });

    let ms = parseDuration(interaction.options.getString('duration'));
    if (!ms || ms < 1000) {
      return interaction.reply({ content: 'Invalid duration. Try `10m`, `1h`, or `1d`.', ephemeral: true });
    }
    if (ms > MAX_TIMEOUT) ms = MAX_TIMEOUT;

    const guard = actionable(interaction, member, 'timeout');
    if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });

    await interaction.deferReply();
    try {
      await member.timeout(ms, `${userTag(interaction.user)}: ${reason || 'No reason'}`);
    } catch (err) {
      return interaction.editReply({ content: `Failed to time out: ${err.message}` });
    }
    const dmed = await notifyTarget(
      target, interaction.guild.name, `timed out for ${humanizeDuration(ms)}`, reason
    );
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'timeout', targetId: target.id, targetTag: userTag(target),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason, durationMs: ms,
    });
    const embed = new EmbedBuilder()
      .setColor(0xf59e0b)
      .setDescription(
        `⏳ **Timed out ${userTag(target)}** for **${humanizeDuration(ms)}** • Case #${caseRow.case_number}\n` +
          `**Reason:** ${reason || '*No reason provided*'}` +
          (dmed ? '' : '\n*Couldn’t DM the user.*')
      );
    return interaction.editReply({ embeds: [embed] });
  },
};

const untimeout = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Remove a member’s timeout')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addUserOption((o) => o.setName('user').setDescription('Member to un-timeout').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) {
      return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    if (!member) return interaction.reply({ content: 'That user isn’t in this server.', ephemeral: true });
    if (!member.isCommunicationDisabled()) {
      return interaction.reply({ content: `**${userTag(target)}** isn’t timed out.`, ephemeral: true });
    }

    const guard = actionable(interaction, member, 'untimeout');
    if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });

    await interaction.deferReply();
    try {
      await member.timeout(null, `${userTag(interaction.user)}: ${reason || 'Timeout removed'}`);
    } catch (err) {
      return interaction.editReply({ content: `Failed to remove timeout: ${err.message}` });
    }
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'untimeout', targetId: target.id, targetTag: userTag(target),
      moderatorId: interaction.user.id, moderatorTag: userTag(interaction.user), reason,
    });
    const embed = new EmbedBuilder()
      .setColor(config.brand.successColor)
      .setDescription(`🔓 **Removed timeout** from ${userTag(target)} • Case #${caseRow.case_number}`);
    return interaction.editReply({ embeds: [embed] });
  },
};

module.exports = [timeout, untimeout];
