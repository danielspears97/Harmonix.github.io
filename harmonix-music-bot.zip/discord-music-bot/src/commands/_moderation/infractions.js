'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const cases = require('../../moderation/cases');
const modlog = require('../../moderation/modlog');
const { actionable, notifyTarget } = require('../../utils/modGuards');
const { userTag } = require('../../utils/format');
const { humanizeDuration } = require('../../utils/duration');
const warnThresholds = require('../../moderation/warnThresholds');

const MOD = PermissionFlagsBits.ModerateMembers;

// ── /warn ────────────────────────────────────────────────────────
const warn = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member (logged as a case)')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addUserOption((o) => o.setName('user').setDescription('Member to warn').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the warning').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) {
      return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');

    const guard = actionable(interaction, member, 'warn');
    if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });

    await interaction.deferReply();
    const caseRow = await modlog.record(client, interaction.guildId, {
      action: 'warn',
      targetId: target.id,
      targetTag: userTag(target),
      moderatorId: interaction.user.id,
      moderatorTag: userTag(interaction.user),
      reason,
    });
    const dmed = member ? await notifyTarget(target, interaction.guild.name, 'warned', reason) : false;
    const total = cases.countActions(interaction.guildId, target.id, 'warn');

    // Auto-escalation: if this warning lands on a configured threshold, act.
    const rule = warnThresholds.matchFor(interaction.guildId, total);
    const autoNote = rule ? await warnThresholds.apply(client, interaction.guild, target, member, rule) : null;

    const embed = new EmbedBuilder()
      .setColor(0xf59e0b)
      .setDescription(
        `⚠️ **Warned ${userTag(target)}** • Case #${caseRow.case_number}\n` +
          `**Reason:** ${reason || '*No reason provided*'}\n` +
          `This user now has **${total}** warning${total === 1 ? '' : 's'}.` +
          (member && !dmed ? `\n*Couldn’t DM the user (their DMs are closed).*` : '') +
          (autoNote ? `\n${autoNote}` : '')
      );
    return interaction.editReply({ embeds: [embed] });
  },
};

// ── /warnings ────────────────────────────────────────────────────
const warnings = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('List a member’s moderation history')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addUserOption((o) => o.setName('user').setDescription('Member to look up').setRequired(true)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) {
      return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const history = cases.getHistory(interaction.guildId, target.id, { limit: 15 });
    if (history.length === 0) {
      return interaction.reply({ content: `**${userTag(target)}** has a clean record. ✨`, ephemeral: true });
    }
    const lines = history.map((c) => {
      const meta = modlog.ACTION_META[c.action] || { emoji: '📝', label: c.action };
      const dur = c.duration_ms ? ` (${humanizeDuration(c.duration_ms)})` : '';
      const when = `<t:${Math.floor(c.created_at / 1000)}:R>`;
      return `\`#${c.case_number}\` ${meta.emoji} **${meta.label}**${dur} — ${c.reason || '*no reason*'} · ${when}`;
    });
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setAuthor({ name: `Moderation history — ${userTag(target)}` })
      .setDescription(lines.join('\n'))
      .setFooter({ text: `User ID: ${target.id} • showing ${history.length} most recent` });
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// ── /case ────────────────────────────────────────────────────────
const caseCmd = {
  data: new SlashCommandBuilder()
    .setName('case')
    .setDescription('View a moderation case by number')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addIntegerOption((o) => o.setName('number').setDescription('Case number').setRequired(true).setMinValue(1)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) {
      return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    }
    const n = interaction.options.getInteger('number');
    const row = cases.getCase(interaction.guildId, n);
    if (!row) return interaction.reply({ content: `No case **#${n}** found.`, ephemeral: true });
    return interaction.reply({ embeds: [modlog.buildCaseEmbed(row)], ephemeral: true });
  },
};

// ── /reason (edit a case) ────────────────────────────────────────
const reason = {
  data: new SlashCommandBuilder()
    .setName('reason')
    .setDescription('Update the reason on an existing case')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MOD)
    .addIntegerOption((o) => o.setName('number').setDescription('Case number').setRequired(true).setMinValue(1))
    .addStringOption((o) => o.setName('reason').setDescription('New reason').setRequired(true)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MOD)) {
      return interaction.reply({ content: 'You need the **Moderate Members** permission.', ephemeral: true });
    }
    const n = interaction.options.getInteger('number');
    const newReason = interaction.options.getString('reason');
    const ok = cases.setReason(interaction.guildId, n, newReason);
    if (!ok) return interaction.reply({ content: `No case **#${n}** found.`, ephemeral: true });
    return interaction.reply({ content: `✅ Updated the reason for case **#${n}**.`, ephemeral: true });
  },
};

module.exports = [warn, warnings, caseCmd, reason];
