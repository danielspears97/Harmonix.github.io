'use strict';

const { SlashCommandBuilder } = require('discord.js');
const controller = require('../controller');
const dj = require('../music/dj');
const { voiceGuard } = require('../utils/guards');

const CHOICES = [
  { name: 'off (clear filters)', value: 'off' },
  { name: 'bass boost', value: 'bassboost' },
  { name: 'nightcore', value: 'nightcore' },
  { name: 'vaporwave', value: 'vaporwave' },
  { name: '8D', value: '8d' },
  { name: 'karaoke', value: 'karaoke' },
  { name: 'treble', value: 'treble' },
  { name: 'lowpass (muffle)', value: 'lowpass' },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('filter')
    .setDescription('Apply an audio filter to playback')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('type').setDescription('Filter to apply').setRequired(true).addChoices(...CHOICES)),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return interaction.reply({ content: g.msg, ephemeral: true });
    if (!dj.isDJ(interaction)) return interaction.reply({ content: '🔒 Filters are DJ-only on this server.', ephemeral: true });

    const player = controller.getPlayer(client, interaction.guildId);
    if (!player || !player.queue.current) return interaction.reply({ content: 'Nothing is playing.', ephemeral: true });

    const type = interaction.options.getString('type');
    const fm = player.filterManager;
    await interaction.deferReply();
    try {
      // resetFilters() clears toggle filters but NOT the equalizer bands, so
      // clear the EQ explicitly too — otherwise bass boost / treble persist.
      await fm.clearEQ();
      await fm.resetFilters();
      if (type === 'bassboost') await fm.setEQ([{ band: 0, gain: 0.6 }, { band: 1, gain: 0.67 }, { band: 2, gain: 0.5 }, { band: 3, gain: 0.35 }, { band: 4, gain: 0.1 }]);
      else if (type === 'treble') await fm.setEQ([{ band: 9, gain: 0.2 }, { band: 10, gain: 0.3 }, { band: 11, gain: 0.4 }, { band: 12, gain: 0.45 }, { band: 13, gain: 0.5 }]);
      else if (type === 'nightcore') await fm.toggleNightcore();
      else if (type === 'vaporwave') await fm.toggleVaporwave();
      else if (type === '8d') await fm.toggleRotation();
      else if (type === 'karaoke') await fm.toggleKaraoke();
      else if (type === 'lowpass') await fm.toggleLowPass();
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t apply that filter: ${err.message}` });
    }
    const label = CHOICES.find((c) => c.value === type)?.name || type;
    return interaction.editReply({ content: type === 'off' ? '🎛️ Filters cleared.' : `🎛️ Filter applied: **${label}**.` });
  },
};
