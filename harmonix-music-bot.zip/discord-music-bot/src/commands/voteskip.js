'use strict';

const { SlashCommandBuilder } = require('discord.js');
const controller = require('../controller');
const dj = require('../music/dj');
const voteskip = require('../music/voteskip');
const { voiceGuard } = require('../utils/guards');

module.exports = {
  data: new SlashCommandBuilder().setName('voteskip').setDescription('Vote to skip the current track').setDMPermission(false),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return interaction.reply({ content: g.msg, ephemeral: true });
    const player = controller.getPlayer(client, interaction.guildId);
    if (!player || !player.queue.current) return interaction.reply({ content: 'Nothing is playing.', ephemeral: true });

    // DJs / admins skip instantly.
    if (dj.isDJ(interaction) && dj.getRole(interaction.guildId)) {
      await controller.skip(client, interaction.guildId);
      voteskip.reset(interaction.guildId);
      return interaction.reply({ content: '⏭️ Skipped (DJ).' });
    }

    const channel = client.channels.cache.get(player.voiceChannelId);
    const listeners = channel ? channel.members.filter((m) => !m.user.bot).size : 1;
    if (listeners <= 1) {
      await controller.skip(client, interaction.guildId);
      voteskip.reset(interaction.guildId);
      return interaction.reply({ content: '⏭️ Skipped.' });
    }
    const needed = Math.ceil(listeners / 2);
    const votes = voteskip.vote(interaction.guildId, player, interaction.user.id);
    if (votes >= needed) {
      await controller.skip(client, interaction.guildId);
      voteskip.reset(interaction.guildId);
      return interaction.reply({ content: `🗳️ Vote passed (${votes}/${needed}) — skipping!` });
    }
    return interaction.reply({ content: `🗳️ Skip vote: **${votes}/${needed}**. Use \`/voteskip\` to add your vote.` });
  },
};
