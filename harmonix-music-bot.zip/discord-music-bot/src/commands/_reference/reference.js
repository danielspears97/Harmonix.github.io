'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const { getJson } = require('../../utils/fetchJson');

const C = config.brand.color;

// ── /define ──────────────────────────────────────────────────────
const define = {
  data: new SlashCommandBuilder()
    .setName('define')
    .setDescription('Look up a word’s definition')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('word').setDescription('Word to define').setRequired(true)),
  async execute(client, interaction) {
    const word = interaction.options.getString('word').trim();
    await interaction.deferReply();
    try {
      const data = await getJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
      const entry = data[0];
      const embed = new EmbedBuilder()
        .setColor(C)
        .setTitle(`📖 ${entry.word}`)
        .setDescription(entry.phonetic || (entry.phonetics?.find((p) => p.text)?.text) || '');
      for (const m of entry.meanings.slice(0, 3)) {
        const defs = m.definitions.slice(0, 2).map((d, i) => `${i + 1}. ${d.definition}`).join('\n');
        embed.addFields({ name: m.partOfSpeech, value: defs.slice(0, 1000) });
      }
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `No definition found for **${word}**.` });
    }
  },
};

// ── /country ─────────────────────────────────────────────────────
const country = {
  data: new SlashCommandBuilder()
    .setName('country')
    .setDescription('Look up information about a country')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('name').setDescription('Country name').setRequired(true)),
  async execute(client, interaction) {
    const name = interaction.options.getString('name').trim();
    await interaction.deferReply();
    try {
      const data = await getJson(`https://restcountries.com/v3.1/name/${encodeURIComponent(name)}?fields=name,capital,population,region,subregion,flags,currencies,languages,timezones`);
      const c = data[0];
      const currencies = c.currencies ? Object.values(c.currencies).map((x) => x.name).join(', ') : '—';
      const languages = c.languages ? Object.values(c.languages).join(', ') : '—';
      const embed = new EmbedBuilder()
        .setColor(C)
        .setTitle(`${c.flags?.emoji || '🌍'} ${c.name.common}`)
        .addFields(
          { name: 'Capital', value: c.capital?.[0] || '—', inline: true },
          { name: 'Region', value: `${c.region}${c.subregion ? ` (${c.subregion})` : ''}`, inline: true },
          { name: 'Population', value: c.population.toLocaleString(), inline: true },
          { name: 'Currencies', value: currencies, inline: true },
          { name: 'Languages', value: languages, inline: true },
          { name: 'Timezones', value: (c.timezones || []).slice(0, 4).join(', ') || '—', inline: true }
        );
      if (c.flags?.png) embed.setThumbnail(c.flags.png);
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t find a country called **${name}**.` });
    }
  },
};

// ── /convert (currency) ──────────────────────────────────────────
const convert = {
  data: new SlashCommandBuilder()
    .setName('convert')
    .setDescription('Convert currency (ECB rates)')
    .setDMPermission(false)
    .addNumberOption((o) => o.setName('amount').setDescription('Amount').setRequired(true).setMinValue(0))
    .addStringOption((o) => o.setName('from').setDescription('From currency (e.g. USD)').setRequired(true))
    .addStringOption((o) => o.setName('to').setDescription('To currency (e.g. EUR)').setRequired(true)),
  async execute(client, interaction) {
    const amount = interaction.options.getNumber('amount');
    const from = interaction.options.getString('from').toUpperCase().trim();
    const to = interaction.options.getString('to').toUpperCase().trim();
    await interaction.deferReply();
    try {
      const data = await getJson(`https://api.frankfurter.dev/v1/latest?base=${encodeURIComponent(from)}&symbols=${encodeURIComponent(to)}`);
      const rate = data.rates?.[to];
      if (rate == null) throw new Error('unsupported currency');
      const result = (amount * rate).toLocaleString(undefined, { maximumFractionDigits: 2 });
      const embed = new EmbedBuilder()
        .setColor(C)
        .setAuthor({ name: '💱 Currency conversion' })
        .setDescription(`**${amount.toLocaleString()} ${from}** = **${result} ${to}**`)
        .setFooter({ text: `Rate: 1 ${from} = ${rate} ${to} • ECB via Frankfurter` });
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t convert ${from}→${to}. Check the 3-letter currency codes.` });
    }
  },
};

// ── /crypto ──────────────────────────────────────────────────────
const crypto = {
  data: new SlashCommandBuilder()
    .setName('crypto')
    .setDescription('Get a cryptocurrency’s price')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('coin').setDescription('Coin id or symbol (e.g. bitcoin, eth)').setRequired(true))
    .addStringOption((o) => o.setName('currency').setDescription('Fiat currency (default usd)').setRequired(false)),
  async execute(client, interaction) {
    const coin = interaction.options.getString('coin').toLowerCase().trim();
    const vs = (interaction.options.getString('currency') || 'usd').toLowerCase().trim();
    await interaction.deferReply();
    try {
      // Resolve symbol -> id via the coins list isn't worth a call here; CoinGecko
      // accepts common ids. Try the id directly, fall back to a search.
      let id = coin;
      const search = await getJson(`https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(coin)}`).catch(() => null);
      if (search?.coins?.length) {
        const exact = search.coins.find((c) => c.id === coin || c.symbol?.toLowerCase() === coin) || search.coins[0];
        id = exact.id;
      }
      const data = await getJson(
        `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(id)}&vs_currencies=${encodeURIComponent(vs)}&include_market_cap=true&include_24hr_change=true`
      );
      const d = data[id];
      if (!d || d[vs] == null) throw new Error('not found');
      const change = d[`${vs}_24h_change`];
      const arrow = change >= 0 ? '📈' : '📉';
      const embed = new EmbedBuilder()
        .setColor(C)
        .setAuthor({ name: `🪙 ${id} / ${vs.toUpperCase()}` })
        .addFields(
          { name: 'Price', value: `${d[vs].toLocaleString(undefined, { maximumFractionDigits: 8 })} ${vs.toUpperCase()}`, inline: true },
          { name: '24h', value: `${arrow} ${change != null ? change.toFixed(2) + '%' : '—'}`, inline: true },
          { name: 'Market cap', value: d[`${vs}_market_cap`] ? Math.round(d[`${vs}_market_cap`]).toLocaleString() : '—', inline: true }
        );
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t find a coin matching **${coin}**.` });
    }
  },
};

// ── /wiki ────────────────────────────────────────────────────────
const wiki = {
  data: new SlashCommandBuilder()
    .setName('wiki')
    .setDescription('Get a Wikipedia summary')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('query').setDescription('Topic to look up').setRequired(true)),
  async execute(client, interaction) {
    const query = interaction.options.getString('query').trim();
    await interaction.deferReply();
    try {
      const data = await getJson(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`);
      if (data.type === 'disambiguation' || !data.extract) throw new Error('no clear article');
      const embed = new EmbedBuilder()
        .setColor(C)
        .setTitle(data.title)
        .setURL(data.content_urls?.desktop?.page)
        .setDescription(data.extract.slice(0, 1200));
      if (data.thumbnail?.source) embed.setThumbnail(data.thumbnail.source);
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t find a clear Wikipedia article for **${query}**.` });
    }
  },
};

// ── /forecast ────────────────────────────────────────────────────
const WEATHER_CODES = {
  0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast', 45: 'Fog', 48: 'Rime fog',
  51: 'Light drizzle', 53: 'Drizzle', 55: 'Heavy drizzle', 61: 'Light rain', 63: 'Rain', 65: 'Heavy rain',
  71: 'Light snow', 73: 'Snow', 75: 'Heavy snow', 80: 'Rain showers', 81: 'Rain showers', 82: 'Violent showers',
  95: 'Thunderstorm', 96: 'Thunderstorm w/ hail', 99: 'Thunderstorm w/ hail',
};
const forecast = {
  data: new SlashCommandBuilder()
    .setName('forecast')
    .setDescription('3-day weather forecast for a place')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('location').setDescription('City or place').setRequired(true)),
  async execute(client, interaction) {
    const location = interaction.options.getString('location').trim();
    await interaction.deferReply();
    try {
      const geo = await getJson(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1`);
      if (!geo.results?.length) throw new Error('place not found');
      const place = geo.results[0];
      const wx = await getJson(
        `https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=3&timezone=auto`
      );
      const d = wx.daily;
      const embed = new EmbedBuilder()
        .setColor(C)
        .setAuthor({ name: `🌤️ Forecast — ${place.name}, ${place.country_code}` });
      for (let i = 0; i < d.time.length; i++) {
        embed.addFields({
          name: new Date(d.time[i]).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }),
          value: `${WEATHER_CODES[d.weather_code[i]] || '—'} · ${Math.round(d.temperature_2m_min[i])}°–${Math.round(d.temperature_2m_max[i])}°C`,
        });
      }
      embed.setFooter({ text: 'Data: Open-Meteo' });
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t get a forecast for “${location}”.` });
    }
  },
};

module.exports = [define, country, convert, crypto, wiki, forecast];
