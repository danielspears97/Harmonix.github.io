'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const history = require('../music/history');
const levels = require('../engagement/levels');
const achievements = require('../engagement/achievements');

const RANGES = { '7': 7, '30': 30, '90': 90, all: 36500 };

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wrapped')
    .setDMPermission(false)
    .setDescription('A recap of your server’s music & activity')
    .addStringOption((o) => o.setName('scope').setDescription('Server-wide or just you').addChoices({ name: 'Server', value: 'server' }, { name: 'Me', value: 'me' }))
    .addStringOption((o) => o.setName('range').setDescription('Time window').addChoices({ name: 'Last 7 days', value: '7' }, { name: 'Last 30 days', value: '30' }, { name: 'Last 90 days', value: '90' }, { name: 'All time', value: 'all' })),
  async execute(client, interaction) {
    const scope = interaction.options.getString('scope') || 'server';
    const rangeKey = interaction.options.getString('range') || '30';
    const days = RANGES[rangeKey] || 30;
    const label = rangeKey === 'all' ? 'all time' : `the last ${rangeKey} days`;
    const gid = interaction.guildId;

    const embed = new EmbedBuilder().setColor(config.brand.color).setTimestamp();

    if (scope === 'me') {
      const plays = history.userPlayCount(gid, interaction.user.id);
      const me = levels.getUser(gid, interaction.user.id);
      const rank = levels.rankOf(gid, interaction.user.id);
      const unlocked = achievements.list(gid, interaction.user.id).filter((a) => a.unlocked);
      embed
        .setAuthor({ name: `${interaction.user.username}'s Wrapped`, iconURL: interaction.user.displayAvatarURL() })
        .setDescription(`Here’s your recap for **${interaction.guild.name}**.`)
        .addFields(
          { name: '🎵 Songs you’ve played', value: String(plays), inline: true },
          { name: '⭐ Level', value: `${me.level} (#${rank || '—'})`, inline: true },
          { name: '🏆 Achievements', value: `${unlocked.length}/${achievements.DEFS.length}`, inline: true }
        );
      if (unlocked.length) embed.addFields({ name: 'Badges', value: unlocked.map((a) => `${a.emoji} ${a.name}`).join(' · ') });
      return interaction.reply({ embeds: [embed] });
    }

    // Server-wide
    const totals = history.totals(gid, days);
    if (!totals.plays) {
      return interaction.reply({ content: `No music has been played in ${label} yet — come back after a few sessions! 🎶`, ephemeral: true });
    }
    const tracks = history.topTracks(gid, days, 5);
    const djs = history.topListeners(gid, days, 5);
    const hour = history.busiestHour(gid, days);
    const topMembers = levels.top(gid, 3) || [];

    const medal = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
    embed
      .setAuthor({ name: `${interaction.guild.name} · Wrapped`, iconURL: interaction.guild.iconURL() || undefined })
      .setDescription(`Your server’s recap for **${label}**.`)
      .addFields(
        { name: '🎶 Tracks played', value: String(totals.plays), inline: true },
        { name: '🧑‍🤝‍🧑 Listeners', value: String(totals.listeners), inline: true },
        { name: '🕐 Peak hour', value: hour == null ? '—' : `${((hour + 11) % 12) + 1}${hour < 12 ? 'am' : 'pm'}`, inline: true },
        { name: '🔥 Top tracks', value: tracks.map((t, i) => `${medal[i]} **${t.title}**${t.author ? ` — ${t.author}` : ''} ×${t.plays}`).join('\n') || '—' }
      );
    if (djs.length) embed.addFields({ name: '🎧 Top DJs', value: djs.map((d, i) => `${medal[i]} <@${d.user_id}> — ${d.plays} plays`).join('\n') });
    if (topMembers.length) embed.addFields({ name: '⭐ Most active', value: topMembers.map((m, i) => `${medal[i]} <@${m.user_id}> — level ${m.level}`).join('\n') });
    return interaction.reply({ embeds: [embed] });
  },
};
