'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const controller = require('../controller');
const playlists = require('../music/playlists');
const { voiceGuard } = require('../utils/guards');
const { config } = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('playlist')
    .setDescription('Save and load your music playlists')
    .setDMPermission(false)
    .addSubcommand((s) => s.setName('save').setDescription('Save the current queue as a playlist').addStringOption((o) => o.setName('name').setDescription('Playlist name').setRequired(true)))
    .addSubcommand((s) => s.setName('load').setDescription('Queue up one of your playlists').addStringOption((o) => o.setName('name').setDescription('Playlist name').setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List your saved playlists'))
    .addSubcommand((s) => s.setName('show').setDescription('Show a playlist’s tracks').addStringOption((o) => o.setName('name').setDescription('Playlist name').setRequired(true)))
    .addSubcommand((s) => s.setName('delete').setDescription('Delete a playlist').addStringOption((o) => o.setName('name').setDescription('Playlist name').setRequired(true))),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const uid = interaction.user.id;

    if (sub === 'save') {
      const name = interaction.options.getString('name');
      const player = controller.getPlayer(client, interaction.guildId);
      if (!player || !player.queue.current) return interaction.reply({ content: 'Nothing is playing to save.', ephemeral: true });
      const all = [player.queue.current, ...(player.queue.tracks || [])];
      const tracks = all.filter((t) => t && t.info && t.info.uri).map((t) => ({ uri: t.info.uri, title: t.info.title || 'Unknown' }));
      if (!tracks.length) return interaction.reply({ content: 'Couldn’t capture any saveable tracks.', ephemeral: true });
      playlists.save(uid, name, tracks);
      return interaction.reply({ content: `💾 Saved **${name}** with **${tracks.length}** track${tracks.length === 1 ? '' : 's'}.`, ephemeral: true });
    }

    if (sub === 'load') {
      const g = voiceGuard(client, interaction);
      if (!g.ok) return interaction.reply({ content: g.msg, ephemeral: true });
      const pl = playlists.get(uid, interaction.options.getString('name'));
      if (!pl) return interaction.reply({ content: 'No playlist by that name. See `/playlist list`.', ephemeral: true });
      await interaction.deferReply();
      const voiceChannelId = interaction.member.voice.channelId;
      let added = 0;
      for (const t of pl.tracks) {
        const r = await controller.play(client, { guildId: interaction.guildId, voiceChannelId, textChannelId: interaction.channelId, query: t.uri, requester: interaction.user }).catch(() => null);
        if (r && r.ok !== false) added += 1;
      }
      return interaction.editReply({ content: `▶️ Loaded **${pl.name}** — queued **${added}/${pl.tracks.length}** track${pl.tracks.length === 1 ? '' : 's'}.` });
    }

    if (sub === 'list') {
      const items = playlists.list(uid);
      if (!items.length) return interaction.reply({ content: 'You have no saved playlists. Save one with `/playlist save`.', ephemeral: true });
      const lines = items.map((p) => `**${p.name}** — ${p.count} track${p.count === 1 ? '' : 's'}`);
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(config.brand.color).setTitle('🎵 Your playlists').setDescription(lines.join('\n'))], ephemeral: true });
    }

    if (sub === 'show') {
      const pl = playlists.get(uid, interaction.options.getString('name'));
      if (!pl) return interaction.reply({ content: 'No playlist by that name.', ephemeral: true });
      const lines = pl.tracks.slice(0, 20).map((t, i) => `${i + 1}. ${t.title}`);
      const more = pl.tracks.length > 20 ? `\n…and ${pl.tracks.length - 20} more` : '';
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(config.brand.color).setTitle(`🎵 ${pl.name}`).setDescription(lines.join('\n') + more)], ephemeral: true });
    }

    // delete
    const ok = playlists.remove(uid, interaction.options.getString('name'));
    return interaction.reply({ content: ok ? '🗑️ Playlist deleted.' : 'No playlist by that name.', ephemeral: true });
  },
};
