'use strict';
// /tools — text & dev utilities (see _dev/dev.js)
module.exports = require('./_dev/dev');
