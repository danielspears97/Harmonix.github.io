'use strict';

const { composeCategory } = require('../utils/compose');

const leveling = require('./_engagement/levels'); // [rank, leaderboard, levels (group w/ internal reward group)]
const byName = (n) => leveling.find((c) => c.data.name === n);

// rank + leaderboard stay as plain subcommands; the "levels" admin command is
// promoted so its subcommands (enable/disable/announce/setxp + reward group)
// sit directly under /level rather than as a 3rd nesting level.
module.exports = composeCategory('level', 'Leveling & ranks', [
  byName('rank'),
  byName('leaderboard'),
  { module: byName('levels'), promote: true },
]);
