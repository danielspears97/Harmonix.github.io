'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const userSettings = require('../server/userSettings');
const { config } = require('../../config');

const EXAMPLES = 'Examples: `America/Chicago`, `America/New_York`, `Europe/London`, `Asia/Tokyo`, `Australia/Sydney`. Full list: https://en.wikipedia.org/wiki/List_of_tz_database_time_zones';

function localTime(tz) {
  return new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'short', hour: 'numeric', minute: '2-digit', hour12: true, timeZoneName: 'short' }).format(new Date());
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timezone')
    .setDescription('Set your timezone so the bot can show your local time')
    .setDMPermission(true)
    .addSubcommand((s) => s
      .setName('set')
      .setDescription('Set your timezone (IANA name like America/Chicago)')
      .addStringOption((o) => o.setName('timezone').setDescription('e.g. America/Chicago').setRequired(true)))
    .addSubcommand((s) => s
      .setName('show')
      .setDescription('Show a timezone & current local time')
      .addUserOption((o) => o.setName('user').setDescription('Whose timezone to show (default: you)').setRequired(false)))
    .addSubcommand((s) => s.setName('clear').setDescription('Remove your saved timezone')),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'set') {
      const tz = interaction.options.getString('timezone', true).trim();
      if (!userSettings.isValidTimezone(tz)) {
        return interaction.reply({ content: `❌ \`${tz}\` isn’t a valid timezone. Use an IANA name.\n${EXAMPLES}`, ephemeral: true });
      }
      userSettings.setTimezone(interaction.user.id, tz);
      return interaction.reply({ content: `✅ Your timezone is set to **${tz}** — it’s currently **${localTime(tz)}** for you.`, ephemeral: true });
    }
    if (sub === 'clear') {
      userSettings.setTimezone(interaction.user.id, null);
      return interaction.reply({ content: '✅ Cleared your saved timezone.', ephemeral: true });
    }
    // show
    const target = interaction.options.getUser('user') || interaction.user;
    const tz = userSettings.getTimezone(target.id);
    if (!tz) {
      const who = target.id === interaction.user.id ? 'You haven’t' : `${target.username} hasn’t`;
      return interaction.reply({ content: `${who} set a timezone yet. ${target.id === interaction.user.id ? 'Use `/timezone set`.' : ''}`, ephemeral: true });
    }
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setAuthor({ name: `${target.username}'s local time`, iconURL: target.displayAvatarURL() })
      .setDescription(`🕐 **${localTime(tz)}**\n🌍 ${tz}`);
    return interaction.reply({ embeds: [embed] });
  },
};
