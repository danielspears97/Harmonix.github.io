'use strict';

const { SlashCommandBuilder, EmbedBuilder, version: djsVersion } = require('discord.js');
const { config } = require('../../config');

function humanUptime(sec) {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return [d && `${d}d`, h && `${h}h`, m && `${m}m`, `${s}s`].filter(Boolean).join(' ');
}

module.exports = {
  data: new SlashCommandBuilder().setName('status').setDescription('Show the bot’s health & status'),
  async execute(client, interaction) {
    const mem = process.memoryUsage().rss / 1048576;
    const players = client.lavalink?.players?.size || 0;
    const playing = [...(client.lavalink?.players?.values() || [])].filter((p) => p.playing).length;

    let nodeLine = 'No Lavalink nodes';
    const nodes = client.lavalink?.nodeManager?.nodes;
    if (nodes && nodes.size) {
      const parts = [...nodes.values()].map((n) => `${n.connected ? '🟢' : '🔴'} ${n.id || 'node'}`);
      nodeLine = parts.join('  ');
    }

    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setAuthor({ name: `${client.user.username} · status`, iconURL: client.user.displayAvatarURL() })
      .addFields(
        { name: '⏱️ Uptime', value: humanUptime(process.uptime()), inline: true },
        { name: '📡 Gateway ping', value: `${Math.max(0, Math.round(client.ws.ping))} ms`, inline: true },
        { name: '🧠 Memory', value: `${mem.toFixed(0)} MB`, inline: true },
        { name: '🏠 Servers', value: String(client.guilds.cache.size), inline: true },
        { name: '🎧 Players', value: `${playing} playing / ${players} active`, inline: true },
        { name: '🟢 Lavalink', value: nodeLine, inline: false }
      )
      .setFooter({ text: `discord.js v${djsVersion} · Node ${process.version}` })
      .setTimestamp();
    return interaction.reply({ embeds: [embed] });
  },
};
