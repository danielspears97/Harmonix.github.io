'use strict';
// /util — practical utilities
const { composeCategory } = require('../utils/compose');
const reminder = require('./_utility/reminder');   // group
const feed = require('./_utility/feed');            // group
const translate = require('./_utility/translate');  // plain
const weather = require('./_utility/weather');       // plain
const freegames = require('./_utility/freegames');   // group
module.exports = composeCategory('util', 'Reminders, translate, weather, feeds & free games', [reminder, feed, translate, weather, freegames]);
