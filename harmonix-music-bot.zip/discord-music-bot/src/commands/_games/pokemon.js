'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const { getJson } = require('../../utils/fetchJson');

const command = {
  data: new SlashCommandBuilder()
    .setName('pokemon')
    .setDescription('Look up a Pokémon')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('name').setDescription('Name or Pokédex number').setRequired(true)),
  async execute(client, interaction) {
    const name = interaction.options.getString('name').toLowerCase().trim();
    await interaction.deferReply();
    try {
      const p = await getJson(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(name)}`);
      const types = p.types.map((t) => t.type.name).join(', ');
      const stats = p.stats.map((s) => `**${s.stat.name}**: ${s.base_stat}`).join('\n');
      const embed = new EmbedBuilder()
        .setColor(config.brand.color)
        .setTitle(`#${p.id} ${p.name.charAt(0).toUpperCase() + p.name.slice(1)}`)
        .addFields(
          { name: 'Type', value: types, inline: true },
          { name: 'Height', value: `${p.height / 10} m`, inline: true },
          { name: 'Weight', value: `${p.weight / 10} kg`, inline: true },
          { name: 'Base stats', value: stats }
        );
      const sprite = p.sprites?.other?.['official-artwork']?.front_default || p.sprites?.front_default;
      if (sprite) embed.setThumbnail(sprite);
      return interaction.editReply({ embeds: [embed] });
    } catch {
      return interaction.editReply({ content: `Couldn’t find a Pokémon called **${name}**.` });
    }
  },
};

module.exports = command;
