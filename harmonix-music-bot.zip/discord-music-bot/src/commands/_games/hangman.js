'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const { getConfig, setConfig, deleteConfig } = require('../../db');

const MAX_WRONG = 6;
const WORDS = [
  'galaxy', 'puzzle', 'rhythm', 'jukebox', 'voyage', 'quartz', 'wizard', 'falcon', 'maple', 'orbit',
  'cactus', 'dolphin', 'ember', 'glacier', 'harbor', 'island', 'jungle', 'kettle', 'lantern', 'meadow',
  'nebula', 'oyster', 'pyramid', 'quiver', 'ribbon', 'sphinx', 'turtle', 'umbrella', 'velvet', 'walnut',
  'xylophone', 'yogurt', 'zephyr', 'anchor', 'breeze', 'comet', 'dragon', 'echo', 'feather', 'gadget',
];

const key = (channelId) => `hangman:${channelId}`;
const STAGES = ['😀', '🙂', '😐', '😟', '😣', '😵', '💀'];

function mask(word, guessed) {
  return word.split('').map((c) => (guessed.includes(c) ? c : '_')).join(' ');
}

function render(state, title) {
  const wrongLetters = state.guessed.filter((g) => !state.word.includes(g));
  const embed = new EmbedBuilder()
    .setColor(state.status === 'won' ? config.brand.successColor : state.status === 'lost' ? config.brand.errorColor : config.brand.color)
    .setTitle(`🪢 Hangman ${STAGES[state.wrong]}`)
    .setDescription('```\n' + mask(state.word, state.guessed) + '\n```')
    .addFields(
      { name: 'Wrong', value: `${state.wrong}/${MAX_WRONG}`, inline: true },
      { name: 'Guessed', value: state.guessed.length ? state.guessed.join(' ') : '—', inline: true }
    );
  if (title) embed.setFooter({ text: title });
  if (state.status === 'won') embed.addFields({ name: 'You won! 🎉', value: `The word was **${state.word}**.` });
  if (state.status === 'lost') embed.addFields({ name: 'Game over 💀', value: `The word was **${state.word}**.` });
  if (wrongLetters.length) embed.addFields({ name: 'Misses', value: wrongLetters.join(' ') });
  return embed;
}

const command = {
  data: new SlashCommandBuilder()
    .setName('hangman')
    .setDescription('Play hangman in this channel')
    .setDMPermission(false)
    .addSubcommand((s) => s.setName('start').setDescription('Start a new game'))
    .addSubcommand((s) =>
      s.setName('guess').setDescription('Guess a letter').addStringOption((o) => o.setName('letter').setDescription('A single letter').setRequired(true))
    )
    .addSubcommand((s) => s.setName('quit').setDescription('End the current game')),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const k = key(interaction.channel.id);
    const existing = getConfig(interaction.guildId, k, null);

    if (sub === 'start') {
      if (existing && existing.status === 'playing') {
        return interaction.reply({ content: 'A game is already running here. Use `/game hangman guess` or `/game hangman quit`.', ephemeral: true });
      }
      const word = WORDS[Math.floor(Math.random() * WORDS.length)];
      const state = { word, guessed: [], wrong: 0, status: 'playing' };
      setConfig(interaction.guildId, k, state);
      return interaction.reply({ embeds: [render(state, 'Guess with /hangman guess')] });
    }

    if (sub === 'quit') {
      if (!existing) return interaction.reply({ content: 'No game running here.', ephemeral: true });
      deleteConfig(interaction.guildId, k);
      return interaction.reply({ content: `Game ended — the word was **${existing.word}**.` });
    }

    // guess
    if (!existing || existing.status !== 'playing') {
      return interaction.reply({ content: 'No active game. Start one with `/game hangman start`.', ephemeral: true });
    }
    const letter = interaction.options.getString('letter').toLowerCase().trim();
    if (!/^[a-z]$/.test(letter)) return interaction.reply({ content: 'Guess a single letter (a–z).', ephemeral: true });
    if (existing.guessed.includes(letter)) return interaction.reply({ content: `**${letter}** was already guessed.`, ephemeral: true });

    existing.guessed.push(letter);
    if (!existing.word.includes(letter)) existing.wrong += 1;

    const solved = existing.word.split('').every((c) => existing.guessed.includes(c));
    if (solved) existing.status = 'won';
    else if (existing.wrong >= MAX_WRONG) existing.status = 'lost';

    if (existing.status === 'playing') setConfig(interaction.guildId, k, existing);
    else deleteConfig(interaction.guildId, k);

    return interaction.reply({ embeds: [render(existing, `${interaction.user.username} guessed “${letter}”`)] });
  },
};

module.exports = command;
