'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');

const C = config.brand.color;

const EIGHTBALL = [
  'It is certain.', 'Without a doubt.', 'Yes — definitely.', 'You may rely on it.', 'Most likely.',
  'Outlook good.', 'Signs point to yes.', 'Reply hazy, try again.', 'Ask again later.',
  'Better not tell you now.', 'Cannot predict now.', 'Don’t count on it.', 'My reply is no.',
  'My sources say no.', 'Outlook not so good.', 'Very doubtful.',
];

const eightball = {
  data: new SlashCommandBuilder().setName('8ball').setDescription('Ask the magic 8-ball').setDMPermission(false)
    .addStringOption((o) => o.setName('question').setDescription('Your yes/no question').setRequired(true)),
  async execute(client, interaction) {
    const q = interaction.options.getString('question');
    const a = EIGHTBALL[Math.floor(Math.random() * EIGHTBALL.length)];
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setDescription(`🎱 **Q:** ${q}\n**A:** ${a}`)] });
  },
};

const rps = {
  data: new SlashCommandBuilder().setName('rps').setDescription('Rock, paper, scissors vs the bot').setDMPermission(false)
    .addStringOption((o) => o.setName('choice').setDescription('Your move').setRequired(true).addChoices({ name: 'rock', value: 'rock' }, { name: 'paper', value: 'paper' }, { name: 'scissors', value: 'scissors' })),
  async execute(client, interaction) {
    const moves = ['rock', 'paper', 'scissors'];
    const emoji = { rock: '🪨', paper: '📄', scissors: '✂️' };
    const you = interaction.options.getString('choice');
    const me = moves[Math.floor(Math.random() * 3)];
    let result;
    if (you === me) result = 'It’s a tie!';
    else if ((you === 'rock' && me === 'scissors') || (you === 'paper' && me === 'rock') || (you === 'scissors' && me === 'paper')) result = 'You win! 🎉';
    else result = 'I win! 😎';
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setDescription(`You: ${emoji[you]}  •  Me: ${emoji[me]}\n\n**${result}**`)] });
  },
};

const coinflip = {
  data: new SlashCommandBuilder().setName('coinflip').setDescription('Flip a coin').setDMPermission(false),
  async execute(client, interaction) {
    return interaction.reply({ content: `🪙 **${Math.random() < 0.5 ? 'Heads' : 'Tails'}!**` });
  },
};

const roll = {
  data: new SlashCommandBuilder().setName('roll').setDescription('Roll dice (e.g. 2d6, d20, 3d6+2)').setDMPermission(false)
    .addStringOption((o) => o.setName('dice').setDescription('Dice notation (default 1d6)')),
  async execute(client, interaction) {
    const input = (interaction.options.getString('dice') || '1d6').toLowerCase().replace(/\s/g, '');
    const m = input.match(/^(\d*)d(\d+)([+-]\d+)?$/) || (/^\d+$/.test(input) ? [null, '1', input, null] : null);
    if (!m) return interaction.reply({ content: 'Try something like `2d6`, `d20`, or `3d6+2`.', ephemeral: true });
    const count = Math.min(Math.max(parseInt(m[1] || '1', 10), 1), 100);
    const sides = Math.min(Math.max(parseInt(m[2], 10), 2), 1000);
    const mod = m[3] ? parseInt(m[3], 10) : 0;
    const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1);
    const sum = rolls.reduce((a, b) => a + b, 0) + mod;
    const detail = count > 1 || mod ? `\n[${rolls.join(', ')}]${mod ? ` ${mod > 0 ? '+' : ''}${mod}` : ''}` : '';
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setDescription(`🎲 **${sum}**${detail}`)] });
  },
};

const draw = {
  data: new SlashCommandBuilder().setName('draw').setDescription('Draw cards from a shuffled deck').setDMPermission(false)
    .addIntegerOption((o) => o.setName('count').setDescription('How many (1-10)').setMinValue(1).setMaxValue(10)),
  async execute(client, interaction) {
    const n = interaction.options.getInteger('count') || 1;
    const suits = ['♠', '♥', '♦', '♣'];
    const ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const deck = [];
    for (const su of suits) for (const r of ranks) deck.push(`${r}${su}`);
    for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setDescription(`🃏 ${deck.slice(0, n).join('  ')}`)] });
  },
};

module.exports = [eightball, rps, coinflip, roll, draw];
