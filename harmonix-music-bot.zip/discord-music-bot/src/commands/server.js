'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { composeCategory } = require('../utils/compose');

const greetings = require('./_server/greetings'); // [welcome (group), goodbye (group)]
const autorole = require('./_server/autorole'); // group
const reactionrole = require('./_server/reactionrole'); // group
const starboard = require('./_server/starboard'); // group
const settings = require('./_server/settings'); // [autodelete, triviachannel]
const autoresponder = require('./_server/autoresponder'); // group
const sticky = require('./_server/sticky'); // group
const rolemenu = require('./_server/rolemenu'); // group
const prefix = require('./_server/prefix'); // prefix

module.exports = composeCategory(
  'server',
  'Server setup & management',
  [...greetings, autorole, reactionrole, starboard, ...settings, autoresponder, sticky, rolemenu, prefix],
  PermissionFlagsBits.ManageGuild
);
