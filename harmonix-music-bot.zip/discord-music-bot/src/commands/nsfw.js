'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../config');

// Curated anime/illustrated NSFW sources (no real people, no loli/shota
// boorus). nekosapi is the reliable backbone (S3-hosted, not Cloudflare-gated
// — works even from blocked hosts); waifu.im/purrbot add category coverage.
const TIMEOUT_MS = 6000;
const UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36';

async function getJson(url, headers = {}) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json', 'Cache-Control': 'no-cache', ...headers }, signal: ctrl.signal });
    if (!res.ok) throw new Error(`${url.split('?')[0]} → ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

// ── source adapters (each returns an image URL or throws) ─────────
async function nekosApi(tag) {
  let url = 'https://api.nekosapi.com/v4/images/random?rating=explicit&limit=1';
  if (tag) url += `&tags=${encodeURIComponent(tag)}`;
  const d = await getJson(url);
  const arr = Array.isArray(d) ? d : (d.items || []);
  const u = arr[0] && arr[0].url;
  if (!u) throw new Error('nekosapi empty');
  return u;
}
async function waifuIm(tag) {
  const d = await getJson(`https://api.waifu.im/search?is_nsfw=true${tag ? `&included_tags=${tag}` : ''}`, { 'Accept-Version': 'v5' });
  const u = d && d.images && d.images[0] && d.images[0].url;
  if (!u) throw new Error('waifu.im empty');
  return u;
}
async function purrbot(type) {
  const d = await getJson(`https://purrbot.site/api/img/nsfw/${type}/img`);
  if (!d || !d.link) throw new Error('purrbot empty');
  return d.link;
}

// category → ordered chain. nekosApi(tag) is the reliable primary (applies the
// category and varies); waifu.im/purrbot add variety when reachable; a plain
// nekosApi() is the last-resort so a category never hard-fails.
const CHAINS = {
  random: [() => nekosApi(), () => waifuIm()],
  hentai: [() => nekosApi('exposed_girl_breasts'), () => waifuIm('hentai'), () => nekosApi()],
  ass: [() => nekosApi('exposed_anus'), () => waifuIm('ass'), () => nekosApi()],
  oppai: [() => nekosApi('large_breasts'), () => waifuIm('oppai'), () => nekosApi()],
  pussy: [() => nekosApi('pussy'), () => nekosApi()],
  uniform: [() => nekosApi('school_uniform'), () => waifuIm('uniform'), () => nekosApi()],
  bikini: [() => nekosApi('bikini'), () => nekosApi()],
  maid: [() => nekosApi('maid'), () => waifuIm('maid'), () => nekosApi()],
  yuri: [() => nekosApi('yuri'), () => purrbot('yuri'), () => nekosApi()],
  neko: [() => nekosApi('kemonomimi'), () => purrbot('neko'), () => nekosApi()],
  solo: [() => nekosApi('masturbating'), () => nekosApi()],
  threesome: [() => nekosApi('threesome'), () => nekosApi()],
  wet: [() => nekosApi('wet'), () => nekosApi()],
};

const CATEGORY_CHOICES = Object.keys(CHAINS).map((c) => ({ name: c, value: c }));

async function fetchImage(category) {
  const chain = CHAINS[category] || CHAINS.random;
  let lastErr;
  for (const fetcher of chain) {
    try {
      const url = await fetcher();
      if (url) return url;
    } catch (err) {
      lastErr = err;
      console.warn('[nsfw] source failed:', err.message);
    }
  }
  throw lastErr || new Error('all sources failed');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nsfw')
    .setDescription('Adult images — only works in age-restricted (NSFW) channels')
    .setDMPermission(false)
    .setNSFW(true)
    .addStringOption((o) => o.setName('category').setDescription('Type of image').setRequired(false).addChoices(...CATEGORY_CHOICES)),
  async execute(client, interaction) {
    if (!interaction.channel || !interaction.channel.nsfw) {
      return interaction.reply({ content: '🔞 This command only works in channels marked **age-restricted (NSFW)**. Ask a moderator to enable that in the channel settings.', ephemeral: true });
    }
    const category = interaction.options.getString('category') || 'random';
    await interaction.deferReply();
    let url;
    try {
      url = await fetchImage(category);
    } catch {
      return interaction.editReply({ content: '⚠️ Couldn’t fetch an image right now — every source was unavailable or rate-limited. Check the bot console for `[nsfw] source failed` lines, or try again in a moment.' });
    }
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setTitle(`🔞 ${category}`)
      .setImage(url)
      .setFooter({ text: `Requested by ${interaction.user.username}` });
    return interaction.editReply({ embeds: [embed] });
  },
};
