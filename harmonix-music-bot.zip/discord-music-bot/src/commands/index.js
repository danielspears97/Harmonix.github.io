'use strict';

const fs = require('fs');
const path = require('path');

const { config } = require('../../config');

// Files that make up the music feature set (used in MUSIC_ONLY mode).
const MUSIC_FILES = new Set(['controls', 'dj', 'filter', 'nowplaying', 'play', 'playlist', 'queue', 'setup', 'volume', 'voteskip', 'voicelock']);

/** Recursively collect all .js files under a directory. */
function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('_')) continue; // leaf logic composed by parents, not registered directly
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

/**
 * Load every command module in this directory tree (subfolders allowed, so
 * commands can be grouped by category). A module may export either a single
 * { data, execute } object or an array of them. In MUSIC_ONLY mode only the
 * music command files are loaded.
 */
function loadCommands() {
  const commands = new Map();
  for (const file of walk(__dirname)) {
    if (file === __filename) continue; // skip this loader
    if (config.musicOnly && !MUSIC_FILES.has(path.basename(file, '.js'))) continue;
    const mod = require(file);
    const list = Array.isArray(mod) ? mod : [mod];
    for (const cmd of list) {
      if (!cmd || !cmd.data || typeof cmd.execute !== 'function') continue;
      commands.set(cmd.data.name, cmd);
    }
  }
  return commands;
}

module.exports = { loadCommands };
