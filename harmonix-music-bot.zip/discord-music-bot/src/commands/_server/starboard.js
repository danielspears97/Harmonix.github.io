'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const starboard = require('../../server/starboard');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const command = {
  data: new SlashCommandBuilder()
    .setName('starboard')
    .setDescription('Configure the starboard')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Enable the starboard in a channel')
        .addChannelOption((o) => o.setName('channel').setDescription('Starboard channel').addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addIntegerOption((o) => o.setName('threshold').setDescription('Stars needed (default 3)').setMinValue(1).setMaxValue(50).setRequired(false))
        .addStringOption((o) => o.setName('emoji').setDescription('Emoji to count (default ⭐)').setRequired(false))
    )
    .addSubcommand((s) => s.setName('disable').setDescription('Turn the starboard off'))
    .addSubcommand((s) => s.setName('status').setDescription('Show starboard settings')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();
    const settings = starboard.getSettings(interaction.guildId);

    if (sub === 'set') {
      settings.enabled = true;
      settings.channelId = interaction.options.getChannel('channel').id;
      settings.threshold = interaction.options.getInteger('threshold') || settings.threshold || 3;
      settings.emoji = (interaction.options.getString('emoji') || settings.emoji || '⭐').trim();
      starboard.saveSettings(interaction.guildId, settings);
      return interaction.reply({
        content: `⭐ Starboard set to <#${settings.channelId}> — ${settings.threshold}× ${settings.emoji} to feature a message.`,
        ephemeral: true,
      });
    }
    if (sub === 'disable') {
      starboard.disable(interaction.guildId);
      return interaction.reply({ content: 'Starboard disabled.', ephemeral: true });
    }
    return interaction.reply({
      content:
        settings.enabled && settings.channelId
          ? `Starboard: <#${settings.channelId}> · threshold ${settings.threshold} · emoji ${settings.emoji}`
          : 'Starboard is off. Enable it with `/server starboard set`.',
      ephemeral: true,
    });
  },
};

module.exports = command;
