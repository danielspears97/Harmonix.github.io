'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const autoResponder = require('../../community/autoResponder');

const MANAGE = PermissionFlagsBits.ManageGuild;

const autoresponder = {
  data: new SlashCommandBuilder()
    .setName('autoresponder')
    .setDescription('Keyword auto-replies')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Add an auto-reply')
        .addStringOption((o) => o.setName('trigger').setDescription('Text that triggers the reply').setRequired(true))
        .addStringOption((o) => o.setName('response').setDescription('What the bot replies').setRequired(true))
        .addStringOption((o) => o.setName('match').setDescription('How to match').addChoices({ name: 'contains', value: 'contains' }, { name: 'exact', value: 'exact' }, { name: 'starts with', value: 'startswith' }).setRequired(false))
    )
    .addSubcommand((s) => s.setName('remove').setDescription('Remove an auto-reply by id or trigger').addStringOption((o) => o.setName('id_or_trigger').setDescription('ID (from list) or the trigger text').setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List auto-replies')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const sub = interaction.options.getSubcommand();
    if (sub === 'add') {
      const trigger = interaction.options.getString('trigger');
      const response = interaction.options.getString('response');
      const match = interaction.options.getString('match') || 'contains';
      const r = autoResponder.add(interaction.guildId, trigger, response, match);
      if (!r.ok) return interaction.reply({ content: r.reason, ephemeral: true });
      return interaction.reply({ content: `✅ Auto-reply **#${r.id}** added (${match}): \`${trigger}\` → "${response.slice(0, 100)}"`, ephemeral: true });
    }
    if (sub === 'remove') {
      const removed = autoResponder.remove(interaction.guildId, interaction.options.getString('id_or_trigger'));
      return interaction.reply({ content: removed ? `Removed ${removed} auto-reply(ies).` : 'No matching auto-reply.', ephemeral: true });
    }
    const items = autoResponder.list(interaction.guildId);
    if (!items.length) return interaction.reply({ content: 'No auto-replies set. Add one with `/server autoresponder add`.', ephemeral: true });
    const lines = items.map((t) => `**#${t.id}** (${t.match || 'contains'}) \`${t.trigger}\` → ${t.response.slice(0, 80)}`);
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(config.brand.color).setTitle('💬 Auto-responders').setDescription(lines.join('\n').slice(0, 4000))], ephemeral: true });
  },
};

module.exports = autoresponder;
