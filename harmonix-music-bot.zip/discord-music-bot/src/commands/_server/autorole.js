'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const greetings = require('../../server/greetings');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const autorole = {
  data: new SlashCommandBuilder()
    .setName('autorole')
    .setDescription('Automatically give a role to new members')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Set the role to assign on join')
        .addRoleOption((o) => o.setName('role').setDescription('Role to assign').setRequired(true))
    )
    .addSubcommand((s) => s.setName('disable').setDescription('Turn off autorole'))
    .addSubcommand((s) => s.setName('status').setDescription('Show the autorole configuration')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const role = interaction.options.getRole('role');
      if (role.managed || role.id === interaction.guild.id) {
        return interaction.reply({ content: 'That role can’t be assigned manually.', ephemeral: true });
      }
      const me = interaction.guild.members.me;
      if (role.position >= me.roles.highest.position) {
        return interaction.reply({
          content: 'That role is above my highest role, so I can’t assign it. Move my role higher.',
          ephemeral: true,
        });
      }
      greetings.setAutorole(interaction.guildId, { enabled: true, roleId: role.id });
      return interaction.reply({ content: `✅ New members will receive ${role}.`, ephemeral: true });
    }
    if (sub === 'disable') {
      greetings.setAutorole(interaction.guildId, { enabled: false });
      return interaction.reply({ content: 'Autorole disabled.', ephemeral: true });
    }
    const cfg = greetings.getAutorole(interaction.guildId);
    return interaction.reply({
      content: cfg.enabled && cfg.roleId ? `Autorole: <@&${cfg.roleId}>` : 'Autorole is off.',
      ephemeral: true,
    });
  },
};

module.exports = autorole;
