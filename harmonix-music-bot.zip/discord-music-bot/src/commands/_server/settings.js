'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const settings = require('../../server/guildSettings');

const MANAGE = PermissionFlagsBits.ManageGuild;

const autodelete = {
  data: new SlashCommandBuilder()
    .setName('autodelete')
    .setDescription('Auto-delete the bot’s replies after a delay (0 = off)')
    .setDMPermission(false)
    .addIntegerOption((o) => o.setName('seconds').setDescription('Seconds before deletion (0 disables, max 3600)').setMinValue(0).setMaxValue(3600).setRequired(true)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const v = settings.setAutoDelete(interaction.guildId, interaction.options.getInteger('seconds'));
    return interaction.reply({ content: v ? `🧹 The bot’s replies will auto-delete after **${v}s**.` : 'Auto-delete disabled.', ephemeral: true });
  },
};

const triviachannel = {
  data: new SlashCommandBuilder()
    .setName('triviachannel')
    .setDescription('Set the channel auto-cleared every hour for trivia (omit channel to clear)')
    .setDMPermission(false)
    .addChannelOption((o) => o.setName('channel').setDescription('Trivia channel').addChannelTypes(ChannelType.GuildText).setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const channel = interaction.options.getChannel('channel');
    settings.setTriviaChannel(interaction.guildId, channel ? channel.id : null);
    return interaction.reply({ content: channel ? `🧠 Trivia channel set to ${channel} — it’ll be cleared hourly.` : 'Trivia channel cleared (hourly clearing off).', ephemeral: true });
  },
};

module.exports = [autodelete, triviachannel];
