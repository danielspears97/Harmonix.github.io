'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, ButtonStyle } = require('discord.js');
const { config } = require('../../../config');
const rr = require('../../server/reactionRoles');

const MANAGE_ROLES = PermissionFlagsBits.ManageRoles;

const STYLE_CHOICES = [
  { name: 'grey', value: ButtonStyle.Secondary },
  { name: 'blurple', value: ButtonStyle.Primary },
  { name: 'green', value: ButtonStyle.Success },
  { name: 'red', value: ButtonStyle.Danger },
];

async function refreshPanel(client, panel) {
  const channel = await client.channels.fetch(panel.channel_id).catch(() => null);
  if (!channel) return false;
  const message = await channel.messages.fetch(panel.message_id).catch(() => null);
  if (!message) return false;
  await message.edit({ components: rr.buildComponents(rr.getButtons(panel.message_id)) });
  return true;
}

const command = {
  data: new SlashCommandBuilder()
    .setName('reactionrole')
    .setDescription('Self-assignable role buttons')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_ROLES)
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Post a new reaction-role message')
        .addChannelOption((o) => o.setName('channel').setDescription('Where to post').addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addStringOption((o) => o.setName('title').setDescription('Embed title').setRequired(true))
        .addStringOption((o) => o.setName('description').setDescription('Embed description').setRequired(false))
    )
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Add a role button to a panel')
        .addStringOption((o) => o.setName('message_id').setDescription('The panel message ID').setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to grant').setRequired(true))
        .addStringOption((o) => o.setName('label').setDescription('Button label').setRequired(false))
        .addStringOption((o) => o.setName('emoji').setDescription('Button emoji').setRequired(false))
        .addIntegerOption((o) => o.setName('color').setDescription('Button color').addChoices(...STYLE_CHOICES).setRequired(false))
    )
    .addSubcommand((s) =>
      s
        .setName('remove')
        .setDescription('Remove a role button from a panel')
        .addStringOption((o) => o.setName('message_id').setDescription('The panel message ID').setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role button to remove').setRequired(true))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List reaction-role panels in this server')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_ROLES)) {
      return interaction.reply({ content: 'You need the **Manage Roles** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      const channel = interaction.options.getChannel('channel');
      const title = interaction.options.getString('title');
      const description = interaction.options.getString('description') || 'Click a button below to toggle a role.';
      const embed = new EmbedBuilder().setColor(config.brand.color).setTitle(title).setDescription(description);
      const msg = await channel.send({ embeds: [embed] }).catch(() => null);
      if (!msg) return interaction.reply({ content: `I couldn’t post in ${channel}. Check my permissions there.`, ephemeral: true });
      rr.createPanel(interaction.guildId, channel.id, msg.id);
      return interaction.reply({
        content: `✅ Panel created in ${channel}.\nAdd role buttons with:\n\`/server reactionrole add message_id:${msg.id} role:@Role\``,
        ephemeral: true,
      });
    }

    if (sub === 'add') {
      const messageId = interaction.options.getString('message_id').trim();
      const role = interaction.options.getRole('role');
      const label = interaction.options.getString('label');
      const emoji = interaction.options.getString('emoji');
      const style = interaction.options.getInteger('color') || ButtonStyle.Secondary;

      const panel = rr.getPanel(messageId);
      if (!panel || panel.guild_id !== interaction.guildId) {
        return interaction.reply({ content: 'No reaction-role panel with that message ID. Create one with `/server reactionrole create`.', ephemeral: true });
      }
      if (role.managed || role.id === interaction.guild.id) {
        return interaction.reply({ content: 'That role can’t be self-assigned.', ephemeral: true });
      }
      const me = interaction.guild.members.me;
      if (role.position >= me.roles.highest.position) {
        return interaction.reply({ content: 'That role is above my highest role — move my role higher first.', ephemeral: true });
      }
      if (rr.getButtons(messageId).length >= rr.MAX_BUTTONS) {
        return interaction.reply({ content: `A panel can have at most ${rr.MAX_BUTTONS} buttons.`, ephemeral: true });
      }

      rr.addButton(messageId, { roleId: role.id, label: label || role.name, emoji, style });
      const ok = await refreshPanel(client, panel);
      return interaction.reply({
        content: ok ? `Added ${role} to the panel.` : 'Saved, but I couldn’t edit the message (was it deleted?).',
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const messageId = interaction.options.getString('message_id').trim();
      const role = interaction.options.getRole('role');
      const panel = rr.getPanel(messageId);
      if (!panel || panel.guild_id !== interaction.guildId) {
        return interaction.reply({ content: 'No panel with that message ID.', ephemeral: true });
      }
      const removed = rr.removeButton(messageId, role.id);
      if (!removed) return interaction.reply({ content: 'That role isn’t on the panel.', ephemeral: true });
      await refreshPanel(client, panel);
      return interaction.reply({ content: `Removed ${role} from the panel.`, ephemeral: true });
    }

    // list
    const panels = rr.listPanels(interaction.guildId);
    if (!panels.length) return interaction.reply({ content: 'No reaction-role panels yet. Create one with `/server reactionrole create`.', ephemeral: true });
    const lines = panels.map(
      (p) => `• [panel](https://discord.com/channels/${p.guild_id}/${p.channel_id}/${p.message_id}) in <#${p.channel_id}> — ${p.button_count} button(s) · \`${p.message_id}\``
    );
    return interaction.reply({ content: lines.join('\n'), ephemeral: true });
  },
};

module.exports = command;
