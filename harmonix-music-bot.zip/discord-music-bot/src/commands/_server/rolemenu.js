'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const roleMenus = require('../../community/roleMenus');
const { buildEmbed, buildComponents, rerender } = require('../../handlers/roleMenus');

const MANAGE = PermissionFlagsBits.ManageRoles;

const rolemenu = {
  data: new SlashCommandBuilder()
    .setName('rolemenu')
    .setDescription('Self-assignable role dropdown menus')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Create a role menu in this channel')
        .addStringOption((o) => o.setName('title').setDescription('Menu title').setRequired(true))
        .addStringOption((o) => o.setName('description').setDescription('Menu description').setRequired(false))
    )
    .addSubcommand((s) =>
      s
        .setName('addrole')
        .setDescription('Add a role to a menu')
        .addStringOption((o) => o.setName('menu_id').setDescription('Menu ID (from create/list)').setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to add').setRequired(true))
        .addStringOption((o) => o.setName('label').setDescription('Label shown in the dropdown').setRequired(false))
        .addStringOption((o) => o.setName('emoji').setDescription('Emoji').setRequired(false))
        .addStringOption((o) => o.setName('description').setDescription('Option description').setRequired(false))
    )
    .addSubcommand((s) =>
      s
        .setName('removerole')
        .setDescription('Remove a role from a menu')
        .addStringOption((o) => o.setName('menu_id').setDescription('Menu ID').setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to remove').setRequired(true))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List this server’s role menus')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE)) return interaction.reply({ content: 'You need the **Manage Roles** permission.', ephemeral: true });
    const sub = interaction.options.getSubcommand();
    const gid = interaction.guildId;

    if (sub === 'create') {
      const title = interaction.options.getString('title');
      const description = interaction.options.getString('description');
      const id = roleMenus.create(gid, { channelId: interaction.channel.id, title, description });
      const menu = roleMenus.get(gid, id);
      const msg = await interaction.channel.send({ embeds: [buildEmbed(menu)], components: [] });
      roleMenus.setMessageId(gid, id, msg.id);
      return interaction.reply({ content: `✅ Role menu created. ID: \`${id}\`\nAdd roles with \`/server rolemenu addrole menu_id:${id} role:@Role\`.`, ephemeral: true });
    }

    if (sub === 'addrole') {
      const id = interaction.options.getString('menu_id');
      const role = interaction.options.getRole('role');
      const me = interaction.guild.members.me;
      if (role.position >= me.roles.highest.position) return interaction.reply({ content: 'That role is above my highest role — move mine up first.', ephemeral: true });
      const r = roleMenus.addRole(gid, id, { roleId: role.id, label: interaction.options.getString('label') || role.name, emoji: interaction.options.getString('emoji') || null, description: interaction.options.getString('description') || null });
      if (!r.ok) return interaction.reply({ content: r.reason, ephemeral: true });
      await rerender(client, gid, id);
      return interaction.reply({ content: `✅ Added <@&${role.id}> to menu \`${id}\`.`, ephemeral: true });
    }

    if (sub === 'removerole') {
      const id = interaction.options.getString('menu_id');
      const role = interaction.options.getRole('role');
      const ok = roleMenus.removeRole(gid, id, role.id);
      if (ok) await rerender(client, gid, id);
      return interaction.reply({ content: ok ? `Removed <@&${role.id}> from \`${id}\`.` : 'Menu or role not found.', ephemeral: true });
    }

    // list
    const menus = roleMenus.list(gid);
    if (!menus.length) return interaction.reply({ content: 'No role menus yet. Create one with `/server rolemenu create`.', ephemeral: true });
    const lines = menus.map((m) => `\`${m.id}\` — **${m.title}** in <#${m.channelId}> (${m.roles.length} role${m.roles.length === 1 ? '' : 's'})`);
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(config.brand.color).setTitle('🎭 Role menus').setDescription(lines.join('\n'))], ephemeral: true });
  },
};

module.exports = rolemenu;
