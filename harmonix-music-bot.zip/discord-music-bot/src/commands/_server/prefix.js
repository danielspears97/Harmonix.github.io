'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const guildSettings = require('../../server/guildSettings');

const MANAGE = PermissionFlagsBits.ManageGuild;

const prefix = {
  data: new SlashCommandBuilder()
    .setName('prefix')
    .setDescription('Set or view the text-command prefix (e.g. !)')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addStringOption((o) => o.setName('prefix').setDescription('New prefix (1–5 chars). Omit to view current.').setRequired(false)),
  async execute(client, interaction) {
    const next = interaction.options.getString('prefix');
    if (next == null) {
      return interaction.reply({ content: `Current text-command prefix: \`${guildSettings.getPrefix(interaction.guildId)}\``, ephemeral: true });
    }
    if (!interaction.memberPermissions.has(MANAGE)) return interaction.reply({ content: 'You need **Manage Server** to change the prefix.', ephemeral: true });
    const set = guildSettings.setPrefix(interaction.guildId, next);
    return interaction.reply({ content: `✅ Text-command prefix set to \`${set}\`. Try \`${set}help\`.`, ephemeral: true });
  },
};

module.exports = prefix;
