'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const greetings = require('../../server/greetings');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

function makeCommand(kind, label, defaultMsg) {
  return {
    data: new SlashCommandBuilder()
      .setName(kind)
      .setDescription(`Configure the ${label} message`)
      .setDMPermission(false)
      .setDefaultMemberPermissions(MANAGE_GUILD)
      .addSubcommand((s) =>
        s
          .setName('set')
          .setDescription(`Enable & configure the ${label} message`)
          .addChannelOption((o) =>
            o.setName('channel').setDescription('Channel to post in').addChannelTypes(ChannelType.GuildText).setRequired(true)
          )
          .addStringOption((o) =>
            o
              .setName('message')
              .setDescription('Use {user} {username} {server} {membercount}')
              .setRequired(false)
          )
      )
      .addSubcommand((s) => s.setName('test').setDescription(`Preview the ${label} message`))
      .addSubcommand((s) => s.setName('disable').setDescription(`Turn off the ${label} message`))
      .addSubcommand((s) => s.setName('status').setDescription(`Show the ${label} configuration`)),
    async execute(client, interaction) {
      if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
        return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
      }
      const sub = interaction.options.getSubcommand();

      if (sub === 'set') {
        const channel = interaction.options.getChannel('channel');
        const message = interaction.options.getString('message') || defaultMsg;
        greetings.setGreeting(interaction.guildId, kind, { enabled: true, channelId: channel.id, message });
        return interaction.reply({
          content: `✅ ${label} messages enabled in ${channel}.\nPreview: ${greetings.render(message, interaction.member)}`,
          ephemeral: true,
        });
      }
      if (sub === 'test') {
        const cfg = greetings.getGreeting(interaction.guildId, kind);
        if (!cfg.enabled) return interaction.reply({ content: `${label} messages are off. Use \`/${kind} set\`.`, ephemeral: true });
        return interaction.reply({ content: greetings.render(cfg.message || defaultMsg, interaction.member), ephemeral: true });
      }
      if (sub === 'disable') {
        greetings.setGreeting(interaction.guildId, kind, { enabled: false });
        return interaction.reply({ content: `${label} messages disabled.`, ephemeral: true });
      }
      // status
      const cfg = greetings.getGreeting(interaction.guildId, kind);
      return interaction.reply({
        content: cfg.enabled
          ? `${label}: **on** in <#${cfg.channelId}>\nMessage: \`${cfg.message || defaultMsg}\``
          : `${label}: **off**.`,
        ephemeral: true,
      });
    },
  };
}

module.exports = [
  makeCommand('welcome', 'Welcome', greetings.DEFAULT_WELCOME),
  makeCommand('goodbye', 'Goodbye', greetings.DEFAULT_GOODBYE),
];
