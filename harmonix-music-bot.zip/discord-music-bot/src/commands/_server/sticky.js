'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const sticky = require('../../community/sticky');

const MANAGE = PermissionFlagsBits.ManageGuild;

const stickyCmd = {
  data: new SlashCommandBuilder()
    .setName('sticky')
    .setDescription('Keep a message pinned to the bottom of a channel')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addSubcommand((s) => s.setName('set').setDescription('Set the sticky message for this channel').addStringOption((o) => o.setName('message').setDescription('The sticky text').setRequired(true)))
    .addSubcommand((s) => s.setName('remove').setDescription('Remove this channel’s sticky message'))
    .addSubcommand((s) => s.setName('list').setDescription('List channels with sticky messages')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const sub = interaction.options.getSubcommand();
    if (sub === 'set') {
      const message = interaction.options.getString('message');
      sticky.set(interaction.guildId, interaction.channel.id, message);
      return interaction.reply({ content: '📌 Sticky set for this channel — it’ll stay at the bottom as people chat.', ephemeral: true });
    }
    if (sub === 'remove') {
      const ok = sticky.remove(interaction.guildId, interaction.channel.id);
      return interaction.reply({ content: ok ? 'Sticky removed from this channel.' : 'No sticky here.', ephemeral: true });
    }
    const channels = sticky.list(interaction.guildId);
    return interaction.reply({ content: channels.length ? `Sticky messages in: ${channels.map((c) => `<#${c}>`).join(', ')}` : 'No sticky messages set.', ephemeral: true });
  },
};

module.exports = stickyCmd;
