'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const controller = require('../controller');
const { config } = require('../../config');
const { msToTime, truncate } = require('../utils/format');

module.exports = {
  data: new SlashCommandBuilder().setName('queue').setDescription('Show the current queue.'),

  async execute(client, interaction) {
    const state = controller.getState(client, interaction.guildId);
    const embed = new EmbedBuilder().setColor(config.brand.color).setTitle(`Queue — ${state.guildName}`);

    if (!state.current && state.queue.length === 0) {
      embed.setDescription('Nothing is playing and the queue is empty.');
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (state.current) {
      embed.addFields({
        name: 'Now playing',
        value: `${truncate(state.current.title, 60)} \`${state.current.isStream ? 'LIVE' : msToTime(state.current.duration)}\``,
      });
    }

    if (state.queue.length) {
      const list = state.queue
        .slice(0, 20)
        .map((q, i) => `\`${i + 1}.\` ${truncate(q.title, 50)} \`${q.isStream ? 'LIVE' : msToTime(q.duration)}\``)
        .join('\n');
      const more = state.queue.length > 20 ? `\n…and ${state.queue.length - 20} more` : '';
      embed.addFields({ name: `Up next (${state.queue.length})`, value: list + more });
    }

    embed.setFooter({
      text: `Volume ${state.volume}% • Loop ${state.repeatMode} • Autoplay ${state.autoplay ? 'ON' : 'OFF'} • 24/7 ${state.twentyFourSeven ? 'ON' : 'OFF'}`,
    });
    return interaction.reply({ embeds: [embed] });
  },
};
