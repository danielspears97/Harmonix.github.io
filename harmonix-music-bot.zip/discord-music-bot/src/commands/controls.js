'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const controller = require('../controller');
const { voiceGuard } = require('../utils/guards');
const dj = require('../music/dj');
const { config } = require('../../config');
const { msToTime, truncate } = require('../utils/format');
const { buildOverview, makeCtx } = require('../handlers/help');

const reply = (interaction, content, ephemeral = true) =>
  interaction.reply({ content, ephemeral });

/** Parse "mm:ss", "h:mm:ss" or plain seconds into milliseconds. */
function parsePosition(input) {
  if (/^\d+$/.test(input)) return parseInt(input, 10) * 1000;
  const parts = input.split(':').map((p) => parseInt(p, 10));
  if (parts.some((n) => Number.isNaN(n))) return null;
  let seconds = 0;
  for (const p of parts) seconds = seconds * 60 + p;
  return seconds * 1000;
}

const pause = {
  data: new SlashCommandBuilder().setName('pause').setDescription('Pause the current track.'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const r = await controller.pause(client, interaction.guildId);
    return reply(interaction, r.ok ? '⏸️ Paused.' : 'Nothing is playing.');
  },
};

const resume = {
  data: new SlashCommandBuilder().setName('resume').setDescription('Resume playback.'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const r = await controller.resume(client, interaction.guildId);
    return reply(interaction, r.ok ? '▶️ Resumed.' : 'Nothing is playing.');
  },
};

const skip = {
  data: new SlashCommandBuilder().setName('skip').setDescription('Skip to the next track.'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const ownSong = controller.currentRequesterId(client, interaction.guildId) === interaction.user.id;
    if (!ownSong && !dj.isDJ(interaction)) return reply(interaction, '🔒 DJ only — use `/voteskip` to start a vote. (You can always skip a song you queued.)');
    const r = await controller.skip(client, interaction.guildId);
    return reply(interaction, r.ok ? '⏭️ Skipped.' : 'Nothing to skip.');
  },
};

const previous = {
  data: new SlashCommandBuilder().setName('previous').setDescription('Go back to the previous track.'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const r = await controller.previous(client, interaction.guildId);
    if (r.ok) return reply(interaction, '⏮️ Playing previous track.');
    return reply(interaction, r.reason === 'no-previous' ? 'There is no previous track.' : 'Nothing is playing.');
  },
};

const stop = {
  data: new SlashCommandBuilder().setName('stop').setDescription('Stop playback and clear the queue.'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    if (!dj.isDJ(interaction)) return reply(interaction, '🔒 DJ only.');
    const r = await controller.stop(client, interaction.guildId);
    if (!r.ok) return reply(interaction, 'Nothing is playing.');
    return reply(interaction, r.disconnected ? '⏹️ Stopped, cleared the queue, and left the channel.' : '⏹️ Stopped and cleared the queue — staying connected (24/7 is on).');
  },
};

const leave = {
  data: new SlashCommandBuilder().setName('leave').setDescription('Disconnect the bot from the voice channel.'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const r = await controller.disconnect(client, interaction.guildId);
    return reply(interaction, r.ok ? '👋 Disconnected.' : 'I am not connected to a voice channel.');
  },
};

const loop = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Set or cycle the loop mode.')
    .addStringOption((o) =>
      o
        .setName('mode')
        .setDescription('Loop mode (leave empty to cycle)')
        .addChoices(
          { name: 'Off', value: 'off' },
          { name: 'Track', value: 'track' },
          { name: 'Queue', value: 'queue' }
        )
        .setRequired(false)
    ),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const mode = interaction.options.getString('mode');
    const r = mode
      ? await controller.setLoop(client, interaction.guildId, mode)
      : await controller.cycleLoop(client, interaction.guildId);
    if (!r.ok) return reply(interaction, 'Nothing is playing.');
    const label = { off: 'Off 🔁', track: 'Track 🔂', queue: 'Queue 🔁' }[r.mode];
    return reply(interaction, `Loop set to **${label}**.`);
  },
};

const shuffle = {
  data: new SlashCommandBuilder().setName('shuffle').setDescription('Shuffle the queue.'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const r = await controller.shuffle(client, interaction.guildId);
    return reply(interaction, r.ok ? '🔀 Shuffled the queue.' : 'Need at least 2 tracks in the queue.');
  },
};

const seek = {
  data: new SlashCommandBuilder()
    .setName('seek')
    .setDescription('Jump to a position in the current track.')
    .addStringOption((o) =>
      o.setName('position').setDescription('e.g. 90, 1:30 or 1:02:00').setRequired(true)
    ),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const ms = parsePosition(interaction.options.getString('position', true).trim());
    if (ms === null) return reply(interaction, 'Could not understand that position. Try `90`, `1:30` or `1:02:00`.');
    const r = await controller.seek(client, interaction.guildId, ms);
    if (!r.ok) {
      if (r.reason === 'stream') return reply(interaction, 'You cannot seek in a live stream.');
      return reply(interaction, 'Nothing is playing.');
    }
    return reply(interaction, `⏩ Seeked to \`${msToTime(r.position)}\`.`);
  },
};

const remove = {
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Remove a track from the queue by its position.')
    .addIntegerOption((o) =>
      o.setName('position').setDescription('Queue position (see /queue)').setMinValue(1).setRequired(true)
    ),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    if (!dj.isDJ(interaction)) return reply(interaction, '🔒 DJ only.');
    const pos = interaction.options.getInteger('position', true);
    const r = controller.removeAt(client, interaction.guildId, pos - 1);
    if (!r.ok) return reply(interaction, 'That position is not in the queue.');
    return reply(interaction, `🗑️ Removed **${truncate(r.removed.title, 60)}**.`);
  },
};

const clear = {
  data: new SlashCommandBuilder().setName('clear').setDescription('Clear the queue (keeps the current track).'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    if (!dj.isDJ(interaction)) return reply(interaction, '🔒 DJ only.');
    const r = controller.clearQueue(client, interaction.guildId);
    return reply(interaction, r.ok ? `🧹 Cleared ${r.count} track(s).` : 'Nothing is playing.');
  },
};

const autoplay = {
  data: new SlashCommandBuilder().setName('autoplay').setDescription('Toggle autoplay (keeps the music going with related tracks).'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const r = controller.toggleAutoplay(client, interaction.guildId);
    return reply(interaction, `♾️ Autoplay is now **${r.autoplay ? 'ON' : 'OFF'}**.`);
  },
};

const twentyFourSeven = {
  data: new SlashCommandBuilder().setName('247').setDescription('Toggle 24/7 mode (the bot stays in the channel forever).'),
  async execute(client, interaction) {
    const g = voiceGuard(client, interaction);
    if (!g.ok) return reply(interaction, g.msg);
    const r = controller.toggle247(client, interaction.guildId);
    return reply(interaction, `🕒 24/7 mode is now **${r.twentyFourSeven ? 'ON' : 'OFF'}**.`);
  },
};

const help = {
  data: new SlashCommandBuilder().setName('help').setDescription('Browse everything this bot can do.'),
  async execute(client, interaction) {
    const ctx = makeCtx(interaction.guildId, interaction.member);
    return interaction.reply({ ...buildOverview(ctx), ephemeral: true });
  },
};

module.exports = [
  pause,
  resume,
  skip,
  previous,
  stop,
  leave,
  loop,
  shuffle,
  seek,
  remove,
  clear,
  autoplay,
  twentyFourSeven,
  help,
];
