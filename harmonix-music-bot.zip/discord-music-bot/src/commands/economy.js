'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const eco = require('../engagement/economy');
const { config } = require('../../config');
const { humanizeDuration } = require('../utils/duration');
const { userTag } = require('../utils/format');

const MANAGE = PermissionFlagsBits.ManageGuild;

const data = new SlashCommandBuilder()
  .setName('economy')
  .setDescription('Server economy: currency, daily rewards, shop and games')
  .setDMPermission(false)
  .addSubcommand((s) => s.setName('balance').setDescription('Check a balance').addUserOption((o) => o.setName('user').setDescription('Whose balance').setRequired(false)))
  .addSubcommand((s) => s.setName('daily').setDescription('Claim your daily reward'))
  .addSubcommand((s) => s.setName('work').setDescription('Work for some coins'))
  .addSubcommand((s) => s.setName('give').setDescription('Give coins to someone').addUserOption((o) => o.setName('user').setDescription('Recipient').setRequired(true)).addIntegerOption((o) => o.setName('amount').setDescription('Amount').setRequired(true).setMinValue(1)))
  .addSubcommand((s) => s.setName('leaderboard').setDescription('Richest members'))
  .addSubcommand((s) => s.setName('slots').setDescription('Spin the slot machine').addIntegerOption((o) => o.setName('bet').setDescription('Amount to bet').setRequired(true).setMinValue(1).setMaxValue(1000000)))
  .addSubcommand((s) => s.setName('coinflip').setDescription('Bet on a coin flip').addIntegerOption((o) => o.setName('bet').setDescription('Amount to bet').setRequired(true).setMinValue(1).setMaxValue(1000000)).addStringOption((o) => o.setName('side').setDescription('heads or tails').setRequired(true).addChoices({ name: 'heads', value: 'heads' }, { name: 'tails', value: 'tails' })))
  .addSubcommandGroup((g) =>
    g
      .setName('shop')
      .setDescription('Server shop')
      .addSubcommand((s) => s.setName('list').setDescription('Browse the shop'))
      .addSubcommand((s) => s.setName('buy').setDescription('Buy an item').addStringOption((o) => o.setName('item').setDescription('Item name').setRequired(true)))
      .addSubcommand((s) => s.setName('additem').setDescription('Add a shop item (admin)').addStringOption((o) => o.setName('name').setDescription('Item name').setRequired(true)).addIntegerOption((o) => o.setName('price').setDescription('Price').setRequired(true).setMinValue(1)).addRoleOption((o) => o.setName('role').setDescription('Role granted on purchase').setRequired(false)).addStringOption((o) => o.setName('description').setDescription('Description').setRequired(false)))
      .addSubcommand((s) => s.setName('removeitem').setDescription('Remove a shop item (admin)').addStringOption((o) => o.setName('name').setDescription('Item name').setRequired(true)))
  )
  .addSubcommandGroup((g) =>
    g
      .setName('admin')
      .setDescription('Adjust balances (admin)')
      .addSubcommand((s) => s.setName('add').setDescription('Add coins to a user').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)).addIntegerOption((o) => o.setName('amount').setDescription('Amount').setRequired(true).setMinValue(1)))
      .addSubcommand((s) => s.setName('remove').setDescription('Remove coins from a user').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)).addIntegerOption((o) => o.setName('amount').setDescription('Amount').setRequired(true).setMinValue(1)))
      .addSubcommand((s) => s.setName('set').setDescription('Set a user’s balance').addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)).addIntegerOption((o) => o.setName('amount').setDescription('Balance').setRequired(true).setMinValue(0)))
  )
  .addSubcommandGroup((g) =>
    g
      .setName('config')
      .setDescription('Economy settings (admin)')
      .addSubcommand((s) => s.setName('currency').setDescription('Set currency name & symbol').addStringOption((o) => o.setName('name').setDescription('Currency name').setRequired(false)).addStringOption((o) => o.setName('symbol').setDescription('Currency symbol/emoji').setRequired(false)))
      .addSubcommand((s) => s.setName('rates').setDescription('Set daily/work payouts').addIntegerOption((o) => o.setName('daily').setDescription('Daily reward').setMinValue(0).setRequired(false)).addIntegerOption((o) => o.setName('work_min').setDescription('Minimum work payout').setMinValue(0).setRequired(false)).addIntegerOption((o) => o.setName('work_max').setDescription('Maximum work payout').setMinValue(0).setRequired(false)))
  );

function needManage(interaction) {
  if (!interaction.memberPermissions.has(MANAGE)) {
    interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    return false;
  }
  return true;
}

async function execute(client, interaction) {
  const gid = interaction.guildId;
  const cfg = eco.getCfg(gid);
  const group = interaction.options.getSubcommandGroup(false);
  const sub = interaction.options.getSubcommand();

  // ── plain subcommands ──────────────────────────────────────────
  if (!group) {
    if (sub === 'balance') {
      const user = interaction.options.getUser('user') || interaction.user;
      const acc = eco.account(gid, user.id);
      const embed = new EmbedBuilder().setColor(config.brand.color)
        .setAuthor({ name: userTag(user), iconURL: user.displayAvatarURL() })
        .setDescription(`Balance: ${eco.fmt(acc.balance, cfg)}${acc.streak ? `\nDaily streak: **${acc.streak}** 🔥` : ''}`);
      return interaction.reply({ embeds: [embed] });
    }
    if (sub === 'daily') {
      const r = eco.claimDaily(gid, interaction.user.id);
      if (!r.ok) return interaction.reply({ content: `⏳ You’ve already claimed today. Come back in **${humanizeDuration(r.nextIn)}**.`, ephemeral: true });
      return interaction.reply({ content: `🎁 You claimed ${eco.fmt(r.amount, cfg)}${r.bonus ? ` (incl. +${r.bonus} streak bonus)` : ''}! Streak: **${r.streak}** 🔥\nBalance: ${eco.fmt(r.balance, cfg)}` });
    }
    if (sub === 'work') {
      const r = eco.work(gid, interaction.user.id);
      if (!r.ok) return interaction.reply({ content: `⏳ You’re tired. Try again in **${humanizeDuration(r.nextIn)}**.`, ephemeral: true });
      return interaction.reply({ content: `💼 You worked and earned ${eco.fmt(r.amount, cfg)}!\nBalance: ${eco.fmt(r.balance, cfg)}` });
    }
    if (sub === 'give') {
      const to = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('amount');
      if (to.bot) return interaction.reply({ content: 'You can’t give coins to a bot.', ephemeral: true });
      const r = eco.transfer(gid, interaction.user.id, to.id, amount);
      if (!r.ok) return interaction.reply({ content: r.reason, ephemeral: true });
      return interaction.reply({ content: `💸 You gave ${eco.fmt(amount, cfg)} to <@${to.id}>.` });
    }
    if (sub === 'leaderboard') {
      const rows = eco.top(gid, 10);
      if (!rows.length) return interaction.reply({ content: 'Nobody has any coins yet!', ephemeral: true });
      const medals = ['🥇', '🥈', '🥉'];
      const lines = rows.map((r, i) => `${medals[i] || `**${i + 1}.**`} <@${r.user_id}> — ${eco.fmt(r.balance, cfg)}`);
      const embed = new EmbedBuilder().setColor(config.brand.color).setTitle(`💰 Richest members`).setDescription(lines.join('\n'));
      return interaction.reply({ embeds: [embed] });
    }
    if (sub === 'slots' || sub === 'coinflip') {
      const bet = interaction.options.getInteger('bet');
      if (eco.balance(gid, interaction.user.id) < bet) return interaction.reply({ content: `You don’t have ${eco.fmt(bet, cfg)}.`, ephemeral: true });
      if (sub === 'slots') {
        const r = eco.slots(bet);
        eco.addBalance(gid, interaction.user.id, r.net);
        const outcome = r.mult ? `You won ${eco.fmt(r.payout, cfg)} (${r.mult}×)! 🎉` : `You lost ${eco.fmt(bet, cfg)}. 😔`;
        return interaction.reply({ content: `🎰 ┃ ${r.reels.join(' ┃ ')} ┃\n${outcome}\nBalance: ${eco.fmt(eco.balance(gid, interaction.user.id), cfg)}` });
      }
      const side = interaction.options.getString('side');
      const r = eco.coinflip(bet, side);
      eco.addBalance(gid, interaction.user.id, r.net);
      return interaction.reply({ content: `🪙 It landed on **${r.result}** — you ${r.win ? `won ${eco.fmt(bet, cfg)}! 🎉` : `lost ${eco.fmt(bet, cfg)}. 😔`}\nBalance: ${eco.fmt(eco.balance(gid, interaction.user.id), cfg)}` });
    }
  }

  // ── shop ───────────────────────────────────────────────────────
  if (group === 'shop') {
    if (sub === 'list') {
      const items = eco.listItems(gid);
      if (!items.length) return interaction.reply({ content: 'The shop is empty.', ephemeral: true });
      const lines = items.map((it) => `**${it.name}** — ${eco.fmt(it.price, cfg)}${it.role_id ? ` → <@&${it.role_id}>` : ''}${it.description ? `\n   ${it.description}` : ''}`);
      const embed = new EmbedBuilder().setColor(config.brand.color).setTitle('🛒 Shop').setDescription(lines.join('\n')).setFooter({ text: 'Buy with /economy shop buy <item>' });
      return interaction.reply({ embeds: [embed] });
    }
    if (sub === 'buy') {
      const name = interaction.options.getString('item');
      const item = eco.getItemByName(gid, name);
      if (!item) return interaction.reply({ content: `No item called **${name}**. See \`/economy shop list\`.`, ephemeral: true });
      if (eco.balance(gid, interaction.user.id) < item.price) return interaction.reply({ content: `You need ${eco.fmt(item.price, cfg)} to buy that.`, ephemeral: true });
      if (item.role_id) {
        if (interaction.member.roles.cache.has(item.role_id)) return interaction.reply({ content: 'You already own that role.', ephemeral: true });
        const me = interaction.guild.members.me;
        const role = interaction.guild.roles.cache.get(item.role_id);
        if (!role || !me.permissions.has(PermissionFlagsBits.ManageRoles) || role.position >= me.roles.highest.position) {
          return interaction.reply({ content: '⚠️ I can’t grant that role — check my **Manage Roles** permission and role position.', ephemeral: true });
        }
        await interaction.member.roles.add(role.id, 'Shop purchase').catch(() => {});
      }
      eco.addBalance(gid, interaction.user.id, -item.price);
      return interaction.reply({ content: `✅ You bought **${item.name}** for ${eco.fmt(item.price, cfg)}.${item.role_id ? ` Role <@&${item.role_id}> granted!` : ''}` });
    }
    if (sub === 'additem') {
      if (!needManage(interaction)) return;
      eco.addItem(gid, interaction.options.getString('name'), interaction.options.getInteger('price'), interaction.options.getRole('role')?.id, interaction.options.getString('description'));
      return interaction.reply({ content: `✅ Added **${interaction.options.getString('name')}** to the shop.`, ephemeral: true });
    }
    if (sub === 'removeitem') {
      if (!needManage(interaction)) return;
      const ok = eco.removeItemByName(gid, interaction.options.getString('name'));
      return interaction.reply({ content: ok ? '✅ Removed.' : 'No item by that name.', ephemeral: true });
    }
  }

  // ── admin ──────────────────────────────────────────────────────
  if (group === 'admin') {
    if (!needManage(interaction)) return;
    const user = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    if (sub === 'add') { const b = eco.addBalance(gid, user.id, amount); return interaction.reply({ content: `Added ${eco.fmt(amount, cfg)} to <@${user.id}> (now ${eco.fmt(b, cfg)}).`, ephemeral: true }); }
    if (sub === 'remove') { const b = eco.addBalance(gid, user.id, -amount); return interaction.reply({ content: `Removed ${eco.fmt(amount, cfg)} from <@${user.id}> (now ${eco.fmt(b, cfg)}).`, ephemeral: true }); }
    if (sub === 'set') { const b = eco.setBalance(gid, user.id, amount); return interaction.reply({ content: `Set <@${user.id}>’s balance to ${eco.fmt(b, cfg)}.`, ephemeral: true }); }
  }

  // ── config ─────────────────────────────────────────────────────
  if (group === 'config') {
    if (!needManage(interaction)) return;
    if (sub === 'currency') {
      const patch = {};
      const name = interaction.options.getString('name');
      const symbol = interaction.options.getString('symbol');
      if (name) patch.name = name;
      if (symbol) patch.symbol = symbol;
      const next = eco.setCfg(gid, patch);
      return interaction.reply({ content: `Currency is now **${next.name}** ${next.symbol}.`, ephemeral: true });
    }
    if (sub === 'rates') {
      const patch = {};
      const daily = interaction.options.getInteger('daily');
      const wmin = interaction.options.getInteger('work_min');
      const wmax = interaction.options.getInteger('work_max');
      if (daily != null) patch.daily = daily;
      if (wmin != null) patch.workMin = wmin;
      if (wmax != null) patch.workMax = wmax;
      const next = eco.setCfg(gid, patch);
      if (next.workMin > next.workMax) return interaction.reply({ content: '⚠️ work_min can’t exceed work_max.', ephemeral: true });
      return interaction.reply({ content: `Daily: ${next.daily} • Work: ${next.workMin}–${next.workMax} ${next.symbol}`, ephemeral: true });
    }
  }
}

module.exports = { data, execute };
