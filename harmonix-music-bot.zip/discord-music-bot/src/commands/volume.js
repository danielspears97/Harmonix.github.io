'use strict';

const { SlashCommandBuilder } = require('discord.js');
const controller = require('../controller');
const { voiceGuard } = require('../utils/guards');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set the playback volume (0-150).')
    .addIntegerOption((o) =>
      o.setName('percent').setDescription('Volume from 0 to 150').setMinValue(0).setMaxValue(controller.VOLUME_MAX).setRequired(true)
    ),

  async execute(client, interaction) {
    const guard = voiceGuard(client, interaction);
    if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });
    const percent = interaction.options.getInteger('percent', true);
    const r = await controller.setVolume(client, interaction.guildId, percent);
    return interaction.reply({ content: `🔊 Volume set to **${r.volume}%**.`, ephemeral: true });
  },
};
