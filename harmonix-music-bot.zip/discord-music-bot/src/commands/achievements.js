'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const achievements = require('../engagement/achievements');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('achievements')
    .setDMPermission(false)
    .setDescription('View unlocked badges')
    .addUserOption((o) => o.setName('user').setDescription('Whose achievements to view (default: you)')),
  async execute(client, interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const list = achievements.list(interaction.guildId, target.id);
    const unlocked = list.filter((a) => a.unlocked);

    const lines = list.map((a) => (a.unlocked ? `${a.emoji} **${a.name}** — ${a.desc}` : `🔒 ~~${a.name}~~ — ${a.desc}`));
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setAuthor({ name: `${target.username}'s achievements`, iconURL: target.displayAvatarURL() })
      .setDescription(lines.join('\n'))
      .setFooter({ text: `${unlocked.length} of ${list.length} unlocked` });
    return interaction.reply({ embeds: [embed] });
  },
};
