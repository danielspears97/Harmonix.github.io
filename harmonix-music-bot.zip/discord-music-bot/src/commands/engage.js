'use strict';
// /engage — community engagement extras
const { composeCategory } = require('../utils/compose');
const poll = require('./_engagement/poll');       // group
const giveaway = require('./_engagement/giveaway'); // group
const tempchannels = require('./_engagement/tempchannels'); // [tempvoice (group), temptext]
module.exports = composeCategory('engage', 'Polls, giveaways & temporary channels', [poll, giveaway, ...tempchannels]);
