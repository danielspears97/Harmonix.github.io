'use strict';
// /engage — community engagement extras
const { composeCategory } = require('../utils/compose');
const poll = require('./_engagement/poll');       // group
const giveaway = require('./_engagement/giveaway'); // group
const tempchannels = require('./_engagement/tempchannels'); // [tempvoice (group), temptext]
const event = require('./_engagement/event');
module.exports = composeCategory('engage', 'Polls, giveaways, events & temporary channels', [poll, giveaway, event, ...tempchannels]);
