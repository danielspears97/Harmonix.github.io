'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const controller = require('../controller');
const { config } = require('../../config');
const { progressBar, truncate } = require('../utils/format');

module.exports = {
  data: new SlashCommandBuilder().setName('nowplaying').setDescription('Show the track that is currently playing.'),

  async execute(client, interaction) {
    const state = controller.getState(client, interaction.guildId);
    if (!state.current) {
      return interaction.reply({ content: 'Nothing is playing right now.', ephemeral: true });
    }
    const t = state.current;
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setAuthor({ name: state.paused ? 'Paused' : 'Now Playing' })
      .setTitle(truncate(t.title, 80))
      .setURL(t.uri || null)
      .setDescription(t.isStream ? '🔴 **LIVE**' : progressBar(state.position, t.duration))
      .addFields(
        { name: 'Artist', value: truncate(t.author, 40) || '—', inline: true },
        { name: 'Source', value: t.sourceName, inline: true },
        { name: 'Requested by', value: t.requester ? `<@${t.requester.id}>` : 'Autoplay', inline: true }
      );
    if (t.artworkUrl) embed.setImage(t.artworkUrl);
    return interaction.reply({ embeds: [embed] });
  },
};
