'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const guildSettings = require('../server/guildSettings');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('voicelock')
    .setDescription('Restrict music to a single voice channel')
    .setDMPermission(false)
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) => s
      .setName('set')
      .setDescription('Lock music to a voice channel')
      .addChannelOption((o) => o.setName('channel').setDescription('Voice channel to lock music to').addChannelTypes(ChannelType.GuildVoice).setRequired(true)))
    .addSubcommand((s) => s.setName('off').setDescription('Remove the music voice lock'))
    .addSubcommand((s) => s.setName('status').setDescription('Show the current music voice lock')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();
    if (sub === 'set') {
      const ch = interaction.options.getChannel('channel');
      guildSettings.setMusicChannel(interaction.guildId, ch.id);
      return interaction.reply({ content: `🔒 Music is now locked to ${ch}. Members must be in that channel to play.`, ephemeral: true });
    }
    if (sub === 'off') {
      guildSettings.setMusicChannel(interaction.guildId, null);
      return interaction.reply({ content: '🔓 Music voice lock removed — any voice channel works again.', ephemeral: true });
    }
    const cur = guildSettings.getMusicChannel(interaction.guildId);
    return interaction.reply({ content: cur ? `🔒 Music is locked to <#${cur}>.` : '🔓 No music voice lock is set.', ephemeral: true });
  },
};
