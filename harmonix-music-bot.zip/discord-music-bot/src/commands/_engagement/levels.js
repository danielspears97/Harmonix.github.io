'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const levels = require('../../engagement/levels');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

function bar(have, need, len = 16) {
  const ratio = need > 0 ? Math.min(1, have / need) : 0;
  const filled = Math.round(ratio * len);
  return '▰'.repeat(filled) + '▱'.repeat(len - filled);
}

// ── /rank ────────────────────────────────────────────────────────
const rank = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Show your (or someone’s) level and XP')
    .setDMPermission(false)
    .addUserOption((o) => o.setName('user').setDescription('Whose rank to show').setRequired(false)),
  async execute(client, interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const info = levels.rankOf(interaction.guildId, target.id);
    const prog = levels.levelProgress(info.xp);
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setAuthor({ name: target.username, iconURL: target.displayAvatarURL() })
      .addFields(
        { name: 'Level', value: `**${prog.level}**`, inline: true },
        { name: 'Rank', value: `**#${info.rank}**`, inline: true },
        { name: 'Total XP', value: `**${info.xp}**`, inline: true },
        { name: `Progress — ${prog.have} / ${prog.need} XP`, value: bar(prog.have, prog.need) }
      );
    return interaction.reply({ embeds: [embed] });
  },
};

// ── /leaderboard ─────────────────────────────────────────────────
const leaderboard = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Show the server XP leaderboard')
    .setDMPermission(false),
  async execute(client, interaction) {
    const rows = levels.top(interaction.guildId, 10);
    if (!rows.length) return interaction.reply({ content: 'No XP earned yet. Start chatting!', ephemeral: true });
    const medals = ['🥇', '🥈', '🥉'];
    const lines = rows.map((r, i) => {
      const place = medals[i] || `**${i + 1}.**`;
      return `${place} <@${r.user_id}> — Level **${r.level}** · ${r.xp} XP`;
    });
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setTitle(`🏆 ${interaction.guild.name} — Leaderboard`)
      .setDescription(lines.join('\n'));
    return interaction.reply({ embeds: [embed] });
  },
};

// ── /levels (config) ─────────────────────────────────────────────
const levelsConfig = {
  data: new SlashCommandBuilder()
    .setName('levels')
    .setDescription('Configure the leveling system')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) => s.setName('enable').setDescription('Turn leveling on'))
    .addSubcommand((s) => s.setName('disable').setDescription('Turn leveling off'))
    .addSubcommand((s) =>
      s.setName('announce').setDescription('Toggle level-up announcements').addBooleanOption((o) => o.setName('enabled').setDescription('On/off').setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('setxp')
        .setDescription('Set a member’s total XP')
        .addUserOption((o) => o.setName('user').setDescription('Member').setRequired(true))
        .addIntegerOption((o) => o.setName('xp').setDescription('Total XP').setRequired(true).setMinValue(0))
    )
    .addSubcommandGroup((g) =>
      g
        .setName('reward')
        .setDescription('Role rewards for reaching levels')
        .addSubcommand((s) =>
          s
            .setName('add')
            .setDescription('Add a role reward at a level')
            .addIntegerOption((o) => o.setName('level').setDescription('Level').setRequired(true).setMinValue(1))
            .addRoleOption((o) => o.setName('role').setDescription('Role to grant').setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('remove').setDescription('Remove a role reward').addIntegerOption((o) => o.setName('level').setDescription('Level').setRequired(true).setMinValue(1))
        )
        .addSubcommand((s) => s.setName('list').setDescription('List role rewards'))
    ),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const gid = interaction.guildId;
    const settings = levels.getSettings(gid);
    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();

    if (group === 'reward') {
      if (sub === 'add') {
        const level = interaction.options.getInteger('level');
        const role = interaction.options.getRole('role');
        settings.rewards = settings.rewards.filter((r) => r.level !== level);
        settings.rewards.push({ level, roleId: role.id });
        settings.rewards.sort((a, b) => a.level - b.level);
        levels.saveSettings(gid, settings);
        return interaction.reply({ content: `✅ ${role} will be granted at level **${level}**.`, ephemeral: true });
      }
      if (sub === 'remove') {
        const level = interaction.options.getInteger('level');
        settings.rewards = settings.rewards.filter((r) => r.level !== level);
        levels.saveSettings(gid, settings);
        return interaction.reply({ content: `Removed the reward at level **${level}**.`, ephemeral: true });
      }
      // list
      if (!settings.rewards.length) return interaction.reply({ content: 'No level rewards set.', ephemeral: true });
      return interaction.reply({
        content: settings.rewards.map((r) => `Level **${r.level}** → <@&${r.roleId}>`).join('\n'),
        ephemeral: true,
      });
    }

    if (sub === 'enable' || sub === 'disable') {
      settings.enabled = sub === 'enable';
      levels.saveSettings(gid, settings);
      return interaction.reply({ content: `Leveling **${settings.enabled ? 'enabled' : 'disabled'}**.`, ephemeral: true });
    }
    if (sub === 'announce') {
      settings.announce = interaction.options.getBoolean('enabled');
      levels.saveSettings(gid, settings);
      return interaction.reply({ content: `Level-up announcements **${settings.announce ? 'on' : 'off'}**.`, ephemeral: true });
    }
    if (sub === 'setxp') {
      const user = interaction.options.getUser('user');
      const xp = interaction.options.getInteger('xp');
      const res = levels.setXp(gid, user.id, xp);
      return interaction.reply({ content: `Set ${user}'s XP to **${res.xp}** (level ${res.level}).`, ephemeral: true });
    }
  },
};

module.exports = [rank, leaderboard, levelsConfig];
