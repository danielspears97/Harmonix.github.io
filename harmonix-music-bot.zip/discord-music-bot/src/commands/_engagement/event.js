'use strict';

const {
  SlashCommandBuilder, PermissionFlagsBits, ModalBuilder, TextInputBuilder,
  TextInputStyle, ActionRowBuilder, EmbedBuilder,
} = require('discord.js');
const events = require('../../engagement/events');
const { getTimezone } = require('../../server/userSettings');

const MANAGE = PermissionFlagsBits.ManageEvents;
const KEEP_AFTER_START_MS = 24 * 60 * 60 * 1000; // auto-remove a day after it starts

const DEFAULT_RSVP = [
  { emoji: '\u2705', label: 'Going' },
  { emoji: '\u274C', label: "Can't make it" },
  { emoji: '\u2753', label: 'Maybe' },
];
// Used when a chunk has no emoji of its own, or repeats one already taken.
const FALLBACK_EMOJI = ['\u2705', '\u274C', '\u2753', '\uD83D\uDD35', '\uD83D\uDFE3'];

/**
 * Turn "✅ Going, ❌ Can't, ❓ Maybe" (or plain "Going, Can't, Maybe") into
 * button definitions. Every comma-separated chunk becomes its own button;
 * missing or duplicated emoji get a distinct fallback rather than being
 * dropped, which previously collapsed the whole list down to one button.
 */
function parseReactions(raw) {
  const chunks = String(raw || '').split(',').map((c) => c.trim()).filter(Boolean);
  if (!chunks.length) return DEFAULT_RSVP.slice();

  const used = new Set();
  const out = [];
  for (const chunk of chunks) {
    // a custom emoji <:name:id>, or a real pictographic emoji (with any
    // variation selector / ZWJ sequence) at the start of the chunk
    const m = chunk.match(/^(<a?:\w+:\d+>|\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic}|\p{Emoji_Modifier})*)\s*(.*)$/u);
    let emoji = m ? m[1] : null;
    let label = (m ? m[2] : chunk).trim();
    if (!label) label = emoji ? 'RSVP' : chunk;
    if (!emoji || used.has(emoji)) emoji = FALLBACK_EMOJI.find((e) => !used.has(e)) || null;
    if (!emoji) continue; // ran out of distinct fallbacks (>5 unlabelled)
    used.add(emoji);
    out.push({ emoji, label: label.slice(0, 40) || 'RSVP' });
    if (out.length === 5) break; // Discord allows 5 buttons per row
  }
  return out.length ? out : DEFAULT_RSVP.slice();
}

function buildModal(repeat = '') {
  const modal = new ModalBuilder()
    .setCustomId(repeat ? `event:create:${repeat}` : 'event:create')
    .setTitle('Create an event');
  modal.addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('Event name').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('desc').setLabel('Description').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(1000)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('when').setLabel('Start time (your timezone)').setPlaceholder('2026-08-14 19:30   or   +2h30m').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(60)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('image').setLabel('Image URL (optional)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(400)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reacts').setLabel('RSVP buttons (blank = Going/Can’t/Maybe)').setPlaceholder('✅ Going, ❌ Can’t, ❓ Maybe').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(200)),
  );
  return modal;
}

const command = {
  data: new SlashCommandBuilder()
    .setName('event')
    .setDescription('Create and manage events with RSVP buttons')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addSubcommand((s) => s.setName('create').setDescription('Open the event form (posts to this channel)')
      .addStringOption((o) => o.setName('repeat')
        .setDescription('How often to repeat — pick one or type your own (e.g. "every 5 days")')
        .setRequired(false)
        .setAutocomplete(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List upcoming events'))
    .addSubcommand((s) => s.setName('cancel').setDescription('Cancel an event').addIntegerOption((o) => o.setName('id').setDescription('Event # (from /event list)').setRequired(true)))
    .addSubcommand((s) => s.setName('format').setDescription('How this server reads dates you type')
      .addStringOption((o) => o.setName('style').setDescription('Date order').setRequired(true)
        .addChoices(
          { name: 'US - month/day/year (8/14/2026)', value: 'mdy' },
          { name: 'EU - day/month/year (14/08/2026)', value: 'dmy' },
          { name: 'ISO - year-month-day (2026-08-14)', value: 'ymd' },
        ))),

  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      const raw = interaction.options.getString('repeat') || '';
      const repeat = events.parseRepeat(raw);
      if (raw && !repeat) {
        return interaction.reply({
          content: `❌ I couldn’t read the repeat “${raw}”. Try a preset like \`weekly\`, or something like \`every 5 days\` / \`3w\` / \`every 6 months\`.`,
          ephemeral: true,
        });
      }
      return interaction.showModal(buildModal(repeat || ''));
    }

    if (sub === 'format') {
      const style = interaction.options.getString('style');
      events.setTimeFormat(interaction.guildId, style);
      const f = events.TIME_FORMATS[style];
      return interaction.reply({ content: `📅 Dates are now read as **${f.label}**. Example: \`${f.example}\``, ephemeral: true });
    }

    if (sub === 'list') {
      const list = events.upcomingForGuild(interaction.guildId);
      if (!list.length) return interaction.reply({ content: 'No upcoming events.', ephemeral: true });
      const embed = new EmbedBuilder()
        .setColor(0xf04c3c)
        .setTitle('📅 Upcoming events')
        .setDescription(list.map((e) => {
          const rule = events.repeatRule(e.repeat_mode);
          const next = rule ? events.nextOccurrence(e.start_at, e.repeat_mode) : null;
          const r = rule ? `\n\u00a0 \u00a0 🔁 repeats ${rule.label.toLowerCase()}${next ? ` · next <t:${Math.floor(next / 1000)}:D>` : ''}` : '';
          return `**#${e.id}** — ${e.name} · <t:${Math.floor(e.start_at / 1000)}:R>${r}`;
        }).join('\n'));
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getInteger('id');
      const ev = events.get(id);
      if (!ev || ev.guild_id !== interaction.guildId) return interaction.reply({ content: 'No event with that ID.', ephemeral: true });
      if (ev.message_id) {
        const ch = await client.channels.fetch(ev.channel_id).catch(() => null);
        const msg = ch && await ch.messages.fetch(ev.message_id).catch(() => null);
        if (msg) await msg.delete().catch(() => {});
      }
      events.remove(id, interaction.guildId);
      return interaction.reply({ content: `Event #${id} cancelled.`, ephemeral: true });
    }
    return interaction.reply({ content: 'Unknown subcommand.', ephemeral: true });
  },

  /** Suggest repeat presets, and echo a valid custom interval as you type. */
  async autocomplete(client, interaction) {
    const focused = String(interaction.options.getFocused() || '').toLowerCase();
    const presets = Object.entries(events.REPEAT).map(([value, r]) => ({ name: r.label, value }));
    const out = [];

    const typed = events.parseRepeat(focused);
    if (focused && typed && !events.REPEAT[typed]) {
      const rule = events.repeatRule(typed);
      out.push({ name: `${rule.label}  (custom)`, value: typed });
    }
    out.push(...presets.filter((p) => !focused || p.name.toLowerCase().includes(focused) || p.value.includes(focused)));
    if (!out.length) out.push(...presets);
    return interaction.respond(out.slice(0, 25));
  },

  // modal submit (customId 'event:create') — posts to the channel it was opened in
  async handleModal(client, interaction) {
    const tz = getTimezone(interaction.user.id) || 'UTC';
    const fmt = events.getTimeFormat(interaction.guildId);
    const repeatMode = interaction.customId.split(':')[2] || null;
    const name = interaction.fields.getTextInputValue('name');
    const description = interaction.fields.getTextInputValue('desc');
    const image = interaction.fields.getTextInputValue('image');
    const startAt = events.parseWhen(interaction.fields.getTextInputValue('when'), tz, fmt);
    const reactions = parseReactions(interaction.fields.getTextInputValue('reacts'));

    if (!startAt || startAt < Date.now() - 60000) {
      const f = events.TIME_FORMATS[fmt];
      return interaction.reply({
        content: `❌ I couldn’t read that start time.\nThis server reads dates as **${f.label}** — e.g. \`${f.example}\`. Relative times like \`+2h30m\` also work.\nChange the style with \`/event format\`, and set your zone with \`/timezone\`.`,
        ephemeral: true,
      });
    }
    if (image && !/^https?:\/\//i.test(image)) {
      return interaction.reply({ content: '❌ The image must be a direct http(s) URL.', ephemeral: true });
    }

    const ev = events.create({
      guildId: interaction.guildId,
      channelId: interaction.channelId,
      creatorId: interaction.user.id,
      name,
      description,
      imageUrl: image || null,
      startAt,
      postAt: Date.now(), // post immediately
      removeAt: startAt + KEEP_AFTER_START_MS,
      reactions,
      repeatMode,
    });

    // post right away rather than waiting for the scheduler tick
    const msg = await interaction.channel
      .send({ embeds: [events.buildEmbed(ev)], components: events.buildComponents(ev) })
      .catch(() => null);
    if (msg) events.setMessage(ev.id, msg.id);

    let rep = '';
    const rule = events.repeatRule(repeatMode);
    if (rule) {
      const next = events.nextOccurrence(startAt, repeatMode);
      rep = ` · repeats **${rule.label.toLowerCase()}**${next ? ` (next <t:${Math.floor(next / 1000)}:D>)` : ''}`;
    }
    await interaction.reply({ content: `✅ **${name}** is up (event #${ev.id}) — starts <t:${Math.floor(startAt / 1000)}:R>${rep}.`, ephemeral: true });
  },

  // RSVP button (customId event:rsvp:<eventId>:<index>) — single choice
  async handleButton(client, interaction) {
    const [, , idStr, idxStr] = interaction.customId.split(':');
    const ev = events.get(Number(idStr));
    if (!ev) return interaction.reply({ content: 'This event no longer exists.', ephemeral: true });
    const choice = ev.reactions[Number(idxStr)];
    if (!choice) return interaction.reply({ content: 'That option is gone.', ephemeral: true });

    const res = events.setRsvp(ev.id, interaction.user.id, choice.emoji);
    await require('../../engagement/eventScheduler').refresh(client, events.get(ev.id));

    const msg = res.status === 'removed'
      ? `Removed your RSVP.`
      : res.status === 'changed'
        ? `Changed your RSVP to **${choice.label}** ${choice.emoji}`
        : `You're down for **${choice.label}** ${choice.emoji}`;
    return interaction.reply({ content: msg, ephemeral: true });
  },
};

module.exports = command;
