'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const { getConfig, setConfig, deleteConfig } = require('../../db');

const MAX_GUESSES = 6;
const ANSWERS = [
  'crane', 'pluck', 'mango', 'flint', 'jolly', 'quirk', 'vivid', 'zesty', 'brisk', 'cloud',
  'dwarf', 'ember', 'frost', 'glove', 'haunt', 'ivory', 'knack', 'lemon', 'mirth', 'noble',
  'olive', 'prism', 'quilt', 'raven', 'spice', 'tiger', 'usher', 'vault', 'wharf', 'yacht',
  'zebra', 'angle', 'blaze', 'charm', 'drift', 'eagle', 'fjord', 'grape', 'hatch', 'inlet',
];

const key = (channelId, userId) => `wordle:${channelId}:${userId}`;

function score(guess, answer) {
  const res = Array(5).fill('⬛');
  const a = answer.split('');
  for (let i = 0; i < 5; i++) if (guess[i] === a[i]) { res[i] = '🟩'; a[i] = null; }
  for (let i = 0; i < 5; i++) {
    if (res[i] === '🟩') continue;
    const idx = a.indexOf(guess[i]);
    if (idx !== -1) { res[i] = '🟨'; a[idx] = null; }
  }
  return res.join('');
}

function render(state, title) {
  const lines = state.guesses.map((g) => `${g.marks}  \`${g.word.toUpperCase().split('').join(' ')}\``);
  const blanks = MAX_GUESSES - state.guesses.length;
  const embed = new EmbedBuilder()
    .setColor(state.status === 'won' ? config.brand.successColor : state.status === 'lost' ? config.brand.errorColor : config.brand.color)
    .setTitle('🟩 Wordle')
    .setDescription(lines.join('\n') + (blanks > 0 && state.status === 'playing' ? `\n${'⬜⬜⬜⬜⬜\n'.repeat(blanks).trim()}` : ''));
  if (state.status === 'won') embed.setFooter({ text: `Solved in ${state.guesses.length}/${MAX_GUESSES}! 🎉` });
  if (state.status === 'lost') embed.setFooter({ text: `Out of guesses — the word was ${state.answer.toUpperCase()}.` });
  if (title) embed.setAuthor({ name: title });
  return embed;
}

const command = {
  data: new SlashCommandBuilder()
    .setName('wordle')
    .setDescription('Play Wordle (your own game in this channel)')
    .setDMPermission(false)
    .addSubcommand((s) => s.setName('start').setDescription('Start a new game'))
    .addSubcommand((s) => s.setName('guess').setDescription('Guess a 5-letter word').addStringOption((o) => o.setName('word').setDescription('5-letter word').setRequired(true)))
    .addSubcommand((s) => s.setName('quit').setDescription('Give up your game')),
  async execute(client, interaction) {
    const k = key(interaction.channel.id, interaction.user.id);
    const sub = interaction.options.getSubcommand();
    const existing = getConfig(interaction.guildId, k, null);

    if (sub === 'start') {
      if (existing && existing.status === 'playing') return interaction.reply({ content: 'You already have a game going here — use `/game wordle guess`.', ephemeral: true });
      const state = { answer: ANSWERS[Math.floor(Math.random() * ANSWERS.length)], guesses: [], status: 'playing' };
      setConfig(interaction.guildId, k, state);
      return interaction.reply({ embeds: [render(state, 'New game — guess a 5-letter word with /wordle guess')], ephemeral: true });
    }
    if (sub === 'quit') {
      if (!existing) return interaction.reply({ content: 'No game to quit.', ephemeral: true });
      deleteConfig(interaction.guildId, k);
      return interaction.reply({ content: `Gave up — the word was **${existing.answer.toUpperCase()}**.`, ephemeral: true });
    }
    // guess
    if (!existing || existing.status !== 'playing') return interaction.reply({ content: 'No active game. Start one with `/game wordle start`.', ephemeral: true });
    const word = interaction.options.getString('word').toLowerCase().trim();
    if (!/^[a-z]{5}$/.test(word)) return interaction.reply({ content: 'Guess must be exactly 5 letters.', ephemeral: true });

    existing.guesses.push({ word, marks: score(word, existing.answer) });
    if (word === existing.answer) existing.status = 'won';
    else if (existing.guesses.length >= MAX_GUESSES) existing.status = 'lost';

    if (existing.status === 'playing') setConfig(interaction.guildId, k, existing);
    else deleteConfig(interaction.guildId, k);

    return interaction.reply({ embeds: [render(existing)], ephemeral: true });
  },
};

module.exports = command;
