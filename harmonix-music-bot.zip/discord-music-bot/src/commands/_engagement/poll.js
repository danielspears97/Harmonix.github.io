'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const polls = require('../../engagement/polls');

// ── command ──────────────────────────────────────────────────────
const command = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a live poll')
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Start a new poll')
        .addStringOption((o) => o.setName('question').setDescription('The poll question').setRequired(true))
        .addStringOption((o) =>
          o.setName('options').setDescription('Options separated by | (or commas), 2–10').setRequired(true)
        )
        .addBooleanOption((o) => o.setName('multi').setDescription('Allow choosing more than one option').setRequired(false))
    )
    .addSubcommand((s) =>
      s.setName('end').setDescription('Close a poll').addStringOption((o) => o.setName('message_id').setDescription('Poll message ID').setRequired(true))
    ),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      const question = interaction.options.getString('question');
      const raw = interaction.options.getString('options');
      const multi = interaction.options.getBoolean('multi') || false;
      const options = raw
        .split(raw.includes('|') ? '|' : ',')
        .map((o) => o.trim())
        .filter(Boolean)
        .slice(0, polls.MAX_OPTIONS);
      if (options.length < 2) {
        return interaction.reply({ content: 'Give at least 2 options, separated by `|`.', ephemeral: true });
      }

      await interaction.deferReply({ ephemeral: true });
      const pollStub = { question, options, multi, closed: false, message_id: '0' };
      const msg = await interaction.channel
        .send({ embeds: [polls.buildEmbed(pollStub, { arr: new Array(options.length).fill(0), voters: 0 })] })
        .catch(() => null);
      if (!msg) return interaction.editReply({ content: 'I couldn’t post the poll here. Check my permissions.' });

      polls.createPoll(interaction.guildId, interaction.channel.id, msg.id, question, options, multi);
      polls.setCreator(msg.id, interaction.user.id);
      // Re-render with creator + voting buttons now that the message id is known.
      const created = polls.getPoll(msg.id);
      await msg.edit({ embeds: [polls.buildEmbed(created, { arr: new Array(options.length).fill(0), voters: 0 })], components: polls.buildComponents(created) }).catch(() => {});
      return interaction.editReply({ content: `📊 Poll created! Message ID: \`${msg.id}\`` });
    }

    // end
    const messageId = interaction.options.getString('message_id').trim();
    const poll = polls.getPoll(messageId);
    if (!poll || poll.guild_id !== interaction.guildId) {
      return interaction.reply({ content: 'No poll with that message ID.', ephemeral: true });
    }
    const isManager = interaction.memberPermissions.has(PermissionFlagsBits.ManageMessages);
    if (poll.created_by && poll.created_by !== interaction.user.id && !isManager) {
      return interaction.reply({ content: 'Only the poll creator or a moderator can end it.', ephemeral: true });
    }
    polls.close(messageId);
    const closed = polls.getPoll(messageId);
    const c = polls.counts(messageId, closed.options.length);
    const channel = await client.channels.fetch(poll.channel_id).catch(() => null);
    const msg = channel ? await channel.messages.fetch(messageId).catch(() => null) : null;
    if (msg) await msg.edit({ embeds: [polls.buildEmbed(closed, c)], components: polls.buildComponents(closed) }).catch(() => {});
    return interaction.reply({ content: '📊 Poll closed.', ephemeral: true });
  },
};

module.exports = command;
