'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const scramble = require('../../engagement/scramble');

const command = {
  data: new SlashCommandBuilder().setName('scramble').setDescription('Unscramble the word — first to type it wins!').setDMPermission(false),
  async execute(client, interaction) {
    if (scramble.active(interaction.channel.id)) {
      return interaction.reply({ content: 'A scramble is already running in this channel!', ephemeral: true });
    }
    const state = scramble.start(interaction.channel.id);
    const embed = new EmbedBuilder()
      .setColor(config.brand.color)
      .setTitle('🔤 Word Scramble')
      .setDescription(`Unscramble this and type your answer:\n\n# \`${state.scrambled}\``);
    return interaction.reply({ embeds: [embed] });
  },
};

module.exports = command;
