'use strict';

const { SlashCommandBuilder } = require('discord.js');
const whosthat = require('../../engagement/whosthat');

const command = {
  data: new SlashCommandBuilder().setName('whosthat').setDescription('Play “Who’s That Pokémon?”').setDMPermission(false),
  async execute(client, interaction) {
    await interaction.deferReply();
    let round;
    try {
      round = await whosthat.fetchRound();
    } catch {
      return interaction.editReply({ content: 'Couldn’t start a round right now (PokéAPI hiccup). Try again.' });
    }
    await interaction.editReply({ embeds: [whosthat.buildEmbed(round)], components: whosthat.buildComponents(round) });
    const msg = await interaction.fetchReply();
    whosthat.startSession(msg.id, round);

    // Auto-reveal after 25s if nobody solves it.
    setTimeout(async () => {
      const s = whosthat.getSession(msg.id);
      if (!s || s.solved) return;
      whosthat.endSession(msg.id);
      await msg.edit({ embeds: [whosthat.buildReveal(s, null)], components: whosthat.buildComponents(s, true) }).catch(() => {});
    }, 25000);
  },
};

module.exports = command;
