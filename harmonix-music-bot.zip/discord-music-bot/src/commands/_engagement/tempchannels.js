'use strict';

const {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder,
} = require('discord.js');
const { config } = require('../../../config');
const tempChannels = require('../../engagement/tempChannels');
const { parseDuration, humanizeDuration } = require('../../utils/duration');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;
const MANAGE_CHANNELS = PermissionFlagsBits.ManageChannels;

// ── /engage tempvoice (group) — private join-to-create ───────────
const tempvoice = {
  data: new SlashCommandBuilder()
    .setName('tempvoice')
    .setDescription('Join-to-create private voice channels with a control panel')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('setup')
        .setDescription('Set the hub members join to spawn their own private voice channel + control panel')
        .addChannelOption((o) => o.setName('hub').setDescription('Voice channel that acts as the hub').addChannelTypes(ChannelType.GuildVoice).setRequired(true))
        .addChannelOption((o) => o.setName('category').setDescription('Category new channels are created in').addChannelTypes(ChannelType.GuildCategory).setRequired(false))
    )
    .addSubcommand((s) => s.setName('disable').setDescription('Turn off join-to-create'))
    .addSubcommand((s) => s.setName('status').setDescription('Show join-to-create settings')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) return interaction.reply({ content: 'You need **Manage Server**.', ephemeral: true });
    const sub = interaction.options.getSubcommand();
    if (sub === 'setup') {
      const hub = interaction.options.getChannel('hub');
      const category = interaction.options.getChannel('category');
      tempChannels.setVoiceSettings(interaction.guildId, { privateHubId: hub.id, categoryId: category ? category.id : null });
      return interaction.reply({ content: `🔒 Join-to-create set. Joining **${hub.name}** now spawns a **private, locked** voice channel (you're the only one allowed) plus a control text channel with buttons to allow members, rename, set a limit, lock/unlock, claim, and delete.${category ? ` New channels go under **${category.name}**.` : ''}`, ephemeral: true });
    }
    if (sub === 'disable') {
      tempChannels.setVoiceSettings(interaction.guildId, { privateHubId: null });
      return interaction.reply({ content: 'Join-to-create disabled.', ephemeral: true });
    }
    const s = tempChannels.getVoiceSettings(interaction.guildId);
    return interaction.reply({ content: s.privateHubId ? `🔒 Hub: <#${s.privateHubId}>${s.categoryId ? ` • category <#${s.categoryId}>` : ''}.` : 'Not set up. Use `/engage tempvoice setup`.', ephemeral: true });
  },
};

// ── /engage temptext ─────────────────────────────────────────────
const temptext = {
  data: new SlashCommandBuilder()
    .setName('temptext')
    .setDescription('Create a temporary text channel that auto-deletes')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_CHANNELS)
    .addStringOption((o) => o.setName('duration').setDescription('How long it lasts, e.g. 30m, 2h, 1d').setRequired(true))
    .addStringOption((o) => o.setName('name').setDescription('Channel name').setRequired(false))
    .addBooleanOption((o) => o.setName('private').setDescription('Only you (and staff) can see it').setRequired(false)),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_CHANNELS)) return interaction.reply({ content: 'You need the **Manage Channels** permission.', ephemeral: true });
    const me = interaction.guild.members.me;
    if (!me.permissions.has(MANAGE_CHANNELS)) return interaction.reply({ content: 'I need the **Manage Channels** permission.', ephemeral: true });

    const ms = parseDuration(interaction.options.getString('duration'));
    if (!ms || ms < 60000) return interaction.reply({ content: 'Give a duration of at least 1 minute (e.g. `30m`, `2h`, `1d`).', ephemeral: true });
    const cap = 30 * 24 * 60 * 60 * 1000;
    const dur = Math.min(ms, cap);

    const rawName = interaction.options.getString('name') || `temp-${interaction.user.username}`;
    const name = rawName.toLowerCase().replace(/[^a-z0-9 _-]/g, '').replace(/\s+/g, '-').slice(0, 90) || 'temp-channel';
    const isPrivate = interaction.options.getBoolean('private') || false;

    const overwrites = [];
    if (isPrivate) {
      overwrites.push({ id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] });
      overwrites.push({ id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
      overwrites.push({ id: me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] });
    }

    await interaction.deferReply({ ephemeral: true });
    let channel;
    try {
      channel = await interaction.guild.channels.create({
        name,
        type: ChannelType.GuildText,
        parent: interaction.channel?.parentId || null,
        topic: `Temporary channel • deletes <t:${Math.floor((Date.now() + dur) / 1000)}:R> • created by ${interaction.user.tag}`,
        permissionOverwrites: overwrites.length ? overwrites : undefined,
      });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t create the channel: ${err.message}` });
    }

    tempChannels.record(channel.id, interaction.guildId, 'text', interaction.user.id, Date.now() + dur);
    await channel.send({ embeds: [new EmbedBuilder().setColor(config.brand.color).setDescription(`🕒 This is a temporary channel — it will be deleted <t:${Math.floor((Date.now() + dur) / 1000)}:R>.`)] }).catch(() => {});
    return interaction.editReply({ content: `✅ Created ${channel} — auto-deletes in **${humanizeDuration(dur)}**.` });
  },
};

module.exports = [tempvoice, temptext];
