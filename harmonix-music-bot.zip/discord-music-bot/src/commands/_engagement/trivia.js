'use strict';

const { SlashCommandBuilder } = require('discord.js');
const trivia = require('../../engagement/trivia');

// Broad categories (The Trivia API "categories") + specific topics ("tags",
// prefixed tag:). Max 25 choices per option.
const CATEGORIES = [
  { name: 'General Knowledge', value: 'general_knowledge' },
  { name: 'Science', value: 'science' },
  { name: 'Film & TV', value: 'film_and_tv' },
  { name: 'Music', value: 'music' },
  { name: 'History', value: 'history' },
  { name: 'Geography', value: 'geography' },
  { name: 'Arts & Literature', value: 'arts_and_literature' },
  { name: 'Sport & Leisure', value: 'sport_and_leisure' },
  { name: 'Society & Culture', value: 'society_and_culture' },
  { name: 'Food & Drink', value: 'food_and_drink' },
  // more specific topics:
  { name: 'Video Games', value: 'tag:video_games' },
  { name: 'Movies', value: 'tag:movies' },
  { name: 'Marvel', value: 'tag:marvel' },
  { name: 'Comics', value: 'tag:comics' },
  { name: 'Harry Potter', value: 'tag:harry_potter' },
  { name: 'Space & Astronomy', value: 'tag:space' },
  { name: 'Mathematics', value: 'tag:mathematics' },
  { name: 'Chemistry', value: 'tag:chemistry' },
  { name: 'Physics', value: 'tag:physics' },
  { name: 'Biology', value: 'tag:biology' },
  { name: 'Animals', value: 'tag:animals' },
  { name: 'Mythology', value: 'tag:mythology' },
  { name: 'Football', value: 'tag:football' },
  { name: 'Board Games', value: 'tag:board_games' },
  { name: 'Anime & Manga', value: 'otdb:anime' },
];

const command = {
  data: new SlashCommandBuilder()
    .setName('trivia')
    .setDescription('Start continuous trivia in this channel (run again to stop)')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('category').setDescription('Question category or topic').addChoices(...CATEGORIES).setRequired(false))
    .addStringOption((o) =>
      o.setName('difficulty').setDescription('Question difficulty')
        .addChoices({ name: 'easy', value: 'easy' }, { name: 'medium', value: 'medium' }, { name: 'hard', value: 'hard' })
        .setRequired(false))
    .addStringOption((o) =>
      o.setName('mode').setDescription('Game mode')
        .addChoices({ name: 'normal', value: 'normal' }, { name: '⚡ speed (short timer, bonus XP)', value: 'speed' })
        .setRequired(false))
    .addIntegerOption((o) =>
      o.setName('timer').setDescription('Seconds to answer each question (5–120; overrides the mode default)')
        .setMinValue(5).setMaxValue(120).setRequired(false)),
  async execute(client, interaction) {
    // Running while a game is active stops it.
    if (trivia.isActive(interaction.channel.id)) {
      trivia.stop(interaction.channel.id);
      return interaction.reply({ content: '🛑 Trivia stopped.' });
    }
    const mode = interaction.options.getString('mode') || 'normal';
    const timerSecs = interaction.options.getInteger('timer');
    const opts = {
      category: interaction.options.getString('category') || undefined,
      difficulty: interaction.options.getString('difficulty') || undefined,
      mode,
      questionMs: timerSecs ? timerSecs * 1000 : undefined,
    };
    const secs = timerSecs || (mode === 'speed' ? trivia.SPEED_QUESTION_MS / 1000 : trivia.DEFAULT_QUESTION_MS / 1000);
    const header = mode === 'speed' ? '⚡ **Speed Trivia started!**' : '🧠 **Trivia started!**';
    await interaction.reply({ content: `${header} ${secs}s per question. Type your answers in chat — it keeps going until the channel goes quiet, or run \`/game trivia\` again to stop.` });
    await trivia.start(client, interaction.channel, interaction.guildId, opts);
  },
};

module.exports = command;
