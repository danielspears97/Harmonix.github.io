'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const giveaways = require('../../engagement/giveaways');
const scheduler = require('../../engagement/giveawayScheduler');
const { parseDuration, humanizeDuration } = require('../../utils/duration');

const MANAGE = PermissionFlagsBits.ManageGuild;

const command = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Run a giveaway')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addSubcommand((s) =>
      s
        .setName('start')
        .setDescription('Start a giveaway')
        .addStringOption((o) => o.setName('duration').setDescription('e.g. 1h, 30m, 1d').setRequired(true))
        .addStringOption((o) => o.setName('prize').setDescription('What you’re giving away').setRequired(true))
        .addIntegerOption((o) => o.setName('winners').setDescription('Number of winners (default 1)').setMinValue(1).setMaxValue(20).setRequired(false))
    )
    .addSubcommand((s) =>
      s.setName('end').setDescription('End a giveaway now').addStringOption((o) => o.setName('message_id').setDescription('Giveaway message ID').setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName('reroll').setDescription('Reroll winners').addStringOption((o) => o.setName('message_id').setDescription('Giveaway message ID').setRequired(true))
    ),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();

    if (sub === 'start') {
      const ms = parseDuration(interaction.options.getString('duration'));
      if (!ms || ms < 10000) return interaction.reply({ content: 'Duration must be at least 10 seconds (e.g. `1h`).', ephemeral: true });
      const prize = interaction.options.getString('prize');
      const winners = interaction.options.getInteger('winners') || 1;
      const endsAt = Date.now() + ms;

      await interaction.deferReply({ ephemeral: true });
      const stub = { prize, winners, ends_at: endsAt, ended: 0, host_id: interaction.user.id };
      const msg = await interaction.channel
        .send({ embeds: [giveaways.buildEmbed(stub, 0)], components: giveaways.buildComponents(stub) })
        .catch(() => null);
      if (!msg) return interaction.editReply({ content: 'I couldn’t post the giveaway here. Check my permissions.' });

      giveaways.create(interaction.guildId, interaction.channel.id, msg.id, prize, winners, endsAt, interaction.user.id);
      return interaction.editReply({ content: `🎉 Giveaway for **${prize}** started — ends in ${humanizeDuration(ms)}.` });
    }

    if (sub === 'end') {
      const id = interaction.options.getString('message_id').trim();
      const row = giveaways.get(id);
      if (!row || row.guild_id !== interaction.guildId) return interaction.reply({ content: 'No giveaway with that message ID.', ephemeral: true });
      if (row.ended) return interaction.reply({ content: 'That giveaway already ended.', ephemeral: true });
      await scheduler.endGiveaway(client, row);
      return interaction.reply({ content: 'Giveaway ended.', ephemeral: true });
    }

    // reroll
    const id = interaction.options.getString('message_id').trim();
    const row = giveaways.get(id);
    if (!row || row.guild_id !== interaction.guildId) return interaction.reply({ content: 'No giveaway with that message ID.', ephemeral: true });
    const winners = giveaways.pickWinners(giveaways.entries(id), row.winners);
    if (!winners.length) return interaction.reply({ content: 'No entries to reroll.', ephemeral: true });
    const mentions = winners.map((u) => `<@${u}>`).join(', ');
    const channel = await client.channels.fetch(row.channel_id).catch(() => null);
    if (channel) await channel.send({ content: `🎉 Reroll! New winner(s) for **${row.prize}**: ${mentions}`, allowedMentions: { users: winners } }).catch(() => {});
    return interaction.reply({ content: 'Rerolled.', ephemeral: true });
  },
};

module.exports = command;
