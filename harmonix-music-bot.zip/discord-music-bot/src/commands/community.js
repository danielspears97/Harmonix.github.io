'use strict';
// /community — tags, afk, snipe, suggestions, info lookups
const { composeCategory } = require('../utils/compose');
const tags = require('./_community/tags');       // tag (group)
const afk = require('./_community/afk');          // [afk, snipe]
const suggest = require('./_community/suggest');  // [suggest, suggestions (group)]
const info = require('./_community/info');        // [userinfo, serverinfo, roleinfo, avatar, membercount]
const birthday = require('./_community/birthday'); // birthday (group)
module.exports = composeCategory('community', 'Tags, AFK, suggestions, birthdays & info', [tags, ...afk, ...suggest, ...info, birthday]);
