'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const controller = require('../controller');
const { voiceGuard } = require('../utils/guards');
const { config } = require('../../config');
const { truncate, msToTime } = require('../utils/format');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a track or playlist (YouTube, Spotify, SoundCloud — link or search).')
    .addStringOption((o) =>
      o.setName('query').setDescription('Song name or a YouTube/Spotify/SoundCloud link').setRequired(true)
    )
    .addBooleanOption((o) =>
      o.setName('next').setDescription('Add to the front of the queue (plays after the current song)').setRequired(false)
    ),

  async execute(client, interaction) {
    const guard = voiceGuard(client, interaction);
    if (!guard.ok) return interaction.reply({ content: guard.msg, ephemeral: true });

    await interaction.deferReply();
    const query = interaction.options.getString('query', true);
    const next = interaction.options.getBoolean('next') || false;

    const requester = {
      id: interaction.user.id,
      username: interaction.user.username,
      avatar: interaction.user.displayAvatarURL?.({ extension: 'png' }) || null,
    };

    let result;
    try {
      result = await controller.play(client, {
        guildId: interaction.guildId,
        voiceChannelId: guard.voiceChannelId,
        textChannelId: interaction.channelId,
        query,
        requester,
        next,
      });
    } catch (err) {
      console.error('[play] error:', err);
      return interaction.editReply('❌ Something went wrong while loading that. Is the Lavalink node online?');
    }

    if (!result.ok) {
      const limit = result.limit;
      const msg = result.reason === 'queue-full' ? `🚫 The queue is full (max **${limit}** songs).`
        : result.reason === 'too-long' ? `🚫 That track is **${msToTime((result.durSec || 0) * 1000)}** — over the **${msToTime(limit * 1000)}** per-song limit.`
          : result.reason === 'user-limit' ? `🚫 You already have **${limit}** song${limit === 1 ? '' : 's'} queued (the per-user limit). Wait for one to play.`
            : '🔎 No results found for that query.';
      return interaction.editReply(msg);
    }

    const embed = new EmbedBuilder().setColor(config.brand.successColor);
    if (result.added.type === 'playlist') {
      embed
        .setAuthor({ name: 'Added to queue' })
        .setDescription(`📃 **${truncate(result.added.name, 80)}** — ${result.added.count} tracks${result.added.trimmed ? ' *(trimmed to fit the queue limit)*' : ''}`);
    } else {
      const t = result.added.track;
      embed
        .setAuthor({ name: result.added.next ? 'Playing next' : 'Added to queue' })
        .setDescription(`🎵 ${t.uri ? `[${truncate(t.title, 70)}](${t.uri})` : truncate(t.title, 70)}${result.added.duplicate ? '\n⚠️ *This song is already in the queue.*' : ''}`)
        .addFields(
          { name: 'Artist', value: truncate(t.author, 40) || '—', inline: true },
          { name: 'Length', value: t.isStream ? 'LIVE' : msToTime(t.duration), inline: true },
          { name: 'Source', value: t.sourceName, inline: true }
        );
      if (result.added.position > 1 && result.added.etaMs > 0) {
        embed.addFields(
          { name: 'Position', value: `#${result.added.position}`, inline: true },
          { name: 'Plays in', value: `~${msToTime(result.added.etaMs)}`, inline: true }
        );
      }
      if (t.artworkUrl) embed.setThumbnail(t.artworkUrl);
    }
    return interaction.editReply({ embeds: [embed] });
  },
};
