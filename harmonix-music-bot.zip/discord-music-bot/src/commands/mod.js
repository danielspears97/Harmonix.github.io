'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { composeCategory } = require('../utils/compose');

const infractions = require('./_moderation/infractions'); // [warn, warnings, case, reason]
const bans = require('./_moderation/bans'); // [kick, ban, unban]
const timeouts = require('./_moderation/timeouts'); // [timeout, untimeout]
const cleanup = require('./_moderation/cleanup'); // [purge, slowmode]
const modlog = require('./_moderation/config'); // modlog (group)
const logging = require('./_moderation/logging'); // logging (group)
const ticket = require('./_moderation/tickets'); // ticket (group)
const verify = require('./_moderation/verify'); // verify (group)
const antiraid = require('./_moderation/antiraid'); // antiraid (group)
const temppunish = require('./_moderation/temppunish'); // [tempban, mute, unmute]
const warnthreshold = require('./_moderation/warnthreshold'); // warnthreshold (group)
const lockdown = require('./_moderation/lockdown'); // [lockdown, unlock]

module.exports = composeCategory(
  'mod',
  'Moderation tools',
  [...infractions, ...bans, ...timeouts, ...cleanup, modlog, logging, ticket, verify, antiraid, ...temppunish, warnthreshold, ...lockdown],
  PermissionFlagsBits.ManageMessages
);
