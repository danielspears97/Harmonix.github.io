'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const reminders = require('../../utility/reminders');
const { parseDuration, humanizeDuration } = require('../../utils/duration');

const MAX_MS = 365 * 24 * 60 * 60 * 1000; // 1 year

const command = {
  data: new SlashCommandBuilder()
    .setName('reminder')
    .setDescription('Set and manage reminders')
    .setDMPermission(false)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Set a reminder')
        .addStringOption((o) => o.setName('when').setDescription('e.g. 10m, 2h, 1d, 1w').setRequired(true))
        .addStringOption((o) => o.setName('text').setDescription('What to remind you about').setRequired(true))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List your active reminders'))
    .addSubcommand((s) =>
      s.setName('cancel').setDescription('Cancel a reminder').addIntegerOption((o) => o.setName('id').setDescription('Reminder ID (from /reminder list)').setRequired(true))
    ),
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const ms = parseDuration(interaction.options.getString('when'));
      if (!ms || ms < 10000) return interaction.reply({ content: 'Give a time at least 10 seconds out, like `10m` or `2h`.', ephemeral: true });
      if (ms > MAX_MS) return interaction.reply({ content: 'That’s too far out — max is 1 year.', ephemeral: true });
      const text = interaction.options.getString('text');
      const remindAt = Date.now() + ms;
      const id = reminders.add(interaction.guildId, interaction.channel.id, interaction.user.id, text, remindAt);
      return interaction.reply({
        content: `⏰ Got it! I’ll DM you in **${humanizeDuration(ms)}** (<t:${Math.floor(remindAt / 1000)}:f>). Reminder \`#${id}\`.`,
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const rows = reminders.listForUser(interaction.guildId, interaction.user.id);
      if (!rows.length) return interaction.reply({ content: 'You have no active reminders.', ephemeral: true });
      const lines = rows.map((r) => `\`#${r.id}\` <t:${Math.floor(r.remind_at / 1000)}:R> — ${r.text || '(no note)'}`);
      const embed = new EmbedBuilder().setColor(config.brand.color).setTitle('⏰ Your reminders').setDescription(lines.join('\n'));
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // cancel
    const id = interaction.options.getInteger('id');
    const ok = reminders.cancel(id, interaction.user.id);
    return interaction.reply({ content: ok ? `Cancelled reminder \`#${id}\`.` : `No active reminder \`#${id}\` of yours found.`, ephemeral: true });
  },
};

module.exports = command;
