'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');

const command = {
  data: new SlashCommandBuilder()
    .setName('translate')
    .setDescription('Translate text to another language')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('text').setDescription('Text to translate').setRequired(true))
    .addStringOption((o) => o.setName('to').setDescription('Target language code (default: en)').setRequired(false))
    .addStringOption((o) => o.setName('from').setDescription('Source language code (default: auto-detect)').setRequired(false)),
  async execute(client, interaction) {
    const text = interaction.options.getString('text');
    const to = (interaction.options.getString('to') || 'en').toLowerCase();
    const from = (interaction.options.getString('from') || 'auto').toLowerCase();

    await interaction.deferReply();
    try {
      const url =
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(from)}` +
        `&tl=${encodeURIComponent(to)}&dt=t&q=${encodeURIComponent(text)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`status ${res.status}`);
      const data = await res.json();
      const translated = (data[0] || []).map((chunk) => chunk[0]).join('');
      const detected = data[2] || from;
      if (!translated) throw new Error('empty result');

      const embed = new EmbedBuilder()
        .setColor(config.brand.color)
        .setAuthor({ name: `🌐 Translation (${detected} → ${to})` })
        .addFields(
          { name: 'Original', value: text.slice(0, 1000) },
          { name: 'Translated', value: translated.slice(0, 1000) }
        );
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t translate that right now (${err.message}). Check the language codes and try again.` });
    }
  },
};

module.exports = command;
