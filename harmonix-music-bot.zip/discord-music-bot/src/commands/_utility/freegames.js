'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fg = require('../../utility/freeGames');
const scheduler = require('../../utility/freeGameScheduler');

const MANAGE = PermissionFlagsBits.ManageGuild;

function statusEmbed(guildId) {
  const c = fg.getConfigFor(guildId);
  const on = (b) => (b ? '✅' : '❌');
  const plats = fg.PLATFORMS.map((p) => `${on(c.platforms.includes(p.key))} ${p.label}`).join('\n');
  return new EmbedBuilder()
    .setColor(0x5ad27e)
    .setTitle('🎮 Free-game notifier')
    .setDescription(c.enabled ? `Posting to <#${c.channelId}> · checks every 15 min` : 'Currently **off** — set a channel and enable it.')
    .addFields(
      { name: 'Offer kinds', value: `${on(c.keep)} Free to keep\n${on(c.timed)} Free (limited time)\n${on(c.discounts)} Steep discounts`, inline: true },
      { name: 'Content', value: `${on(c.games)} Full games\n${on(c.dlc)} DLC / loot\n${on(c.earlyaccess)} Early access`, inline: true },
      { name: 'Platforms', value: plats, inline: true },
    )
    .setFooter({ text: 'via GamerPower' });
}

const command = {
  data: new SlashCommandBuilder()
    .setName('freegames')
    .setDescription('Notify a channel about free & heavily discounted games')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE)
    .addSubcommand((s) => s.setName('setup').setDescription('Pick the channel and turn it on')
      .addChannelOption((o) => o.setName('channel').setDescription('Where to post free games').setRequired(true)))
    .addSubcommand((s) => s.setName('toggle').setDescription('Turn the notifier on or off')
      .addBooleanOption((o) => o.setName('on').setDescription('Enable or disable').setRequired(true)))
    .addSubcommand((s) => s.setName('platform').setDescription('Toggle a platform on/off')
      .addStringOption((o) => o.setName('name').setDescription('Platform').setRequired(true)
        .addChoices(...fg.PLATFORMS.map((p) => ({ name: p.label, value: p.key }))))
      .addBooleanOption((o) => o.setName('on').setDescription('Notify about this platform?').setRequired(true)))
    .addSubcommand((s) => s.setName('kinds').setDescription('Choose which offer types to post')
      .addBooleanOption((o) => o.setName('keep').setDescription('Free to keep forever'))
      .addBooleanOption((o) => o.setName('timed').setDescription('Free to play for a limited time'))
      .addBooleanOption((o) => o.setName('discounts').setDescription('Very steep discounts (not free)')))
    .addSubcommand((s) => s.setName('content').setDescription('Choose which content types to post')
      .addBooleanOption((o) => o.setName('games').setDescription('Full games'))
      .addBooleanOption((o) => o.setName('dlc').setDescription('DLC, loot & in-game packs'))
      .addBooleanOption((o) => o.setName('earlyaccess').setDescription('Early-access / beta keys')))
    .addSubcommand((s) => s.setName('status').setDescription('Show current settings'))
    .addSubcommand((s) => s.setName('test').setDescription('Post matching free games right now')),

  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const gid = interaction.guildId;

    if (sub === 'setup') {
      const ch = interaction.options.getChannel('channel');
      await interaction.deferReply({ ephemeral: true });
      fg.setConfigFor(gid, { channelId: ch.id, enabled: true });

      // Mark everything currently live as already seen. Without this the first
      // poll would treat ~90 existing giveaways as new and drip-feed them for
      // hours; from here you only get genuinely new ones.
      let seeded = 0;
      try {
        const all = await fg.fetchGiveaways();
        for (const g of all) { fg.markSeen(gid, g.id); seeded += 1; }
      } catch { /* offline — the first poll will just post what it finds */ }

      return interaction.editReply({
        content: `✅ Free-game alerts on for ${ch}. Checks every 15 minutes.\n📦 Skipped ${seeded} giveaway${seeded === 1 ? '' : 's'} that are already live so you don't get a flood — run \`/freegames test\` to see current ones.`,
        embeds: [statusEmbed(gid)],
      });
    }
    if (sub === 'toggle') {
      const on = interaction.options.getBoolean('on');
      const c = fg.getConfigFor(gid);
      if (on && !c.channelId) return interaction.reply({ content: 'Set a channel first with `/freegames setup`.', ephemeral: true });
      fg.setConfigFor(gid, { enabled: on });
      return interaction.reply({ content: on ? '✅ Notifier enabled.' : '⏸️ Notifier disabled.', ephemeral: true });
    }
    if (sub === 'platform') {
      const key = interaction.options.getString('name');
      const on = interaction.options.getBoolean('on');
      const c = fg.getConfigFor(gid);
      const set = new Set(c.platforms);
      if (on) set.add(key); else set.delete(key);
      fg.setConfigFor(gid, { platforms: [...set] });
      return interaction.reply({ embeds: [statusEmbed(gid)], ephemeral: true });
    }
    if (sub === 'kinds') {
      const patch = {};
      for (const k of ['keep', 'timed', 'discounts']) {
        const v = interaction.options.getBoolean(k);
        if (v !== null) patch[k] = v;
      }
      if (!Object.keys(patch).length) return interaction.reply({ content: 'Pass at least one of keep/timed/discounts.', ephemeral: true });
      fg.setConfigFor(gid, patch);
      return interaction.reply({ embeds: [statusEmbed(gid)], ephemeral: true });
    }
    if (sub === 'content') {
      const patch = {};
      for (const k of ['games', 'dlc', 'earlyaccess']) {
        const v = interaction.options.getBoolean(k);
        if (v !== null) patch[k] = v;
      }
      if (!Object.keys(patch).length) return interaction.reply({ content: 'Pass at least one of games/dlc/earlyaccess.', ephemeral: true });
      fg.setConfigFor(gid, patch);
      return interaction.reply({ embeds: [statusEmbed(gid)], ephemeral: true });
    }
    if (sub === 'status') {
      return interaction.reply({ embeds: [statusEmbed(gid)], ephemeral: true });
    }
    if (sub === 'test') {
      const c = fg.getConfigFor(gid);
      if (!c.channelId) return interaction.reply({ content: 'Set a channel first with `/freegames setup`.', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      let list;
      try { list = await fg.fetchGiveaways(true); } catch { return interaction.editReply('Could not reach the free-games service right now.'); }
      const matches = list.filter((g) => fg.matchesConfig(g, c)).slice(0, 3);
      if (!matches.length) return interaction.editReply('No current giveaways match your platform/kind filters.');
      const channel = await client.channels.fetch(c.channelId).catch(() => null);
      if (!channel) return interaction.editReply('I can’t see the configured channel.');
      for (const g of matches) { await channel.send({ embeds: [scheduler.buildEmbed(g)] }).catch(() => {}); fg.markSeen(gid, g.id); }
      return interaction.editReply(`Posted ${matches.length} sample${matches.length === 1 ? '' : 's'} to <#${c.channelId}>.`);
    }
    return interaction.reply({ content: 'Unknown subcommand.', ephemeral: true });
  },
};

module.exports = command;
