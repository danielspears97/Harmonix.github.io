'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const feeds = require('../../utility/feeds');

const MANAGE_GUILD = PermissionFlagsBits.ManageGuild;

const command = {
  data: new SlashCommandBuilder()
    .setName('feed')
    .setDescription('RSS / Atom feed announcements')
    .setDMPermission(false)
    .setDefaultMemberPermissions(MANAGE_GUILD)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Subscribe a channel to a feed')
        .addStringOption((o) => o.setName('url').setDescription('RSS/Atom feed URL').setRequired(true))
        .addChannelOption((o) => o.setName('channel').setDescription('Where to post (defaults to here)').addChannelTypes(ChannelType.GuildText).setRequired(false))
    )
    .addSubcommand((s) =>
      s.setName('remove').setDescription('Unsubscribe a feed').addIntegerOption((o) => o.setName('id').setDescription('Feed ID (from /feed list)').setRequired(true))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List this server’s feeds')),
  async execute(client, interaction) {
    if (!interaction.memberPermissions.has(MANAGE_GUILD)) {
      return interaction.reply({ content: 'You need the **Manage Server** permission.', ephemeral: true });
    }
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const url = interaction.options.getString('url').trim();
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      await interaction.deferReply({ ephemeral: true });

      let parsed;
      try {
        parsed = await feeds.fetchFeed(url);
      } catch (err) {
        return interaction.editReply({ content: `Couldn’t read that feed (${err.message}). Make sure it’s a valid RSS/Atom URL.` });
      }
      // Baseline to the newest item so we don't dump history on the first poll.
      const newest = (parsed.items || [])[0];
      const lastGuid = newest ? feeds.itemId(newest) : null;
      const lastPublished = newest ? feeds.itemTime(newest) : null;
      const id = feeds.add(interaction.guildId, channel.id, url, parsed.title, lastGuid, lastPublished);
      return interaction.editReply({
        content: `📰 Subscribed **${parsed.title || url}** → ${channel}. New posts will appear there. Feed \`#${id}\`.`,
      });
    }

    if (sub === 'remove') {
      const id = interaction.options.getInteger('id');
      const ok = feeds.remove(id, interaction.guildId);
      return interaction.reply({ content: ok ? `Removed feed \`#${id}\`.` : `No feed \`#${id}\` in this server.`, ephemeral: true });
    }

    // list
    const rows = feeds.listForGuild(interaction.guildId);
    if (!rows.length) return interaction.reply({ content: 'No feeds yet. Add one with `/util feed add`.', ephemeral: true });
    const lines = rows.map((r) => `\`#${r.id}\` ${r.title ? `**${r.title}**` : r.url} → <#${r.channel_id}>`);
    const embed = new EmbedBuilder().setColor(config.brand.color).setTitle('📰 Feeds').setDescription(lines.join('\n'));
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

module.exports = command;
