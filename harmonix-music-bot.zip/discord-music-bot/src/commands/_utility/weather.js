'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');

const command = {
  data: new SlashCommandBuilder()
    .setName('weather')
    .setDescription('Show current weather for a place')
    .setDMPermission(false)
    .addStringOption((o) => o.setName('location').setDescription('City, postcode, or place').setRequired(true)),
  async execute(client, interaction) {
    const location = interaction.options.getString('location');
    await interaction.deferReply();
    try {
      const res = await fetch(`https://wttr.in/${encodeURIComponent(location)}?format=j1`, {
        headers: { 'User-Agent': 'Harmonix-Bot' },
      });
      if (!res.ok) throw new Error(`status ${res.status}`);
      const data = await res.json();
      const cur = data.current_condition && data.current_condition[0];
      if (!cur) throw new Error('no data for that location');

      const area = data.nearest_area && data.nearest_area[0];
      const place = area
        ? [area.areaName?.[0]?.value, area.region?.[0]?.value, area.country?.[0]?.value].filter(Boolean).join(', ')
        : location;
      const desc = cur.weatherDesc?.[0]?.value || '—';

      const embed = new EmbedBuilder()
        .setColor(config.brand.color)
        .setAuthor({ name: `🌤️ Weather — ${place}` })
        .setDescription(`**${desc}**`)
        .addFields(
          { name: 'Temperature', value: `${cur.temp_C}°C / ${cur.temp_F}°F`, inline: true },
          { name: 'Feels like', value: `${cur.FeelsLikeC}°C / ${cur.FeelsLikeF}°F`, inline: true },
          { name: 'Humidity', value: `${cur.humidity}%`, inline: true },
          { name: 'Wind', value: `${cur.windspeedKmph} km/h`, inline: true },
          { name: 'Cloud cover', value: `${cur.cloudcover}%`, inline: true },
          { name: 'Visibility', value: `${cur.visibility} km`, inline: true }
        )
        .setFooter({ text: 'Data: wttr.in' });
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      return interaction.editReply({ content: `Couldn’t get weather for “${location}” (${err.message}).` });
    }
  },
};

module.exports = command;
