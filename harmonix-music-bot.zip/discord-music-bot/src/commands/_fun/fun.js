'use strict';

const { EmbedBuilder } = require('discord.js');
const { config } = require('../../../config');
const { getJson, getText } = require('../../utils/fetchJson');
const { buildGroup } = require('../../utils/group');

const C = config.brand.color;

// Helper for "defer → fetch → reply text" subcommands.
function textItem(name, description, fn) {
  return {
    name,
    description,
    run: async (client, interaction) => {
      await interaction.deferReply();
      try { return interaction.editReply({ content: await fn(interaction) }); }
      catch { return interaction.editReply({ content: 'That service is unavailable right now — try again shortly.' }); }
    },
  };
}
function embedItem(name, description, fn, setup) {
  return {
    name,
    description,
    setup,
    run: async (client, interaction) => {
      await interaction.deferReply();
      try { return interaction.editReply({ embeds: [await fn(interaction)] }); }
      catch { return interaction.editReply({ content: 'That service is unavailable right now — try again shortly.' }); }
    },
  };
}

const items = [
  textItem('dadjoke', 'A random dad joke', async () => `😄 ${(await getJson('https://icanhazdadjoke.com/', { headers: { Accept: 'application/json' } })).joke}`),
  textItem('joke', 'A random (safe-mode) joke', async () => {
    const d = await getJson('https://v2.jokeapi.dev/joke/Any?safe-mode');
    return `😆 ${d.type === 'twopart' ? `${d.setup}\n\n||${d.delivery}||` : d.joke}`;
  }),
  textItem('fact', 'A random useless fact', async () => `💡 ${(await getJson('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en')).text}`),
  textItem('advice', 'A random piece of advice', async () => `🧭 ${(await getJson(`https://api.adviceslip.com/advice?t=${Date.now()}`)).slip.advice}`),
  textItem('catfact', 'A random cat fact', async () => `🐈 ${(await getJson('https://catfact.ninja/fact')).fact}`),
  textItem('affirmation', 'A positive affirmation', async () => `🌷 ${(await getJson('https://www.affirmations.dev/')).affirmation}`),
  textItem('chucknorris', 'A random Chuck Norris fact', async () => `🥋 ${(await getJson('https://api.chucknorris.io/jokes/random')).value}`),
  textItem('quote', 'A random inspirational quote', async () => {
    const d = await getJson('https://zenquotes.io/api/random');
    return `❝ ${d[0].q} ❞\n— *${d[0].a}*`;
  }),
  embedItem('dog', 'A random dog picture', async () => new EmbedBuilder().setColor(C).setTitle('🐶 Woof!').setImage((await getJson('https://dog.ceo/api/breeds/image/random')).message)),
  {
    name: 'cat',
    description: 'A random cat picture',
    run: async (client, interaction) => interaction.reply({ embeds: [new EmbedBuilder().setColor(C).setTitle('🐱 Meow!').setImage(`https://cataas.com/cat?ts=${Date.now()}`)] }),
  },
  embedItem('inspire', 'An AI-generated inspirational poster', async () => {
    const url = (await getText('https://inspirobot.me/api?generate=true')).trim();
    if (!/^https?:\/\//.test(url)) throw new Error('bad url');
    return new EmbedBuilder().setColor(C).setImage(url);
  }),
  embedItem(
    'xkcd',
    'A random or specific xkcd comic',
    async (interaction) => {
      const latest = await getJson('https://xkcd.com/info.0.json');
      const num = interaction.options.getInteger('number') || Math.floor(Math.random() * latest.num) + 1;
      const d = num === latest.num ? latest : await getJson(`https://xkcd.com/${num}/info.0.json`);
      return new EmbedBuilder().setColor(C).setTitle(`xkcd #${d.num}: ${d.title}`).setURL(`https://xkcd.com/${d.num}/`).setImage(d.img).setFooter({ text: d.alt?.slice(0, 2000) || '' });
    },
    (s) => s.addIntegerOption((o) => o.setName('number').setDescription('Comic number (default: random)').setMinValue(1))
  ),
  embedItem('iss', 'Where is the Space Station right now?', async () => {
    const d = await getJson('https://api.wheretheiss.at/v1/satellites/25544');
    return new EmbedBuilder()
      .setColor(C)
      .setTitle('🛰️ International Space Station')
      .addFields(
        { name: 'Latitude', value: d.latitude.toFixed(3), inline: true },
        { name: 'Longitude', value: d.longitude.toFixed(3), inline: true },
        { name: 'Altitude', value: `${Math.round(d.altitude)} km`, inline: true },
        { name: 'Speed', value: `${Math.round(d.velocity).toLocaleString()} km/h`, inline: true },
        { name: 'Map', value: `[View](https://www.google.com/maps?q=${d.latitude},${d.longitude})`, inline: true }
      );
  }),
  embedItem('apod', 'NASA Astronomy Picture of the Day', async () => {
    const key = process.env.NASA_API_KEY || 'DEMO_KEY';
    const d = await getJson(`https://api.nasa.gov/planetary/apod?api_key=${key}`);
    const embed = new EmbedBuilder().setColor(C).setTitle(`🔭 ${d.title}`).setDescription((d.explanation || '').slice(0, 600)).setFooter({ text: `NASA APOD • ${d.date}` });
    if (d.media_type === 'image') embed.setImage(d.hdurl || d.url);
    else embed.addFields({ name: 'Media', value: d.url });
    return embed;
  }),
  {
    name: 'guessage',
    description: 'Playfully guess an age from a first name',
    setup: (s) => s.addStringOption((o) => o.setName('name').setDescription('A first name').setRequired(true)),
    run: async (client, interaction) => {
      const name = interaction.options.getString('name').trim();
      await interaction.deferReply();
      try {
        const d = await getJson(`https://api.agify.io/?name=${encodeURIComponent(name)}`);
        if (d.age == null) throw new Error('none');
        return interaction.editReply({ content: `🔮 People named **${d.name}** are, on average, around **${d.age}** years old. *(based on ${d.count.toLocaleString()} samples — just for fun!)*` });
      } catch { return interaction.editReply({ content: `Couldn’t guess an age for “${name}”.` }); }
    },
  },
  {
    name: 'recipe',
    description: 'Get a meal recipe (random or search)',
    setup: (s) => s.addStringOption((o) => o.setName('search').setDescription('Dish to search for')),
    run: async (client, interaction) => {
      const q = interaction.options.getString('search');
      await interaction.deferReply();
      try {
        const data = q
          ? await getJson(`https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(q)}`)
          : await getJson('https://www.themealdb.com/api/json/v1/1/random.php');
        const m = data.meals && data.meals[0];
        if (!m) return interaction.editReply({ content: q ? `No recipe found for “${q}”.` : 'Couldn’t fetch a recipe right now.' });
        const ing = [];
        for (let i = 1; i <= 20; i++) { const n = m[`strIngredient${i}`], me = m[`strMeasure${i}`]; if (n && n.trim()) ing.push(`${me ? me.trim() : ''} ${n.trim()}`.trim()); }
        const embed = new EmbedBuilder().setColor(C).setTitle(`🍽️ ${m.strMeal}`).setURL(m.strSource || m.strYoutube || null)
          .setDescription(`${m.strArea || ''} · ${m.strCategory || ''}`)
          .addFields({ name: 'Ingredients', value: ing.slice(0, 15).join('\n').slice(0, 1000) || '—' }, { name: 'Instructions', value: (m.strInstructions || '').slice(0, 600) + '…' });
        if (m.strMealThumb) embed.setThumbnail(m.strMealThumb);
        return interaction.editReply({ embeds: [embed] });
      } catch { return interaction.editReply({ content: 'Couldn’t fetch a recipe right now.' }); }
    },
  },
  {
    name: 'cocktail',
    description: 'Get a cocktail recipe (random or search)',
    setup: (s) => s.addStringOption((o) => o.setName('search').setDescription('Drink to search for')),
    run: async (client, interaction) => {
      const q = interaction.options.getString('search');
      await interaction.deferReply();
      try {
        const data = q
          ? await getJson(`https://www.thecocktaildb.com/api/json/v1/1/search.php?s=${encodeURIComponent(q)}`)
          : await getJson('https://www.thecocktaildb.com/api/json/v1/1/random.php');
        const d = data.drinks && data.drinks[0];
        if (!d) return interaction.editReply({ content: q ? `No cocktail found for “${q}”.` : 'Couldn’t fetch a cocktail right now.' });
        const ing = [];
        for (let i = 1; i <= 15; i++) { const n = d[`strIngredient${i}`], me = d[`strMeasure${i}`]; if (n && n.trim()) ing.push(`${me ? me.trim() : ''} ${n.trim()}`.trim()); }
        const embed = new EmbedBuilder().setColor(C).setTitle(`🍸 ${d.strDrink}`).setDescription(`${d.strAlcoholic || ''} · ${d.strGlass || ''}`)
          .addFields({ name: 'Ingredients', value: ing.join('\n').slice(0, 1000) || '—' }, { name: 'Instructions', value: (d.strInstructions || '').slice(0, 600) });
        if (d.strDrinkThumb) embed.setThumbnail(d.strDrinkThumb);
        return interaction.editReply({ embeds: [embed] });
      } catch { return interaction.editReply({ content: 'Couldn’t fetch a cocktail right now.' }); }
    },
  },
];

module.exports = buildGroup('fun', 'Jokes, facts, food, pictures & random fun', items);
