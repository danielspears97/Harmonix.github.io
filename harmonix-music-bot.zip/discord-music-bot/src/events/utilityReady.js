'use strict';

const { Events } = require('discord.js');
const reminderScheduler = require('../utility/reminderScheduler');
const feedScheduler = require('../utility/feedScheduler');
const triviaClear = require('../engagement/triviaClear');
const tempScheduler = require('../moderation/tempScheduler');
const tempChannels = require('../engagement/tempChannels');
const birthdayScheduler = require('../community/birthdayScheduler');
const privateVoice = require('../engagement/privateVoice');
const voiceXp = require('../engagement/voiceXp');
const eventScheduler = require('../engagement/eventScheduler');
const freeGameScheduler = require('../utility/freeGameScheduler');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    reminderScheduler.start(client);
    feedScheduler.start(client);
    triviaClear.start(client);
    tempScheduler.start(client);
    tempChannels.start(client);
    birthdayScheduler.start(client);
    voiceXp.start(client);
    eventScheduler.start(client);
    freeGameScheduler.start(client);
    privateVoice.bootCleanup(client).catch(() => {});
  },
};
