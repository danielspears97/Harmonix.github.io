'use strict';

const { Events } = require('discord.js');
const starboard = require('../../server/starboard');

module.exports = [
  {
    name: Events.MessageReactionAdd,
    async execute(client, reaction) {
      await starboard.handleReactionChange(client, reaction);
    },
  },
  {
    name: Events.MessageReactionRemove,
    async execute(client, reaction) {
      await starboard.handleReactionChange(client, reaction);
    },
  },
];
