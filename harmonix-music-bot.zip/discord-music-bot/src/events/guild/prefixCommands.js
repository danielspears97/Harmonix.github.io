'use strict';

const { Events } = require('discord.js');
const prefixBridge = require('../../utils/prefixBridge');

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    await prefixBridge.handleMessage(client, message);
  },
};
