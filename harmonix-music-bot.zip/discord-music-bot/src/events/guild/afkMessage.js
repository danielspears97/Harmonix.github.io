'use strict';

const { Events } = require('discord.js');
const afk = require('../../community/afk');

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (!message.guild || message.author.bot || message.system) return;

    // Returning from AFK.
    const own = afk.get(message.guild.id, message.author.id);
    if (own) {
      afk.clear(message.guild.id, message.author.id);
      const back = await message.reply({ content: `👋 Welcome back, ${message.author}! I removed your AFK.`, allowedMentions: { repliedUser: false } }).catch(() => null);
      if (back) setTimeout(() => back.delete().catch(() => {}), 5000);
    }

    // Mentioning AFK users.
    if (message.mentions.users.size) {
      const notes = [];
      for (const user of message.mentions.users.values()) {
        if (user.id === message.author.id) continue;
        const status = afk.get(message.guild.id, user.id);
        if (status) notes.push(`💤 **${user.username}** is AFK: ${status.reason}`);
      }
      if (notes.length) await message.reply({ content: notes.join('\n'), allowedMentions: { parse: [] } }).catch(() => {});
    }
  },
};
