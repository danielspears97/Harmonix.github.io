'use strict';

const { Events, ChannelType, PermissionFlagsBits } = require('discord.js');
const tempChannels = require('../../engagement/tempChannels');
const pvc = require('../../engagement/privateVoice');
const { buildPanel } = require('../../handlers/privateVoice');

function slug(name) {
  return name.toLowerCase().replace(/[^a-z0-9 _-]/g, '').replace(/\s+/g, '-').slice(0, 90) || 'private';
}

module.exports = {
  name: Events.VoiceStateUpdate,
  async execute(client, oldState, newState) {
    const guild = newState.guild || oldState.guild;
    if (!guild) return;
    const settings = tempChannels.getVoiceSettings(guild.id);

    // 1) Joined the private hub → create a locked VC + companion control channel.
    if (settings.privateHubId && newState.channelId === settings.privateHubId) {
      const me = guild.members.me;
      if (!me || !me.permissions.has(PermissionFlagsBits.ManageChannels) || !me.permissions.has(PermissionFlagsBits.MoveMembers)) return;
      const member = newState.member;
      const parent = settings.categoryId || newState.channel?.parentId || null;
      try {
        const voice = await guild.channels.create({
          name: `🔒 ${member.displayName}`,
          type: ChannelType.GuildVoice,
          parent,
          permissionOverwrites: [
            { id: guild.id, deny: [PermissionFlagsBits.Connect] },
            { id: member.id, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.Speak, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers] },
            { id: me.id, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers] },
          ],
        });
        const text = await guild.channels.create({
          name: `${slug(member.displayName)}-controls`,
          type: ChannelType.GuildText,
          parent,
          permissionOverwrites: [
            { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: member.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            { id: me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] },
          ],
        });
        pvc.setPair(guild.id, voice.id, text.id, member.id);
        await member.voice.setChannel(voice).catch(() => {});
        const state = { ownerId: member.id, name: voice.name, locked: true, limit: 0 };
        const panelMsg = await text.send({ content: `<@${member.id}>`, allowedMentions: { users: [member.id] }, ...buildPanel(state) }).catch(() => null);
        if (panelMsg) pvc.setPanel(guild.id, voice.id, panelMsg.id);
      } catch { /* missing perms / hierarchy */ }
      return;
    }

    // 2) Left a private VC → tear down the pair once it's empty.
    if (oldState.channelId && oldState.channelId !== newState.channelId) {
      const pair = pvc.byVoice(guild.id, oldState.channelId);
      if (pair) {
        const ch = oldState.channel || (await client.channels.fetch(oldState.channelId).catch(() => null));
        if (ch && ch.members.filter((m) => !m.user.bot).size === 0) {
          const text = await client.channels.fetch(pair.textId).catch(() => null);
          pvc.removePair(guild.id, oldState.channelId);
          if (text) await text.delete('Private VC empty').catch(() => {});
          await ch.delete('Private VC empty').catch(() => {});
        }
      }
    }
  },
};
