'use strict';

const { Events } = require('discord.js');
const levels = require('../../engagement/levels');
const guildSettings = require('../../server/guildSettings');
const featureToggles = require('../../server/featureToggles');
const achievements = require('../../engagement/achievements');

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (!message.guild || message.author.bot || message.system) return;
    if (!featureToggles.isModuleEnabled(message.guild.id, 'leveling')) return;

    const settings = levels.getSettings(message.guild.id);
    if (!settings.enabled) return;

    // Skip XP in ignored channels (parent category counts too).
    const ignore = guildSettings.getXpIgnore(message.guild.id);
    if (ignore.length && (ignore.includes(message.channel.id) || (message.channel.parentId && ignore.includes(message.channel.parentId)))) return;

    const result = levels.awardMessage(message.guild.id, message.author.id, settings);
    if (!result || !result.leveledUp) return;

    const member = message.member;

    // Role rewards: grant any reward whose level the member has now reached.
    if (member && settings.rewards.length) {
      const me = message.guild.members.me;
      for (const reward of settings.rewards) {
        if (reward.level > result.newLevel) continue;
        const role = message.guild.roles.cache.get(reward.roleId);
        if (role && me && role.position < me.roles.highest.position && !member.roles.cache.has(role.id)) {
          member.roles.add(role.id, `Level ${reward.level} reward`).catch(() => {});
        }
      }
    }

    // Level milestone achievements (announced per the achievement setting).
    const unlocked = achievements.checkLevel(message.guild.id, message.author.id, result.newLevel);
    if (unlocked.length) achievements.announce(message.client, { guildId: message.guild.id, userId: message.author.id, channel: message.channel, defs: unlocked });

    if (settings.announce) {
      if (guildSettings.getLevelupDM(message.guild.id)) {
        message.author.send(`🎉 You reached **level ${result.newLevel}** in **${message.guild.name}**!`).catch(() => {});
      } else {
        message.channel
          .send({ content: `🎉 ${message.author}, you reached **level ${result.newLevel}**!`, allowedMentions: { users: [message.author.id] } })
          .catch(() => {});
      }
    }
  },
};
