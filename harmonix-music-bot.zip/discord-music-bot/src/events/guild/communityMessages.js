'use strict';

const { Events, EmbedBuilder } = require('discord.js');
const autoResponder = require('../../community/autoResponder');
const sticky = require('../../community/sticky');
const { config } = require('../../../config');

const stickyTimers = new Map(); // channelId -> timeout

async function repostSticky(client, guildId, channel) {
  stickyTimers.delete(channel.id);
  const s = sticky.get(guildId, channel.id);
  if (!s) return;
  if (s.lastId) {
    const old = await channel.messages.fetch(s.lastId).catch(() => null);
    if (old) await old.delete().catch(() => {});
  }
  const sent = await channel
    .send({ embeds: [new EmbedBuilder().setColor(config.brand.color).setDescription(s.content).setFooter({ text: '📌 Sticky' })] })
    .catch(() => null);
  if (sent) sticky.updateLastId(guildId, channel.id, sent.id);
}

module.exports = [
  {
    name: Events.MessageCreate,
    async execute(client, message) {
      if (!message.guild || message.author.bot || !message.content) return;
      const response = autoResponder.match(message.guild.id, message.content);
      if (response) await message.reply({ content: response, allowedMentions: { repliedUser: false } }).catch(() => {});
    },
  },
  {
    name: Events.MessageCreate,
    async execute(client, message) {
      if (!message.guild || message.author.bot) return; // ignore the bot's own repost (prevents loops)
      if (!sticky.get(message.guild.id, message.channel.id)) return;
      const key = message.channel.id;
      if (stickyTimers.has(key)) clearTimeout(stickyTimers.get(key));
      stickyTimers.set(key, setTimeout(() => repostSticky(client, message.guild.id, message.channel).catch(() => {}), 2500));
    },
  },
];
