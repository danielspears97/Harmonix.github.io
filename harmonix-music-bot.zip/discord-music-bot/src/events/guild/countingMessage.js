'use strict';

const { Events } = require('discord.js');
const counting = require('../../engagement/counting');
const featureToggles = require('../../server/featureToggles');

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (!message.guild || message.author.bot || message.system) return;
    if (!featureToggles.isModuleEnabled(message.guild.id, 'engagement')) return;
    try {
      await counting.handle(message);
    } catch { /* best-effort */ }
  },
};
