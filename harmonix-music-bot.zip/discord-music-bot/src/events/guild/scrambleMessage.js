'use strict';

const { Events } = require('discord.js');
const scramble = require('../../engagement/scramble');
const levels = require('../../engagement/levels');

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (!message.guild || message.author.bot || !message.content) return;
    if (!scramble.active(message.channel.id)) return;
    const won = scramble.check(message.channel.id, message.content);
    if (!won) return;
    const lvl = levels.getSettings(message.guild.id);
    if (lvl.enabled) levels.addXp(message.guild.id, message.author.id, 15);
    await message
      .reply({ content: `🎉 ${message.author} got it — the word was **${won}**!`, allowedMentions: { users: [message.author.id] } })
      .catch(() => {});
  },
};
