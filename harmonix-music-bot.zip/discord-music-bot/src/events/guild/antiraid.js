'use strict';

const { Events, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const antiraid = require('../../moderation/antiraid');
const logger = require('../../moderation/logger');
const { userTag } = require('../../utils/format');

async function alert(client, guild, settings, text, color = 0xff5c5c) {
  const channelId = settings.alertChannelId || logger.getSettings(guild.id).channelId;
  if (!channelId) return;
  const ch = await client.channels.fetch(channelId).catch(() => null);
  if (ch && ch.isTextBased()) {
    await ch.send({ embeds: [new EmbedBuilder().setColor(color).setTitle('🛡️ Anti-raid').setDescription(text).setTimestamp()] }).catch(() => {});
  }
}

async function applyAction(member, settings, reason) {
  try {
    if (settings.action === 'timeout') {
      await member.timeout(settings.timeoutMin * 60 * 1000, reason);
    } else {
      await member.kick(reason);
    }
    return true;
  } catch {
    return false;
  }
}

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(client, member) {
    const settings = antiraid.getSettings(member.guild.id);
    if (!settings.enabled) return;

    const me = member.guild.members.me;
    const need = settings.action === 'timeout' ? PermissionFlagsBits.ModerateMembers : PermissionFlagsBits.KickMembers;
    const canAct = me && me.permissions.has(need);

    // 1) minimum account age gate
    if (settings.minAccountDays > 0) {
      const ageDays = (Date.now() - member.user.createdTimestamp) / 86400000;
      if (ageDays < settings.minAccountDays) {
        const ok = canAct && (await applyAction(member, settings, 'Anti-raid: account too new'));
        await alert(client, member.guild, settings, `${ok ? '🚫' : '⚠️ (no permission to action)'} New account blocked: ${userTag(member.user)} — created <t:${Math.floor(member.user.createdTimestamp / 1000)}:R> (min ${settings.minAccountDays}d).`);
        return;
      }
    }

    // 2) join-rate raid detection
    const tripped = antiraid.recordJoin(member.guild.id, settings.windowSec, settings.threshold);
    if (tripped && !antiraid.inRaid(member.guild.id)) {
      antiraid.startRaid(member.guild.id);
      await alert(client, member.guild, settings, `🚨 **Raid detected** — ${settings.threshold}+ joins in ${settings.windowSec}s. Auto-${settings.action} on new joins for the next 60s.`, 0xb31b1b);
    }
    if (antiraid.inRaid(member.guild.id)) {
      if (canAct) await applyAction(member, settings, 'Anti-raid: raid in progress');
    }
  },
};
