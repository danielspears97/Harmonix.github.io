'use strict';

const { Events } = require('discord.js');
const snipeStore = require('../../community/snipeStore');
const { userTag } = require('../../utils/format');

module.exports = {
  name: Events.MessageDelete,
  async execute(client, message) {
    try {
      if (message.partial) return; // uncached — no content to show
      if (!message.guild || message.author?.bot) return;
      const image = [...message.attachments.values()].find((a) => a.contentType?.startsWith('image/'));
      snipeStore.remember(message.channel.id, {
        content: message.content,
        authorTag: userTag(message.author),
        authorId: message.author.id,
        avatar: message.author.displayAvatarURL(),
        image: image?.url || null,
        at: Date.now(),
      });
    } catch { /* ignore */ }
  },
};
