'use strict';

const { Events } = require('discord.js');
const trivia = require('../../engagement/trivia');

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (!message.guild) return;
    await trivia.handleMessage(client, message);
  },
};
