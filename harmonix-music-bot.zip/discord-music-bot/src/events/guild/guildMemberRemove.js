'use strict';

const { Events } = require('discord.js');
const greetings = require('../../server/greetings');

module.exports = {
  name: Events.GuildMemberRemove,
  async execute(client, member) {
    if (member.user?.bot) return;
    try {
      const g = greetings.getGreeting(member.guild.id, 'goodbye');
      if (g.enabled && g.channelId && g.message) {
        const ch =
          member.guild.channels.cache.get(g.channelId) ||
          (await client.channels.fetch(g.channelId).catch(() => null));
        if (ch && ch.isTextBased()) {
          await ch.send({ content: greetings.render(g.message, member), allowedMentions: { parse: [] } }).catch(() => {});
        }
      }
    } catch (err) {
      console.error('[goodbye] error:', err.message);
    }
  },
};
