'use strict';

const { Events, EmbedBuilder } = require('discord.js');
const logger = require('../../moderation/logger');
const { userTag } = require('../../utils/format');

const COLORS = {
  messageDelete: 0xff5c5c, messageEdit: 0xffb627, memberJoin: 0x5ad27e,
  memberLeave: 0x9a8f86, memberUpdate: 0x5b8def, voice: 0xb57edc, ban: 0xb31b1b, unban: 0x5ad27e,
};
const ts = (d = new Date()) => Math.floor(d.getTime() / 1000);

module.exports = [
  {
    name: Events.MessageDelete,
    async execute(client, message) {
      try {
        if (message.partial || !message.guild || message.author?.bot) return;
        if (!logger.isEnabled(message.guild.id, 'messageDelete')) return;
        if (logger.isIgnored(message.guild.id, message.channel.id)) return;
        const embed = new EmbedBuilder()
          .setColor(COLORS.messageDelete)
          .setAuthor({ name: userTag(message.author), iconURL: message.author.displayAvatarURL() })
          .setDescription(`🗑️ **Message deleted** in <#${message.channel.id}>\n${message.content ? message.content.slice(0, 1800) : '*[no text content]*'}`)
          .setFooter({ text: `User ID: ${message.author.id}` })
          .setTimestamp();
        await logger.send(client, message.guild.id, embed);
      } catch { /* ignore */ }
    },
  },
  {
    name: Events.MessageUpdate,
    async execute(client, oldMsg, newMsg) {
      try {
        if (!newMsg.guild || newMsg.author?.bot) return;
        if (oldMsg.partial || newMsg.partial) return; // no cached content to compare
        if (oldMsg.content === newMsg.content) return;
        if (!logger.isEnabled(newMsg.guild.id, 'messageEdit')) return;
        if (logger.isIgnored(newMsg.guild.id, newMsg.channel.id)) return;
        const embed = new EmbedBuilder()
          .setColor(COLORS.messageEdit)
          .setAuthor({ name: userTag(newMsg.author), iconURL: newMsg.author.displayAvatarURL() })
          .setDescription(`✏️ **Message edited** in <#${newMsg.channel.id}> · [jump](${newMsg.url})`)
          .addFields(
            { name: 'Before', value: (oldMsg.content || '*empty*').slice(0, 1000) },
            { name: 'After', value: (newMsg.content || '*empty*').slice(0, 1000) }
          )
          .setFooter({ text: `User ID: ${newMsg.author.id}` })
          .setTimestamp();
        await logger.send(client, newMsg.guild.id, embed);
      } catch { /* ignore */ }
    },
  },
  {
    name: Events.GuildMemberAdd,
    async execute(client, member) {
      if (!logger.isEnabled(member.guild.id, 'memberJoin')) return;
      const embed = new EmbedBuilder()
        .setColor(COLORS.memberJoin)
        .setAuthor({ name: userTag(member.user), iconURL: member.user.displayAvatarURL() })
        .setDescription(`📥 **Member joined** — <@${member.id}>`)
        .addFields(
          { name: 'Account created', value: `<t:${ts(member.user.createdAt)}:R>`, inline: true },
          { name: 'Member count', value: String(member.guild.memberCount), inline: true }
        )
        .setFooter({ text: `User ID: ${member.id}` })
        .setTimestamp();
      await logger.send(client, member.guild.id, embed);
    },
  },
  {
    name: Events.GuildMemberRemove,
    async execute(client, member) {
      if (!logger.isEnabled(member.guild.id, 'memberLeave')) return;
      const roles = member.roles?.cache ? member.roles.cache.filter((r) => r.id !== member.guild.id).map((r) => `<@&${r.id}>`) : [];
      const embed = new EmbedBuilder()
        .setColor(COLORS.memberLeave)
        .setAuthor({ name: userTag(member.user), iconURL: member.user.displayAvatarURL() })
        .setDescription(`📤 **Member left** — ${userTag(member.user)}`)
        .addFields({ name: `Roles (${roles.length})`, value: roles.slice(0, 15).join(' ') || 'None' })
        .setFooter({ text: `User ID: ${member.id}` })
        .setTimestamp();
      await logger.send(client, member.guild.id, embed);
    },
  },
  {
    name: Events.GuildMemberUpdate,
    async execute(client, oldM, newM) {
      if (!logger.isEnabled(newM.guild.id, 'memberUpdate')) return;
      // nickname change
      if (oldM.nickname !== newM.nickname) {
        const embed = new EmbedBuilder()
          .setColor(COLORS.memberUpdate)
          .setAuthor({ name: userTag(newM.user), iconURL: newM.user.displayAvatarURL() })
          .setDescription(`📝 **Nickname changed** for <@${newM.id}>`)
          .addFields(
            { name: 'Before', value: oldM.nickname || '*none*', inline: true },
            { name: 'After', value: newM.nickname || '*none*', inline: true }
          )
          .setTimestamp();
        await logger.send(client, newM.guild.id, embed);
      }
      // role changes
      const before = oldM.roles.cache, after = newM.roles.cache;
      const added = after.filter((r) => !before.has(r.id)).map((r) => `<@&${r.id}>`);
      const removed = before.filter((r) => !after.has(r.id)).map((r) => `<@&${r.id}>`);
      if (added.length || removed.length) {
        const embed = new EmbedBuilder()
          .setColor(COLORS.memberUpdate)
          .setAuthor({ name: userTag(newM.user), iconURL: newM.user.displayAvatarURL() })
          .setDescription(`🎭 **Roles updated** for <@${newM.id}>`)
          .setTimestamp();
        if (added.length) embed.addFields({ name: 'Added', value: added.join(' ') });
        if (removed.length) embed.addFields({ name: 'Removed', value: removed.join(' ') });
        await logger.send(client, newM.guild.id, embed);
      }
    },
  },
  {
    name: Events.VoiceStateUpdate,
    async execute(client, oldS, newS) {
      const guild = newS.guild || oldS.guild;
      if (!guild || !logger.isEnabled(guild.id, 'voice')) return;
      // skip if either the channel joined or left is ignored
      if (logger.isIgnored(guild.id, newS.channelId) || logger.isIgnored(guild.id, oldS.channelId)) return;
      const user = newS.member?.user || oldS.member?.user;
      if (!user || user.bot) return;
      let desc = null;
      if (!oldS.channelId && newS.channelId) desc = `🔊 **Joined voice** <#${newS.channelId}>`;
      else if (oldS.channelId && !newS.channelId) desc = `🔈 **Left voice** <#${oldS.channelId}>`;
      else if (oldS.channelId && newS.channelId && oldS.channelId !== newS.channelId) desc = `🔀 **Moved voice** <#${oldS.channelId}> → <#${newS.channelId}>`;
      if (!desc) return;
      const embed = new EmbedBuilder()
        .setColor(COLORS.voice)
        .setAuthor({ name: userTag(user), iconURL: user.displayAvatarURL() })
        .setDescription(desc)
        .setFooter({ text: `User ID: ${user.id}` })
        .setTimestamp();
      await logger.send(client, guild.id, embed);
    },
  },
  {
    name: Events.GuildBanAdd,
    async execute(client, ban) {
      if (!logger.isEnabled(ban.guild.id, 'bans')) return;
      const embed = new EmbedBuilder()
        .setColor(COLORS.ban)
        .setAuthor({ name: userTag(ban.user), iconURL: ban.user.displayAvatarURL() })
        .setDescription(`🔨 **Member banned** — ${userTag(ban.user)}`)
        .setFooter({ text: `User ID: ${ban.user.id}` })
        .setTimestamp();
      await logger.send(client, ban.guild.id, embed);
    },
  },
  {
    name: Events.GuildBanRemove,
    async execute(client, ban) {
      if (!logger.isEnabled(ban.guild.id, 'bans')) return;
      const embed = new EmbedBuilder()
        .setColor(COLORS.unban)
        .setAuthor({ name: userTag(ban.user), iconURL: ban.user.displayAvatarURL() })
        .setDescription(`♻️ **Member unbanned** — ${userTag(ban.user)}`)
        .setFooter({ text: `User ID: ${ban.user.id}` })
        .setTimestamp();
      await logger.send(client, ban.guild.id, embed);
    },
  },
];
