'use strict';

const { Events } = require('discord.js');
const greetings = require('../../server/greetings');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(client, member) {
    // Autorole (applies to humans and bots unless you'd rather not — kept simple).
    try {
      const ar = greetings.getAutorole(member.guild.id);
      if (ar.enabled && ar.roleId) {
        const role = member.guild.roles.cache.get(ar.roleId);
        const me = member.guild.members.me;
        if (role && me && role.position < me.roles.highest.position) {
          await member.roles.add(role, 'Autorole').catch(() => {});
        }
      }
    } catch (err) {
      console.error('[autorole] error:', err.message);
    }

    if (member.user.bot) return; // don't greet bots

    try {
      const w = greetings.getGreeting(member.guild.id, 'welcome');
      if (w.enabled && w.channelId && w.message) {
        const ch =
          member.guild.channels.cache.get(w.channelId) ||
          (await client.channels.fetch(w.channelId).catch(() => null));
        if (ch && ch.isTextBased()) {
          await ch
            .send({ content: greetings.render(w.message, member), allowedMentions: { users: [member.id] } })
            .catch(() => {});
        }
      }
    } catch (err) {
      console.error('[welcome] error:', err.message);
    }
  },
};
