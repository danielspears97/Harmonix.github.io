'use strict';

const { Events, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const automod = require('../../moderation/automod');
const modlog = require('../../moderation/modlog');
const { userTag } = require('../../utils/format');

function anyRuleEnabled(settings) {
  return Object.values(settings.rules).some(Boolean);
}

async function logViolation(client, message, violation) {
  const channelId = modlog.getModlogChannelId(message.guild.id);
  if (!channelId) return;
  const ch = await client.channels.fetch(channelId).catch(() => null);
  if (!ch || !ch.isTextBased()) return;
  const embed = new EmbedBuilder()
    .setColor(0xf59e0b)
    .setAuthor({ name: `🛡️ AutoMod • ${violation.rule}` })
    .setDescription(
      `**User:** <@${message.author.id}> \`${userTag(message.author)}\`\n` +
        `**Channel:** <#${message.channel.id}>\n` +
        `**Trigger:** ${violation.reason}`
    )
    .setTimestamp(new Date());
  if (message.content) {
    embed.addFields({ name: 'Message', value: message.content.slice(0, 1000) });
  }
  await ch.send({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (!message.guild || message.author.bot || message.system) return;
    const member = message.member;
    if (!member) return;

    // Staff and exempt roles bypass automod.
    if (member.permissions.has(PermissionFlagsBits.ManageMessages)) return;

    const settings = automod.getSettings(message.guild.id);
    if (!anyRuleEnabled(settings)) return;
    if (settings.exemptRoles.some((id) => member.roles.cache.has(id))) return;

    const mentionCount =
      message.mentions.users.size + message.mentions.roles.size + (message.mentions.everyone ? 1 : 0);

    const violation =
      automod.checkSpam(message.guild.id, message.author.id, settings) ||
      automod.scanContent(message.content, { mentionCount }, settings);

    if (!violation) return;

    await message.delete().catch(() => {});
    try {
      const warn = await message.channel.send({
        content: `<@${message.author.id}>, your message was removed — **${violation.reason}**.`,
        allowedMentions: { users: [message.author.id] },
      });
      setTimeout(() => warn.delete().catch(() => {}), 5000);
    } catch { /* missing perms — ignore */ }

    await logViolation(client, message, violation);
  },
};
