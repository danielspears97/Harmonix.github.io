'use strict';

module.exports = {
  name: 'raw',
  execute(client, packet) {
    // Lavalink needs the raw VOICE_STATE_UPDATE / VOICE_SERVER_UPDATE payloads.
    client.lavalink.sendRawData(packet);
  },
};
