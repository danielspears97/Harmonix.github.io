'use strict';

const { Events, MessageFlags } = require('discord.js');
const { handleButton } = require('../handlers/buttons');
const { handleReactionRoleButton } = require('../handlers/reactionRoles');
const { handlePollButton } = require('../handlers/polls');
const { handleGiveawayButton } = require('../handlers/giveaways');
const { handleSuggestionButton } = require('../handlers/suggestions');
const { handleWhosthatButton } = require('../handlers/whosthat');
const { handleTicketButton } = require('../handlers/tickets');
const { handleVerifyButton } = require('../handlers/verify');
const { handleRoleMenuSelect } = require('../handlers/roleMenus');
const privateVoice = require('../handlers/privateVoice');
const { handleHelpSelect } = require('../handlers/help');
const guildSettings = require('../server/guildSettings');
const featureToggles = require('../server/featureToggles');
const usage = require('../server/usage');

/** Force a command's replies public or private per the server's reply_mode.
 *  'default' leaves each command's own choice alone. */
function applyReplyMode(interaction, mode) {
  if (mode !== 'public' && mode !== 'ephemeral') return;
  const ephemeral = mode === 'ephemeral';
  for (const fn of ['reply', 'deferReply', 'followUp']) {
    const orig = interaction[fn];
    if (typeof orig !== 'function' || orig.__rm) continue;
    const wrapped = function patched(opts) {
      let o = typeof opts === 'string' ? { content: opts } : { ...(opts || {}) };
      o.ephemeral = ephemeral;
      return orig.call(this, o);
    };
    wrapped.__rm = true;
    interaction[fn] = wrapped;
  }
}

module.exports = {
  name: Events.InteractionCreate,
  async execute(client, interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        // Feature toggles: block commands whose module is disabled for this guild.
        if (interaction.guildId && !featureToggles.isCommandAllowed(interaction.guildId, interaction.commandName)) {
          return interaction.reply({ content: 'That feature is turned off on this server.', ephemeral: true });
        }

        // Per-guild gating at the individual-command level (command + subcommand).
        let path = null;
        if (interaction.guildId && interaction.commandName !== 'help') {
          const parts = [interaction.commandName];
          const grp = interaction.options.getSubcommandGroup(false);
          const sub = interaction.options.getSubcommand(false);
          if (grp) parts.push(grp);
          if (sub) parts.push(sub);
          path = parts.join(' ');
          const level = guildSettings.memberPowerLevel(interaction.member);
          const gate = guildSettings.checkCommand(interaction.guildId, path, interaction.channelId, level);
          if (!gate.ok) {
            const custom = guildSettings.getGateMessages(interaction.guildId);
            const msg = gate.reason === 'disabled'
              ? (custom.disabled || 'That command is disabled on this server.')
              : gate.reason === 'level'
                ? (custom.level ? custom.level.replace('{level}', gate.required) : `You need **power level ${gate.required}** to use that command.`)
                : (custom.channel || 'That command can’t be used in this channel.');
            return interaction.reply({ content: msg, ephemeral: true });
          }
        }

        // Reply visibility: a per-command override wins, else the server-wide default.
        if (interaction.guildId) {
          const perCmd = path ? guildSettings.getCommandReply(interaction.guildId, path) : null;
          applyReplyMode(interaction, perCmd || guildSettings.getReplyMode(interaction.guildId));
        }

        await command.execute(client, interaction);

        // Command-explorer achievements (first use of each feature area).
        if (interaction.guildId && featureToggles.isModuleEnabled(interaction.guildId, 'engagement')) {
          const ach = require('../engagement/achievements');
          const achKey = ach.forModule(featureToggles.moduleForCommand(interaction.commandName));
          if (achKey) {
            const unlocked = [];
            const d1 = ach.unlock(interaction.guildId, interaction.user.id, achKey); if (d1) unlocked.push(d1);
            const d2 = ach.checkExplorer(interaction.guildId, interaction.user.id); if (d2) unlocked.push(d2);
            unlocked.push(...ach.checkMeta(interaction.guildId, interaction.user.id));
            if (unlocked.length) ach.announce(client, { guildId: interaction.guildId, userId: interaction.user.id, channel: interaction.channel, defs: unlocked });
          }
        }

        // Usage stats (best-effort).
        if (interaction.guildId) {
          try { usage.record(interaction.guildId, interaction.commandName); } catch { /* ignore */ }
        }

        // Auto-delete the bot's (non-ephemeral) response after the configured delay.
        if (interaction.guildId) {
          const secs = guildSettings.getAutoDelete(interaction.guildId);
          if (secs > 0) {
            const reply = await interaction.fetchReply().catch(() => null);
            if (reply && !(reply.flags && reply.flags.has(MessageFlags.Ephemeral))) {
              setTimeout(() => interaction.deleteReply().catch(() => {}), secs * 1000);
            }
          }
        }
        return;
      }
      if (interaction.isUserSelectMenu()) {
        if (interaction.customId.startsWith('pvc:')) await privateVoice.handleComponent(client, interaction);
        return;
      }

      if (interaction.isModalSubmit()) {
        if (interaction.customId.startsWith('pvc:')) await privateVoice.handleModal(client, interaction);
        return;
      }

      if (interaction.isStringSelectMenu()) {
        if (interaction.customId.startsWith('rolemenu:')) await handleRoleMenuSelect(client, interaction);
        else if (interaction.customId === 'help:cat') await handleHelpSelect(client, interaction);
        return;
      }

      if (interaction.isButton()) {
        const id = interaction.customId;
        if (id.startsWith('rr:')) await handleReactionRoleButton(client, interaction);
        else if (id.startsWith('poll:')) await handlePollButton(client, interaction);
        else if (id.startsWith('gw:')) await handleGiveawayButton(client, interaction);
        else if (id.startsWith('sug:')) await handleSuggestionButton(client, interaction);
        else if (id.startsWith('ticket:')) await handleTicketButton(client, interaction);
        else if (id.startsWith('verify:')) await handleVerifyButton(client, interaction);
        else if (id.startsWith('whosthat:')) await handleWhosthatButton(client, interaction);
        else if (id.startsWith('pvc:')) await privateVoice.handleComponent(client, interaction);
        else await handleButton(client, interaction);
        return;
      }
    } catch (err) {
      console.error('[interaction] error:', err);
      const msg = '❌ Something went wrong handling that interaction.';
      if (interaction.isRepliable()) {
        if (interaction.replied || interaction.deferred) {
          interaction.followUp({ content: msg, ephemeral: true }).catch(() => {});
        } else {
          interaction.reply({ content: msg, ephemeral: true }).catch(() => {});
        }
      }
    }
  },
};
