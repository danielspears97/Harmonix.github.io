'use strict';

const { Events } = require('discord.js');
const { config } = require('../../config');
const { getGuild } = require('../utils/persistence');
const { notify } = require('../utils/bus');
const controller = require('../controller');

const emptyTimers = new Map(); // guildId -> timeout

function clearEmptyTimer(guildId) {
  if (emptyTimers.has(guildId)) {
    clearTimeout(emptyTimers.get(guildId));
    emptyTimers.delete(guildId);
  }
}

module.exports = {
  name: Events.VoiceStateUpdate,
  async execute(client, oldState, newState) {
    const guildId = (newState.guild || oldState.guild)?.id;
    if (!guildId) return;

    const player = controller.getPlayer(client, guildId);
    if (!player) return;

    // If the bot itself was force-disconnected, tear down the player.
    if (oldState.id === client.user.id && oldState.channelId && !newState.channelId) {
      clearEmptyTimer(guildId);
      await player.destroy().catch(() => {});
      notify(guildId);
      return;
    }
    // If the bot was moved to another channel, keep the player in sync.
    if (newState.id === client.user.id && newState.channelId && newState.channelId !== player.voiceChannelId) {
      player.voiceChannelId = newState.channelId;
    }

    const botChannelId = player.voiceChannelId;
    if (!botChannelId) return;
    const channel = client.channels.cache.get(botChannelId);
    if (!channel) return;

    const humans = channel.members.filter((m) => !m.user.bot).size;
    const settings = getGuild(guildId);

    if (humans === 0) {
      if (settings.twentyFourSeven) return; // stay forever in 24/7 mode
      if (emptyTimers.has(guildId)) return;
      emptyTimers.set(
        guildId,
        setTimeout(async () => {
          emptyTimers.delete(guildId);
          const p = controller.getPlayer(client, guildId);
          const stillEmpty =
            p && client.channels.cache.get(p.voiceChannelId)?.members.filter((m) => !m.user.bot).size === 0;
          if (p && stillEmpty && !getGuild(guildId).twentyFourSeven) {
            await p.destroy().catch(() => {});
            notify(guildId);
          }
        }, config.leaveTimeoutMs)
      );
    } else {
      clearEmptyTimer(guildId);
    }
  },
};
