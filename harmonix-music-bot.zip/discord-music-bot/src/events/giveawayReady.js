'use strict';

const { Events } = require('discord.js');
const scheduler = require('../engagement/giveawayScheduler');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    scheduler.start(client);
  },
};
