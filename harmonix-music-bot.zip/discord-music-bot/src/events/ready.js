'use strict';

const { Events } = require('discord.js');
const { config } = require('../../config');
const { load, getGuild } = require('../utils/persistence');
const { ensurePanelMessage } = require('../handlers/controlPanel');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`[bot] logged in as ${client.user.tag}`);

    // Initialise the Lavalink manager now that we have the user id.
    await client.lavalink.init({ id: client.user.id, username: client.user.username });

    // Idle presence + rotation live in the Lavalink event module so music
    // playback and the idle lines can't fight over the same status.
    client.user.setStatus('online');
    const presence = require('../lavalink/events');
    presence.refreshPresence(client);
    presence.startPresenceRotation(client);

    // Re-post / refresh the control panel in every configured guild.
    load();
    for (const guild of client.guilds.cache.values()) {
      const settings = getGuild(guild.id);
      if (settings.controlChannelId) {
        await ensurePanelMessage(client, guild.id).catch(() => {});
      }
    }

    console.log('[bot] ready.');
    console.log(`[bot] in ${client.guilds.cache.size} server(s).`);
    // Re-invite with this URL if slash commands don't appear in a server — it
    // must include the applications.commands scope, or the commands stay hidden.
    console.log(
      `[bot] invite URL (needs applications.commands scope): ` +
      `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`
    );
  },
};
