'use strict';

const { Events } = require('discord.js');
const controller = require('../controller');
const { getGuild } = require('../utils/persistence');
const guildSettings = require('../server/guildSettings');
const { truncate } = require('../utils/format');

module.exports = {
  name: Events.MessageCreate,
  async execute(client, message) {
    if (message.author.bot || !message.guild) return;
    const settings = getGuild(message.guild.id);
    if (!settings.controlChannelId || message.channelId !== settings.controlChannelId) return;

    const query = message.content.trim();
    if (!query) return;

    // Tidy up: remove the user's request message so the channel stays clean.
    const cleanup = () => message.delete().catch(() => {});

    const voiceChannelId = message.member?.voice?.channelId;
    if (!voiceChannelId) {
      const warn = await message.reply('🔇 Join a voice channel first.').catch(() => null);
      setTimeout(() => warn?.delete().catch(() => {}), 5000);
      return cleanup();
    }

    const lock = guildSettings.getMusicChannel(message.guild.id);
    if (lock && voiceChannelId !== lock) {
      const warn = await message.reply(`🔒 Music is locked to <#${lock}>.`).catch(() => null);
      setTimeout(() => warn?.delete().catch(() => {}), 5000);
      return cleanup();
    }

    const player = controller.getPlayer(client, message.guild.id);
    if (player && player.voiceChannelId && player.voiceChannelId !== voiceChannelId) {
      const warn = await message.reply('🔇 You need to be in my voice channel.').catch(() => null);
      setTimeout(() => warn?.delete().catch(() => {}), 5000);
      return cleanup();
    }

    const requester = {
      id: message.author.id,
      username: message.author.username,
      avatar: message.author.displayAvatarURL?.({ extension: 'png' }) || null,
    };

    let result;
    try {
      result = await controller.play(client, {
        guildId: message.guild.id,
        voiceChannelId,
        textChannelId: message.channelId,
        query,
        requester,
      });
    } catch (err) {
      console.error('[request] play error:', err);
      const warn = await message.reply('❌ Could not load that. Is Lavalink online?').catch(() => null);
      setTimeout(() => warn?.delete().catch(() => {}), 6000);
      return cleanup();
    }

    let text;
    if (!result.ok) text = '🔎 No results found.';
    else if (result.added.type === 'playlist')
      text = `📃 Queued **${truncate(result.added.name, 60)}** (${result.added.count} tracks).`;
    else text = `🎵 Queued **${truncate(result.added.track.title, 60)}**.`;

    const note = await message.channel.send(text).catch(() => null);
    setTimeout(() => note?.delete().catch(() => {}), 5000);
    cleanup();
  },
};
