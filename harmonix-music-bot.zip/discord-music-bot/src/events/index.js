'use strict';

const fs = require('fs');
const path = require('path');
const { config } = require('../../config');

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(full));
    else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

// In MUSIC_ONLY mode, skip handlers/schedulers for non-music features. The
// kept root events (ready, interactionCreate, messageCreate, voiceStateUpdate,
// raw) are all needed for music.
function isMusicEvent(file) {
  if (file.includes(`${path.sep}guild${path.sep}`)) return false; // autorole, leveling, automod, tempvoice, logging…
  const base = path.basename(file, '.js');
  if (base === 'utilityReady' || base === 'giveawayReady') return false; // non-music schedulers
  return true;
}

/**
 * Register every event module in this directory tree. Each module exports
 * { name, once?, execute }. Multiple modules may listen to the same event.
 */
function registerEvents(client) {
  for (const file of walk(__dirname)) {
    if (file === __filename) continue;
    if (config.musicOnly && !isMusicEvent(file)) continue;
    const event = require(file);
    const list = Array.isArray(event) ? event : [event];
    for (const e of list) {
      if (!e || !e.name || typeof e.execute !== 'function') continue;
      const handler = (...args) => e.execute(client, ...args);
      if (e.once) client.once(e.name, handler);
      else client.on(e.name, handler);
    }
  }
}

module.exports = { registerEvents };
