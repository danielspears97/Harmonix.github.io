'use strict';

const path = require('path');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const { Server } = require('socket.io');
const { PermissionFlagsBits, ChannelType } = require('discord.js');

const { config } = require('../../config');
const controller = require('../controller');
const { bus } = require('../utils/bus');
const guildSettings = require('../server/guildSettings');
const featureToggles = require('../server/featureToggles');
const cases = require('../moderation/cases');
const levels = require('../engagement/levels');
const usage = require('../server/usage');
const greetings = require('../server/greetings');
const starboard = require('../server/starboard');
const logFeed = require('../moderation/logFeed');

const DISCORD_API = 'https://discord.com/api';
const MANAGE = PermissionFlagsBits.ManageGuild; // 0x20
const ADMIN = PermissionFlagsBits.Administrator; // 0x8

// Dashboard capabilities → the Discord permissions that grant each one (any-of).
// Administrator / guild owner implies every capability.
const P = PermissionFlagsBits;
const CAP_PERMS = {
  commands: [P.ManageGuild], // command gating + role power levels
  settings: [P.ManageGuild], // server settings + feature module toggles
  config: [P.ManageGuild], // welcome / autorole / starboard
  levels: [P.ManageGuild], // leveling config + editing XP
  stats: [P.ManageGuild, P.ViewAuditLog], // command usage
  achievements: [P.ManageGuild, P.ModerateMembers, P.ManageMessages, P.KickMembers, P.BanMembers],
  cases: [P.ManageGuild, P.ModerateMembers, P.ManageMessages, P.KickMembers, P.BanMembers],
  log: [P.ManageGuild, P.ViewAuditLog], // live log feed
};
const ALL_CAPS = Object.keys(CAP_PERMS);

/** Capability keys a member with this permission bitfield holds. */
function computeCaps(permsBigInt, owner) {
  if (owner || (permsBigInt & ADMIN) === ADMIN) return [...ALL_CAPS];
  return ALL_CAPS.filter((cap) => CAP_PERMS[cap].some((bit) => (permsBigInt & bit) === bit));
}

function startDashboard(client) {
  if (!config.dashboard.enabled) {
    console.log('[dashboard] disabled (DASHBOARD_ENABLED=false)');
    return null;
  }

  const oauth = config.dashboard.oauth;
  const oauthMode = !!(oauth.clientId && oauth.clientSecret && oauth.redirectUri);
  const passwordRequired = !oauthMode && !!config.dashboard.password;

  if (oauthMode) {
    console.log('[dashboard] auth mode: Discord OAuth2');
  } else {
    console.log(
      `[dashboard] auth mode: local${passwordRequired ? ' (password)' : ' (open — set CLIENT_SECRET to enable OAuth)'}`
    );
  }

  const app = express();
  const server = http.createServer(app);
  const io = new Server(server, { cors: { origin: true, credentials: true } });

  // When behind a tunnel / reverse proxy (Cloudflare, ngrok, nginx…), trust the
  // X-Forwarded-* headers so HTTPS detection and secure cookies work correctly.
  const behindHttps = /^https:/i.test(config.dashboard.publicUrl || '') || /^https:/i.test(config.dashboard.oauth.redirectUri || '');
  if (behindHttps) app.set('trust proxy', 1);

  const sessionMiddleware = session({
    secret: config.dashboard.sessionSecret || crypto.randomBytes(32).toString('hex'),
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', secure: behindHttps, maxAge: 7 * 24 * 60 * 60 * 1000 },
  });
  app.use(sessionMiddleware);
  // Share the session with Socket.IO so sockets can read the logged-in user.
  io.engine.use(sessionMiddleware);

  app.use(express.static(path.join(__dirname, 'public')));

  app.get('/api/config', (req, res) => {
    res.json({
      authMode: oauthMode ? 'oauth' : 'local',
      requiresPassword: passwordRequired,
      brand: config.brand.name,
    });
  });

  // ── helpers ────────────────────────────────────────────────────
  const localAuthed = new WeakSet(); // sockets that passed the local password

  // Guilds the bot is in, as a quick lookup.
  function botGuildIds() {
    return new Set(client.guilds.cache.keys());
  }

  // From a raw Discord guild list (user's), keep ones they can manage AND the
  // bot is also in. Returns [{id,name,icon}].
  function mutualGuilds(userGuilds) {
    const inBot = botGuildIds();
    const out = [];
    for (const g of userGuilds || []) {
      if (!inBot.has(g.id)) continue;
      const perms = BigInt(g.permissions || '0');
      const caps = computeCaps(perms, !!g.owner);
      const bg = client.guilds.cache.get(g.id);
      out.push({
        id: g.id,
        name: bg?.name || g.name,
        icon: bg?.iconURL?.({ extension: 'png', size: 64 }) || null,
        caps,
        canManage: caps.length > 0,
      });
    }
    // Managers first, then alphabetical.
    return out.sort((a, b) => (b.canManage - a.canManage) || a.name.localeCompare(b.name));
  }

  // All bot guilds (used in local mode where there's no per-user scoping).
  function allBotGuilds() {
    return [...client.guilds.cache.values()].map((g) => ({
      id: g.id,
      name: g.name,
      icon: g.iconURL?.({ extension: 'png', size: 64 }) || null,
      caps: [...ALL_CAPS],
      canManage: true,
    }));
  }

  // Resolve which guilds a given socket may see/control, and whether it's authed.
  function socketScope(socket) {
    if (oauthMode) {
      const sess = socket.request.session;
      if (!sess || !sess.user) return null;
      return {
        user: sess.user,
        guilds: mutualGuilds(sess.guilds),
      };
    }
    // local mode
    if (passwordRequired && !localAuthed.has(socket)) return null;
    return { user: { id: 'local', username: 'Local', avatar: null }, guilds: allBotGuilds() };
  }

  function canManage(scope, guildId) {
    return !!scope && scope.guilds.some((g) => g.id === guildId && g.canManage);
  }
  // Does the user hold a specific dashboard capability in this guild?
  function hasCap(scope, guildId, cap) {
    const g = scope && scope.guilds.find((x) => x.id === guildId);
    return !!(g && Array.isArray(g.caps) && g.caps.includes(cap));
  }
  // Any mutual guild the user shares with the bot (music console access).
  function inScope(scope, guildId) {
    return !!scope && scope.guilds.some((g) => g.id === guildId);
  }

  // ── display-name resolution ────────────────────────────────────
  // Discord's member cache is sparse, so leaderboards can't rely on it. Fetch
  // whatever is missing (one bulk gateway call), fall back to the global
  // account for people who have left, and remember results briefly so
  // re-renders don't re-hit the API.
  const nameCache = new Map(); // `${guildId}:${userId}` -> { name, avatar, left, at }
  const NAME_TTL_MS = 10 * 60 * 1000;

  async function resolveUsers(guildId, ids) {
    const wanted = [...new Set(ids.filter(Boolean))];
    const out = new Map();
    if (!wanted.length) return out;
    const guild = client.guilds.cache.get(guildId);
    const now = Date.now();
    const missing = [];

    for (const id of wanted) {
      const hit = nameCache.get(`${guildId}:${id}`);
      if (hit && now - hit.at < NAME_TTL_MS) { out.set(id, hit); continue; }
      const cached = guild?.members?.cache?.get(id);
      if (cached) {
        const rec = { name: cached.displayName, avatar: cached.user.displayAvatarURL({ extension: 'png', size: 64 }), left: false, at: now };
        nameCache.set(`${guildId}:${id}`, rec);
        out.set(id, rec);
      } else missing.push(id);
    }

    if (missing.length && guild) {
      // one request for everyone still unknown (needs the GuildMembers intent)
      const fetched = await guild.members.fetch({ user: missing.slice(0, 100) }).catch(() => null);
      if (fetched) {
        for (const [id, member] of fetched) {
          const rec = { name: member.displayName, avatar: member.user.displayAvatarURL({ extension: 'png', size: 64 }), left: false, at: now };
          nameCache.set(`${guildId}:${id}`, rec);
          out.set(id, rec);
        }
      }
    }

    // anyone still unresolved has almost certainly left the server
    const stillMissing = missing.filter((id) => !out.has(id)).slice(0, 25);
    await Promise.all(stillMissing.map(async (id) => {
      const user = await client.users.fetch(id).catch(() => null);
      const rec = user
        ? { name: user.globalName || user.username, avatar: user.displayAvatarURL({ extension: 'png', size: 64 }), left: true, at: now }
        : { name: `Unknown user ${id.slice(-4)}`, avatar: null, left: true, at: now };
      nameCache.set(`${guildId}:${id}`, rec);
      out.set(id, rec);
    }));

    for (const id of wanted) {
      if (!out.has(id)) out.set(id, { name: `Unknown user ${id.slice(-4)}`, avatar: null, left: true, at: now });
    }
    return out;
  }

  // ── OAuth routes ───────────────────────────────────────────────
  if (oauthMode) {
    app.get('/auth/login', (req, res) => {
      const state = crypto.randomBytes(16).toString('hex');
      req.session.oauthState = state;
      const url = new URL(`${DISCORD_API}/oauth2/authorize`);
      url.searchParams.set('client_id', oauth.clientId);
      url.searchParams.set('redirect_uri', oauth.redirectUri);
      url.searchParams.set('response_type', 'code');
      url.searchParams.set('scope', 'identify guilds');
      url.searchParams.set('state', state);
      res.redirect(url.toString());
    });

    app.get('/auth/callback', async (req, res) => {
      const { code, state } = req.query;
      if (!code || !state || state !== req.session.oauthState) {
        return res.status(400).send('Invalid OAuth state. <a href="/auth/login">Try again</a>.');
      }
      delete req.session.oauthState;
      try {
        const tokenRes = await fetch(`${DISCORD_API}/oauth2/token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            client_id: oauth.clientId,
            client_secret: oauth.clientSecret,
            grant_type: 'authorization_code',
            code: String(code),
            redirect_uri: oauth.redirectUri,
          }),
        });
        if (!tokenRes.ok) throw new Error(`token exchange ${tokenRes.status}`);
        const token = await tokenRes.json();

        const headers = { Authorization: `Bearer ${token.access_token}` };
        const [meRes, guildsRes] = await Promise.all([
          fetch(`${DISCORD_API}/users/@me`, { headers }),
          fetch(`${DISCORD_API}/users/@me/guilds`, { headers }),
        ]);
        if (!meRes.ok || !guildsRes.ok) throw new Error('failed to fetch user/guilds');
        const me = await meRes.json();
        const guilds = await guildsRes.json();

        req.session.user = {
          id: me.id,
          username: me.global_name || me.username,
          avatar: me.avatar
            ? `https://cdn.discordapp.com/avatars/${me.id}/${me.avatar}.png`
            : null,
        };
        req.session.guilds = guilds; // raw; filtered per-request via manageableGuilds
        res.redirect('/');
      } catch (err) {
        console.error('[dashboard] OAuth callback failed:', err.message);
        res.status(500).send('Login failed. <a href="/auth/login">Try again</a>.');
      }
    });

    app.get('/auth/logout', (req, res) => {
      req.session.destroy(() => res.redirect('/'));
    });

    app.get('/api/me', (req, res) => {
      if (!req.session.user) return res.status(401).json({ user: null });
      res.json({ user: req.session.user, guilds: mutualGuilds(req.session.guilds) });
    });
  }

  // ── Socket.IO ──────────────────────────────────────────────────
  const subscription = new Map(); // socket.id -> guildId

  io.on('connection', (socket) => {
    socket.emit('hello', {
      authMode: oauthMode ? 'oauth' : 'local',
      requiresPassword: passwordRequired,
      authed: !!socketScope(socket),
    });

    // Local-mode password (no-op in OAuth mode).
    socket.on('auth', (password) => {
      if (oauthMode) return;
      if (!passwordRequired || password === config.dashboard.password) {
        localAuthed.add(socket);
        socket.emit('authResult', { ok: true });
      } else {
        socket.emit('authResult', { ok: false });
      }
    });

    socket.on('getGuilds', () => {
      const scope = socketScope(socket);
      if (!scope) return socket.emit('authResult', { ok: false });
      socket.emit('guilds', scope.guilds);
    });

    socket.on('subscribe', (guildId) => {
      const scope = socketScope(socket);
      if (!scope) return socket.emit('authResult', { ok: false });
      if (!inScope(scope, guildId)) return socket.emit('notice', { type: 'error', message: 'You’re not in that server.' });
      const prev = subscription.get(socket.id);
      if (prev) socket.leave(`guild:${prev}`);
      subscription.set(socket.id, guildId);
      socket.join(`guild:${guildId}`);
      socket.emit('state', controller.getState(client, guildId));
    });

    socket.on('control', async ({ guildId, action, value } = {}) => {
      const scope = socketScope(socket);
      if (!scope || !guildId || !inScope(scope, guildId)) return;
      try {
        switch (action) {
          case 'togglePause': await controller.togglePause(client, guildId); break;
          case 'skip': await controller.skip(client, guildId); break;
          case 'previous': await controller.previous(client, guildId); break;
          case 'stop': await controller.stop(client, guildId); break;
          case 'shuffle': await controller.shuffle(client, guildId); break;
          case 'loop': await controller.cycleLoop(client, guildId); break;
          case 'autoplay': controller.toggleAutoplay(client, guildId); break;
          case '247': controller.toggle247(client, guildId); break;
          case 'volume': await controller.setVolume(client, guildId, Number(value)); break;
          case 'seek': await controller.seek(client, guildId, Number(value)); break;
          case 'remove': controller.removeAt(client, guildId, Number(value)); break;
          case 'move': controller.move(client, guildId, Number(value?.from), Number(value?.to)); break;
          case 'clear': controller.clearQueue(client, guildId); break;
          case 'disconnect': await controller.disconnect(client, guildId); break;
          default: break;
        }
      } catch (err) {
        console.error('[dashboard] control error:', err.message);
      }
      socket.emit('state', controller.getState(client, guildId));
    });

    socket.on('play', async ({ guildId, query } = {}) => {
      const scope = socketScope(socket);
      if (!scope || !guildId || !query || !inScope(scope, guildId)) return;
      const player = controller.getPlayer(client, guildId);
      if (!player || !player.voiceChannelId) {
        return socket.emit('notice', {
          type: 'error',
          message: 'Start playback from Discord first so I know which voice channel to join.',
        });
      }
      try {
        const res = await controller.play(client, {
          guildId,
          voiceChannelId: player.voiceChannelId,
          textChannelId: player.textChannelId,
          query,
          requester: { id: scope.user.id, username: scope.user.username, avatar: scope.user.avatar },
        });
        socket.emit('notice', {
          type: res.ok ? 'success' : 'error',
          message: res.ok ? 'Added to the queue.' : 'No results found.',
        });
      } catch {
        socket.emit('notice', { type: 'error', message: 'Failed to load that track.' });
      }
    });

    socket.on('disconnect', () => subscription.delete(socket.id));

    socket.on('getHealth', () => {
      if (!socketScope(socket)) return;
      const players = client.lavalink?.players;
      const nodes = client.lavalink?.nodeManager?.nodes;
      socket.emit('health', {
        uptimeSec: Math.floor(process.uptime()),
        memMb: Math.round(process.memoryUsage().rss / 1048576),
        ping: Math.max(0, Math.round(client.ws.ping)),
        guilds: client.guilds.cache.size,
        players: players?.size || 0,
        playing: [...(players?.values() || [])].filter((p) => p.playing).length,
        nodes: nodes ? [...nodes.values()].map((n) => ({ id: n.id || 'node', connected: !!n.connected })) : [],
      });
    });

    // ── server manager: command gating + settings ──────────────────
    function managerPayload(guildId) {
      const guild = client.guilds.cache.get(guildId);
      // Flatten every command into individual leaf paths (command + group + subcommand).
      const commands = [];
      for (const c of client.commands.values()) {
        if (c.data.name === 'help') continue;
        const j = c.data.toJSON();
        const opts = j.options || [];
        const subs = opts.filter((o) => o.type === 1);
        const groups = opts.filter((o) => o.type === 2);
        if (!subs.length && !groups.length) {
          commands.push({ path: j.name, description: j.description });
        }
        for (const s of subs) commands.push({ path: `${j.name} ${s.name}`, description: s.description });
        for (const g of groups) for (const s of (g.options || []).filter((o) => o.type === 1)) {
          commands.push({ path: `${j.name} ${g.name} ${s.name}`, description: s.description });
        }
      }
      commands.sort((a, b) => a.path.localeCompare(b.path));
      const channels = guild
        ? [...guild.channels.cache.values()]
            .filter((ch) => ch.type === ChannelType.GuildText)
            .map((ch) => ({ id: ch.id, name: ch.name }))
            .sort((a, b) => a.name.localeCompare(b.name))
        : [];
      const roles = guild
        ? [...guild.roles.cache.values()].filter((r) => r.id !== guild.id && !r.managed).sort((a, b) => b.position - a.position).map((r) => ({ id: r.id, name: r.name }))
        : [];
      const voiceChannels = guild
        ? [...guild.channels.cache.values()].filter((ch) => ch.type === ChannelType.GuildVoice).map((ch) => ({ id: ch.id, name: ch.name })).sort((a, b) => a.name.localeCompare(b.name))
        : [];
      return {
        guildId,
        commands,
        channels,
        voiceChannels,
        roles,
        powerRoles: guildSettings.getPowerRoles(guildId),
        gate: guildSettings.getGate(guildId),
        autodelete: guildSettings.getAutoDelete(guildId),
        triviaChannel: guildSettings.getTriviaChannel(guildId),
        musicChannel: guildSettings.getMusicChannel(guildId),
        musicSettings: guildSettings.getMusicSettings(guildId),
        replyMode: guildSettings.getReplyMode(guildId),
        gateMessages: guildSettings.getGateMessages(guildId),
        xpIgnore: guildSettings.getXpIgnore(guildId),
        levelupDM: guildSettings.getLevelupDM(guildId),
        voiceXp: guildSettings.getVoiceXp(guildId),
        countingChannel: require('../engagement/counting').getState(guildId).channelId,
        achAnnounce: guildSettings.getAchievementAnnounce(guildId),
        featureChannels: {
          music: require('../utils/persistence').getGuild(guildId).controlChannelId || null,
          logging: require('../moderation/logger').getSettings(guildId).channelId || null,
          modlog: require('../moderation/modlog').getModlogChannelId(guildId) || null,
          tickets: require('../moderation/tickets').getSettings(guildId).logChannelId || null,
          suggestions: require('../community/suggestions').getChannel(guildId) || null,
          birthday: (require('../community/birthdays').getCfg(guildId) || {}).channelId || null,
        },
        modules: featureToggles.MODULES.map((m) => ({ key: m.key, label: m.label })),
        disabledModules: featureToggles.getDisabled(guildId),
        prefix: guildSettings.getPrefix(guildId),
      };
    }

    socket.on('getManager', (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !(hasCap(scope, guildId, 'commands') || hasCap(scope, guildId, 'settings'))) return;
      const payload = managerPayload(guildId);
      const g = scope.guilds.find((x) => x.id === guildId);
      payload.caps = (g && g.caps) || [];
      socket.emit('manager', payload);
    });

    socket.on('saveManager', (payload = {}) => {
      const { guildId, gate, autodelete, triviaChannel, prefix } = payload;
      const scope = socketScope(socket);
      if (!scope) return;
      const mayCommands = hasCap(scope, guildId, 'commands');
      const maySettings = hasCap(scope, guildId, 'settings');
      if (!mayCommands && !maySettings) return;
      try {
        // ── command gating + power levels (requires 'commands') ──
        if (mayCommands) {
          const clean = {};
          if (gate && typeof gate === 'object') {
            for (const [name, rule] of Object.entries(gate)) {
              const mode = rule && (rule.mode === 'allow' || rule.mode === 'deny') ? rule.mode : null;
              const channels = Array.isArray(rule && rule.channels) ? rule.channels.filter((x) => typeof x === 'string') : [];
              const enabled = !(rule && rule.enabled === false);
              const level = Math.max(0, Math.min(2, Math.floor(Number(rule && rule.level) || 0)));
              const reply = ['public', 'ephemeral'].includes(rule && rule.reply) ? rule.reply : null;
              if (!enabled || mode || level || reply) clean[name] = { enabled, mode, channels, level, reply };
            }
            guildSettings.setGate(guildId, clean);
          }
          if (payload.powerRoles && typeof payload.powerRoles === 'object') {
            const pr = {};
            for (const [rid, lv] of Object.entries(payload.powerRoles)) {
              const v = Math.max(0, Math.min(2, Math.floor(Number(lv) || 0)));
              if (v) pr[rid] = v;
            }
            guildSettings.setPowerRoles(guildId, pr);
          }
        }
        // ── server settings + feature toggles (requires 'settings') ──
        if (maySettings) {
          if ('autodelete' in payload) guildSettings.setAutoDelete(guildId, Number(autodelete) || 0);
          if ('triviaChannel' in payload) guildSettings.setTriviaChannel(guildId, triviaChannel || null);
          if ('musicChannel' in payload) guildSettings.setMusicChannel(guildId, payload.musicChannel || null);
          if (payload.musicSettings) guildSettings.setMusicSettings(guildId, payload.musicSettings);
          if (payload.replyMode) guildSettings.setReplyMode(guildId, payload.replyMode);
          if (payload.gateMessages) guildSettings.setGateMessages(guildId, payload.gateMessages);
          if ('xpIgnore' in payload) guildSettings.setXpIgnore(guildId, payload.xpIgnore || []);
          if ('levelupDM' in payload) guildSettings.setLevelupDM(guildId, !!payload.levelupDM);
          if ('voiceXp' in payload) guildSettings.setVoiceXp(guildId, !!payload.voiceXp);
          if ('disabledModules' in payload) featureToggles.setDisabled(guildId, payload.disabledModules || []);
          if ('countingChannel' in payload) require('../engagement/counting').setChannel(guildId, payload.countingChannel || null);
          if (payload.achAnnounce) guildSettings.setAchievementAnnounce(guildId, payload.achAnnounce);
          if (payload.featureChannels) {
            const fc = payload.featureChannels;
            if ('logging' in fc) require('../moderation/logger').setChannel(guildId, fc.logging || null);
            if ('modlog' in fc) { const ml = require('../moderation/modlog'); fc.modlog ? ml.setModlogChannel(guildId, fc.modlog) : ml.disableModlog(guildId); }
            if ('tickets' in fc) require('../moderation/tickets').setSettings(guildId, { logChannelId: fc.tickets || null });
            if ('suggestions' in fc) require('../community/suggestions').setChannel(guildId, fc.suggestions || null);
            if ('birthday' in fc) { const b = require('../community/birthdays'); b.setCfg(guildId, { ...(b.getCfg(guildId) || {}), channelId: fc.birthday || null }); }
            if ('music' in fc) {
              const persistence = require('../utils/persistence');
              const cur = persistence.getGuild(guildId);
              if ((cur.controlChannelId || null) !== (fc.music || null)) {
                persistence.setGuild(guildId, { controlChannelId: fc.music || null, controlMessageId: null });
                if (fc.music) require('../handlers/controlPanel').ensurePanelMessage(client, guildId).catch(() => {});
              }
            }
          }
          if (typeof prefix === 'string' && prefix.trim()) guildSettings.setPrefix(guildId, prefix.trim());
        }
        socket.emit('saved');
      } catch (err) {
        console.error('[dashboard] saveManager error:', err.message);
        socket.emit('notice', { type: 'error', message: 'Failed to save settings.' });
      }
    });

    // ── mod cases ──────────────────────────────────────────────────
    socket.on('getCases', (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'cases')) return;
      socket.emit('cases', { guildId, cases: cases.listRecent(guildId, { limit: 40 }) });
    });

    // ── leveling ───────────────────────────────────────────────────
    async function levelsPayload(guildId) {
      const rows = levels.top(guildId, 50);
      const names = await resolveUsers(guildId, rows.map((r) => r.user_id));
      return {
        guildId,
        levels: rows.map((r) => {
          const u = names.get(r.user_id) || {};
          return {
            userId: r.user_id,
            name: u.name || `Unknown user ${r.user_id.slice(-4)}`,
            avatar: u.avatar || null,
            left: !!u.left,
            xp: r.xp,
            level: levels.levelFromXp(r.xp),
          };
        }),
      };
    }
    socket.on('getLevels', async (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'levels')) return;
      socket.emit('levels', await levelsPayload(guildId));
    });
    socket.on('saveLevel', async (payload = {}) => {
      const { guildId, userId, xp } = payload;
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'levels')) return;
      if (typeof userId === 'string' && Number.isFinite(Number(xp))) {
        levels.setXp(guildId, userId, Math.max(0, Math.floor(Number(xp))));
        socket.emit('levels', await levelsPayload(guildId));
        socket.emit('notice', { type: 'success', message: 'XP updated.' });
      }
    });

    // ── command stats ──────────────────────────────────────────────
    socket.on('getStats', (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'stats')) return;
      socket.emit('stats', { guildId, top: usage.top(guildId, 20), total: usage.total(guildId) });
    });

    // ── achievements leaderboard ───────────────────────────────────
    socket.on('getAchievements', async (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'achievements')) return;
      const achievements = require('../engagement/achievements');
      const rows = achievements.leaderboard(guildId, 15);
      const names = await resolveUsers(guildId, rows.map((r) => r.user_id));
      const board = rows.map((r) => {
        const u = names.get(r.user_id) || {};
        return {
          userId: r.user_id,
          name: u.name || `Unknown user ${r.user_id.slice(-4)}`,
          avatar: u.avatar || null,
          left: !!u.left,
          count: r.count,
        };
      });
      socket.emit('achievements', { guildId, defs: achievements.DEFS, counts: achievements.stats(guildId), total: achievements.DEFS.length, board });
    });

    // ── overview (home) ────────────────────────────────────────────
    socket.on('getOverview', (guildId) => {
      const scope = socketScope(socket);
      // Read-only stats are fine for anyone in the guild; the manager-only
      // extras below are withheld unless they can actually manage it.
      if (!scope || !guildId || !inScope(scope, guildId)) return;
      const canManageHere = canManage(scope, guildId);
      const guild = client.guilds.cache.get(guildId);
      const history = require('../music/history');
      const achievements = require('../engagement/achievements');
      const totalsWeek = history.totals(guildId, 7);
      const topWeek = history.topTracks(guildId, 7, 1)[0] || null;
      const achStats = achievements.stats(guildId);
      const unlockedTotal = Object.values(achStats).reduce((a, b) => a + b, 0);
      socket.emit('overview', {
        guildId,
        canManage: canManageHere,
        guildName: guild?.name || '',
        members: guild?.memberCount ?? null,
        playsWeek: totalsWeek.plays,
        listenersWeek: totalsWeek.listeners,
        topTrack: topWeek ? { title: topWeek.title, author: topWeek.author, plays: topWeek.plays } : null,
        commandsUsed: usage.total(guildId).total,
        achievementsUnlocked: unlockedTotal,
        // server configuration — managers only
        disabledModules: canManageHere ? featureToggles.getDisabled(guildId).length : null,
        uptimeSec: Math.floor(process.uptime()),
        ping: Math.max(0, Math.round(client.ws.ping)),
      });
    });

    // ── config export / import ─────────────────────────────────────
    socket.on('exportConfig', (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'settings')) return;
      const guild = client.guilds.cache.get(guildId);
      socket.emit('configExport', {
        guildName: guild?.name || guildId,
        version: 1,
        exportedAt: new Date().toISOString(),
        config: require('../db').getAllConfig(guildId),
      });
    });

    socket.on('importConfig', ({ guildId, data } = {}) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'settings')) return;
      try {
        const cfg = data && typeof data === 'object' && data.config ? data.config : data;
        if (!cfg || typeof cfg !== 'object' || Array.isArray(cfg)) {
          return socket.emit('notice', { type: 'error', message: 'That doesn’t look like a Harmonix config file.' });
        }
        const { setConfig } = require('../db');
        let n = 0;
        for (const [k, v] of Object.entries(cfg)) { setConfig(guildId, k, v); n += 1; }
        socket.emit('notice', { type: 'success', message: `Imported ${n} settings. Re-check channel/role pickers — those IDs are per-server.` });
      } catch {
        socket.emit('notice', { type: 'error', message: 'Import failed — the file may be corrupted.' });
      }
    });

    // ── message / embed / reaction-role composer ───────────────────
    socket.on('composerSend', async ({ guildId, channelId, content, embed, mode, roles } = {}) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'settings')) return;
      const guild = client.guilds.cache.get(guildId);
      const channel = guild?.channels?.cache?.get(channelId);
      if (!channel || !channel.isTextBased?.()) {
        return socket.emit('notice', { type: 'error', message: 'Pick a valid text channel to post in.' });
      }
      const { EmbedBuilder } = require('discord.js');
      let embeds = [];
      if (embed && (embed.title || embed.description || embed.image || embed.author || embed.thumbnail || (embed.fields || []).length)) {
        const e = new EmbedBuilder();
        if (embed.title) e.setTitle(String(embed.title).slice(0, 256));
        if (embed.description) e.setDescription(String(embed.description).slice(0, 4096));
        const col = parseInt(String(embed.color || '').replace('#', ''), 16);
        if (!Number.isNaN(col)) e.setColor(col);
        if (embed.author) e.setAuthor({ name: String(embed.author).slice(0, 256) });
        if (embed.thumbnail) e.setThumbnail(String(embed.thumbnail));
        if (embed.image) e.setImage(String(embed.image));
        if (embed.footer) e.setFooter({ text: String(embed.footer).slice(0, 2048) });
        for (const f of (Array.isArray(embed.fields) ? embed.fields : []).slice(0, 10)) {
          if (f && f.name && f.value) e.addFields({ name: String(f.name).slice(0, 256), value: String(f.value).slice(0, 1024), inline: !!f.inline });
        }
        embeds = [e];
      }
      const text = content ? String(content).slice(0, 2000) : undefined;
      try {
        if (mode === 'reactionrole' && Array.isArray(roles) && roles.some((r) => r.roleId)) {
          const rr = require('../server/reactionRoles');
          // A panel needs visible content — fall back to a default prompt.
          if (!text && !embeds.length) {
            const e = new EmbedBuilder().setTitle('Choose your roles').setDescription('Click a button below to toggle a role.');
            embeds = [e];
          }
          const msg = await channel.send({ content: text, embeds });
          rr.createPanel(guildId, channel.id, msg.id);
          for (const r of roles.filter((x) => x.roleId).slice(0, rr.MAX_BUTTONS)) {
            rr.addButton(msg.id, { roleId: r.roleId, label: r.label || undefined, emoji: r.emoji || undefined });
          }
          await msg.edit({ components: rr.buildComponents(rr.getButtons(msg.id)) }).catch(() => {});
          socket.emit('notice', { type: 'success', message: `Reaction-role panel posted in #${channel.name}.` });
        } else {
          if (!text && !embeds.length) return socket.emit('notice', { type: 'error', message: 'Add a message or embed content first.' });
          await channel.send({ content: text, embeds });
          socket.emit('notice', { type: 'success', message: `Sent to #${channel.name}.` });
        }
      } catch {
        socket.emit('notice', { type: 'error', message: `Couldn’t post in #${channel.name} — check my permissions there.` });
      }
    });

    // ── config pages (welcome / goodbye / autorole / starboard) ─────
    function configPayload(guildId) {
      const guild = client.guilds.cache.get(guildId);
      const channels = guild
        ? [...guild.channels.cache.values()].filter((ch) => ch.type === ChannelType.GuildText).map((ch) => ({ id: ch.id, name: ch.name })).sort((a, b) => a.name.localeCompare(b.name))
        : [];
      const me = guild ? guild.members.me : null;
      const botTop = me ? me.roles.highest.position : 0;
      const roles = guild
        ? [...guild.roles.cache.values()].filter((r) => r.id !== guild.id && !r.managed).sort((a, b) => b.position - a.position).map((r) => ({ id: r.id, name: r.name, assignable: r.position < botTop }))
        : [];
      return {
        guildId, channels, roles,
        welcome: greetings.getGreeting(guildId, 'welcome'),
        goodbye: greetings.getGreeting(guildId, 'goodbye'),
        autorole: greetings.getAutorole(guildId),
        starboard: starboard.getSettings(guildId),
      };
    }
    socket.on('getConfig', (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'config')) return;
      socket.emit('config', configPayload(guildId));
    });
    socket.on('saveConfig', (payload = {}) => {
      const { guildId, section, data } = payload;
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'config') || !data) return;
      try {
        if (section === 'welcome' || section === 'goodbye') {
          greetings.setGreeting(guildId, section, { enabled: !!data.enabled, channelId: data.channelId || null, message: data.message || null });
        } else if (section === 'autorole') {
          const roleId = data.roleId || null;
          if (data.enabled && !roleId) {
            return socket.emit('notice', { type: 'error', message: 'Pick a role before enabling autorole.' });
          }
          if (data.enabled && roleId) {
            const guild = client.guilds.cache.get(guildId);
            const role = guild && guild.roles.cache.get(roleId);
            const me = guild && guild.members.me;
            if (!role) return socket.emit('notice', { type: 'error', message: 'That role no longer exists.' });
            if (role.managed || role.id === guildId) return socket.emit('notice', { type: 'error', message: 'That role can’t be assigned manually.' });
            if (me && role.position >= me.roles.highest.position) {
              return socket.emit('notice', { type: 'error', message: `I can’t assign “${role.name}” — it’s above my highest role. Move my role above it in Server Settings → Roles, then try again.` });
            }
          }
          greetings.setAutorole(guildId, { enabled: !!data.enabled, roleId });
        } else if (section === 'starboard') {
          starboard.saveSettings(guildId, { enabled: !!data.enabled, channelId: data.channelId || null, threshold: Math.max(1, Math.min(50, Number(data.threshold) || 3)), emoji: data.emoji || '⭐' });
        } else return;
        socket.emit('saved');
      } catch (err) {
        console.error('[dashboard] saveConfig error:', err.message);
        socket.emit('notice', { type: 'error', message: 'Failed to save configuration.' });
      }
    });

    // ── live log feed ──────────────────────────────────────────────
    let logGuild = null;
    const onLogEntry = (gid, entry) => { if (gid === logGuild) socket.emit('logentry', entry); };
    logFeed.events.on('entry', onLogEntry);
    socket.on('getLogFeed', (guildId) => {
      const scope = socketScope(socket);
      if (!scope || !hasCap(scope, guildId, 'log')) return;
      logGuild = guildId;
      socket.emit('logfeed', { guildId, entries: logFeed.recent(guildId) });
    });
    socket.on('disconnect', () => logFeed.events.off('entry', onLogEntry));
  });

  // Push fresh state to a guild's room whenever anything changes.
  bus.on('stateChange', (guildId) => {
    io.to(`guild:${guildId}`).emit('state', controller.getState(client, guildId));
  });

  // Smooth progress bar: tick subscribed, actively-playing guilds every second.
  setInterval(() => {
    const active = new Set(subscription.values());
    for (const guildId of active) {
      const room = io.sockets.adapter.rooms.get(`guild:${guildId}`);
      if (!room || room.size === 0) continue;
      const state = controller.getState(client, guildId);
      if (state.playing && !state.paused) io.to(`guild:${guildId}`).emit('state', state);
    }
  }, 1000);

  server.listen(config.dashboard.port, () => {
    const pub = config.dashboard.publicUrl;
    console.log(`[dashboard] running at http://localhost:${config.dashboard.port}${pub ? ` (public: ${pub})` : ''}`);
  });

  return server;
}

module.exports = { startDashboard };
