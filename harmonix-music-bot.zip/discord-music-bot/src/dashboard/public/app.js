'use strict';

/* Harmonix dashboard client.
 * Talks to src/dashboard/server.js over Socket.IO.
 * Server protocol:
 *   <- hello {requiresPassword}
 *   <- authResult {ok}
 *   <- guilds [{id,name,icon}]
 *   <- state  {full snapshot from controller.getState}
 *   <- notice {type,message}
 *   -> auth <password>
 *   -> getGuilds
 *   -> subscribe <guildId>
 *   -> control {guildId, action, value}
 *   -> play {guildId, query}
 */

const socket = io();

// ---- element refs -------------------------------------------------------
const $ = (id) => document.getElementById(id);
const lock = $('lock');
const lockInput = $('lockInput');
const lockBtn = $('lockBtn');
const lockErr = $('lockErr');
const oauthBox = $('oauthBox');
const passwordBox = $('passwordBox');
const userbox = $('userbox');
const userAvatar = $('userAvatar');
const userName = $('userName');
const app = $('app');

const guildSelect = $('guildSelect');
const guildIcon = $('guildIcon');

const main = $('main');
const disc = $('disc');

const elArt = $('art');
const elEyebrow = $('eyebrow');
const elTitle = $('title');
const elSub = $('sub');
const elBadges = $('badges');
const elCur = $('cur');
const elDur = $('dur');
const elBar = $('bar');
const elFill = $('fill');

const btnPrev = $('prev');
const btnPlay = $('play');
// Flat monochrome icons — emoji glyphs rendered in colour and clashed.
const ICO = {
  play: 'M8 5v14l11-7z',
  pause: 'M6 19h4V5H6v14zm8-14v14h4V5h-4z',
};
// Sources arrive lowercase from Lavalink ("youtube", "soundcloud"); show them
// the way the platforms actually spell themselves.
const SOURCE_NAMES = {
  youtube: 'YouTube', youtubemusic: 'YouTube Music', ytmusic: 'YouTube Music',
  soundcloud: 'SoundCloud', spotify: 'Spotify', applemusic: 'Apple Music',
  deezer: 'Deezer', bandcamp: 'Bandcamp', twitch: 'Twitch', vimeo: 'Vimeo',
  http: 'Direct link', local: 'Local file', nico: 'Niconico', flowerytts: 'Flowery TTS',
};
function titleCase(s) {
  return String(s || '').replace(/\b\w/g, (ch) => ch.toUpperCase());
}
function prettySource(src) {
  const key = String(src || '').toLowerCase().replace(/[^a-z]/g, '');
  return SOURCE_NAMES[key] || titleCase(String(src || '').replace(/[_-]+/g, ' '));
}

function setPlayIcon(paused) {
  const path = btnPlay.querySelector('path');
  if (path) path.setAttribute('d', paused ? ICO.play : ICO.pause);
}
const btnSkip = $('skip');
const btnStop = $('stop');
const btnShuffle = $('shuffle');
const btnLoop = $('loop');
const vol = $('vol');
const volNum = $('volNum');

const searchInput = $('searchInput');
const searchBtn = $('searchBtn');

const btnAutoplay = $('autoplay');
const bt247 = $('t247');
const btnClear = $('clear');
const btnDisconnect = $('disconnect');

const queueEl = $('queue');
const notice = $('notice');

// manager refs
const hamburger = $('hamburger');
const hamMenu = $('hamMenu');
const managerEl = $('manager');
const mgrCommandsPanel = $('mgrCommandsPanel');
const mgrSettingsPanel = $('mgrSettingsPanel');
const mgrAutodelete = $('mgrAutodelete');
const mgrTrivia = $('mgrTrivia');
const mgrPrefix = $('mgrPrefix');
const mgrMusicLock = $('mgrMusicLock');
const mgrDjOnly = $('mgrDjOnly');
const mgrMaxQueue = $('mgrMaxQueue');
const mgrMaxSong = $('mgrMaxSong');
const mgrMaxPerUser = $('mgrMaxPerUser');
const mgrReplyMode = $('mgrReplyMode');
const mgrGateDisabled = $('mgrGateDisabled');
const mgrGateLevel = $('mgrGateLevel');
const mgrGateChannel = $('mgrGateChannel');
const mgrLevelupDM = $('mgrLevelupDM');
const mgrXpIgnore = $('mgrXpIgnore');
const mgrLogIgnore = $('mgrLogIgnore');
const mgrVoiceXp = $('mgrVoiceXp');
const mgrFade = $('mgrFade');
const mgrCounting = $('mgrCounting');
const homeStats = $('homeStats');
const mgrModules = $('mgrModules');
const mgrHealth = $('mgrHealth');
const mgrChMusic = $('mgrChMusic');
const mgrChLogging = $('mgrChLogging');
const mgrChModlog = $('mgrChModlog');
const mgrChTickets = $('mgrChTickets');
const mgrChSuggest = $('mgrChSuggest');
const mgrChBirthday = $('mgrChBirthday');
const mgrAchMode = $('mgrAchMode');
const mgrAchChannel = $('mgrAchChannel');
const mgrCommands = $('mgrCommands');
const mgrFilter = $('mgrFilter');
const mgrExpandAll = $('mgrExpandAll');
const mgrCollapseAll = $('mgrCollapseAll');
const mgrSaveCmds = $('mgrSaveCmds');
const mgrSaveSettings = $('mgrSaveSettings');
let currentView = 'music'; // 'music' | 'commands' | 'settings'
let managerData = null;
let gateModel = {}; // path -> { enabled, mode:''|'allow'|'deny', channels:Set, level:0|1|2 }
let powerModel = {}; // roleId -> 0|1|2

// ---- state --------------------------------------------------------------
let currentGuild = null;
// A dashboard link from Discord carries ?guild=<id>; otherwise fall back to the
// last server this browser used, then the first one available.
const LINKED_GUILD = new URLSearchParams(location.search).get('guild');
const REMEMBERED_GUILD = (() => { try { return localStorage.getItem('lastGuild'); } catch { return null; } })();
let latest = null;
let volumeDragging = false;

const PLACEHOLDER_ART =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Crect width='220' height='220' fill='%231a1722'/%3E%3C/svg%3E";

// If artwork fails to load (404, hotlink-protected, etc.), fall back to the
// placeholder instead of showing the browser's broken-image icon.
elArt.addEventListener('error', () => {
  if (elArt.src !== PLACEHOLDER_ART) elArt.src = PLACEHOLDER_ART;
});

// ---- helpers ------------------------------------------------------------
function msToTime(ms) {
  if (!ms || ms < 0) ms = 0;
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

let noticeTimer = null;
function showNotice(type, message) {
  notice.textContent = message;
  notice.className = `show ${type === 'error' ? 'error' : 'success'}`;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => { notice.className = ''; }, 3200);
}

function emitControl(action, value) {
  if (!currentGuild) return;
  socket.emit('control', { guildId: currentGuild, action, value });
}

// ---- render -------------------------------------------------------------
function render(state) {
  if (pickerOpen) return; // the picker owns the screen until a server is chosen
  latest = state;
  if (!state) return;
  if (currentView !== 'music') return; // a manager view owns the screen; just keep latest fresh

  if (!state.connected) {
    main.style.display = 'none';
    disc.style.display = '';
    return;
  }
  main.style.display = '';
  disc.style.display = 'none';

  const c = state.current;
  if (c) {
    elArt.src = c.artworkUrl || PLACEHOLDER_ART;
    elEyebrow.textContent = state.paused ? 'Paused' : 'Now Playing';
    elTitle.textContent = c.title;
    elSub.textContent = c.author;
    setPlayIcon(state.paused);

    if (c.isStream) {
      elCur.textContent = 'LIVE';
      elDur.textContent = '∞';
      elFill.style.width = '100%';
    } else {
      elCur.textContent = msToTime(state.position);
      elDur.textContent = msToTime(c.duration);
      const pct = c.duration ? Math.min(100, (state.position / c.duration) * 100) : 0;
      elFill.style.width = `${pct}%`;
    }
  } else {
    elArt.src = PLACEHOLDER_ART;
    elEyebrow.textContent = 'Idle';
    elTitle.textContent = 'Nothing playing';
    elSub.textContent = 'Queue a track in Discord or search below.';
    setPlayIcon(true);
    elCur.textContent = '0:00';
    elDur.textContent = '0:00';
    elFill.style.width = '0%';
  }

  // badges
  const badges = [];
  if (c) badges.push(`<span class="badge">${escapeHtml(prettySource(c.sourceName))}</span>`);
  if (state.repeatMode && state.repeatMode !== 'off') {
    badges.push(`<span class="badge">🔁 ${escapeHtml(titleCase(state.repeatMode))}</span>`);
  }
  if (state.autoplay) badges.push('<span class="badge on">Autoplay</span>');
  if (state.twentyFourSeven) badges.push('<span class="badge on">🕒 24/7</span>');
  if (c && c.requester) badges.push(`<span class="badge">Requested by ${escapeHtml(c.requester.username)}</span>`);
  elBadges.innerHTML = badges.join('');

  // toggle button active states
  btnAutoplay.classList.toggle('on', !!state.autoplay);
  bt247.classList.toggle('on', !!state.twentyFourSeven);
  btnLoop.classList.toggle('active', state.repeatMode && state.repeatMode !== 'off');

  // volume (don't fight the user mid-drag)
  if (!volumeDragging) {
    vol.value = state.volume;
    if (document.activeElement !== volNum) volNum.value = state.volume;
  }

  // queue
  if (!state.queue || state.queue.length === 0) {
    queueEl.innerHTML = '<div class="empty">Queue is empty. Add something below 👇</div>';
  } else {
    queueEl.innerHTML = state.queue.map((t, i) => `
      <div class="q-item" draggable="true" data-i="${i}">
        <div class="q-idx">${i + 1}</div>
        <img class="q-art" src="${escapeHtml(t.artworkUrl || PLACEHOLDER_ART)}" alt="" onerror="this.onerror=null;this.style.visibility='hidden'" />
        <div class="q-info">
          <div class="q-title">${escapeHtml(t.title)}</div>
          <div class="q-artist">${escapeHtml(t.author)} · ${escapeHtml(prettySource(t.sourceName))}</div>
        </div>
        <div class="q-dur">${t.isStream ? 'LIVE' : msToTime(t.duration)}</div>
        <button class="q-rm" data-i="${i}" title="Remove">✕</button>
      </div>
    `).join('');
  }
}

// ---- guild selection ----------------------------------------------------
const MANAGE_VIEWS = ['commands', 'settings', 'cases', 'levels', 'stats', 'achievements', 'composer', 'config', 'log'];
// Each management view requires the matching capability from the server.
const VIEW_CAP = { commands: 'commands', settings: 'settings', cases: 'cases', levels: 'levels', stats: 'stats', achievements: 'achievements', composer: 'settings', config: 'config', log: 'log' };
let guildCaps = {};
let allGuilds = []; // id -> [caps]
let currentCaps = [];
let currentCanManage = true;

function canView(view) {
  if (view === 'music') return true;
  const cap = VIEW_CAP[view];
  return !cap || currentCaps.includes(cap);
}

function applyPermissionView() {
  // Show each menu item only if the user holds its capability in this guild.
  hamMenu.querySelectorAll('button').forEach((b) => {
    b.style.display = canView(b.dataset.view) ? '' : 'none';
  });
  // Hide any group label whose buttons are all hidden.
  hamMenu.querySelectorAll('.nav-label').forEach((label) => {
    let el = label.nextElementSibling;
    let anyVisible = false;
    while (el && !el.classList.contains('nav-label')) {
      if (el.tagName === 'BUTTON' && el.style.display !== 'none') anyVisible = true;
      el = el.nextElementSibling;
    }
    label.style.display = anyVisible ? '' : 'none';
  });
  hamMenu.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.view === currentView));
  // If the user is on a view they can't access, send them somewhere they can.
  if (!canView(currentView)) {
    const fallback = MANAGE_VIEWS.find((v) => canView(v)) || 'music';
    setView(currentCaps.length ? fallback : 'music');
  }
}

function populateGuilds(guilds) {
  if (!guilds || guilds.length === 0) {
    guildSelect.innerHTML = '<option>No servers</option>';
    return;
  }
  allGuilds = guilds;
  guildCaps = {};
  for (const g of guilds) guildCaps[g.id] = Array.isArray(g.caps) ? g.caps : [];
  guildSelect.innerHTML = guilds
    .map((g) => `<option value="${escapeHtml(g.id)}">${escapeHtml(g.name)}${g.canManage ? '' : ' (member)'}</option>`)
    .join('');

  // linked guild (?guild=) wins, then the last one used here, then current, then first
  const ids = guilds.map((g) => g.id);
  if (!currentGuild || !ids.includes(currentGuild)) {
    currentGuild =
      (LINKED_GUILD && ids.includes(LINKED_GUILD) && LINKED_GUILD) ||
      (REMEMBERED_GUILD && ids.includes(REMEMBERED_GUILD) && REMEMBERED_GUILD) ||
      guilds[0].id;
  }
  guildSelect.value = currentGuild;
  rememberGuild(currentGuild);
  currentCaps = guildCaps[currentGuild] || [];
  currentCanManage = currentCaps.length > 0;
  applyPermissionView();

  setGuildIcon(currentGuild);

  // A ?guild= link (from /help or the control panel) goes straight in.
  // Otherwise ask which server they're here for — unless there's only one,
  // in which case there's nothing to choose.
  const linked = LINKED_GUILD && ids.includes(LINKED_GUILD);
  if (!linked && guilds.length > 1) {
    showGuildPicker();
    return;
  }

  socket.emit('subscribe', currentGuild);
  refreshHome();
}

/** Keep the topbar icon in step with the selected server. */
function setGuildIcon(id) {
  const sel = allGuilds.find((g) => g.id === id);
  guildIcon.src = (sel && sel.icon) || PLACEHOLDER_ART;
  guildIcon.style.visibility = sel && sel.icon ? 'visible' : 'hidden';
}

// ── server picker ────────────────────────────────────────────────
const guildPicker = $('guildPicker');
const pickerList = $('pickerList');
let pickerOpen = false;

/** Arriving without a ?guild= link → make the person choose a server first. */
function showGuildPicker() {
  if (!guildPicker) return;
  pickerOpen = true;
  document.body.classList.add('picking');
  guildPicker.style.display = '';
  managerEl.style.display = 'none';
  main.style.display = 'none';
  disc.style.display = 'none';
  if (homeStats) homeStats.style.display = 'none';
  if (mini) mini.style.display = 'none';

  pickerList.innerHTML = allGuilds.map((g) => `
    <button class="gp-item" data-gid="${escapeHtml(g.id)}">
      ${g.icon
        ? `<img class="gp-icon" src="${escapeHtml(g.icon)}" alt="" />`
        : `<span class="gp-icon gp-icon-fallback">${escapeHtml((g.name || '?').slice(0, 1).toUpperCase())}</span>`}
      <span class="gp-meta">
        <span class="gp-name">${escapeHtml(g.name)}</span>
        <span class="gp-role">${g.canManage ? 'Manage this server' : 'Member'}</span>
      </span>
      <span class="gp-go">→</span>
    </button>`).join('') || '<div class="empty">Harmonix isn’t in any servers you’re in yet.</div>';
}

/** Leave the picker and open the chosen server's dashboard. */
function enterGuild(id) {
  pickerOpen = false;
  document.body.classList.remove('picking');
  if (guildPicker) guildPicker.style.display = 'none';
  currentGuild = id;
  guildSelect.value = id;
  setGuildIcon(id);
  rememberGuild(id);
  currentCaps = guildCaps[id] || [];
  currentCanManage = currentCaps.length > 0;
  applyPermissionView();
  socket.emit('subscribe', id);
  setView('music');
}

if (pickerList) {
  pickerList.addEventListener('click', (e) => {
    const btn = e.target.closest('.gp-item');
    if (btn) enterGuild(btn.dataset.gid);
  });
}

function rememberGuild(id) {
  try { localStorage.setItem('lastGuild', id); } catch { /* private mode */ }
}

// Show/refresh the Overview stats that sit above the console on the home view.
function refreshHome() {
  if (!homeStats) return;
  const show = currentView === 'music';
  homeStats.style.display = show ? '' : 'none';
  if (show && currentGuild) socket.emit('getOverview', currentGuild);
}

guildSelect.addEventListener('change', () => {
  currentGuild = guildSelect.value;
  setGuildIcon(currentGuild); // was only set on first load, so it never changed
  rememberGuild(currentGuild);
  currentCaps = guildCaps[currentGuild] || [];
  currentCanManage = currentCaps.length > 0;
  applyPermissionView();
  socket.emit('subscribe', currentGuild);
  if (currentView !== 'music' && canView(currentView)) refreshView();
  refreshHome();
});

// ---- socket lifecycle ---------------------------------------------------
let authMode = 'local';

function showApp() {
  lock.style.display = 'none';
  app.style.display = '';
  hamburger.style.display = '';
  socket.emit('getGuilds');
}

function showLogin(mode) {
  app.style.display = 'none';
  lock.style.display = '';
  oauthBox.style.display = mode === 'oauth' ? '' : 'none';
  passwordBox.style.display = mode === 'oauth' ? 'none' : '';
  if (mode !== 'oauth') lockInput.focus();
}

async function loadMe() {
  try {
    const me = await fetch('/api/me', { credentials: 'same-origin' }).then((r) =>
      r.ok ? r.json() : null
    );
    if (me && me.user) {
      userbox.style.display = '';
      userName.textContent = me.user.username;
      if (me.user.avatar) {
        userAvatar.src = me.user.avatar;
        userAvatar.style.display = '';
      } else {
        userAvatar.style.display = 'none';
      }
    }
  } catch { /* non-fatal */ }
}

socket.on('hello', ({ authMode: mode, requiresPassword, authed }) => {
  authMode = mode || 'local';
  if (authMode === 'oauth') {
    if (authed) { showApp(); loadMe(); }
    else showLogin('oauth');
  } else if (requiresPassword && !authed) {
    showLogin('local');
  } else {
    showApp();
  }
});

socket.on('authResult', ({ ok }) => {
  if (ok) {
    showApp();
  } else if (authMode === 'oauth') {
    showLogin('oauth');
  } else {
    lockErr.textContent = 'Incorrect password.';
    lockInput.value = '';
    lockInput.focus();
  }
});

socket.on('guilds', populateGuilds);
socket.on('state', (state) => {
  if (!currentGuild || state.guildId === currentGuild) { render(state); updateMini(state); }
});
socket.on('notice', ({ type, message }) => showNotice(type, message));

// keep guild list fresh on reconnect
socket.on('connect', () => {
  if (app.style.display !== 'none') socket.emit('getGuilds');
});

// ---- lock screen --------------------------------------------------------
function submitPassword() {
  socket.emit('auth', lockInput.value);
}
lockBtn.addEventListener('click', submitPassword);
lockInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') submitPassword(); });

// ---- transport wiring ---------------------------------------------------
btnPrev.addEventListener('click', () => emitControl('previous'));
btnPlay.addEventListener('click', () => emitControl('togglePause'));
btnSkip.addEventListener('click', () => emitControl('skip'));
btnStop.addEventListener('click', () => emitControl('stop'));
btnShuffle.addEventListener('click', () => emitControl('shuffle'));
btnLoop.addEventListener('click', () => emitControl('loop'));
btnAutoplay.addEventListener('click', () => emitControl('autoplay'));
bt247.addEventListener('click', () => emitControl('247'));
btnClear.addEventListener('click', () => emitControl('clear'));
btnDisconnect.addEventListener('click', () => emitControl('disconnect'));

// volume: slider and typed input stay in sync, either can set it
const VOL_MAX = 150;
const clampVol = (n) => Math.min(VOL_MAX, Math.max(0, Math.round(Number(n) || 0)));

vol.addEventListener('input', () => {
  volumeDragging = true;
  volNum.value = vol.value;
});
vol.addEventListener('change', () => {
  applyVolume(vol.value);
});

function applyVolume(raw) {
  const v = clampVol(raw);
  vol.value = v;
  volNum.value = v;
  emitControl('volume', v);
  volumeDragging = true;
  setTimeout(() => { volumeDragging = false; }, 300);
}

// clicking anywhere in the pill (including the % sign) starts editing
const volPill = volNum.closest('.vol-num');
if (volPill) volPill.addEventListener('click', () => volNum.focus());
volNum.addEventListener('focus', () => volNum.select()); // type straight over it
// arrow keys nudge the volume now that the native spinners are gone
volNum.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); volNum.blur(); return; }
  if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
    e.preventDefault();
    const step = e.shiftKey ? 10 : 1;
    applyVolume(clampVol(volNum.value) + (e.key === 'ArrowUp' ? step : -step));
  }
});
volNum.addEventListener('change', () => applyVolume(volNum.value));
volNum.addEventListener('blur', () => applyVolume(volNum.value));

// seek by clicking the progress bar
elBar.addEventListener('click', (e) => {
  if (!latest || !latest.current || latest.current.isStream) return;
  const rect = elBar.getBoundingClientRect();
  const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
  emitControl('seek', Math.floor(ratio * latest.current.duration));
});

// queue remove (event delegation)
queueEl.addEventListener('click', (e) => {
  const btn = e.target.closest('.q-rm');
  if (!btn) return;
  emitControl('remove', Number(btn.dataset.i));
});

// queue drag-to-reorder
let dragFrom = null;
queueEl.addEventListener('dragstart', (e) => {
  const item = e.target.closest('.q-item');
  if (!item) return;
  dragFrom = Number(item.dataset.i);
  e.dataTransfer.effectAllowed = 'move';
  item.classList.add('dragging');
});
queueEl.addEventListener('dragend', () => {
  dragFrom = null;
  queueEl.querySelectorAll('.q-item').forEach((el) => el.classList.remove('dragging', 'drop-target'));
});
queueEl.addEventListener('dragover', (e) => {
  e.preventDefault();
  const item = e.target.closest('.q-item');
  queueEl.querySelectorAll('.q-item.drop-target').forEach((el) => el.classList.remove('drop-target'));
  if (item) item.classList.add('drop-target');
});
queueEl.addEventListener('drop', (e) => {
  e.preventDefault();
  const item = e.target.closest('.q-item');
  if (!item || dragFrom == null) return;
  const to = Number(item.dataset.i);
  if (to !== dragFrom) emitControl('move', { from: dragFrom, to });
  dragFrom = null;
});

// search / add
function doSearch() {
  const query = searchInput.value.trim();
  if (!query || !currentGuild) return;
  socket.emit('play', { guildId: currentGuild, query });
  searchInput.value = '';
}
searchBtn.addEventListener('click', doSearch);
searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSearch(); });

// ---- server manager -----------------------------------------------------
const PANELS = { commands: 'mgrCommandsPanel', settings: 'mgrSettingsPanel', cases: 'mgrCasesPanel', levels: 'mgrLevelsPanel', stats: 'mgrStatsPanel', achievements: 'mgrAchievementsPanel', composer: 'mgrComposerPanel', config: 'mgrConfigPanel', log: 'mgrLogPanel' };

function refreshView() {
  if (!currentGuild) return;
  if (currentView === 'commands' || currentView === 'settings') socket.emit('getManager', currentGuild);
  else if (currentView === 'cases') socket.emit('getCases', currentGuild);
  else if (currentView === 'levels') socket.emit('getLevels', currentGuild);
  else if (currentView === 'stats') socket.emit('getStats', currentGuild);
  else if (currentView === 'achievements') socket.emit('getAchievements', currentGuild);
  else if (currentView === 'composer') socket.emit('getManager', currentGuild);
  else if (currentView === 'config') socket.emit('getConfig', currentGuild);
  else if (currentView === 'log') socket.emit('getLogFeed', currentGuild);
}

function setView(view) {
  if (pickerOpen) return; // still choosing a server
  if (!canView(view)) view = 'music'; // refuse views the user lacks permission for
  currentView = view;
  hamMenu.classList.remove('open'); // close the mobile drawer; desktop sidebar stays
  hamMenu.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
  if (view === 'music') {
    managerEl.style.display = 'none';
    // Overview = server stats + the music console on one page.
    refreshHome();
    render(latest); // restore the player
    return;
  }
  if (homeStats) homeStats.style.display = 'none';
  main.style.display = 'none';
  disc.style.display = 'none';
  managerEl.style.display = '';
  for (const [v, id] of Object.entries(PANELS)) {
    const el = $(id);
    if (el) el.style.display = v === view ? '' : 'none';
  }
  refreshView();
}

hamburger.addEventListener('click', (e) => {
  e.stopPropagation();
  hamMenu.classList.toggle('open');
});
hamMenu.querySelectorAll('button').forEach((b) => b.addEventListener('click', () => setView(b.dataset.view)));
document.addEventListener('click', (e) => {
  if (!hamMenu.contains(e.target) && e.target !== hamburger) hamMenu.classList.remove('open');
});

function renderManager(data) {
  managerData = data;
  startHealthPoll();

  // settings panel
  mgrAutodelete.value = data.autodelete || 0;
  mgrTrivia.innerHTML =
    `<option value="">— none —</option>` +
    data.channels.map((ch) => `<option value="${escapeHtml(ch.id)}">#${escapeHtml(ch.name)}</option>`).join('');
  mgrTrivia.value = data.triviaChannel || '';
  if (mgrPrefix) mgrPrefix.value = data.prefix || '!';
  if (mgrMusicLock) {
    const vcs = data.voiceChannels || [];
    mgrMusicLock.innerHTML = '<option value="">— not locked —</option>' + vcs.map((c) => `<option value="${escapeHtml(c.id)}">🔊 ${escapeHtml(c.name)}</option>`).join('');
    mgrMusicLock.value = data.musicChannel || '';
  }
  const ms = data.musicSettings || {};
  if (mgrDjOnly) mgrDjOnly.checked = !!ms.djOnly;
  if (mgrMaxQueue) mgrMaxQueue.value = ms.maxQueue || 0;
  if (mgrMaxSong) mgrMaxSong.value = ms.maxSongSec ? Math.round(ms.maxSongSec / 60) : 0;
  if (mgrMaxPerUser) mgrMaxPerUser.value = ms.maxPerUser || 0;
  if (mgrReplyMode) mgrReplyMode.value = data.replyMode || 'default';
  const gm = data.gateMessages || {};
  if (mgrGateDisabled) mgrGateDisabled.value = gm.disabled || '';
  if (mgrGateLevel) mgrGateLevel.value = gm.level || '';
  if (mgrGateChannel) mgrGateChannel.value = gm.channel || '';
  if (mgrLevelupDM) mgrLevelupDM.checked = !!data.levelupDM;
  if (mgrXpIgnore) {
    const ig = data.xpIgnore || [];
    mgrXpIgnore.innerHTML = (data.channels || []).map((c) => `<option value="${escapeHtml(c.id)}" ${ig.includes(c.id) ? 'selected' : ''}>#${escapeHtml(c.name)}</option>`).join('');
  }
  if (mgrVoiceXp) mgrVoiceXp.checked = !!data.voiceXp;
  if (mgrFade) mgrFade.value = ms.fadeSec || 0;
  if (mgrCounting) mgrCounting.innerHTML = '<option value="">— none —</option>' + (data.channels || []).map((c) => `<option value="${escapeHtml(c.id)}" ${data.countingChannel === c.id ? 'selected' : ''}>#${escapeHtml(c.name)}</option>`).join('');
  if (mgrModules) {
    const disabled = new Set(data.disabledModules || []);
    mgrModules.innerHTML = (data.modules || []).map((m) => `<label class="mod-toggle"><input type="checkbox" data-mod="${escapeHtml(m.key)}" ${disabled.has(m.key) ? '' : 'checked'} /> ${escapeHtml(m.label)}</label>`).join('');
  }
  // feature channels + achievement announce
  const chanOpts = (sel) => '<option value="">— none —</option>' + (data.channels || []).map((c) => `<option value="${escapeHtml(c.id)}" ${sel === c.id ? 'selected' : ''}>#${escapeHtml(c.name)}</option>`).join('');
  const fc = data.featureChannels || {};
  if (mgrChMusic) mgrChMusic.innerHTML = chanOpts(fc.music);
  if (mgrChLogging) mgrChLogging.innerHTML = chanOpts(fc.logging);
  if (mgrLogIgnore) {
    const li = data.logIgnored || [];
    mgrLogIgnore.innerHTML = (data.channels || []).map((c) => `<option value="${escapeHtml(c.id)}" ${li.includes(c.id) ? 'selected' : ''}>#${escapeHtml(c.name)}</option>`).join('');
  }
  if (mgrChModlog) mgrChModlog.innerHTML = chanOpts(fc.modlog);
  if (mgrChTickets) mgrChTickets.innerHTML = chanOpts(fc.tickets);
  if (mgrChSuggest) mgrChSuggest.innerHTML = chanOpts(fc.suggestions);
  if (mgrChBirthday) mgrChBirthday.innerHTML = chanOpts(fc.birthday);
  const aa = data.achAnnounce || { mode: 'channel', channelId: null };
  if (mgrAchMode) mgrAchMode.value = aa.mode || 'channel';
  if (mgrAchChannel) mgrAchChannel.innerHTML = chanOpts(aa.channelId);

  // build the editable model from stored rules (everything defaults to on, no limit)
  gateModel = {};
  for (const cmd of data.commands) {
    const r = data.gate[cmd.path] || {};
    gateModel[cmd.path] = { enabled: r.enabled !== false, mode: r.mode || '', channels: new Set(r.channels || []), level: r.level || 0, reply: ['public', 'ephemeral'].includes(r.reply) ? r.reply : '' };
  }

  // role power levels
  powerModel = {};
  const roles = data.roles || [];
  for (const r of roles) powerModel[r.id] = (data.powerRoles && data.powerRoles[r.id]) || 0;
  const mgrPower = $('mgrPower');
  if (mgrPower) {
    mgrPower.innerHTML = roles.length
      ? roles.map((r) => `<div class="prole" data-role="${escapeHtml(r.id)}">
          <span class="prole-name">${escapeHtml(r.name)}</span>
          <div class="lvl" data-act="plvl">
            ${[0, 1, 2].map((n) => `<button type="button" data-lvl="${n}" class="${powerModel[r.id] === n ? 'active' : ''}">${n}</button>`).join('')}
          </div>
        </div>`).join('')
      : '<div class="mgr-empty">No assignable roles found.</div>';
  }

  const chipRow = (path) =>
    data.channels.map((ch) => `<button type="button" class="chip" data-ch="${escapeHtml(ch.id)}">#${escapeHtml(ch.name)}</button>`).join('') ||
    '<span class="chips-empty">No text channels.</span>';

  // one command row (identical in both views; the full /path is always shown)
  const buildCmdRow = (cmd) => {
    const m = gateModel[cmd.path];
    return `<div class="cmd ${m.enabled ? '' : 'off'}" data-path="${escapeHtml(cmd.path)}">
        <div class="cmd-head">
          <button type="button" class="sw ${m.enabled ? 'on' : ''}" data-act="toggle" title="Enable / disable"><span></span></button>
          <div class="cmd-id">
            <code>/${escapeHtml(cmd.path)}</code>
            <span class="cmd-state"></span>
          </div>
          <div class="lvl" data-act="lvl" title="Minimum power level to use this command">
            ${[[0, 'Everyone'], [1, 'Trusted'], [2, 'Staff']].map(([n, label]) => `<button type="button" data-lvl="${n}" class="${m.level === n ? 'active' : ''}">${label}</button>`).join('')}
          </div>
          <button type="button" class="cmd-expand" data-act="expand" title="Where it works &amp; reply visibility">⚙<span class="cmd-expand-cx">✕</span></button>
        </div>
        <div class="cmd-detail">
          <div class="cmd-detail-row">
            <span class="cmd-detail-lbl">Where</span>
            <div class="seg" data-act="seg">
              <button type="button" data-mode="" class="${m.mode === '' ? 'active' : ''}">Everywhere</button>
              <button type="button" data-mode="allow" class="${m.mode === 'allow' ? 'active' : ''}">Only in…</button>
              <button type="button" data-mode="deny" class="${m.mode === 'deny' ? 'active' : ''}">Block in…</button>
            </div>
          </div>
          <div class="chips" ${m.mode ? '' : 'hidden'}>${chipRow(cmd.path)}</div>
          <div class="cmd-detail-row">
            <span class="cmd-detail-lbl">Reply</span>
            <div class="lvl reply-seg" data-act="reply" title="How this command replies">
              ${[['', 'Default'], ['public', '👁 Public'], ['ephemeral', '🔒 Private']].map(([v, label]) => `<button type="button" data-reply="${v}" class="${(m.reply || '') === v ? 'active' : ''}">${label}</button>`).join('')}
            </div>
          </div>
        </div>
      </div>`;
  };

  // collapsible categories grouped by top-level command
  const groups = {};
  for (const cmd of data.commands) {
    const top = cmd.path.split(' ')[0];
    (groups[top] = groups[top] || []).push(cmd);
  }
  let html = '';
  for (const [top, cmds] of Object.entries(groups)) {
    html += `<div class="cat" data-top="${escapeHtml(top)}">
      <button type="button" class="cat-head">
        <span class="caret">▸</span> <b>/${escapeHtml(top)}</b>
        <span class="cat-count">${cmds.length}</span>
        <span class="cat-sum"></span>
      </button>
      <div class="cat-tools">
        <span class="cat-tools-lbl">Set all:</span>
        <button type="button" data-bulk="enable" title="Enable every command here">On</button>
        <button type="button" data-bulk="disable" title="Disable every command here">Off</button>
        <span class="cat-tools-lbl">level</span>
        <button type="button" data-bulklvl="0">L0</button>
        <button type="button" data-bulklvl="1">L1</button>
        <button type="button" data-bulklvl="2">L2</button>
      </div>
      <div class="cat-body">${cmds.map(buildCmdRow).join('')}</div></div>`;
  }
  mgrCommands.innerHTML = html;

  // reflect channel selections + category summaries
  mgrCommands.querySelectorAll('.cmd').forEach((row) => { syncChips(row); refreshCmdSummary(row); });
  mgrCommands.querySelectorAll('.cat').forEach((cat) => updateCatSummary(cat));
  applyFilter();
  renderComposer();
  enhanceNumberInputs();
}

// Plain-English state line shown under each command name.
function cmdSummary(path) {
  const m = gateModel[path];
  if (!m.enabled) return 'Disabled — hidden from /help';
  const who = m.level === 2 ? 'Staff only' : m.level === 1 ? 'Trusted+' : 'Everyone';
  let where = 'everywhere';
  const n = m.channels ? m.channels.size : 0;
  if (m.mode === 'allow') where = n ? `only in ${n} channel${n === 1 ? '' : 's'}` : 'no channels chosen yet';
  else if (m.mode === 'deny') where = n ? `blocked in ${n} channel${n === 1 ? '' : 's'}` : 'everywhere';
  const reply = m.reply === 'public' ? ' · public reply' : m.reply === 'ephemeral' ? ' · private reply' : '';
  return `${who} · ${where}${reply}`;
}
function refreshCmdSummary(row) {
  const el = row.querySelector('.cmd-state');
  if (el) el.textContent = cmdSummary(row.dataset.path);
}

function syncChips(row) {
  const m = gateModel[row.dataset.path];
  row.querySelectorAll('.chip').forEach((chip) => chip.classList.toggle('selected', m.channels.has(chip.dataset.ch)));
}

function updateCatSummary(cat) {
  if (!cat) return; // flat view has no category wrappers
  let disabled = 0, restricted = 0, leveled = 0;
  cat.querySelectorAll('.cmd').forEach((row) => {
    const m = gateModel[row.dataset.path];
    if (!m.enabled) disabled += 1;
    else if (m.mode) restricted += 1;
    if (m.enabled && m.level) leveled += 1;
  });
  const bits = [];
  if (disabled) bits.push(`${disabled} off`);
  if (restricted) bits.push(`${restricted} limited`);
  if (leveled) bits.push(`${leveled} gated`);
  const sum = cat.querySelector('.cat-sum');
  sum.textContent = bits.join(' · ');
  sum.classList.toggle('has', bits.length > 0);
}

// one delegated handler for the whole command tree
mgrCommands.addEventListener('click', (e) => {
  const head = e.target.closest('.cat-head');
  if (head) { head.parentElement.classList.toggle('open'); return; }

  // Bulk: set every command in a category to a power level.
  const bulkLvl = e.target.closest('.cat-tools [data-bulklvl]');
  if (bulkLvl) {
    const cat = e.target.closest('.cat');
    const level = Number(bulkLvl.dataset.bulklvl);
    cat.querySelectorAll('.cmd').forEach((row) => {
      gateModel[row.dataset.path].level = level;
      row.querySelectorAll('.lvl[data-act="lvl"] button').forEach((b) => b.classList.toggle('active', Number(b.dataset.lvl) === level));
    });
    updateCatSummary(cat);
    scheduleSave();
    return;
  }
  // Bulk: enable/disable every command in a category.
  const bulkEn = e.target.closest('.cat-tools [data-bulk]');
  if (bulkEn) {
    const cat = e.target.closest('.cat');
    const on = bulkEn.dataset.bulk === 'enable';
    cat.querySelectorAll('.cmd').forEach((row) => {
      gateModel[row.dataset.path].enabled = on;
      row.classList.toggle('off', !on);
      const sw = row.querySelector('.sw[data-act="toggle"]');
      if (sw) sw.classList.toggle('on', on);
    });
    updateCatSummary(cat);
    scheduleSave();
    return;
  }

  const row = e.target.closest('.cmd');
  if (!row) return;
  const m = gateModel[row.dataset.path];

  // Toggle the advanced (where / reply) detail panel.
  const expandBtn = e.target.closest('.cmd-expand');
  if (expandBtn) { row.classList.toggle('expanded'); return; }

  const sw = e.target.closest('.sw');
  if (sw) {
    m.enabled = !m.enabled;
    sw.classList.toggle('on', m.enabled);
    row.classList.toggle('off', !m.enabled);
    refreshCmdSummary(row);
    updateCatSummary(row.closest('.cat'));
    scheduleSave();
    return;
  }
  const modeBtn = e.target.closest('.seg button');
  if (modeBtn) {
    m.mode = modeBtn.dataset.mode;
    row.querySelectorAll('.seg button').forEach((b) => b.classList.toggle('active', b === modeBtn));
    row.querySelector('.chips').hidden = !m.mode;
    refreshCmdSummary(row);
    updateCatSummary(row.closest('.cat'));
    scheduleSave();
    return;
  }
  const lvlBtn = e.target.closest('.lvl[data-act="lvl"] button');
  if (lvlBtn) {
    m.level = Number(lvlBtn.dataset.lvl) || 0;
    row.querySelectorAll('.lvl[data-act="lvl"] button').forEach((b) => b.classList.toggle('active', b === lvlBtn));
    refreshCmdSummary(row);
    updateCatSummary(row.closest('.cat'));
    scheduleSave();
    return;
  }
  const replyBtn = e.target.closest('.reply-seg[data-act="reply"] button');
  if (replyBtn) {
    m.reply = replyBtn.dataset.reply || '';
    row.querySelectorAll('.reply-seg[data-act="reply"] button').forEach((b) => b.classList.toggle('active', b === replyBtn));
    refreshCmdSummary(row);
    scheduleSave();
    return;
  }
  const chip = e.target.closest('.chip');
  if (chip) {
    const id = chip.dataset.ch;
    if (m.channels.has(id)) m.channels.delete(id); else m.channels.add(id);
    chip.classList.toggle('selected', m.channels.has(id));
    refreshCmdSummary(row);
    scheduleSave();
  }
});

function applyFilter() {
  const q = (mgrFilter.value || '').toLowerCase().trim();
  // filter individual rows (works in both flat and grouped views)
  mgrCommands.querySelectorAll('.cmd').forEach((row) => {
    row.style.display = (!q || row.dataset.path.toLowerCase().includes(q)) ? '' : 'none';
  });
  // grouped view: hide empty categories, auto-expand while searching
  mgrCommands.querySelectorAll('.cat').forEach((cat) => {
    const anyVisible = [...cat.querySelectorAll('.cmd')].some((r) => r.style.display !== 'none');
    cat.style.display = anyVisible ? '' : 'none';
    if (q && anyVisible) cat.classList.add('open');
  });
}
mgrFilter.addEventListener('input', applyFilter);
mgrExpandAll.addEventListener('click', () => mgrCommands.querySelectorAll('.cat').forEach((c) => c.classList.add('open')));
mgrCollapseAll.addEventListener('click', () => mgrCommands.querySelectorAll('.cat').forEach((c) => c.classList.remove('open')));


socket.on('manager', renderManager);

socket.on('achievements', (data) => {
  const board = $('mgrAchBoard');
  const grid = $('mgrAchGrid');
  if (board) {
    if (!data.board.length) {
      board.innerHTML = '<div class="empty">No achievements unlocked yet.</div>';
    } else {
      const medal = (i) => ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;
      board.innerHTML = data.board.map((u, i) => `
        <div class="ach-row">
          <span class="ach-rank">${medal(i)}</span>
          ${u.avatar ? `<img class="ach-av" src="${escapeHtml(u.avatar)}" alt="" />` : '<span class="ach-av"></span>'}
          <span class="ach-name" title="${escapeHtml(u.userId)}">${escapeHtml(u.name)}${u.left ? ' <span class="lvl-left">(left)</span>' : ''}</span>
          <span class="ach-count">${u.count}/${data.total}</span>
        </div>`).join('');
    }
  }
  if (grid) {
    const groups = {};
    for (const d of data.defs) { (groups[d.group || 'Other'] ||= []).push(d); }
    grid.innerHTML = Object.entries(groups).map(([name, defs]) => {
      const badges = defs.map((d) => {
        const n = data.counts[d.key] || 0;
        return `<div class="ach-badge ${n ? '' : 'locked'}"><span class="ach-emoji">${d.emoji}</span><div class="ach-meta"><div class="ach-bname">${escapeHtml(d.name)}</div><div class="ach-bdesc">${escapeHtml(d.desc)}</div></div><span class="ach-have">${n} ${n === 1 ? 'member' : 'members'}</span></div>`;
      }).join('');
      return `<div class="ach-group-title">${escapeHtml(name)}</div>${badges}`;
    }).join('');
  }
});

function fmtUptime(sec) {
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
  return [d && `${d}d`, h && `${h}h`, `${m}m`].filter(Boolean).join(' ');
}
socket.on('health', (h) => {
  if (!mgrHealth) return;
  const nodes = (h.nodes || []).map((n) => `${n.connected ? '🟢' : '🔴'} ${escapeHtml(n.id)}`).join(' ') || '🔴 no nodes';
  mgrHealth.innerHTML = [
    `⏱️ ${fmtUptime(h.uptimeSec)}`, `📡 ${h.ping}ms`, `🧠 ${h.memMb}MB`,
    `🏠 ${h.guilds} servers`, `🎧 ${h.playing}/${h.players} playing`, nodes,
  ].map((s) => `<span class="health-pill">${s}</span>`).join('');
});
let healthTimer = null;
function startHealthPoll() {
  const tick = () => { if (mgrHealth && mgrHealth.offsetParent !== null) socket.emit('getHealth'); };
  tick();
  if (!healthTimer) healthTimer = setInterval(tick, 6000);
}

// ── composer: embed / message / reaction-role builder ─────────────
const cmp = {
  channel: $('cmpChannel'), mode: $('cmpMode'), content: $('cmpContent'),
  title: $('cmpTitle'), desc: $('cmpDesc'), color: $('cmpColor'), author: $('cmpAuthor'),
  image: $('cmpImage'), thumb: $('cmpThumb'), footer: $('cmpFooter'),
  rolesWrap: $('cmpRolesWrap'), roles: $('cmpRoles'), addRole: $('cmpAddRole'), send: $('cmpSend'),
};
const cmpChanOpts = (sel) => (managerData && managerData.channels || []).map((c) => `<option value="${escapeHtml(c.id)}" ${sel === c.id ? 'selected' : ''}>#${escapeHtml(c.name)}</option>`).join('');
const cmpRoleOpts = (sel) => '<option value="">— pick a role —</option>' + (managerData && managerData.roles || []).map((r) => `<option value="${escapeHtml(r.id)}" ${sel === r.id ? 'selected' : ''}>${escapeHtml(r.name)}</option>`).join('');

function renderComposer() {
  if (!cmp.channel) return;
  const cur = cmp.channel.value;
  cmp.channel.innerHTML = cmpChanOpts(cur);
  cmp.roles.querySelectorAll('select.cmp-role-sel').forEach((s) => { const v = s.value; s.innerHTML = cmpRoleOpts(v); });
  updateComposerPreview();
}
function setPv(id, text) { const el = $(id); if (!el) return; el.textContent = text || ''; el.style.display = text ? '' : 'none'; }
function updateComposerPreview() {
  if (!cmp.title) return;
  const pc = $('cmpPreviewContent'); if (pc) pc.textContent = cmp.content.value || '';
  const embed = $('cmpPreview');
  const hasEmbed = cmp.title.value || cmp.desc.value || cmp.image.value || cmp.author.value || cmp.thumb.value || cmp.footer.value;
  embed.style.display = hasEmbed ? '' : 'none';
  embed.querySelector('.cmp-embed-bar').style.background = cmp.color.value || 'var(--accent)';
  setPv('cmpPvAuthor', cmp.author.value); setPv('cmpPvTitle', cmp.title.value); setPv('cmpPvDesc', cmp.desc.value); setPv('cmpPvFooter', cmp.footer.value);
  const img = $('cmpPvImage'); if (cmp.image.value) { img.src = cmp.image.value; img.style.display = ''; } else img.style.display = 'none';
  const th = $('cmpPvThumb'); if (cmp.thumb.value) { th.src = cmp.thumb.value; th.style.display = ''; } else th.style.display = 'none';
  const btns = $('cmpPvButtons');
  if (cmp.mode.value === 'reactionrole') {
    btns.innerHTML = [...cmp.roles.querySelectorAll('.cmp-role-row')].map((r) => {
      const sel = r.querySelector('.cmp-role-sel'); if (!sel.value) return '';
      const name = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].textContent : 'role';
      const label = r.querySelector('.cmp-role-label').value; const emoji = r.querySelector('.cmp-role-emoji').value;
      return `<span class="cmp-pv-btn">${escapeHtml(emoji)} ${escapeHtml(label || name)}</span>`;
    }).join('');
  } else btns.innerHTML = '';
}
function addRoleRow() {
  if (cmp.roles.querySelectorAll('.cmp-role-row').length >= 5) return;
  const div = document.createElement('div');
  div.className = 'cmp-role-row';
  div.innerHTML = `<select class="cmp-role-sel">${cmpRoleOpts('')}</select><input class="cmp-role-label" placeholder="Button label" maxlength="80"/><input class="cmp-role-emoji" placeholder="😀" maxlength="16" style="width:64px"/><button type="button" class="cmp-role-rm">✕</button>`;
  cmp.roles.appendChild(div);
  updateComposerPreview();
}
if (cmp.mode) {
  cmp.mode.addEventListener('change', () => { cmp.rolesWrap.style.display = cmp.mode.value === 'reactionrole' ? '' : 'none'; updateComposerPreview(); });
  [cmp.content, cmp.title, cmp.desc, cmp.color, cmp.author, cmp.image, cmp.thumb, cmp.footer].forEach((el) => el && el.addEventListener('input', updateComposerPreview));
  cmp.addRole && cmp.addRole.addEventListener('click', addRoleRow);
  cmp.roles.addEventListener('click', (e) => { if (e.target.closest('.cmp-role-rm')) { e.target.closest('.cmp-role-row').remove(); updateComposerPreview(); } });
  cmp.roles.addEventListener('input', updateComposerPreview);
  cmp.roles.addEventListener('change', updateComposerPreview);
  cmp.send && cmp.send.addEventListener('click', () => {
    if (!cmp.channel.value) return showNotice('error', 'Pick a channel to post in.');
    const roles = [...cmp.roles.querySelectorAll('.cmp-role-row')].map((r) => ({ roleId: r.querySelector('.cmp-role-sel').value, label: r.querySelector('.cmp-role-label').value, emoji: r.querySelector('.cmp-role-emoji').value })).filter((r) => r.roleId);
    if (cmp.mode.value === 'reactionrole' && !roles.length) return showNotice('error', 'Add at least one role button.');
    socket.emit('composerSend', {
      guildId: currentGuild, channelId: cmp.channel.value, content: cmp.content.value, mode: cmp.mode.value, roles,
      embed: { title: cmp.title.value, description: cmp.desc.value, color: cmp.color.value, author: cmp.author.value, image: cmp.image.value, thumbnail: cmp.thumb.value, footer: cmp.footer.value },
    });
  });
}

// ── config export / import ────────────────────────────────────────
const cfgExportBtn = $('cfgExport'), cfgImportBtn = $('cfgImport'), cfgImportFile = $('cfgImportFile');
cfgExportBtn && cfgExportBtn.addEventListener('click', () => socket.emit('exportConfig', currentGuild));
socket.on('configExport', (data) => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `harmonix-config-${String(data.guildName || 'server').replace(/[^a-z0-9]+/gi, '-')}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
  showNotice('success', 'Config file downloaded.');
});
cfgImportBtn && cfgImportBtn.addEventListener('click', () => cfgImportFile.click());
cfgImportFile && cfgImportFile.addEventListener('change', async () => {
  const f = cfgImportFile.files[0]; if (!f) return;
  try {
    const data = JSON.parse(await f.text());
    if (window.confirm('Import these settings into THIS server? Existing values with the same keys will be overwritten.')) {
      socket.emit('importConfig', { guildId: currentGuild, data });
    }
  } catch { showNotice('error', 'That file isn’t valid JSON.'); }
  cfgImportFile.value = '';
});

// Power-level assignment for roles
$('mgrPower').addEventListener('click', (e) => {
  const btn = e.target.closest('.lvl[data-act="plvl"] button');
  if (!btn) return;
  const row = btn.closest('.prole');
  powerModel[row.dataset.role] = Number(btn.dataset.lvl) || 0;
  row.querySelectorAll('.lvl button').forEach((b) => b.classList.toggle('active', b === btn));
  scheduleSave();
});

function gatherAndSave() {
  if (!managerData) return;
  const gate = {};
  for (const [path, m] of Object.entries(gateModel)) {
    if (!m.enabled || m.mode || m.level || m.reply) gate[path] = { enabled: m.enabled, mode: m.mode || null, channels: [...m.channels], level: m.level || 0, reply: m.reply || null };
  }
  const powerRoles = {};
  for (const [rid, lv] of Object.entries(powerModel)) if (lv) powerRoles[rid] = lv;
  socket.emit('saveManager', {
    guildId: currentGuild,
    gate,
    powerRoles,
    autodelete: Number(mgrAutodelete.value) || 0,
    triviaChannel: mgrTrivia.value || null,
    musicChannel: mgrMusicLock ? (mgrMusicLock.value || null) : null,
    musicSettings: {
      djOnly: !!(mgrDjOnly && mgrDjOnly.checked),
      maxQueue: Number(mgrMaxQueue && mgrMaxQueue.value) || 0,
      maxSongSec: (Number(mgrMaxSong && mgrMaxSong.value) || 0) * 60,
      maxPerUser: Number(mgrMaxPerUser && mgrMaxPerUser.value) || 0,
      fadeSec: Number(mgrFade && mgrFade.value) || 0,
    },
    voiceXp: !!(mgrVoiceXp && mgrVoiceXp.checked),
    countingChannel: mgrCounting ? (mgrCounting.value || null) : null,
    disabledModules: mgrModules ? [...mgrModules.querySelectorAll('input[data-mod]')].filter((c) => !c.checked).map((c) => c.dataset.mod) : [],
    achAnnounce: { mode: mgrAchMode ? mgrAchMode.value : 'channel', channelId: (mgrAchChannel && mgrAchChannel.value) || null },
    featureChannels: {
      music: (mgrChMusic && mgrChMusic.value) || null,
      logging: (mgrChLogging && mgrChLogging.value) || null,
      modlog: (mgrChModlog && mgrChModlog.value) || null,
      tickets: (mgrChTickets && mgrChTickets.value) || null,
      suggestions: (mgrChSuggest && mgrChSuggest.value) || null,
      birthday: (mgrChBirthday && mgrChBirthday.value) || null,
    },
    replyMode: mgrReplyMode ? mgrReplyMode.value : 'default',
    gateMessages: {
      disabled: (mgrGateDisabled && mgrGateDisabled.value.trim()) || '',
      level: (mgrGateLevel && mgrGateLevel.value.trim()) || '',
      channel: (mgrGateChannel && mgrGateChannel.value.trim()) || '',
    },
    levelupDM: !!(mgrLevelupDM && mgrLevelupDM.checked),
    xpIgnore: mgrXpIgnore ? [...mgrXpIgnore.selectedOptions].map((o) => o.value) : [],
    logIgnored: mgrLogIgnore ? [...mgrLogIgnore.selectedOptions].map((o) => o.value) : [],
    prefix: mgrPrefix ? (mgrPrefix.value || '!') : undefined,
  });
}

// ---- auto-save ----------------------------------------------------------
function setSaveStatus(text) {
  const saving = /saving/i.test(text);
  document.querySelectorAll('.save-status').forEach((el) => { el.textContent = text; el.classList.toggle('saving', saving); });
}
let saveTimer = null;
function scheduleSave() {
  if (!managerData) return;
  setSaveStatus('Saving…');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(gatherAndSave, 700);
}
socket.on('saved', () => setSaveStatus('All changes saved ✓'));

mgrSaveCmds.addEventListener('click', gatherAndSave);
mgrSaveSettings.addEventListener('click', gatherAndSave);
// Settings inputs auto-save as you change them.
[mgrAutodelete, mgrTrivia, mgrPrefix, mgrMusicLock, mgrDjOnly, mgrMaxQueue, mgrMaxSong, mgrMaxPerUser, mgrReplyMode, mgrGateDisabled, mgrGateLevel, mgrGateChannel, mgrLevelupDM, mgrXpIgnore, mgrLogIgnore, mgrVoiceXp, mgrFade, mgrCounting, mgrChMusic, mgrChLogging, mgrChModlog, mgrChTickets, mgrChSuggest, mgrChBirthday, mgrAchMode, mgrAchChannel].forEach((el) => { if (el) el.addEventListener('change', scheduleSave); });
if (mgrModules) mgrModules.addEventListener('change', (e) => { if (e.target.matches('input[data-mod]')) scheduleSave(); });
// text gate messages also save as you type
[mgrGateDisabled, mgrGateLevel, mgrGateChannel].forEach((el) => { if (el) el.addEventListener('input', scheduleSave); });

// ---- mod cases / leveling / stats ---------------------------------------
const CASE_EMOJI = { warn: '⚠️', kick: '👢', ban: '🔨', tempban: '⏲️', unban: '♻️', timeout: '⏳', untimeout: '🔓', mute: '🔇', unmute: '🔊' };

socket.on('cases', (data) => {
  const el = $('mgrCases');
  if (!data.cases.length) { el.innerHTML = '<div class="mgr-empty">No moderation cases yet.</div>'; return; }
  el.innerHTML = data.cases
    .map((c) => {
      const when = c.created_at ? new Date(c.created_at).toLocaleString() : '';
      return `<div class="case-row">
        <div class="case-head"><span class="case-num">#${c.case_number}</span> <span class="case-act">${CASE_EMOJI[c.action] || '•'} ${escapeHtml(c.action)}</span> <span class="case-tgt">${escapeHtml(c.target_tag || c.target_id || 'unknown')}</span></div>
        <div class="case-meta">by ${escapeHtml(c.moderator_tag || c.moderator_id || 'unknown')} · ${escapeHtml(when)}</div>
        ${c.reason ? `<div class="case-reason">${escapeHtml(c.reason)}</div>` : ''}
      </div>`;
    })
    .join('');
});

socket.on('levels', (data) => {
  const el = $('mgrLevels');
  if (!data.levels.length) { el.innerHTML = '<div class="mgr-empty">No XP recorded yet.</div>'; return; }
  el.innerHTML = data.levels
    .map((l, i) => `<div class="lvl-row" data-uid="${escapeHtml(l.userId)}">
        <span class="lvl-rank">#${i + 1}</span>
        ${l.avatar ? `<img class="lvl-av" src="${escapeHtml(l.avatar)}" alt="" />` : '<span class="lvl-av lvl-av-none"></span>'}
        <span class="lvl-user" title="${escapeHtml(l.userId)}">${escapeHtml(l.name || l.userId)}${l.left ? ' <span class="lvl-left">(left)</span>' : ''}</span>
        <span class="lvl-badge">Lv ${l.level}</span>
        <input class="lvl-xp" type="number" min="0" value="${l.xp}" />
        <button class="lvl-save">Save</button>
      </div>`)
    .join('');
});
$('mgrLevels').addEventListener('click', (e) => {
  const btn = e.target.closest('.lvl-save');
  if (!btn) return;
  const row = btn.closest('.lvl-row');
  const xp = Number(row.querySelector('.lvl-xp').value) || 0;
  socket.emit('saveLevel', { guildId: currentGuild, userId: row.dataset.uid, xp });
});

socket.on('stats', (data) => {
  const el = $('mgrStats');
  const max = data.top.length ? data.top[0].count : 1;
  const bars = data.top
    .map((t) => `<div class="stat-row"><span class="stat-name">/${escapeHtml(t.command)}</span><span class="stat-bar"><span style="width:${Math.round((t.count / max) * 100)}%"></span></span><span class="stat-count">${t.count}</span></div>`)
    .join('');
  el.innerHTML = `<div class="stat-total">${data.total.total} total uses · ${data.total.distinct} distinct commands</div>` + (bars || '<div class="mgr-empty">No usage recorded yet.</div>');
});

// ---- config pages -------------------------------------------------------
function chanSelect(channels, selected) {
  return `<select class="cfg-channel"><option value="">— none —</option>${channels.map((ch) => `<option value="${escapeHtml(ch.id)}" ${ch.id === selected ? 'selected' : ''}>#${escapeHtml(ch.name)}</option>`).join('')}</select>`;
}
function roleSelect(roles, selected) {
  return `<select class="cfg-role"><option value="">— none —</option>${roles.map((r) => `<option value="${escapeHtml(r.id)}" ${r.id === selected ? 'selected' : ''} ${r.assignable === false ? 'disabled' : ''}>${escapeHtml(r.name)}${r.assignable === false ? ' (above my role — can’t assign)' : ''}</option>`).join('')}</select>`;
}
function greetCard(title, section, g, channels) {
  return `<div class="cfg-card" data-section="${section}">
    <div class="cfg-title">${title}</div>
    <label class="cfg-line"><input type="checkbox" class="cfg-enabled" ${g.enabled ? 'checked' : ''}/> Enabled</label>
    <label class="cfg-line">Channel ${chanSelect(channels, g.channelId)}</label>
    <label class="cfg-line">Message<textarea class="cfg-message" rows="2" placeholder="Use {user}, {server}, {count}">${escapeHtml(g.message || '')}</textarea></label>
    <div class="cfg-warn" hidden></div>
    <div class="cfg-actions"><span class="save-status">Saved ✓</span><button class="cfg-save">Save now</button></div>
  </div>`;
}

socket.on('config', (data) => {
  const el = $('mgrConfig');
  el.innerHTML =
    greetCard('👋 Welcome', 'welcome', data.welcome, data.channels) +
    greetCard('🚪 Goodbye', 'goodbye', data.goodbye, data.channels) +
    `<div class="cfg-card" data-section="autorole">
      <div class="cfg-title">🎭 Autorole</div>
      <label class="cfg-line"><input type="checkbox" class="cfg-enabled" ${data.autorole.enabled ? 'checked' : ''}/> Enabled</label>
      <label class="cfg-line">Role ${roleSelect(data.roles, data.autorole.roleId)}</label>
      <div class="cfg-warn" hidden></div>
      <div class="cfg-actions"><span class="save-status">Saved ✓</span><button class="cfg-save">Save now</button></div>
    </div>` +
    `<div class="cfg-card" data-section="starboard">
      <div class="cfg-title">⭐ Starboard</div>
      <label class="cfg-line"><input type="checkbox" class="cfg-enabled" ${data.starboard.enabled ? 'checked' : ''}/> Enabled</label>
      <label class="cfg-line">Channel ${chanSelect(data.channels, data.starboard.channelId)}</label>
      <label class="cfg-line">Threshold <input type="number" class="cfg-threshold" min="1" max="50" value="${data.starboard.threshold}"/></label>
      <label class="cfg-line">Emoji <input type="text" class="cfg-emoji" value="${escapeHtml(data.starboard.emoji || '⭐')}" maxlength="32"/></label>
      <div class="cfg-warn" hidden></div>
      <div class="cfg-actions"><span class="save-status">Saved ✓</span><button class="cfg-save">Save now</button></div>
    </div>`;
  el.querySelectorAll('.cfg-card').forEach(refreshCardWarning);
  enhanceNumberInputs(el);
});

// Inline warning when a feature is enabled but missing its target.
function refreshCardWarning(card) {
  const warn = card.querySelector('.cfg-warn');
  if (!warn) return;
  const enabled = card.querySelector('.cfg-enabled')?.checked;
  const role = card.querySelector('.cfg-role');
  const chan = card.querySelector('.cfg-channel');
  let msg = '';
  if (enabled && role && !role.value) msg = '⚠️ Enabled, but no role is selected — nothing will be assigned.';
  else if (enabled && chan && !chan.value) msg = '⚠️ Enabled, but no channel is set — nothing will be sent.';
  warn.textContent = msg;
  warn.hidden = !msg;
}

function saveConfigCard(card) {
  const section = card.dataset.section;
  const data = { enabled: card.querySelector('.cfg-enabled').checked };
  const chan = card.querySelector('.cfg-channel');
  const role = card.querySelector('.cfg-role');
  const msg = card.querySelector('.cfg-message');
  const thr = card.querySelector('.cfg-threshold');
  const emo = card.querySelector('.cfg-emoji');
  if (chan) data.channelId = chan.value || null;
  if (role) data.roleId = role.value || null;
  if (msg) data.message = msg.value || null;
  if (thr) data.threshold = Number(thr.value) || 3;
  if (emo) data.emoji = emo.value || '⭐';
  setSaveStatus('Saving…');
  socket.emit('saveConfig', { guildId: currentGuild, section, data });
}

const cfgSaveTimers = new WeakMap();
function scheduleConfigSave(card) {
  setSaveStatus('Saving…');
  clearTimeout(cfgSaveTimers.get(card));
  cfgSaveTimers.set(card, setTimeout(() => saveConfigCard(card), 700));
}

$('mgrConfig').addEventListener('change', (e) => {
  const card = e.target.closest('.cfg-card');
  if (!card) return;
  // Picking a role implies you want autorole on.
  const role = e.target.closest('.cfg-role');
  if (role && card.dataset.section === 'autorole' && role.value) {
    const en = card.querySelector('.cfg-enabled');
    if (en) en.checked = true;
  }
  scheduleConfigSave(card);
  refreshCardWarning(card);
});
$('mgrConfig').addEventListener('input', (e) => {
  const card = e.target.closest('.cfg-card');
  if (card && (e.target.classList.contains('cfg-message') || e.target.classList.contains('cfg-threshold') || e.target.classList.contains('cfg-emoji'))) {
    scheduleConfigSave(card);
  }
});
$('mgrConfig').addEventListener('click', (e) => {
  const btn = e.target.closest('.cfg-save');
  if (!btn) return;
  saveConfigCard(btn.closest('.cfg-card'));
});

// ---- live log feed ------------------------------------------------------
function logLine(entry) {
  const t = new Date(entry.at).toLocaleTimeString();
  const color = entry.color ? '#' + entry.color.toString(16).padStart(6, '0') : 'var(--muted)';
  return `<div class="log-line"><span class="log-dot" style="background:${color}"></span><span class="log-time">${escapeHtml(t)}</span><span class="log-text">${escapeHtml(entry.text || '')}</span></div>`;
}
socket.on('logfeed', (data) => {
  const el = $('mgrLog');
  if (!data.entries.length) { el.innerHTML = '<div class="mgr-empty">No events yet. Configure a log channel with <code>/mod logging set</code>.</div>'; return; }
  el.innerHTML = data.entries.slice().reverse().map(logLine).join('');
});
socket.on('logentry', (entry) => {
  if (currentView !== 'log') return;
  const el = $('mgrLog');
  const empty = el.querySelector('.mgr-empty');
  if (empty) el.innerHTML = '';
  el.insertAdjacentHTML('afterbegin', logLine(entry));
  while (el.children.length > 80) el.removeChild(el.lastChild);
});

// sidebar live status dot
const sideStatus = $('sideStatus');
if (sideStatus) {
  socket.on('connect', () => { sideStatus.textContent = 'online'; sideStatus.classList.remove('off'); });
  socket.on('disconnect', () => { sideStatus.textContent = 'offline'; sideStatus.classList.add('off'); });
}

// ── overview (home) ────────────────────────────────────────────────
socket.on('overview', (o) => {
  if (o.guildId !== currentGuild) return;
  $('ovTitle').textContent = o.guildName ? `${o.guildName} — at a glance` : 'Overview';
  $('ovMembers').textContent = o.members == null ? '—' : o.members.toLocaleString();
  $('ovPlays').textContent = o.playsWeek.toLocaleString();
  $('ovListeners').textContent = o.listenersWeek.toLocaleString();
  $('ovCommands').textContent = o.commandsUsed.toLocaleString();
  $('ovAch').textContent = o.achievementsUnlocked.toLocaleString();
  $('ovPing').textContent = `${o.ping}ms`;
  const hero = $('ovHero');
  if (o.topTrack) {
    hero.style.display = '';
    $('ovTopTrack').textContent = `${o.topTrack.title}${o.topTrack.author ? ' — ' + o.topTrack.author : ''}  ×${o.topTrack.plays}`;
  } else hero.style.display = 'none';
  // Jump links and server-config notices are for managers only.
  const quick = document.querySelector('#homeStats .ov-quick');
  if (quick) quick.style.display = o.canManage ? '' : 'none';
  const warn = $('ovWarn');
  if (o.canManage && o.disabledModules > 0) {
    warn.style.display = '';
    warn.textContent = `🧩 ${o.disabledModules} feature module${o.disabledModules === 1 ? ' is' : 's are'} turned off for this server (Server Settings → Feature modules).`;
  } else warn.style.display = 'none';
});
document.querySelectorAll('.ov-quick button').forEach((b) => b.addEventListener('click', () => setView(b.dataset.jump)));

// ── persistent mini-player ─────────────────────────────────────────
const mini = $('mini');
function updateMini(state) {
  if (!mini) return;
  const show = currentView !== 'music' && state && state.current;
  mini.style.display = show ? '' : 'none';
  if (!show) return;
  $('miniTitle').textContent = state.current.title || '';
  $('miniSub').textContent = `${state.paused ? '⏸ paused' : '▶ playing'} · ${state.current.author || ''}`;
  const art = $('miniArt');
  if (state.current.artworkUrl) { art.src = state.current.artworkUrl; art.style.visibility = 'visible'; }
  else art.style.visibility = 'hidden';
}
if (mini) {
  $('miniMeta').addEventListener('click', () => setView('music'));
  $('miniPause').addEventListener('click', () => emitControl('togglePause'));
  $('miniSkip').addEventListener('click', () => emitControl('skip'));
}
// hide/show the mini-player when switching views
const _setViewMini = setView;
setView = function (view) { _setViewMini(view); updateMini(latest); };

// ── Ctrl+K quick-jump palette ──────────────────────────────────────
const palette = $('palette');
const paletteInput = $('paletteInput');
const paletteList = $('paletteList');
function paletteItems() {
  return [...hamMenu.querySelectorAll('button')]
    .filter((b) => b.style.display !== 'none')
    .map((b) => ({ view: b.dataset.view, label: b.textContent.trim() }));
}
function openPalette() {
  palette.style.display = '';
  paletteInput.value = '';
  renderPalette('');
  paletteInput.focus();
}
function closePalette() { palette.style.display = 'none'; }
function renderPalette(q) {
  const items = paletteItems().filter((i) => i.label.toLowerCase().includes(q.toLowerCase()));
  paletteList.innerHTML = items
    .map((i, n) => `<button data-pview="${escapeHtml(i.view)}" class="${n === 0 ? 'sel' : ''}">${escapeHtml(i.label)}</button>`)
    .join('') || '<div class="palette-empty">No matches</div>';
}
if (palette) {
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPalette(); }
    else if (e.key === 'Escape' && palette.style.display !== 'none') closePalette();
  });
  paletteInput.addEventListener('input', () => renderPalette(paletteInput.value));
  paletteInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const first = paletteList.querySelector('button');
      if (first) { setView(first.dataset.pview); closePalette(); }
    }
  });
  paletteList.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-pview]');
    if (b) { setView(b.dataset.pview); closePalette(); }
  });
  palette.addEventListener('click', (e) => { if (e.target === palette) closePalette(); });
}

// ── one-time DOM regroup: Server Settings subheads → section cards ──
// renderManager only fills values by id, so wrapping containers is safe.
(function groupSettings() {
  const grid = document.querySelector('#mgrSettingsPanel .mgr-settings');
  if (!grid || grid.dataset.grouped) return;
  grid.dataset.grouped = '1';
  const kids = [...grid.children];
  grid.innerHTML = '';
  let section = null, body = null;
  for (const el of kids) {
    if (el.classList.contains('mgr-subhead')) {
      section = document.createElement('section');
      section.className = 'set-group';
      const h = document.createElement('h3');
      h.className = 'set-group-title';
      h.innerHTML = el.innerHTML;
      body = document.createElement('div');
      body.className = 'set-group-body';
      section.append(h, body);
      grid.append(section);
    } else if (body) {
      el.style.gridColumn = ''; // clear old full-row hacks
      body.append(el);
    } else {
      grid.append(el); // anything before the first subhead
    }
  }
})();

// ── custom number steppers ───────────────────────────────────────
// The native up/down spinners are hidden in CSS because they're OS-styled;
// these replacements look like the rest of the UI and behave the same
// (respecting min/max/step and firing input+change so autosave still runs).
function enhanceNumberInputs(root) {
  const scope = root || document;
  scope.querySelectorAll('input[type="number"]').forEach((inp) => {
    if (inp.dataset.stepped) return;
    inp.dataset.stepped = '1';
    if (inp.closest('.vol-num')) return; // the volume pill has its own design

    const wrap = document.createElement('span');
    wrap.className = 'num';
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);

    const steps = document.createElement('span');
    steps.className = 'num-steps';
    steps.innerHTML = '<button type="button" class="num-up" tabindex="-1" aria-label="Increase"></button>'
      + '<button type="button" class="num-down" tabindex="-1" aria-label="Decrease"></button>';
    wrap.appendChild(steps);

    steps.addEventListener('click', (e) => {
      const up = e.target.closest('.num-up');
      const down = e.target.closest('.num-down');
      if (!up && !down) return;
      e.preventDefault();
      const step = Number(inp.step) || 1;
      let next = (Number(inp.value) || 0) + (up ? step : -step);
      if (inp.min !== '') next = Math.max(Number(inp.min), next);
      if (inp.max !== '') next = Math.min(Number(inp.max), next);
      if (String(next) === String(inp.value)) return;
      inp.value = next;
      inp.dispatchEvent(new Event('input', { bubbles: true }));
      inp.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });
}
enhanceNumberInputs();
