'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { getConfig, setConfig } = require('../db');

function getRole(guildId) {
  return getConfig(guildId, 'dj_role', null);
}
function setRole(guildId, roleId) {
  setConfig(guildId, 'dj_role', roleId || null);
}
/** DJ-restricted actions: allowed for everyone when no DJ role is set and
 *  DJ-only mode is off; otherwise only members with the DJ role or Manage Server. */
function isDJ(interaction) {
  const roleId = getRole(interaction.guildId);
  const djOnly = getConfig(interaction.guildId, 'dj_only', false);
  if (!roleId && !djOnly) return true;
  if (interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
  return !!(roleId && interaction.member.roles.cache.has(roleId));
}

module.exports = { getRole, setRole, isDJ };
