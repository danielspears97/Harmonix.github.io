'use strict';

const sessions = new Map(); // guildId -> { trackId, voters:Set }

function currentTrackId(player) {
  const c = player && player.queue && player.queue.current;
  return c ? (c.encoded || c.info?.identifier || c.info?.uri || 'cur') : null;
}
function vote(guildId, player, userId) {
  const id = currentTrackId(player);
  let s = sessions.get(guildId);
  if (!s || s.trackId !== id) { s = { trackId: id, voters: new Set() }; sessions.set(guildId, s); }
  s.voters.add(userId);
  return s.voters.size;
}
function reset(guildId) {
  sessions.delete(guildId);
}

module.exports = { vote, reset, currentTrackId };
