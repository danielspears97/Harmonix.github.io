'use strict';

const { getDb } = require('../db');

/** Record one track play. Best-effort; never throws into the event loop. */
function log(guildId, track) {
  try {
    const i = track?.info || {};
    const r = track?.requester || {};
    getDb()
      .prepare(
        `INSERT INTO play_history (guild_id, user_id, title, author, uri, source, played_at)
         VALUES (@g, @u, @t, @a, @uri, @s, @at)`
      )
      .run({
        g: guildId,
        u: r.id || null,
        t: (i.title || 'Unknown').slice(0, 300),
        a: (i.author || '').slice(0, 200),
        uri: i.uri || null,
        s: i.sourceName || null,
        at: Date.now(),
      });
  } catch { /* ignore logging failures */ }
}

function since(days) {
  return Date.now() - days * 86400000;
}

function totals(guildId, days = 36500) {
  const row = getDb()
    .prepare('SELECT COUNT(*) AS plays, COUNT(DISTINCT user_id) AS listeners FROM play_history WHERE guild_id = ? AND played_at >= ?')
    .get(guildId, since(days));
  return { plays: row?.plays || 0, listeners: row?.listeners || 0 };
}

function topTracks(guildId, days = 36500, limit = 5) {
  return getDb()
    .prepare(
      `SELECT title, author, COUNT(*) AS plays FROM play_history
       WHERE guild_id = ? AND played_at >= ?
       GROUP BY title, author ORDER BY plays DESC, MAX(played_at) DESC LIMIT ?`
    )
    .all(guildId, since(days), limit);
}

function topListeners(guildId, days = 36500, limit = 5) {
  return getDb()
    .prepare(
      `SELECT user_id, COUNT(*) AS plays FROM play_history
       WHERE guild_id = ? AND user_id IS NOT NULL AND played_at >= ?
       GROUP BY user_id ORDER BY plays DESC LIMIT ?`
    )
    .all(guildId, since(days), limit);
}

function userPlayCount(guildId, userId) {
  const row = getDb()
    .prepare('SELECT COUNT(*) AS n FROM play_history WHERE guild_id = ? AND user_id = ?')
    .get(guildId, userId);
  return row?.n || 0;
}

/** Distinct lowercased source names a member has played from. */
function userSources(guildId, userId) {
  return getDb()
    .prepare('SELECT DISTINCT LOWER(source) AS s FROM play_history WHERE guild_id = ? AND user_id = ? AND source IS NOT NULL')
    .all(guildId, userId)
    .map((r) => r.s);
}

/** Busiest hour of day (0-23) by play count. */
function busiestHour(guildId, days = 36500) {
  const rows = getDb()
    .prepare('SELECT played_at FROM play_history WHERE guild_id = ? AND played_at >= ?')
    .all(guildId, since(days));
  if (!rows.length) return null;
  const buckets = new Array(24).fill(0);
  for (const r of rows) buckets[new Date(r.played_at).getHours()] += 1;
  let best = 0;
  for (let h = 1; h < 24; h++) if (buckets[h] > buckets[best]) best = h;
  return best;
}

module.exports = { log, totals, topTracks, topListeners, userPlayCount, userSources, busiestHour };
