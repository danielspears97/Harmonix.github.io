'use strict';

const { getDb } = require('../db');

const MAX_TRACKS = 100;

function save(userId, name, tracks) {
  const json = JSON.stringify(tracks.slice(0, MAX_TRACKS));
  getDb()
    .prepare('INSERT INTO playlists (user_id, name, tracks, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(user_id, name) DO UPDATE SET tracks = excluded.tracks, created_at = excluded.created_at')
    .run(userId, name, json, Date.now());
}
function get(userId, name) {
  const row = getDb().prepare('SELECT * FROM playlists WHERE user_id = ? AND LOWER(name) = LOWER(?)').get(userId, name);
  if (!row) return null;
  return { ...row, tracks: JSON.parse(row.tracks) };
}
function list(userId) {
  return getDb().prepare('SELECT name, tracks FROM playlists WHERE user_id = ? ORDER BY created_at DESC').all(userId)
    .map((r) => ({ name: r.name, count: JSON.parse(r.tracks).length }));
}
function remove(userId, name) {
  return getDb().prepare('DELETE FROM playlists WHERE user_id = ? AND LOWER(name) = LOWER(?)').run(userId, name).changes > 0;
}

module.exports = { MAX_TRACKS, save, get, list, remove };
