'use strict';

/**
 * Welcome / goodbye messages and autorole. Config is stored per-guild in the
 * generic guild_config table under the keys 'welcome', 'goodbye', 'autorole'.
 */

const { getConfig, setConfig } = require('../db');

const DEFAULT_WELCOME = 'Welcome to **{server}**, {user}! You’re member **#{membercount}**. 🎉';
const DEFAULT_GOODBYE = '**{username}** has left **{server}**. 👋';

function getGreeting(guildId, kind) {
  return getConfig(guildId, kind, { enabled: false, channelId: null, message: null });
}
function setGreeting(guildId, kind, patch) {
  const cur = getGreeting(guildId, kind);
  return setConfig(guildId, kind, { ...cur, ...patch });
}

function getAutorole(guildId) {
  return getConfig(guildId, 'autorole', { enabled: false, roleId: null });
}
function setAutorole(guildId, patch) {
  const cur = getAutorole(guildId);
  return setConfig(guildId, 'autorole', { ...cur, ...patch });
}

/** Replace {placeholders} in a greeting template. */
function render(template, member) {
  const guild = member.guild;
  const map = {
    '{user}': `<@${member.id}>`,
    '{username}': member.user.username,
    '{tag}': member.user.tag,
    '{server}': guild.name,
    '{membercount}': String(guild.memberCount),
  };
  return String(template || '').replace(/\{user\}|\{username\}|\{tag\}|\{server\}|\{membercount\}/g, (m) => map[m]);
}

module.exports = {
  getGreeting, setGreeting, getAutorole, setAutorole, render,
  DEFAULT_WELCOME, DEFAULT_GOODBYE,
};
