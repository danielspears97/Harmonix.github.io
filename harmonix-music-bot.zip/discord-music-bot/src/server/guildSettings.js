'use strict';

const { getConfig, setConfig } = require('../db');

// ── auto-delete bot responses ────────────────────────────────────
function getAutoDelete(guildId) {
  return Number(getConfig(guildId, 'autodelete_seconds', 0)) || 0;
}
function setAutoDelete(guildId, seconds) {
  const v = Math.max(0, Math.min(3600, Math.floor(Number(seconds) || 0)));
  setConfig(guildId, 'autodelete_seconds', v);
  return v;
}

// ── designated trivia channel (auto-cleared hourly) ──────────────
function getTriviaChannel(guildId) {
  return getConfig(guildId, 'trivia_channel', null);
}
function setTriviaChannel(guildId, channelId) {
  setConfig(guildId, 'trivia_channel', channelId || null);
  return channelId || null;
}

// ── per-command gating ───────────────────────────────────────────
// Shape: { [commandName]: { enabled: bool, mode: 'allow'|'deny'|null, channels: [id] } }
function getGate(guildId) {
  return getConfig(guildId, 'cmdgate', {}) || {};
}
function setGate(guildId, obj) {
  setConfig(guildId, 'cmdgate', obj && typeof obj === 'object' ? obj : {});
  return getGate(guildId);
}
function setCommandRule(guildId, name, rule) {
  const gate = getGate(guildId);
  const prev = gate[name] || {};
  gate[name] = {
    enabled: rule.enabled !== false,
    mode: rule.mode || null,
    channels: Array.isArray(rule.channels) ? rule.channels : [],
    level: rule.level != null ? Math.max(0, Math.min(2, Math.floor(rule.level))) : (prev.level || 0),
    reply: ['public', 'ephemeral'].includes(rule.reply) ? rule.reply : (prev.reply || null),
  };
  return setGate(guildId, gate);
}

/** Per-command reply visibility override ('public' | 'ephemeral' | null). */
function getCommandReply(guildId, name) {
  const c = getGate(guildId)[name];
  return c && ['public', 'ephemeral'].includes(c.reply) ? c.reply : null;
}

// ── role power levels (0 = everyone, 1 = trusted, 2 = staff) ──────
function getPowerRoles(guildId) {
  return getConfig(guildId, 'power_roles', {}) || {};
}
function setPowerRoles(guildId, map) {
  setConfig(guildId, 'power_roles', map && typeof map === 'object' ? map : {});
  return getPowerRoles(guildId);
}
function setRoleLevel(guildId, roleId, level) {
  const m = getPowerRoles(guildId);
  const lv = Math.max(0, Math.min(2, Math.floor(Number(level) || 0)));
  if (lv === 0) delete m[roleId];
  else m[roleId] = lv;
  return setPowerRoles(guildId, m);
}
/** A member's effective power level = highest of their roles (owner/admin always 2). */
function memberPowerLevel(member) {
  if (!member) return 0;
  try {
    if (member.id === member.guild.ownerId) return 2;
    if (member.permissions && member.permissions.has('Administrator')) return 2;
  } catch { /* ignore */ }
  const m = getPowerRoles(member.guild.id);
  let lvl = 0;
  for (const role of member.roles.cache.values()) {
    const v = m[role.id];
    if (v > lvl) lvl = v;
  }
  return lvl;
}
function setCommandLevel(guildId, name, level) {
  const gate = getGate(guildId);
  const cur = gate[name] || { enabled: true, mode: null, channels: [] };
  cur.level = Math.max(0, Math.min(2, Math.floor(Number(level) || 0)));
  gate[name] = cur;
  return setGate(guildId, gate);
}

// ── music voice-channel lock ─────────────────────────────────────
function getMusicChannel(guildId) {
  return getConfig(guildId, 'music_channel', null) || null;
}
function setMusicChannel(guildId, channelId) {
  setConfig(guildId, 'music_channel', channelId || null);
  return channelId || null;
}

// ── DJ-only + queue guardrails ───────────────────────────────────
function getMusicSettings(guildId) {
  return {
    djOnly: !!getConfig(guildId, 'dj_only', false),
    maxQueue: getConfig(guildId, 'max_queue', 0) || 0,
    maxSongSec: getConfig(guildId, 'max_song_sec', 0) || 0,
    maxPerUser: getConfig(guildId, 'max_per_user', 0) || 0,
    fadeSec: getConfig(guildId, 'fade_sec', 0) || 0,
  };
}
function setMusicSettings(guildId, p = {}) {
  if ('djOnly' in p) setConfig(guildId, 'dj_only', !!p.djOnly);
  if ('maxQueue' in p) setConfig(guildId, 'max_queue', Math.max(0, Math.floor(Number(p.maxQueue) || 0)));
  if ('maxSongSec' in p) setConfig(guildId, 'max_song_sec', Math.max(0, Math.floor(Number(p.maxSongSec) || 0)));
  if ('maxPerUser' in p) setConfig(guildId, 'max_per_user', Math.max(0, Math.floor(Number(p.maxPerUser) || 0)));
  if ('fadeSec' in p) setConfig(guildId, 'fade_sec', Math.max(0, Math.min(12, Math.floor(Number(p.fadeSec) || 0))));
  return getMusicSettings(guildId);
}

function getVoiceXp(guildId) {
  return !!getConfig(guildId, 'voice_xp', false);
}
function setVoiceXp(guildId, v) {
  setConfig(guildId, 'voice_xp', !!v);
  return getVoiceXp(guildId);
}

// ── achievement unlock announcements ─────────────────────────────
// mode: 'channel' (where it happened) | 'dm' | 'specific' | 'off'
function getAchievementAnnounce(guildId) {
  const s = getConfig(guildId, 'ach_announce', {}) || {};
  return {
    mode: ['channel', 'dm', 'specific', 'off'].includes(s.mode) ? s.mode : 'channel',
    channelId: s.channelId || null,
  };
}
function setAchievementAnnounce(guildId, { mode, channelId } = {}) {
  setConfig(guildId, 'ach_announce', {
    mode: ['channel', 'dm', 'specific', 'off'].includes(mode) ? mode : 'channel',
    channelId: channelId || null,
  });
  return getAchievementAnnounce(guildId);
}

// ── command reply visibility ('default' | 'public' | 'ephemeral') ─
function getReplyMode(guildId) {
  const m = getConfig(guildId, 'reply_mode', 'default');
  return ['public', 'ephemeral'].includes(m) ? m : 'default';
}
function setReplyMode(guildId, mode) {
  setConfig(guildId, 'reply_mode', ['public', 'ephemeral'].includes(mode) ? mode : 'default');
  return getReplyMode(guildId);
}

// ── custom gate messages ─────────────────────────────────────────
function getGateMessages(guildId) {
  return getConfig(guildId, 'gate_messages', {}) || {};
}
function setGateMessages(guildId, m) {
  setConfig(guildId, 'gate_messages', m && typeof m === 'object' ? m : {});
  return getGateMessages(guildId);
}

// ── XP ignore list + level-up DM ─────────────────────────────────
function getXpIgnore(guildId) {
  return getConfig(guildId, 'xp_ignore_channels', []) || [];
}
function setXpIgnore(guildId, list) {
  setConfig(guildId, 'xp_ignore_channels', Array.isArray(list) ? list.filter((x) => typeof x === 'string') : []);
  return getXpIgnore(guildId);
}
function getLevelupDM(guildId) {
  return !!getConfig(guildId, 'levelup_dm', false);
}
function setLevelupDM(guildId, v) {
  setConfig(guildId, 'levelup_dm', !!v);
  return getLevelupDM(guildId);
}

/** Decide whether a command may run. Returns {ok} or {ok:false, reason}. */
function checkCommand(guildId, name, channelId, memberLevel = 2) {
  const c = getGate(guildId)[name];
  if (!c) return { ok: true };
  if (c.enabled === false) return { ok: false, reason: 'disabled' };
  if (c.level && memberLevel < c.level) return { ok: false, reason: 'level', required: c.level };
  const list = Array.isArray(c.channels) ? c.channels : [];
  if (c.mode === 'allow' && list.length && !list.includes(channelId)) return { ok: false, reason: 'channel' };
  if (c.mode === 'deny' && list.includes(channelId)) return { ok: false, reason: 'channel' };
  return { ok: true };
}

// ── command prefix (for text commands) ───────────────────────────
function getPrefix(guildId) {
  return getConfig(guildId, 'prefix', '!') || '!';
}
function setPrefix(guildId, prefix) {
  const p = String(prefix || '!').trim().slice(0, 5) || '!';
  setConfig(guildId, 'prefix', p);
  return p;
}

module.exports = {
  getAutoDelete, setAutoDelete,
  getTriviaChannel, setTriviaChannel,
  getGate, setGate, setCommandRule, checkCommand,
  getPowerRoles, setPowerRoles, setRoleLevel, memberPowerLevel, setCommandLevel,
  getMusicChannel, setMusicChannel,
  getMusicSettings, setMusicSettings,
  getVoiceXp, setVoiceXp,
  getAchievementAnnounce, setAchievementAnnounce,
  getReplyMode, setReplyMode, getCommandReply,
  getGateMessages, setGateMessages,
  getXpIgnore, setXpIgnore, getLevelupDM, setLevelupDM,
  getPrefix, setPrefix,
};
