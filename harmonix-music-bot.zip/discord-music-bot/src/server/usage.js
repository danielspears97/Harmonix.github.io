'use strict';

const { getDb } = require('../db');

function record(guildId, command) {
  if (!guildId || !command) return;
  getDb()
    .prepare(
      `INSERT INTO command_usage (guild_id, command, count, last_used) VALUES (?, ?, 1, ?)
       ON CONFLICT(guild_id, command) DO UPDATE SET count = count + 1, last_used = excluded.last_used`
    )
    .run(guildId, command, Date.now());
}
function top(guildId, limit = 15) {
  return getDb().prepare('SELECT command, count, last_used FROM command_usage WHERE guild_id = ? ORDER BY count DESC LIMIT ?').all(guildId, limit);
}
function total(guildId) {
  const row = getDb().prepare('SELECT COALESCE(SUM(count), 0) AS n, COUNT(*) AS distinct_cmds FROM command_usage WHERE guild_id = ?').get(guildId);
  return { total: row.n, distinct: row.distinct_cmds };
}

module.exports = { record, top, total };
