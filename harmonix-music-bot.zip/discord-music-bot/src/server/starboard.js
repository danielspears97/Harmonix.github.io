'use strict';

/**
 * Starboard — when a message gets enough of the configured emoji, it's reposted
 * to a starboard channel. The post's star count updates as reactions change,
 * and the entry is removed if it falls back below the threshold.
 */

const { EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const { getDb, getConfig, setConfig, deleteConfig } = require('../db');

const DEFAULTS = { enabled: false, channelId: null, threshold: 3, emoji: '⭐' };

function getSettings(guildId) {
  const s = getConfig(guildId, 'starboard', null);
  return s ? { ...DEFAULTS, ...s } : { ...DEFAULTS };
}
function saveSettings(guildId, settings) {
  return setConfig(guildId, 'starboard', settings);
}
function disable(guildId) {
  const s = getSettings(guildId);
  s.enabled = false;
  saveSettings(guildId, s);
}

function getEntry(guildId, originalId) {
  return getDb()
    .prepare('SELECT * FROM starboard_messages WHERE guild_id = ? AND original_message_id = ?')
    .get(guildId, originalId);
}
function setEntry(guildId, originalId, starboardId, channelId) {
  getDb()
    .prepare(
      `INSERT INTO starboard_messages (guild_id, original_message_id, starboard_message_id, channel_id)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(guild_id, original_message_id) DO UPDATE SET
         starboard_message_id = excluded.starboard_message_id, channel_id = excluded.channel_id`
    )
    .run(guildId, originalId, starboardId, channelId);
}
function deleteEntry(guildId, originalId) {
  getDb().prepare('DELETE FROM starboard_messages WHERE guild_id = ? AND original_message_id = ?').run(guildId, originalId);
}

/** Does a reaction's emoji match the configured starboard emoji? */
function emojiMatches(reaction, settings) {
  const e = reaction.emoji;
  const id = e.id ? e.toString() : e.name; // custom -> "<:n:id>", unicode -> the char
  return id === settings.emoji || e.name === settings.emoji;
}

function buildEmbed(message, count, settings) {
  const embed = new EmbedBuilder()
    .setColor(0xffc83d)
    .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
    .setDescription(message.content || '*[no text]*')
    .addFields({ name: 'Source', value: `[Jump to message](${message.url})` })
    .setFooter({ text: `${settings.emoji} ${count}` })
    .setTimestamp(message.createdAt);

  const image = [...message.attachments.values()].find((a) => a.contentType?.startsWith('image/'));
  if (image) embed.setImage(image.url);
  return embed;
}

/**
 * React-change handler. Fetches partials, counts the configured emoji, then
 * creates / updates / removes the starboard post accordingly.
 */
async function handleReactionChange(client, reaction) {
  try {
    if (reaction.partial) await reaction.fetch();
    if (reaction.message.partial) await reaction.message.fetch();
  } catch {
    return; // message deleted or inaccessible
  }

  const message = reaction.message;
  if (!message.guild) return;

  const settings = getSettings(message.guild.id);
  if (!settings.enabled || !settings.channelId) return;
  if (message.channel.id === settings.channelId) return; // don't star the starboard itself
  if (!emojiMatches(reaction, settings)) return;

  const count = reaction.count || 0;
  const entry = getEntry(message.guild.id, message.id);

  const starChannel = await client.channels.fetch(settings.channelId).catch(() => null);
  if (!starChannel || !starChannel.isTextBased()) return;

  if (count >= settings.threshold) {
    const embed = buildEmbed(message, count, settings);
    if (entry && entry.starboard_message_id) {
      const existing = await starChannel.messages.fetch(entry.starboard_message_id).catch(() => null);
      if (existing) {
        await existing.edit({ embeds: [embed] }).catch(() => {});
        return;
      }
    }
    const posted = await starChannel
      .send({ content: `${settings.emoji} **${count}** · <#${message.channel.id}>`, embeds: [embed] })
      .catch(() => null);
    if (posted) {
      setEntry(message.guild.id, message.id, posted.id, message.channel.id);
      if (message.author && !message.author.bot) {
        const ach = require('../engagement/achievements');
        const d = ach.unlock(message.guild.id, message.author.id, 'star_struck');
        const unlocked = [d, ...ach.checkMeta(message.guild.id, message.author.id)].filter(Boolean);
        if (unlocked.length) ach.announce(client, { guildId: message.guild.id, userId: message.author.id, channel: message.channel, defs: unlocked });
      }
    }
  } else if (entry && entry.starboard_message_id) {
    // Dropped below threshold — remove the starboard post.
    const existing = await starChannel.messages.fetch(entry.starboard_message_id).catch(() => null);
    if (existing) await existing.delete().catch(() => {});
    deleteEntry(message.guild.id, message.id);
  }
}

module.exports = { DEFAULTS, getSettings, saveSettings, disable, getEntry, setEntry, deleteEntry, emojiMatches, buildEmbed, handleReactionChange };
