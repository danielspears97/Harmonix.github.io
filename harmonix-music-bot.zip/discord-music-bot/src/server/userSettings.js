'use strict';

const { getDb } = require('../db');

/** Validate an IANA timezone (e.g. "America/Chicago") using Intl. */
function isValidTimezone(tz) {
  if (!tz || typeof tz !== 'string') return false;
  try {
    Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

function getTimezone(userId) {
  const row = getDb().prepare('SELECT timezone FROM user_settings WHERE user_id = ?').get(userId);
  return row ? row.timezone : null;
}

function setTimezone(userId, tz) {
  getDb()
    .prepare(
      `INSERT INTO user_settings (user_id, timezone) VALUES (@u, @tz)
       ON CONFLICT(user_id) DO UPDATE SET timezone = @tz`
    )
    .run({ u: userId, tz: tz || null });
  return tz || null;
}

module.exports = { isValidTimezone, getTimezone, setTimezone };
