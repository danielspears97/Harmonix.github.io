'use strict';

const { getConfig, setConfig } = require('../db');

// Each module groups a set of top-level command names + (for some) passive
// features. Disabling a module blocks its commands and silences its events.
const MODULES = [
  { key: 'music', label: '🎵 Music', cmds: ['play', 'queue', 'nowplaying', 'volume', 'setup', 'pause', 'resume', 'skip', 'previous', 'stop', 'leave', 'loop', 'mode', 'shuffle', 'seek', 'position', 'remove', 'clear', 'autoplay', 'dj', 'filter', 'voteskip', 'playlist', 'voicelock', 'controls', 'music', 'playnext'] },
  { key: 'moderation', label: '🛡️ Moderation', cmds: ['mod'] },
  { key: 'server', label: '⚙️ Server Management', cmds: ['server'] },
  { key: 'leveling', label: '⭐ Leveling', cmds: ['level'] },
  { key: 'economy', label: '💰 Economy', cmds: ['economy'] },
  { key: 'engagement', label: '🎉 Engagement', cmds: ['engage'] },
  { key: 'games', label: '🎮 Games', cmds: ['game'] },
  { key: 'fun', label: '😄 Fun', cmds: ['fun'] },
  { key: 'utility', label: '🔧 Utility', cmds: ['tools', 'util', 'lookup', 'timezone'] },
  { key: 'community', label: '🌐 Community', cmds: ['community'] },
  { key: 'automod', label: '🚫 AutoMod', cmds: ['automod'] },
  { key: 'nsfw', label: '🔞 NSFW', cmds: ['nsfw'] },
];

const MODULE_OF = {};
for (const m of MODULES) for (const c of m.cmds) MODULE_OF[c] = m.key;

// 'help' and 'status' are always available regardless of toggles.
const ALWAYS_ON = new Set(['help', 'status']);

function getDisabled(guildId) {
  return getConfig(guildId, 'disabled_modules', []) || [];
}
function setDisabled(guildId, list) {
  const keys = MODULES.map((m) => m.key);
  setConfig(guildId, 'disabled_modules', Array.isArray(list) ? list.filter((k) => keys.includes(k)) : []);
  return getDisabled(guildId);
}
function isModuleEnabled(guildId, key) {
  return !getDisabled(guildId).includes(key);
}
function moduleForCommand(commandName) {
  return MODULE_OF[commandName] || null;
}
/** True if the command may run in this guild (its module isn't disabled). */
function isCommandAllowed(guildId, commandName) {
  if (ALWAYS_ON.has(commandName)) return true;
  const mod = MODULE_OF[commandName];
  if (!mod) return true; // uncategorized commands stay available
  return isModuleEnabled(guildId, mod);
}

module.exports = { MODULES, getDisabled, setDisabled, isModuleEnabled, moduleForCommand, isCommandAllowed };
