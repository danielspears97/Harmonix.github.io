'use strict';

/**
 * Button-based reaction roles. A "panel" is a message with up to 25 role
 * buttons; clicking one toggles that role on the member. Button custom IDs are
 * `rr:<roleId>`, so the click handler is stateless — the DB exists so panels
 * can be edited (buttons added/removed) and listed later.
 */

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getDb } = require('../db');

const MAX_BUTTONS = 25;

function createPanel(guildId, channelId, messageId) {
  getDb()
    .prepare('INSERT INTO reaction_role_panels (message_id, guild_id, channel_id, created_at) VALUES (?, ?, ?, ?)')
    .run(messageId, guildId, channelId, Date.now());
}

function getPanel(messageId) {
  return getDb().prepare('SELECT * FROM reaction_role_panels WHERE message_id = ?').get(messageId);
}

function listPanels(guildId) {
  return getDb()
    .prepare(
      `SELECT p.*, COUNT(b.role_id) AS button_count
       FROM reaction_role_panels p
       LEFT JOIN reaction_role_buttons b ON b.message_id = p.message_id
       WHERE p.guild_id = ?
       GROUP BY p.message_id
       ORDER BY p.created_at DESC`
    )
    .all(guildId);
}

function getButtons(messageId) {
  return getDb()
    .prepare('SELECT * FROM reaction_role_buttons WHERE message_id = ? ORDER BY position ASC, rowid ASC')
    .all(messageId);
}

function addButton(messageId, { roleId, label, emoji, style = ButtonStyle.Secondary }) {
  const count = getButtons(messageId).length;
  getDb()
    .prepare(
      `INSERT INTO reaction_role_buttons (message_id, role_id, label, emoji, style, position)
       VALUES (@message_id, @role_id, @label, @emoji, @style, @position)
       ON CONFLICT(message_id, role_id) DO UPDATE SET
         label = excluded.label, emoji = excluded.emoji, style = excluded.style`
    )
    .run({ message_id: messageId, role_id: roleId, label: label ?? null, emoji: emoji ?? null, style, position: count });
}

function removeButton(messageId, roleId) {
  const info = getDb()
    .prepare('DELETE FROM reaction_role_buttons WHERE message_id = ? AND role_id = ?')
    .run(messageId, roleId);
  return info.changes > 0;
}

/** Build action rows (max 5 buttons each) from stored button rows. */
function buildComponents(buttons) {
  const rows = [];
  for (let i = 0; i < buttons.length; i += 5) {
    const row = new ActionRowBuilder();
    for (const b of buttons.slice(i, i + 5)) {
      const btn = new ButtonBuilder().setCustomId(`rr:${b.role_id}`).setStyle(b.style || ButtonStyle.Secondary);
      if (b.label) btn.setLabel(b.label);
      if (b.emoji) {
        try { btn.setEmoji(b.emoji); } catch { /* invalid emoji — skip it */ }
      }
      if (!b.label && !b.emoji) btn.setLabel('Role');
      row.addComponents(btn);
    }
    rows.push(row);
  }
  return rows;
}

module.exports = {
  MAX_BUTTONS,
  createPanel, getPanel, listPanels,
  getButtons, addButton, removeButton, buildComponents,
};
