'use strict';

/**
 * Parse a human duration string like "10m", "1h30m", "2d", "45s" into
 * milliseconds. Returns null if nothing parseable is found.
 */
const UNITS = {
  s: 1000,
  m: 60 * 1000,
  h: 60 * 60 * 1000,
  d: 24 * 60 * 60 * 1000,
  w: 7 * 24 * 60 * 60 * 1000,
};

function parseDuration(input) {
  if (input == null) return null;
  const str = String(input).trim().toLowerCase();
  if (!str) return null;

  // Plain number → treat as minutes (a sensible default for moderation).
  if (/^\d+$/.test(str)) return Number(str) * UNITS.m;

  const re = /(\d+)\s*(w|d|h|m|s)/g;
  let total = 0;
  let matched = false;
  let m;
  while ((m = re.exec(str)) !== null) {
    matched = true;
    total += Number(m[1]) * UNITS[m[2]];
  }
  return matched ? total : null;
}

/** Format milliseconds into a compact human string like "1d 2h 30m". */
function humanizeDuration(ms) {
  if (!ms || ms < 0) return '0s';
  const parts = [];
  const order = [
    ['w', UNITS.w],
    ['d', UNITS.d],
    ['h', UNITS.h],
    ['m', UNITS.m],
    ['s', UNITS.s],
  ];
  let remaining = ms;
  for (const [label, size] of order) {
    if (remaining >= size) {
      const n = Math.floor(remaining / size);
      remaining -= n * size;
      parts.push(`${n}${label}`);
    }
  }
  return parts.slice(0, 3).join(' ') || '0s';
}

module.exports = { parseDuration, humanizeDuration, UNITS };
