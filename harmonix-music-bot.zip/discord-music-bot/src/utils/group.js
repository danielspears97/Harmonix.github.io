'use strict';

const { SlashCommandBuilder } = require('discord.js');

/**
 * Build a single slash command made of subcommands, so many small commands can
 * share one top-level slot (Discord caps apps at 100 top-level commands).
 *
 * items: [{ name, description, setup?(sub), run(client, interaction) }]
 */
function buildGroup(name, description, items, defaultPermissions = null) {
  const data = new SlashCommandBuilder().setName(name).setDescription(description).setDMPermission(false);
  if (defaultPermissions != null) data.setDefaultMemberPermissions(defaultPermissions);
  for (const it of items) {
    data.addSubcommand((s) => {
      s.setName(it.name).setDescription(it.description);
      if (it.setup) it.setup(s);
      return s;
    });
  }
  const runners = new Map(items.map((it) => [it.name, it.run]));
  return {
    data,
    async execute(client, interaction) {
      const run = runners.get(interaction.options.getSubcommand());
      if (run) return run(client, interaction);
    },
  };
}

module.exports = { buildGroup };
