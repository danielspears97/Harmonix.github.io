'use strict';

const controller = require('../controller');
const guildSettings = require('../server/guildSettings');

function userVoiceChannel(interaction) {
  return interaction.member?.voice?.channelId || null;
}

/** Ensure the user shares the bot's voice channel (or the bot isn't connected yet). */
function voiceGuard(client, interaction) {
  const player = controller.getPlayer(client, interaction.guildId);
  const userVc = userVoiceChannel(interaction);
  if (!userVc) return { ok: false, msg: '🔇 Join a voice channel first.' };
  const lock = guildSettings.getMusicChannel(interaction.guildId);
  if (lock && userVc !== lock) {
    return { ok: false, msg: `🔒 Music is locked to <#${lock}>. Join that channel to use music.` };
  }
  if (player && player.voiceChannelId && player.voiceChannelId !== userVc) {
    return { ok: false, msg: '🔇 You need to be in my voice channel to do that.' };
  }
  return { ok: true, voiceChannelId: userVc, player };
}

module.exports = { userVoiceChannel, voiceGuard };
