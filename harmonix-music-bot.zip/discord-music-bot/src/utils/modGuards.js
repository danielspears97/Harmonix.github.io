'use strict';

/**
 * Shared safety checks for moderation commands. Returns { ok, msg }.
 *
 * Covers: acting on yourself / the bot / the server owner, moderator-vs-target
 * role hierarchy, and whether the bot is actually able to perform the action
 * (discord.js exposes .kickable / .bannable / .moderatable which already fold
 * in role position + the bot's permissions).
 */

function actionable(interaction, targetMember, kind) {
  const guild = interaction.guild;
  const me = guild.members.me;

  // These checks need a present member object.
  if (targetMember) {
    if (targetMember.id === interaction.user.id) {
      return { ok: false, msg: `You can’t ${kind} yourself.` };
    }
    if (targetMember.id === me.id) {
      return { ok: false, msg: `I can’t ${kind} myself.` };
    }
    if (targetMember.id === guild.ownerId) {
      return { ok: false, msg: `I can’t ${kind} the server owner.` };
    }

    // Moderator must outrank the target (the owner always outranks everyone).
    const modIsOwner = interaction.user.id === guild.ownerId;
    if (!modIsOwner) {
      const cmp = interaction.member.roles.highest.comparePositionTo(targetMember.roles.highest);
      if (cmp <= 0) {
        return { ok: false, msg: `You can’t ${kind} someone with an equal or higher role than you.` };
      }
    }

    // Bot capability per action type.
    const capable =
      kind === 'kick' ? targetMember.kickable
      : kind === 'ban' ? targetMember.bannable
      : kind === 'timeout' || kind === 'untimeout' ? targetMember.moderatable
      : true; // warn needs no Discord-side capability
    if (!capable) {
      return {
        ok: false,
        msg: `I can’t ${kind} that member — they’re likely above me in the role list, or I’m missing permission. Move my role higher and check my permissions.`,
      };
    }
  }

  return { ok: true };
}

/** Best-effort DM to a user about an action taken against them. */
async function notifyTarget(user, guildName, action, reason, extra = '') {
  try {
    const lines = [
      `You have been **${action}** in **${guildName}**.`,
      reason ? `**Reason:** ${reason}` : null,
      extra || null,
    ].filter(Boolean);
    await user.send(lines.join('\n'));
    return true;
  } catch {
    return false; // DMs closed — not an error
  }
}

module.exports = { actionable, notifyTarget };
