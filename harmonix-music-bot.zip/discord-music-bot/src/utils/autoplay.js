'use strict';

/**
 * Extract a YouTube video id from a track's uri / identifier.
 */
function youtubeId(track) {
  const id = track?.info?.identifier;
  const uri = track?.info?.uri || '';
  if (id && /^[\w-]{11}$/.test(id)) return id;
  const m = uri.match(/[?&]v=([\w-]{11})/) || uri.match(/youtu\.be\/([\w-]{11})/);
  return m ? m[1] : null;
}

/**
 * Find tracks to autoplay next, seeded from the last finished track.
 * Strategy:
 *   1. If the seed is a YouTube video, resolve its "Mix" radio playlist (RD<id>)
 *      which gives an endless, taste-matched stream.
 *   2. Otherwise fall back to a YouTube Music search of "<artist> <title>".
 * Already-played identifiers are filtered out to avoid loops.
 *
 * @returns {Promise<Array>} list of tracks (may be empty)
 */
async function findAutoplayTracks(player, seedTrack, played, limit = 5) {
  if (!seedTrack) return [];
  const requester = seedTrack.requester || player.get('lastRequester') || null;
  const results = [];

  const vid = youtubeId(seedTrack);
  if (vid) {
    try {
      const mixUrl = `https://www.youtube.com/watch?v=${vid}&list=RD${vid}`;
      const res = await player.search({ query: mixUrl }, requester);
      if (res?.tracks?.length) results.push(...res.tracks);
    } catch (err) {
      console.warn('[autoplay] mix lookup failed:', err.message);
    }
  }

  if (results.length === 0) {
    try {
      const author = seedTrack.info?.author || '';
      const title = seedTrack.info?.title || '';
      const query = `${author} ${title}`.trim() || title;
      const res = await player.search({ query, source: 'ytmsearch' }, requester);
      if (res?.tracks?.length) results.push(...res.tracks.slice(1)); // skip the seed itself
    } catch (err) {
      console.warn('[autoplay] search fallback failed:', err.message);
    }
  }

  // Filter out anything we've already played / the seed itself.
  const seen = played instanceof Set ? played : new Set();
  const seedId = seedTrack.info?.identifier;
  const picked = [];
  for (const t of results) {
    const id = t?.info?.identifier;
    if (!id || id === seedId || seen.has(id)) continue;
    picked.push(t);
    if (picked.length >= limit) break;
  }
  return picked;
}

module.exports = { findAutoplayTracks, youtubeId };
