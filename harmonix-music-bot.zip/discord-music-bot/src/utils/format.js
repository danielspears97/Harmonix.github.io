'use strict';

/** Convert milliseconds to a h:mm:ss / m:ss string. */
function msToTime(ms) {
  if (ms === null || ms === undefined || !Number.isFinite(ms) || ms < 0) return '0:00';
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  const pad = (n) => String(n).padStart(2, '0');
  if (hours > 0) return `${hours}:${pad(minutes)}:${pad(seconds)}`;
  return `${minutes}:${pad(seconds)}`;
}

/** Build a textual progress bar. */
function progressBar(position, duration, size = 18) {
  if (!duration || duration <= 0) return '🔴 LIVE';
  const ratio = Math.min(1, Math.max(0, position / duration));
  const filled = Math.round(ratio * size);
  const bar = '─'.repeat(Math.max(0, filled)) + '🔘' + '─'.repeat(Math.max(0, size - filled));
  return `\`${msToTime(position)}\` ${bar} \`${msToTime(duration)}\``;
}

/** Trim a string to a max length with an ellipsis. */
function truncate(str, max = 64) {
  if (!str) return '';
  return str.length > max ? `${str.slice(0, max - 1)}…` : str;
}

/** Friendly source label from a track. */
function sourceName(track) {
  const s = track?.info?.sourceName || 'unknown';
  const map = {
    youtube: 'YouTube',
    youtubemusic: 'YouTube Music',
    spotify: 'Spotify',
    soundcloud: 'SoundCloud',
    deezer: 'Deezer',
    applemusic: 'Apple Music',
    http: 'Direct',
  };
  return map[s] || s;
}

/** Human-friendly tag for a user, handling the new username system (no "#0"). */
function userTag(user) {
  if (!user) return 'Unknown';
  if (user.discriminator && user.discriminator !== '0') {
    return `${user.username}#${user.discriminator}`;
  }
  return user.username;
}

/**
 * Return the URL only if it's a well-formed http(s) URL, otherwise null.
 * Guards Discord embed builders, which throw on malformed image/link URLs
 * (a single bad track artwork URL would otherwise break the whole panel).
 */
function safeUrl(url) {
  if (typeof url !== 'string') return null;
  const u = url.trim();
  if (!/^https?:\/\//i.test(u)) return null;
  try {
    // eslint-disable-next-line no-new
    new URL(u);
    return u;
  } catch {
    return null;
  }
}

module.exports = { msToTime, progressBar, truncate, sourceName, userTag, safeUrl };
