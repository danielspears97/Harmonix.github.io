'use strict';

// Bridges classic text commands (e.g. "!play song") onto the existing
// slash-command handlers by parsing args against each command's declared
// option schema and synthesising a minimal interaction-like object.

const guildSettings = require('../server/guildSettings');
const usage = require('../server/usage');

// ApplicationCommandOptionType
const T = { SUB: 1, GROUP: 2, STRING: 3, INTEGER: 4, BOOLEAN: 5, USER: 6, CHANNEL: 7, ROLE: 8, MENTIONABLE: 9, NUMBER: 10 };

function tokenize(str) {
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  const out = [];
  let m;
  while ((m = re.exec(str))) out.push(m[1] ?? m[2] ?? m[3]);
  return out;
}
function parseId(raw) {
  const m = String(raw || '').match(/\d{5,}/);
  return m ? m[0] : null;
}

/** Resolve which subcommand/group + leaf options a token list maps to. */
function route(json, tokens) {
  let group = null, sub = null, leaf = json.options || [];
  const groups = leaf.filter((o) => o.type === T.GROUP);
  const subs = leaf.filter((o) => o.type === T.SUB);
  if (groups.length || subs.length) {
    const t0 = (tokens[0] || '').toLowerCase();
    const grp = groups.find((g) => g.name === t0);
    if (grp) {
      group = grp.name; tokens.shift();
      const t1 = (tokens.shift() || '').toLowerCase();
      const sc = (grp.options || []).find((s) => s.name === t1);
      if (!sc) return { error: `Usage: \`${json.name} ${group} <${(grp.options || []).map((s) => s.name).join('|')}>\`` };
      sub = sc.name; leaf = sc.options || [];
    } else {
      const sc = subs.find((s) => s.name === t0);
      if (sc) { sub = sc.name; tokens.shift(); leaf = sc.options || []; }
      else return { error: `Usage: \`${json.name} <${[...groups, ...subs].map((s) => s.name).join('|')}> …\`` };
    }
  }
  return { group, sub, leaf, tokens };
}

/** Map remaining tokens to leaf options (the last string option takes the rest). */
function assign(leaf, tokens) {
  const out = [];
  const missing = [];
  let ptr = 0;
  for (let i = 0; i < leaf.length; i++) {
    const opt = leaf[i];
    if (ptr >= tokens.length) { if (opt.required) missing.push(opt.name); continue; }
    let raw;
    if (opt.type === T.STRING && i === leaf.length - 1) { raw = tokens.slice(ptr).join(' '); ptr = tokens.length; }
    else { raw = tokens[ptr]; ptr += 1; }
    out.push({ opt, raw });
  }
  return { assignments: out, missing };
}

async function resolveValues(message, client, assignments) {
  const map = new Map();
  for (const { opt, raw } of assignments) {
    const t = opt.type;
    if (t === T.USER || t === T.MENTIONABLE) {
      const id = parseId(raw);
      const user = (id && (message.mentions.users.get(id) || (await client.users.fetch(id).catch(() => null)))) || null;
      const member = (id && (message.guild.members.cache.get(id) || (await message.guild.members.fetch(id).catch(() => null)))) || null;
      map.set(opt.name, { user, member, role: null });
    } else if (t === T.CHANNEL) {
      const id = parseId(raw);
      map.set(opt.name, { channel: (id && message.guild.channels.cache.get(id)) || null });
    } else if (t === T.ROLE) {
      const id = parseId(raw);
      map.set(opt.name, { role: (id && message.guild.roles.cache.get(id)) || null });
    } else if (t === T.INTEGER || t === T.NUMBER) {
      const n = Number(raw);
      map.set(opt.name, { number: Number.isFinite(n) ? n : null });
    } else if (t === T.BOOLEAN) {
      map.set(opt.name, { bool: /^(true|yes|on|1)$/i.test(raw) });
    } else {
      map.set(opt.name, { string: raw });
    }
  }
  return map;
}

function makeOptions(group, sub, values) {
  const v = (n) => values.get(n);
  return {
    getSubcommand: (req = true) => { if (!sub && req) throw new Error('No subcommand'); return sub; },
    getSubcommandGroup: () => group,
    getString: (n) => v(n)?.string ?? null,
    getInteger: (n) => { const x = v(n); return x && x.number != null ? Math.trunc(x.number) : null; },
    getNumber: (n) => { const x = v(n); return x && x.number != null ? x.number : null; },
    getBoolean: (n) => { const x = v(n); return x ? x.bool : null; },
    getUser: (n) => v(n)?.user ?? null,
    getMember: (n) => v(n)?.member ?? null,
    getChannel: (n) => v(n)?.channel ?? null,
    getRole: (n) => v(n)?.role ?? null,
    getMentionable: (n) => { const x = v(n); return x ? x.member || x.role || x.user || null : null; },
    getAttachment: () => null,
    getFocused: () => '',
  };
}

function makeInteraction(message, client, commandName, options) {
  const state = { replied: false, deferred: false, msg: null };
  const norm = (o) => {
    if (typeof o === 'string') o = { content: o };
    const out = {};
    for (const k of ['content', 'embeds', 'components', 'files', 'allowedMentions']) if (o[k] != null) out[k] = o[k];
    return out; // ephemeral/flags intentionally dropped (text can't be ephemeral)
  };
  return {
    isChatInputCommand: () => true,
    isButton: () => false,
    isStringSelectMenu: () => false,
    isAutocomplete: () => false,
    isRepliable: () => true,
    inGuild: () => true,
    commandName,
    options,
    client,
    guild: message.guild,
    guildId: message.guildId,
    channel: message.channel,
    channelId: message.channelId,
    user: message.author,
    member: message.member,
    memberPermissions: message.member?.permissions,
    appPermissions: message.guild?.members?.me?.permissions,
    locale: 'en-US',
    createdTimestamp: message.createdTimestamp,
    get replied() { return state.replied; },
    get deferred() { return state.deferred; },
    async reply(o) { state.msg = await message.channel.send(norm(o)); state.replied = true; return state.msg; },
    async deferReply() { state.deferred = true; await message.channel.sendTyping().catch(() => {}); },
    async editReply(o) { if (state.msg) { await state.msg.edit(norm(o)).catch(() => {}); return state.msg; } state.msg = await message.channel.send(norm(o)); state.replied = true; return state.msg; },
    async followUp(o) { return message.channel.send(norm(o)); },
    async fetchReply() { return state.msg; },
    async deleteReply() { if (state.msg) await state.msg.delete().catch(() => {}); },
  };
}

async function handleMessage(client, message) {
  if (!message.guild || message.author.bot || !message.content) return;
  const prefix = guildSettings.getPrefix(message.guild.id);
  if (!message.content.startsWith(prefix)) return;

  const tokens = tokenize(message.content.slice(prefix.length).trim());
  if (!tokens.length) return;
  const name = tokens.shift().toLowerCase();
  const command = client.commands.get(name);
  if (!command) return; // unknown command — stay silent

  const json = command.data.toJSON();
  const routed = route(json, tokens);
  if (routed.error) return message.reply({ content: `❌ ${routed.error}`, allowedMentions: { repliedUser: false } }).catch(() => {});

  const { assignments, missing } = assign(routed.leaf, routed.tokens);
  if (missing.length) {
    const path = [name, routed.group, routed.sub].filter(Boolean).join(' ');
    return message.reply({ content: `❌ Missing required: **${missing.join(', ')}**\nUsage: \`${path} ${routed.leaf.map((o) => (o.required ? `<${o.name}>` : `[${o.name}]`)).join(' ')}\``, allowedMentions: { repliedUser: false } }).catch(() => {});
  }

  // Gating (mirror the slash path).
  const path = [name, routed.group, routed.sub].filter(Boolean).join(' ');
  if (name !== 'help') {
    const level = guildSettings.memberPowerLevel(message.member);
    const gate = guildSettings.checkCommand(message.guild.id, path, message.channel.id, level);
    if (!gate.ok) {
      const reason = gate.reason === 'disabled' ? 'That command is disabled here.'
        : gate.reason === 'level' ? `You need power level ${gate.required} to use that command.`
          : 'That command can’t be used in this channel.';
      return message.reply({ content: reason, allowedMentions: { repliedUser: false } }).catch(() => {});
    }
  }

  const values = await resolveValues(message, client, assignments);
  const options = makeOptions(routed.group, routed.sub, values);
  const interaction = makeInteraction(message, client, name, options);

  try {
    await command.execute(client, interaction);
    try { usage.record(message.guild.id, name); } catch { /* ignore */ }
  } catch (err) {
    console.error('[prefix] command error:', err);
    await message.reply({ content: '❌ Something went wrong running that command.', allowedMentions: { repliedUser: false } }).catch(() => {});
  }
}

module.exports = { handleMessage, tokenize, route, assign };
