'use strict';

const { SlashCommandBuilder } = require('discord.js');

/**
 * Copy a single option (from a command's toJSON) onto a subcommand builder,
 * preserving type, required, choices, ranges, channel types, and autocomplete.
 */
function applyOption(sub, opt) {
  const cfg = (o) => {
    o.setName(opt.name).setDescription(opt.description || opt.name);
    if (opt.required) o.setRequired(true);
    if (opt.choices && o.addChoices) o.addChoices(...opt.choices.map((c) => ({ name: c.name, value: c.value })));
    if (opt.min_value != null && o.setMinValue) o.setMinValue(opt.min_value);
    if (opt.max_value != null && o.setMaxValue) o.setMaxValue(opt.max_value);
    if (opt.min_length != null && o.setMinLength) o.setMinLength(opt.min_length);
    if (opt.max_length != null && o.setMaxLength) o.setMaxLength(opt.max_length);
    if (opt.channel_types && o.addChannelTypes) o.addChannelTypes(...opt.channel_types);
    if (opt.autocomplete && o.setAutocomplete) o.setAutocomplete(true);
    return o;
  };
  switch (opt.type) {
    case 3: return sub.addStringOption(cfg);
    case 4: return sub.addIntegerOption(cfg);
    case 5: return sub.addBooleanOption(cfg);
    case 6: return sub.addUserOption(cfg);
    case 7: return sub.addChannelOption(cfg);
    case 8: return sub.addRoleOption(cfg);
    case 9: return sub.addMentionableOption(cfg);
    case 10: return sub.addNumberOption(cfg);
    case 11: return sub.addAttachmentOption(cfg);
    default: return sub;
  }
}

function addSubFromJson(builder, subJson) {
  builder.addSubcommand((s) => {
    s.setName(subJson.name).setDescription(subJson.description || subJson.name);
    for (const o of subJson.options || []) applyOption(s, o);
    return s;
  });
}
function addGroupFromJson(builder, grpJson) {
  builder.addSubcommandGroup((g) => {
    g.setName(grpJson.name).setDescription(grpJson.description || grpJson.name);
    for (const sub of grpJson.options || []) if (sub.type === 1) addSubFromJson(g, sub);
    return g;
  });
}

/**
 * Build a parent command from leaf command modules.
 *
 * entries: each is a command module ({ data, execute }) or { module, promote }.
 *  - plain command  → becomes a subcommand (routed by its name)
 *  - command w/ subs → becomes a subcommand-group (routed by its name)
 *  - { promote:true } → the command's own subcommands/groups are lifted directly
 *                       under the parent (used when a leaf already nests a group)
 */
function composeCategory(name, description, entries, defaultPermissions = null) {
  const data = new SlashCommandBuilder().setName(name).setDescription(description).setDMPermission(false);
  if (defaultPermissions != null) data.setDefaultMemberPermissions(defaultPermissions);
  const route = new Map();

  for (const entry of entries) {
    const mod = entry.module || entry;
    const promote = !!entry.promote;
    const j = mod.data.toJSON();
    const opts = j.options || [];
    const hasSubs = opts.some((o) => o.type === 1 || o.type === 2);

    if (!hasSubs) {
      data.addSubcommand((s) => {
        s.setName(j.name).setDescription(j.description);
        for (const o of opts) applyOption(s, o);
        return s;
      });
      route.set(j.name, mod.execute);
    } else if (promote) {
      for (const o of opts) {
        if (o.type === 1) { addSubFromJson(data, o); route.set(o.name, mod.execute); }
        else if (o.type === 2) { addGroupFromJson(data, o); route.set(o.name, mod.execute); }
      }
    } else {
      data.addSubcommandGroup((g) => {
        g.setName(j.name).setDescription(j.description);
        for (const sub of opts) if (sub.type === 1) addSubFromJson(g, sub);
        return g;
      });
      route.set(j.name, mod.execute);
    }
  }

  return {
    data,
    async execute(client, interaction) {
      const key = interaction.options.getSubcommandGroup(false) || interaction.options.getSubcommand();
      const fn = route.get(key);
      if (fn) return fn(client, interaction);
    },
  };
}

module.exports = { composeCategory, applyOption };
