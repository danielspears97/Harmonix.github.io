'use strict';
const { EventEmitter } = require('events');

// A single shared event bus. Emits 'stateChange' with a guildId whenever
// a player's state changes so the control panel and the web dashboard can refresh.
class Bus extends EventEmitter {}
const bus = new Bus();
bus.setMaxListeners(50);

function notify(guildId) {
  bus.emit('stateChange', guildId);
}

module.exports = { bus, notify };
