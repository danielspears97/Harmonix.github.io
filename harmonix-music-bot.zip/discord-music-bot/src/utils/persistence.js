'use strict';

/**
 * Per-guild settings store.
 *
 * Backed by SQLite (src/db) but presents the exact same synchronous API the
 * rest of the bot already uses — load(), getGuild(id), setGuild(id, patch),
 * DEFAULTS — so it's a drop-in replacement for the old JSON file store.
 *
 * On first run it transparently imports an existing data/guilds.json (from
 * older builds) into the database, then renames it to guilds.json.migrated.
 */

const fs = require('fs');
const path = require('path');
const { getDb } = require('../db');

const DEFAULTS = {
  controlChannelId: null,
  controlMessageId: null,
  twentyFourSeven: false,
  autoplay: false,
  volume: null, // null = use global default
};

const cache = new Map(); // guildId -> settings object

// ── row <-> object mapping ───────────────────────────────────────
function rowToSettings(row) {
  if (!row) return { ...DEFAULTS };
  return {
    controlChannelId: row.control_channel_id ?? null,
    controlMessageId: row.control_message_id ?? null,
    twentyFourSeven: !!row.twenty_four_seven,
    autoplay: !!row.autoplay,
    volume: row.volume ?? null,
  };
}

function upsert(guildId, s) {
  getDb()
    .prepare(
      `INSERT INTO guild_settings
         (guild_id, control_channel_id, control_message_id, twenty_four_seven, autoplay, volume)
       VALUES (@guild_id, @control_channel_id, @control_message_id, @twenty_four_seven, @autoplay, @volume)
       ON CONFLICT(guild_id) DO UPDATE SET
         control_channel_id = excluded.control_channel_id,
         control_message_id = excluded.control_message_id,
         twenty_four_seven  = excluded.twenty_four_seven,
         autoplay           = excluded.autoplay,
         volume             = excluded.volume`
    )
    .run({
      guild_id: guildId,
      control_channel_id: s.controlChannelId ?? null,
      control_message_id: s.controlMessageId ?? null,
      twenty_four_seven: s.twentyFourSeven ? 1 : 0,
      autoplay: s.autoplay ? 1 : 0,
      volume: s.volume ?? null,
    });
}

// ── one-time JSON → SQLite import ────────────────────────────────
function migrateLegacyJson() {
  const file = path.join(__dirname, '..', '..', 'data', 'guilds.json');
  if (!fs.existsSync(file)) return;
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf8')) || {};
    const entries = Object.entries(data);
    if (entries.length) {
      const tx = getDb().transaction((rows) => {
        for (const [guildId, raw] of rows) {
          upsert(guildId, { ...DEFAULTS, ...raw });
        }
      });
      tx(entries);
      console.log(`[persistence] imported ${entries.length} guild(s) from legacy guilds.json`);
    }
    fs.renameSync(file, file + '.migrated');
  } catch (err) {
    console.error('[persistence] legacy import failed:', err.message);
  }
}

// ── public API ───────────────────────────────────────────────────
function load() {
  getDb(); // ensure DB is open + schema applied
  migrateLegacyJson();
  cache.clear();
  const rows = getDb().prepare('SELECT * FROM guild_settings').all();
  for (const row of rows) cache.set(row.guild_id, rowToSettings(row));
  return cache;
}

function getGuild(guildId) {
  let s = cache.get(guildId);
  if (!s) {
    const row = getDb().prepare('SELECT * FROM guild_settings WHERE guild_id = ?').get(guildId);
    s = rowToSettings(row);
    cache.set(guildId, s);
  }
  return s;
}

function setGuild(guildId, patch) {
  const s = getGuild(guildId);
  Object.assign(s, patch);
  cache.set(guildId, s);
  upsert(guildId, s);
  return s;
}

module.exports = { load, getGuild, setGuild, DEFAULTS };
