'use strict';

const { PermissionFlagsBits } = require('discord.js');
const verification = require('../moderation/verification');

async function handleVerifyButton(client, interaction) {
  const settings = verification.getSettings(interaction.guildId);
  if (!settings.roleId) return interaction.reply({ content: 'Verification isn’t set up here.', ephemeral: true });

  const role = interaction.guild.roles.cache.get(settings.roleId);
  if (!role) return interaction.reply({ content: 'The verification role no longer exists. Ask an admin to re-run setup.', ephemeral: true });

  if (interaction.member.roles.cache.has(role.id)) {
    return interaction.reply({ content: '✅ You’re already verified.', ephemeral: true });
  }

  if (settings.minAccountDays > 0) {
    const ageDays = (Date.now() - interaction.user.createdTimestamp) / 86400000;
    if (ageDays < settings.minAccountDays) {
      return interaction.reply({ content: `Your account must be at least ${settings.minAccountDays} day(s) old to verify here.`, ephemeral: true });
    }
  }

  const me = interaction.guild.members.me;
  if (!me.permissions.has(PermissionFlagsBits.ManageRoles) || role.position >= me.roles.highest.position) {
    return interaction.reply({ content: '⚠️ I can’t assign that role — check that I have **Manage Roles** and that my role is above the verification role.', ephemeral: true });
  }

  try {
    await interaction.member.roles.add(role.id, 'Verification');
    return interaction.reply({ content: `✅ You’re verified — welcome!`, ephemeral: true });
  } catch {
    return interaction.reply({ content: 'Something went wrong assigning the role. Please ping a moderator.', ephemeral: true });
  }
}

module.exports = { handleVerifyButton };
