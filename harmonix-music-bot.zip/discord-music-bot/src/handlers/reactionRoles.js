'use strict';

const { PermissionFlagsBits } = require('discord.js');

async function handleReactionRoleButton(client, interaction) {
  const roleId = interaction.customId.slice(3); // strip "rr:"
  const guild = interaction.guild;
  if (!guild) return;

  const role = guild.roles.cache.get(roleId) || (await guild.roles.fetch(roleId).catch(() => null));
  if (!role) {
    return interaction.reply({ content: 'That role no longer exists.', ephemeral: true });
  }

  const me = guild.members.me;
  if (!me.permissions.has(PermissionFlagsBits.ManageRoles) || role.position >= me.roles.highest.position) {
    return interaction.reply({
      content: 'I can’t assign that role — it’s above my highest role, or I’m missing **Manage Roles**.',
      ephemeral: true,
    });
  }

  const member = interaction.member;
  try {
    if (member.roles.cache.has(roleId)) {
      await member.roles.remove(roleId, 'Reaction role');
      return interaction.reply({ content: `Removed **${role.name}**.`, ephemeral: true });
    }
    await member.roles.add(roleId, 'Reaction role');
    return interaction.reply({ content: `Added **${role.name}**.`, ephemeral: true });
  } catch (err) {
    return interaction.reply({ content: `Couldn’t update your roles: ${err.message}`, ephemeral: true });
  }
}

module.exports = { handleReactionRoleButton };
