'use strict';

const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  AttachmentBuilder, ChannelType, PermissionFlagsBits,
} = require('discord.js');
const tickets = require('../moderation/tickets');
const { config } = require('../../config');
const { userTag } = require('../utils/format');

function controlRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket:claim').setLabel('Claim').setEmoji('🙋').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket:close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger)
  );
}

function isStaff(member, settings) {
  if (!member) return false;
  if (settings.staffRoleId && member.roles.cache.has(settings.staffRoleId)) return true;
  return member.permissions.has(PermissionFlagsBits.ManageMessages);
}

async function handleTicketButton(client, interaction) {
  const [, action] = interaction.customId.split(':');
  const settings = tickets.getSettings(interaction.guildId);

  if (action === 'open') return openTicket(client, interaction, settings);
  if (action === 'claim') return claimTicket(client, interaction, settings);
  if (action === 'close') return closeTicket(client, interaction, settings);
}

async function openTicket(client, interaction, settings) {
  const guild = interaction.guild;
  const me = guild.members.me;
  if (!me.permissions.has(PermissionFlagsBits.ManageChannels)) {
    return interaction.reply({ content: '⚠️ I need the **Manage Channels** permission to open tickets.', ephemeral: true });
  }
  const existing = tickets.getOpenByUser(guild.id, interaction.user.id);
  if (existing) {
    return interaction.reply({ content: `You already have an open ticket: <#${existing.channel_id}>`, ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });
  const number = tickets.nextNumber(guild.id);
  const overwrites = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
    { id: me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] },
  ];
  if (settings.staffRoleId) {
    overwrites.push({ id: settings.staffRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
  }

  let channel;
  try {
    channel = await guild.channels.create({
      name: `ticket-${String(number).padStart(4, '0')}`,
      type: ChannelType.GuildText,
      parent: settings.categoryId || null,
      topic: `Ticket #${number} • opened by ${userTag(interaction.user)} (${interaction.user.id})`,
      permissionOverwrites: overwrites,
    });
  } catch (err) {
    return interaction.editReply({ content: `⚠️ Couldn’t create the ticket channel: ${err.message}` });
  }

  tickets.create(guild.id, channel.id, interaction.user.id, number);

  const embed = new EmbedBuilder()
    .setColor(config.brand.color)
    .setTitle(`🎟️ Ticket #${number}`)
    .setDescription(`Thanks for reaching out, <@${interaction.user.id}>. Describe your issue and the team will be with you shortly.\n\nStaff can **Claim** this ticket; anyone involved can **Close** it.`)
    .setTimestamp();
  const ping = settings.staffRoleId ? `<@${interaction.user.id}> <@&${settings.staffRoleId}>` : `<@${interaction.user.id}>`;
  await channel.send({ content: ping, embeds: [embed], components: [controlRow()], allowedMentions: { users: [interaction.user.id], roles: settings.staffRoleId ? [settings.staffRoleId] : [] } });

  return interaction.editReply({ content: `✅ Ticket created: <#${channel.id}>` });
}

async function claimTicket(client, interaction, settings) {
  const ticket = tickets.getByChannel(interaction.channelId);
  if (!ticket) return interaction.reply({ content: 'This isn’t a ticket channel.', ephemeral: true });
  if (!isStaff(interaction.member, settings)) return interaction.reply({ content: 'Only staff can claim tickets.', ephemeral: true });
  tickets.claim(interaction.channelId, interaction.user.id);
  await interaction.reply({ content: `🙋 Claimed by <@${interaction.user.id}>.` });
}

async function closeTicket(client, interaction, settings) {
  const ticket = tickets.getByChannel(interaction.channelId);
  if (!ticket) return interaction.reply({ content: 'This isn’t a ticket channel.', ephemeral: true });
  const isOpener = ticket.user_id === interaction.user.id;
  if (!isOpener && !isStaff(interaction.member, settings)) {
    return interaction.reply({ content: 'Only the ticket opener or staff can close this.', ephemeral: true });
  }

  await interaction.reply({ content: `🔒 Ticket closed by <@${interaction.user.id}>. Saving a transcript and deleting this channel in 5 seconds…` });
  tickets.markClosed(interaction.channelId);

  // Build a transcript from recent messages (oldest → newest).
  let transcript = `Transcript — Ticket #${ticket.number}\nGuild: ${interaction.guild.name}\nOpened by user ID ${ticket.user_id}\nClosed by ${userTag(interaction.user)} at ${new Date().toISOString()}\n\n`;
  try {
    const fetched = await interaction.channel.messages.fetch({ limit: 100 });
    const ordered = [...fetched.values()].reverse();
    for (const m of ordered) {
      const when = new Date(m.createdTimestamp).toISOString();
      const content = m.content || (m.embeds.length ? '[embed]' : m.attachments.size ? '[attachment]' : '');
      transcript += `[${when}] ${userTag(m.author)}: ${content}\n`;
    }
  } catch { transcript += '(could not fetch messages)\n'; }

  const file = new AttachmentBuilder(Buffer.from(transcript, 'utf8'), { name: `ticket-${String(ticket.number).padStart(4, '0')}.txt` });
  const summary = new EmbedBuilder()
    .setColor(0x6b7280)
    .setTitle(`🎟️ Ticket #${ticket.number} closed`)
    .addFields(
      { name: 'Opened by', value: `<@${ticket.user_id}>`, inline: true },
      { name: 'Closed by', value: `<@${interaction.user.id}>`, inline: true },
      { name: 'Claimed by', value: ticket.claimed_by ? `<@${ticket.claimed_by}>` : 'Unclaimed', inline: true }
    )
    .setTimestamp();

  if (settings.logChannelId) {
    const logCh = await client.channels.fetch(settings.logChannelId).catch(() => null);
    if (logCh && logCh.isTextBased()) await logCh.send({ embeds: [summary], files: [file] }).catch(() => {});
  }
  const opener = await client.users.fetch(ticket.user_id).catch(() => null);
  if (opener) await opener.send({ content: `Your ticket #${ticket.number} in **${interaction.guild.name}** was closed. Transcript attached.`, files: [file] }).catch(() => {});

  setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
}

module.exports = { handleTicketButton, controlRow, closeTicket };
