'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');

const { config } = require('../../config');
const { getGuild, setGuild } = require('../utils/persistence');
const { getState } = require('../controller');
const { bus } = require('../utils/bus');
const { msToTime, progressBar, truncate, safeUrl } = require('../utils/format');

const LOOP_LABEL = { off: 'Loop: Off', track: 'Loop: Track', queue: 'Loop: Queue' };

function buildEmbed(state) {
  const embed = new EmbedBuilder().setColor(config.brand.color);

  if (!state.current) {
    embed
      .setAuthor({ name: `${config.brand.name} • Music Controls` })
      .setTitle('Nothing is playing right now')
      .setDescription(
        [
          'Join a voice channel and **type a song name or link** in this channel,',
          'or use `/play <query>`.',
          '',
          'Supports **YouTube**, **Spotify**, and **SoundCloud** links & searches.',
          'Use the buttons below to control playback once a track is queued.',
        ].join('\n')
      )
      .setFooter({ text: `Autoplay ${state.autoplay ? 'ON' : 'OFF'} • 24/7 ${state.twentyFourSeven ? 'ON' : 'OFF'} • Volume ${state.volume}%` });
    return embed;
  }

  const t = state.current;
  const uri = safeUrl(t.uri);
  const art = safeUrl(t.artworkUrl);
  const bar = t.isStream ? '🔴 **LIVE**' : progressBar(state.position, t.duration);
  const timeLine = t.isStream ? '' : `\n\`${msToTime(state.position)} / ${msToTime(t.duration)}\``;

  const meta = [
    t.requester ? `Requested by <@${t.requester.id}>` : 'Added by autoplay',
    t.sourceName,
  ].filter(Boolean).join('  •  ');

  embed
    .setAuthor({ name: state.paused ? '⏸  Paused' : '▶  Now Playing' })
    .setTitle(truncate(t.title, 100))
    .setDescription(`**${truncate(t.author, 60) || '—'}**\n\n${bar}${timeLine}\n\n${meta}`)
    .setFooter({
      text: `Volume ${state.volume}%  •  ${LOOP_LABEL[state.repeatMode] || 'Loop: Off'}  •  Autoplay ${state.autoplay ? 'ON' : 'OFF'}  •  24/7 ${state.twentyFourSeven ? 'ON' : 'OFF'}`,
    });

  if (uri) embed.setURL(uri);
  if (art) embed.setImage(art); // large, full-width cover art — the focal point

  if (state.queue.length) {
    const upNext = state.queue
      .slice(0, 5)
      .map((q, i) => `\`${i + 1}.\` ${truncate(q.title, 50)}`)
      .join('\n');
    const more = state.queue.length > 5 ? `\n*…and ${state.queue.length - 5} more*` : '';
    embed.addFields({ name: `Up next · ${state.queue.length} in queue`, value: upNext + more });
  }
  return embed;
}

function buildComponents(state) {
  const playing = !!state.current;
  const loopOn = state.repeatMode && state.repeatMode !== 'off';

  // Row 1 — core transport. Five uniform icon buttons so the row fills the
  // full message width and reads as evenly balanced.
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mc:prev').setEmoji('⏮️').setStyle(ButtonStyle.Secondary).setDisabled(!playing),
    new ButtonBuilder()
      .setCustomId('mc:pause')
      .setEmoji(state.paused ? '▶️' : '⏸️')
      .setStyle(state.paused ? ButtonStyle.Success : ButtonStyle.Primary)
      .setDisabled(!playing),
    new ButtonBuilder().setCustomId('mc:skip').setEmoji('⏭️').setStyle(ButtonStyle.Secondary).setDisabled(!playing),
    new ButtonBuilder().setCustomId('mc:stop').setEmoji('⏹️').setStyle(ButtonStyle.Danger).setDisabled(!playing),
    new ButtonBuilder().setCustomId('mc:shuffle').setEmoji('🔀').setStyle(ButtonStyle.Secondary).setDisabled(state.queue.length < 2)
  );

  // Row 2 — sound, loop & queue tools. Another full, uniform icon row.
  // Loop turns green when active; Clear stays red as it's destructive.
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('mc:voldown').setEmoji('🔉').setStyle(ButtonStyle.Secondary).setDisabled(!playing),
    new ButtonBuilder().setCustomId('mc:volup').setEmoji('🔊').setStyle(ButtonStyle.Secondary).setDisabled(!playing),
    new ButtonBuilder().setCustomId('mc:loop').setEmoji('🔁').setStyle(loopOn ? ButtonStyle.Success : ButtonStyle.Secondary).setDisabled(!playing),
    new ButtonBuilder().setCustomId('mc:queue').setEmoji('📜').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('mc:clear').setEmoji('🧹').setStyle(ButtonStyle.Danger).setDisabled(!state.queue.length)
  );

  // Row 3 — the two mode toggles (which benefit from text labels) plus the
  // dashboard link, so it isn't stranded on a row of its own.
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('mc:autoplay')
      .setEmoji('♾️')
      .setLabel('Autoplay')
      .setStyle(state.autoplay ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('mc:247')
      .setEmoji('🕒')
      .setLabel('24/7')
      .setStyle(state.twentyFourSeven ? ButtonStyle.Success : ButtonStyle.Secondary)
  );

  if (config.dashboard.enabled) {
    const base = (config.dashboard.publicUrl && config.dashboard.publicUrl.replace(/\/+$/, '')) || `http://localhost:${config.dashboard.port}`;
    // Carry the guild so the dashboard opens on the server you clicked from.
    const url = state.guildId ? `${base}/?guild=${encodeURIComponent(state.guildId)}` : base;
    row3.addComponents(
      new ButtonBuilder()
        .setLabel('Dashboard')
        .setEmoji('🖥️')
        .setStyle(ButtonStyle.Link)
        .setURL(url)
    );
  }

  return [row1, row2, row3];
}

async function renderPanel(client, guildId) {
  const settings = getGuild(guildId);
  if (!settings.controlChannelId) return null;
  const state = getState(client, guildId);
  return {
    embeds: [buildEmbed(state)],
    components: buildComponents(state),
  };
}

/** Create or refresh the panel message in the configured control channel. */
async function ensurePanelMessage(client, guildId) {
  const settings = getGuild(guildId);
  if (!settings.controlChannelId) return null;
  const channel = await client.channels.fetch(settings.controlChannelId).catch(() => null);
  if (!channel) return null;

  const payload = await renderPanel(client, guildId);
  if (!payload) return null;

  let message = null;
  if (settings.controlMessageId) {
    message = await channel.messages.fetch(settings.controlMessageId).catch(() => null);
  }
  if (message) {
    await message.edit(payload).catch(() => null);
  } else {
    message = await channel.send(payload).catch(() => null);
    if (message) setGuild(guildId, { controlMessageId: message.id });
  }
  return message;
}

// ── live update plumbing ──────────────────────────────────────
const pending = new Map(); // guildId -> timeout (debounce)
const progressTimers = new Map(); // guildId -> interval

function scheduleUpdate(client, guildId) {
  if (pending.has(guildId)) return;
  pending.set(
    guildId,
    setTimeout(async () => {
      pending.delete(guildId);
      await ensurePanelMessage(client, guildId).catch(() => {});
    }, 600)
  );
}

/** Start/stop a slow progress-bar refresh while a track plays. */
function manageProgressTimer(client, guildId) {
  const state = getState(client, guildId);
  const active = state.playing && !state.paused && state.current && !state.current.isStream;
  const has = progressTimers.has(guildId);
  if (active && !has) {
    progressTimers.set(
      guildId,
      setInterval(() => ensurePanelMessage(client, guildId).catch(() => {}), 12000)
    );
  } else if (!active && has) {
    clearInterval(progressTimers.get(guildId));
    progressTimers.delete(guildId);
  }
}

/** Wire the panel up to the shared event bus. Call once at startup. */
function attachPanelUpdates(client) {
  bus.on('stateChange', (guildId) => {
    scheduleUpdate(client, guildId);
    manageProgressTimer(client, guildId);
  });
}

module.exports = {
  buildEmbed,
  buildComponents,
  renderPanel,
  ensurePanelMessage,
  attachPanelUpdates,
};
