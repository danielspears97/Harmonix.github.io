'use strict';

const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionFlagsBits } = require('discord.js');
const roleMenus = require('../community/roleMenus');
const { config } = require('../../config');

function buildComponents(menu, id) {
  if (!menu.roles.length) return [];
  const select = new StringSelectMenuBuilder()
    .setCustomId(`rolemenu:${id}`)
    .setPlaceholder('Pick roles to toggle…')
    .setMinValues(0)
    .setMaxValues(menu.roles.length)
    .addOptions(
      menu.roles.map((r) => {
        const opt = { label: r.label, value: r.roleId };
        if (r.description) opt.description = r.description.slice(0, 100);
        if (r.emoji) opt.emoji = r.emoji;
        return opt;
      })
    );
  return [new ActionRowBuilder().addComponents(select)];
}

function buildEmbed(menu) {
  const lines = menu.roles.map((r) => `${r.emoji ? r.emoji + ' ' : ''}<@&${r.roleId}>${r.description ? ` — ${r.description}` : ''}`);
  return new EmbedBuilder()
    .setColor(config.brand.color)
    .setTitle(menu.title)
    .setDescription((menu.description ? menu.description + '\n\n' : '') + (lines.length ? lines.join('\n') : '*No roles yet — an admin can add some.*'));
}

/** Re-render the posted menu message after a change. */
async function rerender(client, guildId, id) {
  const menu = roleMenus.get(guildId, id);
  if (!menu || !menu.messageId) return;
  const channel = await client.channels.fetch(menu.channelId).catch(() => null);
  if (!channel) return;
  const msg = await channel.messages.fetch(menu.messageId).catch(() => null);
  if (!msg) return;
  await msg.edit({ embeds: [buildEmbed(menu)], components: buildComponents(menu, id) }).catch(() => {});
}

async function handleRoleMenuSelect(client, interaction) {
  const id = interaction.customId.split(':')[1];
  const menu = roleMenus.get(interaction.guildId, id);
  if (!menu) return interaction.reply({ content: 'This role menu no longer exists.', ephemeral: true });

  const me = interaction.guild.members.me;
  if (!me.permissions.has(PermissionFlagsBits.ManageRoles)) return interaction.reply({ content: '⚠️ I’m missing the **Manage Roles** permission.', ephemeral: true });

  const selected = new Set(interaction.values);
  const added = [];
  const removed = [];
  const skipped = [];
  for (const roleId of selected) {
    if (!menu.roles.some((r) => r.roleId === roleId)) continue;
    const role = interaction.guild.roles.cache.get(roleId);
    if (!role || role.position >= me.roles.highest.position) { skipped.push(roleId); continue; }
    if (interaction.member.roles.cache.has(roleId)) {
      await interaction.member.roles.remove(roleId, 'Role menu').catch(() => {});
      removed.push(roleId);
    } else {
      await interaction.member.roles.add(roleId, 'Role menu').catch(() => {});
      added.push(roleId);
    }
  }

  const parts = [];
  if (added.length) parts.push(`➕ ${added.map((r) => `<@&${r}>`).join(' ')}`);
  if (removed.length) parts.push(`➖ ${removed.map((r) => `<@&${r}>`).join(' ')}`);
  if (skipped.length) parts.push(`⚠️ couldn’t change ${skipped.map((r) => `<@&${r}>`).join(' ')} (role too high)`);
  return interaction.reply({ content: parts.join('\n') || 'No changes.', ephemeral: true });
}

module.exports = { buildComponents, buildEmbed, rerender, handleRoleMenuSelect };
