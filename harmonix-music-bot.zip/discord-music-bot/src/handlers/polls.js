'use strict';

const polls = require('../engagement/polls');

async function handlePollButton(client, interaction) {
  const choice = Number(interaction.customId.slice(5)); // after "poll:"
  const poll = polls.getPoll(interaction.message.id);
  if (!poll) return interaction.reply({ content: 'This poll is no longer available.', ephemeral: true });
  if (poll.closed) return interaction.reply({ content: 'This poll is closed.', ephemeral: true });

  polls.vote(poll, interaction.user.id, choice);
  const c = polls.counts(poll.message_id, poll.options.length);
  return interaction
    .update({ embeds: [polls.buildEmbed(poll, c)], components: polls.buildComponents(poll) })
    .catch(() => {});
}

module.exports = { handlePollButton };
