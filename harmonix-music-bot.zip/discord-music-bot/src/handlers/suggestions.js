'use strict';

const suggestions = require('../community/suggestions');
const { userTag } = require('../utils/format');

async function handleSuggestionButton(client, interaction) {
  const dir = interaction.customId.slice(4); // "up" | "down"
  const row = suggestions.get(interaction.message.id);
  if (!row) return interaction.reply({ content: 'This suggestion is no longer tracked.', ephemeral: true });

  suggestions.vote(interaction.message.id, interaction.user.id, dir === 'up' ? 1 : -1);
  const c = suggestions.counts(interaction.message.id);

  let authorTag = 'a member';
  const author = await client.users.fetch(row.author_id).catch(() => null);
  if (author) authorTag = userTag(author);

  return interaction
    .update({ embeds: [suggestions.buildEmbed(authorTag, row.text, c)], components: suggestions.buildComponents() })
    .catch(() => {});
}

module.exports = { handleSuggestionButton };
