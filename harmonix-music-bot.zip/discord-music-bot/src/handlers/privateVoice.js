'use strict';

const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  UserSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionFlagsBits,
} = require('discord.js');
const { config } = require('../../config');
const pvc = require('../engagement/privateVoice');

/** Read the current channel state for rendering the panel. */
function readState(voice, ownerId) {
  const everyone = voice.guild.roles.everyone;
  const ow = voice.permissionOverwrites.cache.get(everyone.id);
  const locked = ow ? ow.deny.has(PermissionFlagsBits.Connect) : false;
  return { ownerId, name: voice.name, locked, limit: voice.userLimit || 0 };
}

function buildPanel(state) {
  const embed = new EmbedBuilder()
    .setColor(config.brand.color)
    .setTitle('🔒 Private Voice Controls')
    .setDescription(
      [
        `**Owner:** <@${state.ownerId}>`,
        `**Channel:** ${state.name}`,
        `**Status:** ${state.locked ? '🔒 Locked (invite-only)' : '🔓 Unlocked (anyone can join)'}`,
        `**User limit:** ${state.limit ? state.limit : 'unlimited'}`,
        '',
        'Use the dropdowns to **allow** or **remove** members, and the buttons to manage the channel.',
      ].join('\n')
    )
    .setFooter({ text: 'Only the channel owner can use these controls.' });

  const allowRow = new ActionRowBuilder().addComponents(
    new UserSelectMenuBuilder().setCustomId('pvc:allow').setPlaceholder('➕ Allow members to join…').setMinValues(1).setMaxValues(5)
  );
  const kickRow = new ActionRowBuilder().addComponents(
    new UserSelectMenuBuilder().setCustomId('pvc:kick').setPlaceholder('➖ Remove / disconnect members…').setMinValues(1).setMaxValues(5)
  );
  const btnRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pvc:rename').setEmoji('✏️').setLabel('Rename').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('pvc:limit').setEmoji('👥').setLabel('Limit').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('pvc:lock')
      .setEmoji(state.locked ? '🔓' : '🔒')
      .setLabel(state.locked ? 'Unlock' : 'Lock')
      .setStyle(state.locked ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('pvc:claim').setEmoji('👑').setLabel('Claim').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('pvc:delete').setEmoji('🗑️').setLabel('Delete').setStyle(ButtonStyle.Danger)
  );
  return { embeds: [embed], components: [allowRow, kickRow, btnRow] };
}

/** Re-render the stored panel message to reflect the latest state. */
async function refreshPanel(client, pair, voice) {
  if (!pair.panelMessageId) return;
  const text = await client.channels.fetch(pair.textId).catch(() => null);
  if (!text) return;
  const msg = await text.messages.fetch(pair.panelMessageId).catch(() => null);
  if (!msg) return;
  await msg.edit(buildPanel(readState(voice, pair.ownerId))).catch(() => {});
}

async function resolve(client, interaction) {
  const pair = pvc.byText(interaction.guildId, interaction.channelId);
  if (!pair) { await interaction.reply({ content: 'This control panel is no longer linked to a channel.', ephemeral: true }); return null; }
  const voice = await client.channels.fetch(pair.voiceId).catch(() => null);
  if (!voice) { pvc.removePair(interaction.guildId, pair.voiceId); await interaction.reply({ content: 'The voice channel no longer exists.', ephemeral: true }); return null; }
  return { pair, voice };
}

async function handleComponent(client, interaction) {
  const r = await resolve(client, interaction);
  if (!r) return;
  const { pair, voice } = r;
  const action = interaction.customId.slice(4);

  // Claim — allowed for anyone once the owner has left the voice channel.
  if (action === 'claim') {
    if (voice.members.has(pair.ownerId)) return interaction.reply({ content: 'The owner is still here — you can’t claim it.', ephemeral: true });
    pvc.setOwner(interaction.guildId, pair.voiceId, interaction.user.id);
    await voice.permissionOverwrites.edit(interaction.user.id, { Connect: true, Speak: true, ManageChannels: true }).catch(() => {});
    const updated = pvc.byVoice(interaction.guildId, pair.voiceId);
    await refreshPanel(client, updated, voice);
    return interaction.reply({ content: `👑 ${interaction.user} is now the owner of this channel.` });
  }

  if (interaction.user.id !== pair.ownerId) return interaction.reply({ content: 'Only the channel owner can use these controls.', ephemeral: true });

  if (action === 'allow' && interaction.isUserSelectMenu()) {
    for (const uid of interaction.values) {
      // Grant join + talk on the voice channel only. The control text channel
      // stays owner-only — allowed members should never see the panel.
      await voice.permissionOverwrites.edit(uid, { Connect: true, Speak: true, ViewChannel: true }).catch(() => {});
    }
    return interaction.reply({ content: `✅ Allowed ${interaction.values.map((i) => `<@${i}>`).join(' ')} to join and talk.`, ephemeral: true });
  }

  if (action === 'kick' && interaction.isUserSelectMenu()) {
    for (const uid of interaction.values) {
      if (uid === pair.ownerId) continue;
      await voice.permissionOverwrites.edit(uid, { Connect: false }).catch(() => {});
      const m = voice.members.get(uid);
      if (m) await m.voice.disconnect('Removed from private VC').catch(() => {});
    }
    return interaction.reply({ content: `➖ Removed ${interaction.values.filter((i) => i !== pair.ownerId).map((i) => `<@${i}>`).join(' ') || 'nobody'}.`, ephemeral: true });
  }

  if (action === 'lock') {
    const everyone = interaction.guild.roles.everyone;
    const ow = voice.permissionOverwrites.cache.get(everyone.id);
    const locked = ow ? ow.deny.has(PermissionFlagsBits.Connect) : false;
    // Unlock: explicitly allow connect + speak for everyone (robust against
    // category-level denies). Lock: deny connect.
    await voice.permissionOverwrites.edit(everyone, locked
      ? { Connect: true, Speak: true, ViewChannel: true }
      : { Connect: false }).catch(() => {});
    const fresh = await client.channels.fetch(pair.voiceId).catch(() => voice);
    return interaction.update(buildPanel(readState(fresh, pair.ownerId)));
  }

  if (action === 'rename') {
    const modal = new ModalBuilder().setCustomId('pvc:rename:modal').setTitle('Rename channel').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('New channel name').setStyle(TextInputStyle.Short).setMaxLength(90).setRequired(true))
    );
    return interaction.showModal(modal);
  }

  if (action === 'limit') {
    const modal = new ModalBuilder().setCustomId('pvc:limit:modal').setTitle('Set user limit').addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('limit').setLabel('User limit (0 = unlimited, max 99)').setStyle(TextInputStyle.Short).setMaxLength(2).setRequired(true))
    );
    return interaction.showModal(modal);
  }

  if (action === 'delete') {
    await interaction.reply({ content: '🗑️ Deleting this channel…', ephemeral: true }).catch(() => {});
    const text = await client.channels.fetch(pair.textId).catch(() => null);
    pvc.removePair(interaction.guildId, pair.voiceId);
    if (text) await text.delete('Private VC deleted by owner').catch(() => {});
    return voice.delete('Private VC deleted by owner').catch(() => {});
  }
  return undefined;
}

async function handleModal(client, interaction) {
  const r = await resolve(client, interaction);
  if (!r) return;
  const { pair, voice } = r;
  if (interaction.user.id !== pair.ownerId) return interaction.reply({ content: 'Only the channel owner can do that.', ephemeral: true });

  if (interaction.customId === 'pvc:rename:modal') {
    const name = interaction.fields.getTextInputValue('name').slice(0, 90);
    await voice.setName(name).catch(() => {});
    const fresh = await client.channels.fetch(pair.voiceId).catch(() => voice);
    await refreshPanel(client, pair, fresh);
    return interaction.reply({ content: `✏️ Renamed to **${name}**.`, ephemeral: true });
  }
  if (interaction.customId === 'pvc:limit:modal') {
    const n = Math.max(0, Math.min(99, parseInt(interaction.fields.getTextInputValue('limit'), 10) || 0));
    await voice.setUserLimit(n).catch(() => {});
    const fresh = await client.channels.fetch(pair.voiceId).catch(() => voice);
    await refreshPanel(client, pair, fresh);
    return interaction.reply({ content: `👥 User limit set to **${n === 0 ? 'unlimited' : n}**.`, ephemeral: true });
  }
  return undefined;
}

module.exports = { buildPanel, readState, refreshPanel, handleComponent, handleModal };
