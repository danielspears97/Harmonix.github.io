'use strict';

const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { config } = require('../../config');
const guildSettings = require('../server/guildSettings');

// Each line lists its sub-commands as [label, gatePath]. Help renders only the
// parts the viewer can actually use (not disabled, power level high enough);
// a line with no visible parts disappears, and a category with no visible
// lines disappears too. `prefix` is shown once before bare sub-command labels.
const CATEGORIES = [
  {
    key: 'music', emoji: '🎵', label: 'Music', blurb: 'Play & control audio',
    lines: [
      { parts: [['/play <query>', 'play']], desc: 'Play a song or playlist (YouTube/Spotify/SoundCloud)' },
      { parts: [['/pause', 'pause'], ['/resume', 'resume'], ['/skip', 'skip'], ['/previous', 'previous'], ['/stop', 'stop']], desc: 'Transport controls' },
      { parts: [['/seek', 'seek'], ['/leave', 'leave']], desc: 'Jump to a timestamp / disconnect' },
      { parts: [['/queue', 'queue'], ['/nowplaying', 'nowplaying'], ['/shuffle', 'shuffle']], desc: 'View & shuffle the queue' },
      { parts: [['/remove', 'remove'], ['/clear', 'clear'], ['/loop', 'loop']], desc: 'Manage the queue' },
      { parts: [['/volume', 'volume'], ['/autoplay', 'autoplay'], ['/247', '247']], desc: 'Volume & playback modes' },
      { parts: [['/filter', 'filter'], ['/voteskip', 'voteskip']], desc: 'Audio filters & democratic skip' },
      { parts: [['/dj', 'dj'], ['/playlist', 'playlist']], desc: 'DJ role & saved playlists' },
      { parts: [['/voicelock', 'voicelock']], desc: 'Restrict music to one voice channel (Manage Server)' },
      { parts: [['/setup', 'setup']], desc: 'Create the in-channel player with buttons' },
    ],
  },
  {
    key: 'mod', emoji: '🛡️', label: 'Moderation', blurb: 'Keep your server safe',
    lines: [
      { prefix: '/mod', parts: [['warn', 'mod warn'], ['warnings', 'mod warnings'], ['case', 'mod case'], ['reason', 'mod reason']], desc: 'Infractions & case history' },
      { prefix: '/mod', parts: [['kick', 'mod kick'], ['ban', 'mod ban'], ['unban', 'mod unban'], ['tempban', 'mod tempban']], desc: 'Removals' },
      { prefix: '/mod', parts: [['timeout', 'mod timeout'], ['untimeout', 'mod untimeout'], ['mute', 'mod mute'], ['unmute', 'mod unmute']], desc: 'Silencing' },
      { prefix: '/mod', parts: [['purge', 'mod purge'], ['slowmode', 'mod slowmode']], desc: 'Channel cleanup' },
      { prefix: '/mod', parts: [['lockdown', 'mod lockdown'], ['unlock', 'mod unlock']], desc: 'Lock a channel or the whole server' },
      { prefix: '/mod', parts: [['modlog', 'mod modlog set'], ['logging', 'mod logging set']], desc: 'Audit logging' },
      { prefix: '/mod', parts: [['ticket', 'mod ticket setup'], ['verify', 'mod verify setup'], ['antiraid', 'mod antiraid enable'], ['warnthreshold', 'mod warnthreshold add']], desc: 'Tickets, gates & automation' },
      { parts: [['/automod', 'automod status']], desc: 'Word/spam/link/invite filters' },
    ],
  },
  {
    key: 'server', emoji: '⚙️', label: 'Server setup', blurb: 'Greetings, roles & config',
    lines: [
      { prefix: '/server', parts: [['welcome', 'server welcome set'], ['goodbye', 'server goodbye set']], desc: 'Join/leave messages' },
      { prefix: '/server', parts: [['autorole', 'server autorole set'], ['reactionrole', 'server reactionrole create'], ['rolemenu', 'server rolemenu create']], desc: 'Self-assign & auto roles' },
      { prefix: '/server', parts: [['starboard', 'server starboard set']], desc: 'Highlight popular messages' },
      { prefix: '/server', parts: [['autoresponder', 'server autoresponder add'], ['sticky', 'server sticky set']], desc: 'Auto-replies & pinned-to-bottom messages' },
      { prefix: '/server', parts: [['prefix', 'server prefix']], desc: 'Set the text-command prefix (default !)' },
      { prefix: '/server', parts: [['autodelete', 'server autodelete'], ['triviachannel', 'server triviachannel']], desc: 'Reply cleanup & trivia channel' },
    ],
  },
  {
    key: 'engage', emoji: '🎉', label: 'Engagement', blurb: 'Levels, economy & events',
    lines: [
      { parts: [['/level rank', 'level rank'], ['/level leaderboard', 'level leaderboard']], desc: 'XP & leveling' },
      { prefix: '/engage', parts: [['poll', 'engage poll create'], ['giveaway', 'engage giveaway start']], desc: 'Run polls & giveaways' },
      { prefix: '/engage', parts: [['tempvoice', 'engage tempvoice setup']], desc: 'Join-to-create 🔒 private voice channels with a control panel' },
      { prefix: '/engage', parts: [['temptext', 'engage temptext']], desc: 'Auto-deleting text channels' },
      { parts: [['/economy', 'economy balance']], desc: 'Currency, daily, work, shop, slots, give' },
    ],
  },
  {
    key: 'fun', emoji: '🎲', label: 'Fun & games', blurb: 'Mini-games & random fun',
    lines: [
      { prefix: '/game', parts: [['8ball', 'game 8ball'], ['rps', 'game rps'], ['roll', 'game roll'], ['draw', 'game draw']], desc: 'Quick games' },
      { prefix: '/game', parts: [['pokemon', 'game pokemon'], ['whosthat', 'game whosthat'], ['scramble', 'game scramble'], ['hangman', 'game hangman start'], ['wordle', 'game wordle start']], desc: 'Guessing games' },
      { prefix: '/game', parts: [['trivia', 'game trivia']], desc: 'Continuous trivia — category/topic, difficulty, custom timer, or ⚡ speed mode' },
      { prefix: '/fun', parts: [['joke', 'fun joke'], ['fact', 'fun fact'], ['advice', 'fun advice'], ['dog', 'fun dog'], ['cat', 'fun cat'], ['xkcd', 'fun xkcd'], ['quote', 'fun quote'], ['apod', 'fun apod'], ['recipe', 'fun recipe'], ['cocktail', 'fun cocktail']], desc: 'Random content' },
    ],
  },
  {
    key: 'util', emoji: '🔧', label: 'Utility', blurb: 'Tools & lookups',
    lines: [
      { prefix: '/util', parts: [['reminder', 'util reminder set'], ['translate', 'util translate'], ['weather', 'util weather'], ['feed', 'util feed add']], desc: 'Everyday helpers' },
      { prefix: '/lookup', parts: [['define', 'lookup define'], ['wiki', 'lookup wiki'], ['country', 'lookup country'], ['convert', 'lookup convert'], ['crypto', 'lookup crypto'], ['forecast', 'lookup forecast'], ['github', 'lookup github'], ['anime', 'lookup anime'], ['qr', 'lookup qr']], desc: 'Reference lookups' },
      { prefix: '/tools', parts: [['timestamp', 'tools timestamp'], ['math', 'tools math'], ['base64', 'tools base64'], ['hash', 'tools hash'], ['password', 'tools password'], ['color', 'tools color'], ['choose', 'tools choose'], ['mock', 'tools mock'], ['ascii', 'tools ascii']], desc: 'Handy tools' },
      { parts: [['/timezone set', 'timezone'], ['/timezone show', 'timezone']], desc: 'Set your timezone so the bot shows your local time' },
      { parts: [['/wrapped', 'wrapped'], ['/achievements', 'achievements']], desc: 'Server music recap & your unlocked badges' },
      { parts: [['/status', 'status']], desc: 'Bot uptime, ping & health' },
    ],
  },
  {
    key: 'community', emoji: '🫂', label: 'Community', blurb: 'Tags, info & birthdays',
    lines: [
      { prefix: '/community', parts: [['tag', 'community tag get'], ['afk', 'community afk'], ['snipe', 'community snipe']], desc: 'Tags, AFK & message snipe' },
      { prefix: '/community', parts: [['suggest', 'community suggest'], ['suggestions', 'community suggestions set']], desc: 'Suggestions board' },
      { prefix: '/community', parts: [['userinfo', 'community userinfo'], ['serverinfo', 'community serverinfo'], ['roleinfo', 'community roleinfo'], ['avatar', 'community avatar'], ['membercount', 'community membercount']], desc: 'Info lookups' },
      { prefix: '/community', parts: [['birthday', 'community birthday set']], desc: 'Birthday tracking & announcements' },
    ],
  },
  {
    key: 'nsfw', emoji: '🔞', label: 'NSFW', blurb: 'Adult content (age-restricted channels only)',
    lines: [
      { parts: [['/nsfw [category]', 'nsfw']], desc: 'Adult images — only works in channels marked age-restricted' },
    ],
  },
];

function makeCtx(guildId, member) {
  if (!guildId) return { gate: {}, level: 2 }; // DMs: show everything
  return { gate: guildSettings.getGate(guildId), level: guildSettings.memberPowerLevel(member) };
}
function pathVisible(path, ctx) {
  const rule = ctx.gate[path];
  if (!rule) return true;
  if (rule.enabled === false) return false;
  if ((rule.level || 0) > ctx.level) return false;
  return true;
}
/** Render a line to {name, value} showing only the parts the viewer can use, or null. */
function renderLine(line, ctx) {
  const vis = line.parts.filter(([, path]) => pathVisible(path, ctx));
  if (!vis.length) return null;
  const text = `${line.prefix ? `${line.prefix} ` : ''}${vis.map(([label]) => label).join(' · ')}`;
  return { name: text, value: line.desc };
}
function visibleLines(cat, ctx) {
  return cat.lines.map((l) => renderLine(l, ctx)).filter(Boolean);
}
function visibleCategories(ctx) {
  const cats = config.musicOnly ? CATEGORIES.filter((c) => c.key === 'music') : CATEGORIES;
  return cats.filter((c) => visibleLines(c, ctx).length > 0);
}

function selectRow(active, ctx) {
  const cats = visibleCategories(ctx);
  const menu = new StringSelectMenuBuilder()
    .setCustomId('help:cat')
    .setPlaceholder('📂 Pick a category to see its commands…')
    .addOptions(
      { label: 'Overview', value: 'overview', emoji: '🏠', description: 'Back to the category list', default: active === 'overview' },
      ...cats.map((c) => ({ label: c.label, value: c.key, emoji: c.emoji, description: c.blurb, default: active === c.key }))
    );
  return new ActionRowBuilder().addComponents(menu);
}

function buildOverview(ctx = { gate: {}, level: 2 }) {
  const cats = visibleCategories(ctx);
  const embed = new EmbedBuilder()
    .setColor(config.brand.color)
    .setAuthor({ name: `${config.brand.name} — Help` })
    .setTitle('What would you like to explore?')
    .setDescription('Pick a category from the menu below to see its commands.\n\n' + cats.map((c) => `${c.emoji} **${c.label}** — ${c.blurb}`).join('\n'))
    .setFooter({ text: 'Every command also works as a text command (default prefix !). In the music channel, just type a song name.' });
  if (config.dashboard.enabled) embed.addFields({ name: '🖥️ Web dashboard', value: config.dashboard.publicUrl || `http://localhost:${config.dashboard.port}` });
  return { embeds: [embed], components: [selectRow('overview', ctx)] };
}

function buildCategory(key, ctx = { gate: {}, level: 2 }) {
  const c = CATEGORIES.find((x) => x.key === key);
  if (!c) return buildOverview(ctx);
  const lines = visibleLines(c, ctx);
  if (!lines.length) return buildOverview(ctx);
  const embed = new EmbedBuilder()
    .setColor(config.brand.color)
    .setAuthor({ name: `${config.brand.name} — Help` })
    .setTitle(`${c.emoji} ${c.label}`)
    .setDescription(c.blurb)
    .addFields(lines)
    .setFooter({ text: 'Use the menu to browse another category.' });
  return { embeds: [embed], components: [selectRow(key, ctx)] };
}

async function handleHelpSelect(client, interaction) {
  const ctx = makeCtx(interaction.guildId, interaction.member);
  const value = interaction.values[0];
  const view = value === 'overview' ? buildOverview(ctx) : buildCategory(value, ctx);
  await interaction.update(view).catch(() => {});
}

module.exports = { CATEGORIES, makeCtx, buildOverview, buildCategory, handleHelpSelect };
