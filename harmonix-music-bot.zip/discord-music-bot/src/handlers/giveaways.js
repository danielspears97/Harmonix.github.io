'use strict';

const giveaways = require('../engagement/giveaways');

async function handleGiveawayButton(client, interaction) {
  // customId is "gw:enter"
  const row = giveaways.get(interaction.message.id);
  if (!row) return interaction.reply({ content: 'This giveaway is no longer available.', ephemeral: true });
  if (row.ended) return interaction.reply({ content: 'This giveaway has ended.', ephemeral: true });

  const result = giveaways.toggleEntry(row.message_id, interaction.user.id);
  const count = giveaways.entryCount(row.message_id);

  // Refresh the entry count on the message (best effort).
  await interaction.message
    .edit({ embeds: [giveaways.buildEmbed(row, count)], components: giveaways.buildComponents(row) })
    .catch(() => {});

  return interaction.reply({
    content: result === 'entered' ? '🎉 You’re entered. Good luck!' : 'You’ve left the giveaway.',
    ephemeral: true,
  });
}

module.exports = { handleGiveawayButton };
