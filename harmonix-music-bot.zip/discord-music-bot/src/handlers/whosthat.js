'use strict';

const whosthat = require('../engagement/whosthat');
const levels = require('../engagement/levels');

async function handleWhosthatButton(client, interaction) {
  const choice = Number(interaction.customId.slice(9)); // after "whosthat:"
  const s = whosthat.getSession(interaction.message.id);
  if (!s || s.solved) return interaction.reply({ content: 'This round is over.', ephemeral: true });
  if (s.answered.has(interaction.user.id)) return interaction.reply({ content: 'You already guessed!', ephemeral: true });
  s.answered.add(interaction.user.id);

  if (choice === s.correctIndex) {
    s.solved = true;
    whosthat.endSession(interaction.message.id);
    const lvl = levels.getSettings(interaction.guildId);
    if (lvl.enabled) levels.addXp(interaction.guildId, interaction.user.id, 20);
    return interaction
      .update({ embeds: [whosthat.buildReveal(s, interaction.user.id)], components: whosthat.buildComponents(s, true) })
      .catch(() => {});
  }
  return interaction.reply({ content: 'Not quite — try again next round!', ephemeral: true });
}

module.exports = { handleWhosthatButton };
