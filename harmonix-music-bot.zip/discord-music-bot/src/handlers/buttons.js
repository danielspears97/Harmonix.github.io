'use strict';

const { EmbedBuilder } = require('discord.js');
const controller = require('../controller');
const { config } = require('../../config');
const { msToTime, truncate } = require('../utils/format');
const { voiceGuard, userVoiceChannel } = require('../utils/guards');

async function ephemeral(interaction, content) {
  if (interaction.replied || interaction.deferred) {
    return interaction.followUp({ content, ephemeral: true }).catch(() => {});
  }
  return interaction.reply({ content, ephemeral: true }).catch(() => {});
}

async function handleButton(client, interaction) {
  const id = interaction.customId;
  if (!id.startsWith('mc:')) return;
  const action = id.slice(3);
  const guildId = interaction.guildId;

  // Queue view doesn't require voice membership.
  if (action === 'queue') {
    const state = controller.getState(client, guildId);
    const embed = new EmbedBuilder().setColor(config.brand.color).setTitle('Queue');
    if (state.current) {
      embed.setDescription(
        `**Now:** ${truncate(state.current.title, 60)} \`${state.current.isStream ? 'LIVE' : msToTime(state.current.duration)}\``
      );
    }
    if (state.queue.length) {
      const list = state.queue
        .slice(0, 15)
        .map((q, i) => `\`${i + 1}.\` ${truncate(q.title, 50)} \`${q.isStream ? 'LIVE' : msToTime(q.duration)}\``)
        .join('\n');
      const more = state.queue.length > 15 ? `\n…and ${state.queue.length - 15} more` : '';
      embed.addFields({ name: `Up next (${state.queue.length})`, value: list + more });
    } else {
      embed.addFields({ name: 'Up next', value: 'The queue is empty.' });
    }
    return interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => {});
  }

  const guard = voiceGuard(client, interaction);
  if (!guard.ok) return ephemeral(interaction, guard.msg);

  await interaction.deferUpdate().catch(() => {});

  switch (action) {
    case 'pause': {
      const r = await controller.togglePause(client, guildId);
      if (!r.ok) return ephemeral(interaction, 'Nothing is playing.');
      break;
    }
    case 'skip': {
      const r = await controller.skip(client, guildId);
      if (!r.ok) return ephemeral(interaction, 'Nothing to skip.');
      break;
    }
    case 'prev': {
      const r = await controller.previous(client, guildId);
      if (!r.ok) return ephemeral(interaction, r.reason === 'no-previous' ? 'No previous track.' : 'Nothing is playing.');
      break;
    }
    case 'stop': {
      const r = await controller.stop(client, guildId);
      if (!r.ok) return ephemeral(interaction, 'Nothing is playing.');
      break;
    }
    case 'voldown': {
      await controller.volumeStep(client, guildId, -10);
      break;
    }
    case 'volup': {
      await controller.volumeStep(client, guildId, +10);
      break;
    }
    case 'loop': {
      const r = await controller.cycleLoop(client, guildId);
      if (!r.ok) return ephemeral(interaction, 'Nothing is playing.');
      break;
    }
    case 'shuffle': {
      const r = await controller.shuffle(client, guildId);
      if (!r.ok) return ephemeral(interaction, 'Need at least 2 tracks in the queue to shuffle.');
      break;
    }
    case 'autoplay': {
      controller.toggleAutoplay(client, guildId);
      break;
    }
    case '247': {
      controller.toggle247(client, guildId);
      break;
    }
    case 'clear': {
      const r = await controller.clearQueue(client, guildId);
      if (r.ok) return ephemeral(interaction, `Cleared ${r.count} track(s) from the queue.`);
      break;
    }
    default:
      break;
  }
}

module.exports = { handleButton };
