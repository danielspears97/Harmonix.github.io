'use strict';

const { ActivityType } = require('discord.js');
const { config } = require('../../config');
const { getGuild, setGuild } = require('../utils/persistence');
const { notify } = require('../utils/bus');
const { findAutoplayTracks } = require('../utils/autoplay');
const guildSettings = require('../server/guildSettings');
const history = require('../music/history');
const achievements = require('../engagement/achievements');
const featureToggles = require('../server/featureToggles');

/** Award play-related achievements to the track's requester and announce them. */
function awardPlayAchievements(client, player, track) {
  const guildId = player.guildId;
  const userId = track?.requester?.id;
  if (!userId) return;
  if (!featureToggles.isModuleEnabled(guildId, 'engagement')) return;

  const unlocked = [];
  const count = history.userPlayCount(guildId, userId); // already includes this play
  unlocked.push(...achievements.checkSongMilestones(guildId, userId, count));

  const hour = new Date().getHours();
  if (hour >= 0 && hour < 5) { const d = achievements.unlock(guildId, userId, 'night_owl'); if (d) unlocked.push(d); }
  if (hour >= 5 && hour < 8) { const d = achievements.unlock(guildId, userId, 'early_riser'); if (d) unlocked.push(d); }
  if (track?.info?.isStream) { const d = achievements.unlock(guildId, userId, 'live_wire'); if (d) unlocked.push(d); }

  const sources = history.userSources(guildId, userId);
  const has = (s) => sources.some((x) => x.includes(s));
  if (has('youtube') && has('spotify') && has('soundcloud')) { const d = achievements.unlock(guildId, userId, 'eclectic'); if (d) unlocked.push(d); }

  unlocked.push(...achievements.checkMeta(guildId, userId));

  if (unlocked.length) {
    // Don't clutter the music request channel: when the announce mode is
    // "post in the channel where it happened" and that channel is the
    // request/control channel, unlock silently (still visible in
    // /achievements and on the dashboard). DM / specific-channel / off
    // modes are respected as configured.
    const setting = guildSettings.getAchievementAnnounce(guildId);
    const controlChannelId = getGuild(guildId).controlChannelId;
    if (setting.mode === 'channel' && controlChannelId && player.textChannelId === controlChannelId) return;
    achievements.announce(client, { guildId, userId, channel: client.channels.cache.get(player.textChannelId), defs: unlocked });
  }
}

/** Set (or clear) the voice channel's status line — the text Discord shows
 *  next to the channel name. discord.js 14.26 doesn't wrap this endpoint yet,
 *  so we call it directly. Best-effort: it needs the "Set Voice Channel
 *  Status" permission, and older clients simply won't display it. */
async function setVoiceStatus(client, channelId, status) {
  if (!channelId) return;
  try {
    await client.rest.put(`/channels/${channelId}/voice-status`, {
      body: { status: status ? String(status).slice(0, 500) : null },
    });
  } catch { /* missing permission or unsupported — ignore */ }
}

/** Show the current track as the voice channel status. */
function refreshVoiceStatus(client, player) {
  if (!player?.voiceChannelId) return;
  const t = player.playing && player.queue.current ? player.queue.current.info : null;
  const text = t
    ? `🎵 ${[t.title, t.author].filter(Boolean).join(' — ')}`.slice(0, 480)
    : null; // null clears it
  setVoiceStatus(client, player.voiceChannelId, text);
}

// Idle presence — Harmonix is a full multipurpose bot, so the idle line points
// at /help rather than the old music-only "/play - /setup".
let idleTimer = null;
function idleLine(client) {
  const n = client.guilds.cache.size;
  return `/help \u2022 ${n} server${n === 1 ? '' : 's'}`;
}

/** Set the bot's presence. Discord allows only ONE global status per bot, so:
 *  exactly one guild playing → show that song; several → a generic count;
 *  none → rotate through what the bot does. */
function refreshPresence(client) {
  try {
    const playing = [...(client.lavalink?.players?.values() || [])].filter((p) => p.playing && p.queue.current);
    if (playing.length === 1) {
      const title = (playing[0].queue.current.info?.title || 'music').slice(0, 110);
      client.user.setActivity(title, { type: ActivityType.Listening });
    } else if (playing.length > 1) {
      client.user.setActivity(`music in ${playing.length} servers`, { type: ActivityType.Listening });
    } else {
      client.user.setActivity(idleLine(client), { type: ActivityType.Watching });
    }
  } catch { /* presence is best-effort */ }
}

/** Keep the idle line's server count current (no-op while music plays). */
function startPresenceRotation(client) {
  if (idleTimer) return;
  idleTimer = setInterval(() => {
    const anyPlaying = [...(client.lavalink?.players?.values() || [])].some((p) => p.playing && p.queue.current);
    if (anyPlaying) return; // music takes priority; don't overwrite the track
    refreshPresence(client);
  }, 10 * 60 * 1000);
}

/** Fade volume up from 0 to the player's target over `fadeSec` seconds. */
function fadeIn(player, fadeSec) {
  const target = player.volume || 100;
  const steps = 10;
  const prev = player.get('fadeTimer');
  if (prev) clearInterval(prev);
  player.setVolume(0).catch(() => {});
  let i = 0;
  const timer = setInterval(() => {
    i += 1;
    const v = Math.min(target, Math.round((target * i) / steps));
    player.setVolume(v).catch(() => {});
    if (i >= steps) { clearInterval(timer); player.set('fadeTimer', null); }
  }, (fadeSec * 1000) / steps);
  player.set('fadeTimer', timer);
}

const leaveTimers = new Map(); // guildId -> timeout

function cancelLeave(guildId) {
  if (leaveTimers.has(guildId)) {
    clearTimeout(leaveTimers.get(guildId));
    leaveTimers.delete(guildId);
  }
}

function scheduleLeave(client, player) {
  const guildId = player.guildId;
  const settings = getGuild(guildId);
  if (settings.twentyFourSeven) return; // never auto-leave in 24/7 mode
  cancelLeave(guildId);
  leaveTimers.set(
    guildId,
    setTimeout(async () => {
      leaveTimers.delete(guildId);
      const p = client.lavalink.getPlayer(guildId);
      if (p && !p.playing && p.queue.tracks.length === 0) {
        await p.destroy().catch(() => {});
        notify(guildId);
      }
    }, config.leaveTimeoutMs)
  );
}

const AUTOPLAY_TARGET = 5; // keep this many tracks queued ahead when autoplay is on

/** Keep the queue topped up to AUTOPLAY_TARGET upcoming tracks (autoplay only). */
async function topUpQueue(client, player) {
  if (player.get('stopped')) return; // halted by the stop button
  const settings = getGuild(player.guildId);
  if (!(settings.autoplay || player.get('autoplay'))) return;
  if (player.get('toppingUp')) return;
  const have = player.queue.tracks.length;
  const need = AUTOPLAY_TARGET - have;
  if (need <= 0) return;

  player.set('toppingUp', true);
  try {
    const seed = player.queue.current || player.get('lastPlayed');
    const exclude = new Set(player.get('playedIds') || []);
    for (const t of player.queue.tracks) { const id = t?.info?.identifier; if (id) exclude.add(id); }
    const next = await findAutoplayTracks(player, seed, exclude, need);
    if (next.length) {
      await player.queue.add(next);
      notify(player.guildId);
    }
  } catch (err) {
    console.warn('[autoplay] top-up failed:', err.message);
  } finally {
    player.set('toppingUp', false);
  }
}

function rememberPlayed(player, track) {
  let played = player.get('playedIds');
  if (!Array.isArray(played)) played = [];
  const id = track?.info?.identifier;
  if (id) {
    played.push(id);
    if (played.length > 100) played = played.slice(-100);
    player.set('playedIds', played);
  }
}

function attachPlayerEvents(client) {
  const ll = client.lavalink;

  // Proactively keep the queue topped up to 5 (autoplay) even between track
  // changes — e.g. after removals, or if a previous top-up came up short.
  setInterval(() => {
    const players = ll.players;
    if (!players) return;
    for (const player of players.values()) {
      if (player.queue.current || player.playing) topUpQueue(client, player).catch(() => {});
    }
  }, 12000);

  ll.on('trackStart', (player, track) => {
    cancelLeave(player.guildId);
    player.set('stopped', false); // music is actively playing again
    player.set('lastPlayed', track);
    rememberPlayed(player, track);
    history.log(player.guildId, track);
    awardPlayAchievements(client, player, track);
    refreshPresence(client);
    refreshVoiceStatus(client, player); // show the song on the voice channel
    const fadeSec = guildSettings.getMusicSettings(player.guildId).fadeSec;
    if (fadeSec > 0) fadeIn(player, fadeSec);
    notify(player.guildId);
    // Keep a rolling buffer of upcoming tracks (autoplay). Also fires after a
    // skip, since skipping starts the next track.
    topUpQueue(client, player).catch(() => {});
  });

  ll.on('trackEnd', (player) => {
    notify(player.guildId);
  });

  ll.on('queueEnd', async (player, track) => {
    const guildId = player.guildId;
    const settings = getGuild(guildId);
    const autoplay = (settings.autoplay || player.get('autoplay')) && !player.get('stopped');

    if (autoplay) {
      try {
        const seed = track || player.get('lastPlayed');
        const playedIds = new Set(player.get('playedIds') || []);
        const next = await findAutoplayTracks(player, seed, playedIds, 5);
        if (next.length) {
          await player.queue.add(next);
          if (!player.playing && !player.paused) await player.play();
          notify(guildId);
          return;
        }
      } catch (err) {
        console.warn('[autoplay] failed to continue:', err.message);
      }
    }

    notify(guildId);
    refreshPresence(client);
    setVoiceStatus(client, player.voiceChannelId, null); // nothing playing → clear
    scheduleLeave(client, player);
  });

  ll.on('trackError', (player, track, payload) => {
    console.warn(`[lavalink] track error in ${player.guildId}:`, payload?.exception?.message || '');
    notify(player.guildId);
  });

  ll.on('trackStuck', (player) => {
    console.warn(`[lavalink] track stuck in ${player.guildId}, skipping`);
    player.skip().catch(() => {});
  });

  ll.on('playerDestroy', (player) => {
    cancelLeave(player.guildId);
    setVoiceStatus(client, player.voiceChannelId, null); // clear the channel status
    const fade = player.get('fadeTimer');
    if (fade) { clearInterval(fade); player.set('fadeTimer', null); }
    // Leaving voice turns off autoplay and 24/7 so the control panel buttons
    // don't stay lit after the bot is disconnected.
    setGuild(player.guildId, { autoplay: false, twentyFourSeven: false });
    refreshPresence(client);
    notify(player.guildId);
  });
}

module.exports = { attachPlayerEvents, cancelLeave, scheduleLeave, refreshPresence, startPresenceRotation, setVoiceStatus, refreshVoiceStatus };
