'use strict';

/**
 * Single shared SQLite connection for the whole bot.
 *
 * better-sqlite3 is synchronous, which matches the rest of the codebase's
 * simple get/set persistence API (no await needed). The connection is opened
 * lazily on first use so that tooling (e.g. deploy-commands) that requires
 * config but never touches the DB doesn't create a stray file.
 */

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const { applySchema } = require('./schema');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const DB_PATH = process.env.DATABASE_PATH || path.join(DATA_DIR, 'harmonix.db');

let db = null;

/** Get (opening if necessary) the shared database connection. */
function getDb() {
  if (db) return db;

  if (DB_PATH !== ':memory:') {
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }

  db = new Database(DB_PATH);
  // WAL gives us much better concurrent read/write behaviour; the rest are
  // sensible durability/perf defaults for an app like this.
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');

  applySchema(db);
  return db;
}

/**
 * Per-guild config helpers (generic JSON key/value), used by feature modules.
 * Stored in the guild_config table so modules don't each need schema changes.
 */
function getConfig(guildId, key, fallback = null) {
  const row = getDb()
    .prepare('SELECT value FROM guild_config WHERE guild_id = ? AND key = ?')
    .get(guildId, key);
  if (!row) return fallback;
  try {
    return JSON.parse(row.value);
  } catch {
    return fallback;
  }
}

function setConfig(guildId, key, value) {
  getDb()
    .prepare(
      `INSERT INTO guild_config (guild_id, key, value) VALUES (?, ?, ?)
       ON CONFLICT(guild_id, key) DO UPDATE SET value = excluded.value`
    )
    .run(guildId, key, JSON.stringify(value));
  return value;
}

function deleteConfig(guildId, key) {
  getDb().prepare('DELETE FROM guild_config WHERE guild_id = ? AND key = ?').run(guildId, key);
}

/** All config key/values for a guild, parsed — used by config export. */
function getAllConfig(guildId) {
  const rows = getDb().prepare('SELECT key, value FROM guild_config WHERE guild_id = ?').all(guildId);
  const out = {};
  for (const r of rows) {
    try { out[r.key] = JSON.parse(r.value); } catch { out[r.key] = r.value; }
  }
  return out;
}

/** Close cleanly (used on shutdown / in tests). */
function close() {
  if (db) {
    db.close();
    db = null;
  }
}

module.exports = { getDb, getConfig, setConfig, deleteConfig, getAllConfig, close, DB_PATH };
