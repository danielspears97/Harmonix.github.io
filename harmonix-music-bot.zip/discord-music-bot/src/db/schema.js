'use strict';

/**
 * Database schema for Harmonix.
 *
 * Every statement here is idempotent (CREATE TABLE IF NOT EXISTS / CREATE INDEX
 * IF NOT EXISTS), so applying the schema on every boot is safe. As new feature
 * modules land (moderation, leveling, giveaways…) they add their tables here.
 *
 * SCHEMA_VERSION is informational — bump it when you add tables so you can see
 * at a glance which build a database was last touched by.
 */

const SCHEMA_VERSION = 19;

function applySchema(db) {
  db.exec(`
    -- ── Foundations (v1) ──────────────────────────────────────────────

    -- Replaces the old data/guilds.json store. One row per guild.
    CREATE TABLE IF NOT EXISTS guild_settings (
      guild_id            TEXT PRIMARY KEY,
      control_channel_id  TEXT,
      control_message_id  TEXT,
      twenty_four_seven   INTEGER NOT NULL DEFAULT 0,
      autoplay            INTEGER NOT NULL DEFAULT 0,
      volume              INTEGER          -- NULL = use the global default
    );

    -- Generic per-guild key/value config for feature modules, so we don't have
    -- to ALTER guild_settings every time a module needs a new setting.
    -- 'value' holds a JSON-encoded value.
    CREATE TABLE IF NOT EXISTS guild_config (
      guild_id  TEXT NOT NULL,
      key       TEXT NOT NULL,
      value     TEXT NOT NULL,
      PRIMARY KEY (guild_id, key)
    );

    -- Bookkeeping.
    CREATE TABLE IF NOT EXISTS schema_meta (
      key    TEXT PRIMARY KEY,
      value  TEXT NOT NULL
    );

    -- ── Moderation (v2) ───────────────────────────────────────────────

    -- One row per moderation action. case_number is a per-guild sequential
    -- counter (Case #1, #2, … within each guild).
    CREATE TABLE IF NOT EXISTS mod_cases (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id      TEXT    NOT NULL,
      case_number   INTEGER NOT NULL,
      action        TEXT    NOT NULL,   -- warn | kick | ban | unban | timeout | untimeout
      target_id     TEXT    NOT NULL,
      target_tag    TEXT,
      moderator_id  TEXT    NOT NULL,
      moderator_tag TEXT,
      reason        TEXT,
      duration_ms   INTEGER,            -- for timeouts; NULL otherwise
      created_at    INTEGER NOT NULL,   -- epoch ms
      UNIQUE (guild_id, case_number)
    );

    CREATE INDEX IF NOT EXISTS idx_cases_guild_target
      ON mod_cases (guild_id, target_id);
    CREATE INDEX IF NOT EXISTS idx_cases_guild_action
      ON mod_cases (guild_id, action);

    -- ── Reaction roles (v3) ───────────────────────────────────────────

    CREATE TABLE IF NOT EXISTS reaction_role_panels (
      message_id  TEXT PRIMARY KEY,
      guild_id    TEXT NOT NULL,
      channel_id  TEXT NOT NULL,
      created_at  INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reaction_role_buttons (
      message_id  TEXT NOT NULL,
      role_id     TEXT NOT NULL,
      label       TEXT,
      emoji       TEXT,
      style       INTEGER NOT NULL DEFAULT 2,
      position    INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (message_id, role_id)
    );

    CREATE INDEX IF NOT EXISTS idx_rr_panels_guild
      ON reaction_role_panels (guild_id);

    -- ── Engagement (v4) ───────────────────────────────────────────────

    -- Leveling / XP
    CREATE TABLE IF NOT EXISTS levels (
      guild_id    TEXT NOT NULL,
      user_id     TEXT NOT NULL,
      xp          INTEGER NOT NULL DEFAULT 0,
      level       INTEGER NOT NULL DEFAULT 0,
      last_msg_at INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (guild_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_levels_guild_xp ON levels (guild_id, xp DESC);

    -- Polls
    CREATE TABLE IF NOT EXISTS polls (
      message_id  TEXT PRIMARY KEY,
      guild_id    TEXT NOT NULL,
      channel_id  TEXT NOT NULL,
      question    TEXT NOT NULL,
      options     TEXT NOT NULL,          -- JSON array of option labels
      multi       INTEGER NOT NULL DEFAULT 0,
      created_by  TEXT,
      created_at  INTEGER NOT NULL,
      closed      INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS poll_votes (
      message_id  TEXT NOT NULL,
      user_id     TEXT NOT NULL,
      choice      INTEGER NOT NULL,
      PRIMARY KEY (message_id, user_id, choice)
    );

    -- Giveaways
    CREATE TABLE IF NOT EXISTS giveaways (
      message_id  TEXT PRIMARY KEY,
      guild_id    TEXT NOT NULL,
      channel_id  TEXT NOT NULL,
      prize       TEXT NOT NULL,
      winners     INTEGER NOT NULL DEFAULT 1,
      ends_at     INTEGER NOT NULL,
      host_id     TEXT,
      ended       INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_giveaways_due ON giveaways (ended, ends_at);
    CREATE TABLE IF NOT EXISTS giveaway_entries (
      message_id  TEXT NOT NULL,
      user_id     TEXT NOT NULL,
      PRIMARY KEY (message_id, user_id)
    );

    -- ── Starboard (v5) ────────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS starboard_messages (
      guild_id             TEXT NOT NULL,
      original_message_id  TEXT NOT NULL,
      starboard_message_id TEXT,
      channel_id           TEXT,
      PRIMARY KEY (guild_id, original_message_id)
    );

    -- ── Utility (v6) ──────────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS reminders (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id    TEXT,
      channel_id  TEXT NOT NULL,
      user_id     TEXT NOT NULL,
      text        TEXT,
      remind_at   INTEGER NOT NULL,
      created_at  INTEGER NOT NULL,
      fired       INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders (fired, remind_at);

    CREATE TABLE IF NOT EXISTS feeds (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id       TEXT NOT NULL,
      channel_id     TEXT NOT NULL,
      url            TEXT NOT NULL,
      title          TEXT,
      last_guid      TEXT,
      last_published INTEGER,
      added_at       INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_feeds_guild ON feeds (guild_id);

    -- ── Community (v7) ────────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS tags (
      guild_id   TEXT NOT NULL,
      name       TEXT NOT NULL,
      content    TEXT NOT NULL,
      created_by TEXT,
      uses       INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (guild_id, name)
    );
    CREATE TABLE IF NOT EXISTS afk (
      guild_id TEXT NOT NULL,
      user_id  TEXT NOT NULL,
      reason   TEXT,
      since    INTEGER NOT NULL,
      PRIMARY KEY (guild_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS suggestions (
      message_id TEXT PRIMARY KEY,
      guild_id   TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      author_id  TEXT,
      text       TEXT
    );
    CREATE TABLE IF NOT EXISTS suggestion_votes (
      message_id TEXT NOT NULL,
      user_id    TEXT NOT NULL,
      vote       INTEGER NOT NULL,   -- 1 = up, -1 = down
      PRIMARY KEY (message_id, user_id)
    );

    -- ── Tickets (v8) ──────────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS tickets (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id    TEXT    NOT NULL,
      channel_id  TEXT    NOT NULL UNIQUE,
      user_id     TEXT    NOT NULL,
      number      INTEGER NOT NULL,
      claimed_by  TEXT,
      open        INTEGER NOT NULL DEFAULT 1,
      created_at  INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_tickets_guild_open ON tickets (guild_id, open);

    -- ── Timed punishments (v9) ────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS temp_actions (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id    TEXT    NOT NULL,
      user_id     TEXT    NOT NULL,
      type        TEXT    NOT NULL,   -- 'unban' | 'unmute' (the action performed at expiry)
      role_id     TEXT,               -- mute role, for 'unmute'
      expires_at  INTEGER NOT NULL,
      done        INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_temp_due ON temp_actions (done, expires_at);

    -- ── Temporary channels (v10) ──────────────────────────────────────
    CREATE TABLE IF NOT EXISTS temp_channels (
      channel_id  TEXT PRIMARY KEY,
      guild_id    TEXT NOT NULL,
      kind        TEXT NOT NULL,     -- 'voice' | 'text'
      owner_id    TEXT,
      expires_at  INTEGER,           -- for text channels; NULL for join-to-create voice
      created_at  INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_tempch_expiry ON temp_channels (expires_at);
    CREATE INDEX IF NOT EXISTS idx_tempch_guild ON temp_channels (guild_id, kind);

    -- ── Economy (v11) ─────────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS channel_locks (
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      prev TEXT NOT NULL,
      locked_at INTEGER NOT NULL,
      PRIMARY KEY (guild_id, channel_id)
    );
    CREATE INDEX IF NOT EXISTS idx_locks_guild ON channel_locks (guild_id);

    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      message_id TEXT,
      creator_id TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      image_url TEXT,
      start_at INTEGER NOT NULL,
      post_at INTEGER NOT NULL,
      remove_at INTEGER,
      reactions TEXT,
      repeat_mode TEXT,
      posted INTEGER NOT NULL DEFAULT 0,
      removed INTEGER NOT NULL DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_events_due ON events (posted, post_at);
    CREATE INDEX IF NOT EXISTS idx_events_guild ON events (guild_id);

    CREATE TABLE IF NOT EXISTS event_rsvps (
      event_id INTEGER NOT NULL,
      user_id TEXT NOT NULL,
      emoji TEXT NOT NULL,
      PRIMARY KEY (event_id, user_id, emoji)
    );

    CREATE TABLE IF NOT EXISTS freegame_seen (
      guild_id TEXT NOT NULL,
      giveaway_id INTEGER NOT NULL,
      seen_at INTEGER NOT NULL,
      PRIMARY KEY (guild_id, giveaway_id)
    );
    CREATE INDEX IF NOT EXISTS idx_freegame_seen ON freegame_seen (seen_at);

    CREATE TABLE IF NOT EXISTS economy (
      guild_id   TEXT NOT NULL,
      user_id    TEXT NOT NULL,
      balance    INTEGER NOT NULL DEFAULT 0,
      last_daily INTEGER NOT NULL DEFAULT 0,
      last_work  INTEGER NOT NULL DEFAULT 0,
      streak     INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (guild_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_economy_balance ON economy (guild_id, balance DESC);

    CREATE TABLE IF NOT EXISTS economy_shop (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id    TEXT NOT NULL,
      name        TEXT NOT NULL,
      price       INTEGER NOT NULL,
      role_id     TEXT,
      description TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_shop_guild ON economy_shop (guild_id);

    -- ── Birthdays (v12) ───────────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS birthdays (
      guild_id TEXT NOT NULL,
      user_id  TEXT NOT NULL,
      month    INTEGER NOT NULL,
      day      INTEGER NOT NULL,
      year     INTEGER,
      PRIMARY KEY (guild_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_birthdays_md ON birthdays (month, day);

    -- ── Saved playlists (v13) ─────────────────────────────────────────
    CREATE TABLE IF NOT EXISTS playlists (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id    TEXT NOT NULL,
      name       TEXT NOT NULL,
      tracks     TEXT NOT NULL,   -- JSON array of { uri, title }
      created_at INTEGER NOT NULL,
      UNIQUE (user_id, name)
    );
    CREATE INDEX IF NOT EXISTS idx_playlists_user ON playlists (user_id);

    -- ── Command usage stats (v14) ─────────────────────────────────────
    CREATE TABLE IF NOT EXISTS command_usage (
      guild_id  TEXT NOT NULL,
      command   TEXT NOT NULL,
      count     INTEGER NOT NULL DEFAULT 0,
      last_used INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (guild_id, command)
    );

    CREATE TABLE IF NOT EXISTS user_settings (
      user_id  TEXT PRIMARY KEY,
      timezone TEXT
    );

    CREATE TABLE IF NOT EXISTS play_history (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id  TEXT NOT NULL,
      user_id   TEXT,
      title     TEXT,
      author    TEXT,
      uri       TEXT,
      source    TEXT,
      played_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_play_history_guild ON play_history (guild_id, played_at);

    CREATE TABLE IF NOT EXISTS achievements (
      guild_id     TEXT NOT NULL,
      user_id      TEXT NOT NULL,
      key          TEXT NOT NULL,
      unlocked_at  INTEGER NOT NULL,
      PRIMARY KEY (guild_id, user_id, key)
    );
  `);

  // ── column migrations ────────────────────────────────────────────
  // CREATE TABLE IF NOT EXISTS won't add columns to a table that already
  // exists, so new columns on existing tables are applied explicitly.
  addColumn(db, 'events', 'repeat_mode', 'TEXT');

  db.prepare(
    `INSERT INTO schema_meta (key, value) VALUES ('version', ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  ).run(String(SCHEMA_VERSION));
}

/** Add a column only if it isn't already present (safe to run every boot). */
function addColumn(db, table, column, decl) {
  const exists = db.prepare(`SELECT 1 FROM sqlite_master WHERE type='table' AND name=?`).get(table);
  if (!exists) return;
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  if (!cols.includes(column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${decl}`);
}

module.exports = { applySchema, SCHEMA_VERSION };
