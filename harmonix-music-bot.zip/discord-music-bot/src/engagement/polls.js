'use strict';

/**
 * Button-based polls with live results. Votes persist in the DB so counts
 * survive restarts and one-vote-per-user (single mode) is enforced.
 */

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const { getDb } = require('../db');

const LETTERS = ['🇦', '🇧', '🇨', '🇩', '🇪', '🇫', '🇬', '🇭', '🇮', '🇯'];
const MAX_OPTIONS = 10;

function createPoll(guildId, channelId, messageId, question, options, multi) {
  getDb()
    .prepare(
      `INSERT INTO polls (message_id, guild_id, channel_id, question, options, multi, created_by, created_at, closed)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`
    )
    .run(messageId, guildId, channelId, question, JSON.stringify(options), multi ? 1 : 0, null, Date.now());
}

function getPoll(messageId) {
  const row = getDb().prepare('SELECT * FROM polls WHERE message_id = ?').get(messageId);
  if (!row) return null;
  return { ...row, options: JSON.parse(row.options), multi: !!row.multi, closed: !!row.closed };
}

function setCreator(messageId, userId) {
  getDb().prepare('UPDATE polls SET created_by = ? WHERE message_id = ?').run(userId, messageId);
}

/** Apply a vote. Returns nothing; caller re-reads counts. */
function vote(poll, userId, choice) {
  const db = getDb();
  const existing = db
    .prepare('SELECT 1 FROM poll_votes WHERE message_id = ? AND user_id = ? AND choice = ?')
    .get(poll.message_id, userId, choice);
  if (existing) {
    // Clicking your current choice again removes it (toggle off).
    db.prepare('DELETE FROM poll_votes WHERE message_id = ? AND user_id = ? AND choice = ?').run(poll.message_id, userId, choice);
    return;
  }
  if (!poll.multi) {
    db.prepare('DELETE FROM poll_votes WHERE message_id = ? AND user_id = ?').run(poll.message_id, userId);
  }
  db.prepare('INSERT INTO poll_votes (message_id, user_id, choice) VALUES (?, ?, ?)').run(poll.message_id, userId, choice);
}

function counts(messageId, optionCount) {
  const rows = getDb()
    .prepare('SELECT choice, COUNT(*) AS n FROM poll_votes WHERE message_id = ? GROUP BY choice')
    .all(messageId);
  const arr = new Array(optionCount).fill(0);
  for (const r of rows) if (r.choice < optionCount) arr[r.choice] = r.n;
  const voters = getDb()
    .prepare('SELECT COUNT(DISTINCT user_id) AS v FROM poll_votes WHERE message_id = ?')
    .get(messageId).v;
  return { arr, voters };
}

function close(messageId) {
  getDb().prepare('UPDATE polls SET closed = 1 WHERE message_id = ?').run(messageId);
}

// ── rendering ────────────────────────────────────────────────────
function bar(n, total, len = 16) {
  const ratio = total > 0 ? n / total : 0;
  const filled = Math.round(ratio * len);
  return '▰'.repeat(filled) + '▱'.repeat(len - filled);
}

function buildEmbed(poll, countData) {
  const total = countData.arr.reduce((a, b) => a + b, 0);
  const lines = poll.options.map((opt, i) => {
    const n = countData.arr[i] || 0;
    const pct = total > 0 ? Math.round((n / total) * 100) : 0;
    return `${LETTERS[i]} **${opt}**\n${bar(n, total)} ${n} (${pct}%)`;
  });
  const header = poll.created_by ? `Started by <@${poll.created_by}>\n\n` : '';
  return new EmbedBuilder()
    .setColor(poll.closed ? 0x6b7280 : config.brand.color)
    .setTitle(`📊 ${poll.question}${poll.closed ? ' — Closed' : ''}`)
    .setDescription(header + lines.join('\n\n'))
    .setFooter({ text: `${countData.voters} voter${countData.voters === 1 ? '' : 's'}${poll.multi ? ' • multiple choice' : ''}` });
}

function buildComponents(poll) {
  const rows = [];
  for (let i = 0; i < poll.options.length; i += 5) {
    const row = new ActionRowBuilder();
    for (let j = i; j < Math.min(i + 5, poll.options.length); j++) {
      row.addComponents(
        new ButtonBuilder()
          .setCustomId(`poll:${j}`)
          .setEmoji(LETTERS[j])
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(poll.closed)
      );
    }
    rows.push(row);
  }
  return rows;
}

module.exports = {
  LETTERS, MAX_OPTIONS,
  createPoll, getPoll, setCreator, vote, counts, close,
  buildEmbed, buildComponents,
};
