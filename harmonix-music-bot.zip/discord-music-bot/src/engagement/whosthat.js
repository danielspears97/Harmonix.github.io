'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const { getJson } = require('../utils/fetchJson');

const MAX_ID = 1025;
const sessions = new Map();

function cap(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function rint(max) {
  return Math.floor(Math.random() * max) + 1;
}

/** Fetch a target Pokémon plus three decoy names; returns a round object. */
async function fetchRound() {
  const targetId = rint(MAX_ID);
  const target = await getJson(`https://pokeapi.co/api/v2/pokemon/${targetId}`);
  const decoyIds = new Set();
  while (decoyIds.size < 3) {
    const id = rint(MAX_ID);
    if (id !== targetId) decoyIds.add(id);
  }
  const decoys = await Promise.all([...decoyIds].map((id) => getJson(`https://pokeapi.co/api/v2/pokemon/${id}`)));
  const names = [target.name, ...decoys.map((d) => d.name)];
  // shuffle
  for (let i = names.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [names[i], names[j]] = [names[j], names[i]];
  }
  return {
    name: target.name,
    correctIndex: names.indexOf(target.name),
    options: names,
    types: target.types.map((t) => t.type.name).join(', '),
    sprite: target.sprites?.other?.['official-artwork']?.front_default || target.sprites?.front_default,
    letters: target.name.length,
  };
}

function startSession(messageId, round) {
  sessions.set(messageId, { ...round, answered: new Set(), solved: false });
}
function getSession(messageId) {
  return sessions.get(messageId);
}
function endSession(messageId) {
  sessions.delete(messageId);
}

function buildEmbed(round) {
  return new EmbedBuilder()
    .setColor(config.brand.color)
    .setTitle('❓ Who’s That Pokémon?')
    .setDescription(`**Hints**\nType: **${round.types}**\nLetters: **${round.letters}**\n\nPick the right name below!`);
}
function buildComponents(round, disabled = false) {
  const rows = [];
  for (let i = 0; i < round.options.length; i += 2) {
    const row = new ActionRowBuilder();
    for (let j = i; j < Math.min(i + 2, round.options.length); j++) {
      row.addComponents(new ButtonBuilder().setCustomId(`whosthat:${j}`).setLabel(cap(round.options[j])).setStyle(ButtonStyle.Secondary).setDisabled(disabled));
    }
    rows.push(row);
  }
  return rows;
}
function buildReveal(round, winnerId) {
  const embed = new EmbedBuilder()
    .setColor(winnerId ? config.brand.successColor : config.brand.errorColor)
    .setTitle(`It’s ${cap(round.name)}!`)
    .setDescription(winnerId ? `🎉 <@${winnerId}> got it!` : 'Nobody guessed it in time.');
  if (round.sprite) embed.setImage(round.sprite);
  return embed;
}

module.exports = { fetchRound, startSession, getSession, endSession, buildEmbed, buildComponents, buildReveal, cap };
