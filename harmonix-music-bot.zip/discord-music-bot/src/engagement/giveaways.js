'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const { getDb } = require('../db');

function create(guildId, channelId, messageId, prize, winners, endsAt, hostId) {
  getDb()
    .prepare(
      `INSERT INTO giveaways (message_id, guild_id, channel_id, prize, winners, ends_at, host_id, ended)
       VALUES (?, ?, ?, ?, ?, ?, ?, 0)`
    )
    .run(messageId, guildId, channelId, prize, winners, endsAt, hostId);
}

function get(messageId) {
  return getDb().prepare('SELECT * FROM giveaways WHERE message_id = ?').get(messageId);
}

/** Toggle entry. Returns 'entered' or 'left'. */
function toggleEntry(messageId, userId) {
  const db = getDb();
  const exists = db.prepare('SELECT 1 FROM giveaway_entries WHERE message_id = ? AND user_id = ?').get(messageId, userId);
  if (exists) {
    db.prepare('DELETE FROM giveaway_entries WHERE message_id = ? AND user_id = ?').run(messageId, userId);
    return 'left';
  }
  db.prepare('INSERT INTO giveaway_entries (message_id, user_id) VALUES (?, ?)').run(messageId, userId);
  return 'entered';
}

function entryCount(messageId) {
  return getDb().prepare('SELECT COUNT(*) AS n FROM giveaway_entries WHERE message_id = ?').get(messageId).n;
}
function entries(messageId) {
  return getDb().prepare('SELECT user_id FROM giveaway_entries WHERE message_id = ?').all(messageId).map((r) => r.user_id);
}
function listDue(now = Date.now()) {
  return getDb().prepare('SELECT * FROM giveaways WHERE ended = 0 AND ends_at <= ?').all(now);
}
function markEnded(messageId) {
  getDb().prepare('UPDATE giveaways SET ended = 1 WHERE message_id = ?').run(messageId);
}

/** Pick up to `count` unique random winners from the entrant list. */
function pickWinners(entrantIds, count) {
  const pool = [...entrantIds];
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, Math.max(0, Math.min(count, pool.length)));
}

function buildEmbed(giveaway, count) {
  const host = giveaway.host_id ? `\n**Hosted by:** <@${giveaway.host_id}>` : '';
  return new EmbedBuilder()
    .setColor(giveaway.ended ? 0x6b7280 : config.brand.color)
    .setTitle(`🎉 ${giveaway.prize}`)
    .setDescription(
      giveaway.ended
        ? `This giveaway has ended.${host}`
        : `Click 🎉 below to enter!\n\n**Ends:** <t:${Math.floor(giveaway.ends_at / 1000)}:R>\n**Winners:** ${giveaway.winners}${host}`
    )
    .setFooter({ text: `${count} entr${count === 1 ? 'y' : 'ies'}` });
}

function buildComponents(giveaway) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('gw:enter')
        .setEmoji('🎉')
        .setLabel('Enter')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(!!giveaway.ended)
    ),
  ];
}

module.exports = {
  create, get, toggleEntry, entryCount, entries, listDue, markEnded, pickWinners,
  buildEmbed, buildComponents,
};
