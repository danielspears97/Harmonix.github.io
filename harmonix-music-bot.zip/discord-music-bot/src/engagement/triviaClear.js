'use strict';

const settings = require('../server/guildSettings');

const HOUR_MS = 60 * 60 * 1000;

async function clearOnce(client) {
  for (const guild of client.guilds.cache.values()) {
    const channelId = settings.getTriviaChannel(guild.id);
    if (!channelId) continue;
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (!channel || !channel.isTextBased()) continue;
    try {
      // bulkDelete only removes messages younger than 14 days; loop a couple of times for busy channels.
      let deleted;
      let rounds = 0;
      do {
        deleted = await channel.bulkDelete(100, true).catch(() => null);
        rounds += 1;
      } while (deleted && deleted.size === 100 && rounds < 5);
    } catch (err) {
      console.error(`[trivia-clear] failed for ${channelId}:`, err.message);
    }
  }
}

function start(client) {
  setInterval(() => clearOnce(client).catch(() => {}), HOUR_MS);
  console.log('[trivia-clear] hourly channel clear scheduled');
}

module.exports = { start, clearOnce };
