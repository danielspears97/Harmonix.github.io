'use strict';

const levels = require('./levels');
const achievements = require('./achievements');
const guildSettings = require('../server/guildSettings');
const featureToggles = require('../server/featureToggles');

const TICK_MS = 60000; // award once per minute
const XP_PER_TICK = 5; // XP per active voice minute

let timer = null;

/** Award voice XP to eligible members currently in voice. */
function sweep(client) {
  for (const guild of client.guilds.cache.values()) {
    if (!featureToggles.isModuleEnabled(guild.id, 'leveling')) continue;
    if (!guildSettings.getVoiceXp(guild.id)) continue;
    if (!levels.getSettings(guild.id).enabled) continue;

    const afkId = guild.afkChannelId;
    for (const channel of guild.channels.cache.values()) {
      if (channel.type !== 2 && channel.type !== 13) continue; // GuildVoice / StageVoice
      if (channel.id === afkId) continue;
      const humans = channel.members.filter((m) => !m.user.bot);
      if (humans.size < 2) continue; // must be with at least one other person
      for (const member of humans.values()) {
        const vs = member.voice;
        if (vs.deaf || vs.selfDeaf) continue; // not actually listening
        const res = levels.addXp(guild.id, member.id, XP_PER_TICK);
        const unlocked = [achievements.unlock(guild.id, member.id, 'socialite')].filter(Boolean);
        if (res.leveledUp) unlocked.push(...achievements.checkLevel(guild.id, member.id, res.newLevel));
        unlocked.push(...achievements.checkMeta(guild.id, member.id));
        if (unlocked.length) achievements.announce(client, { guildId: guild.id, userId: member.id, channel: guild.systemChannel || null, defs: unlocked });
      }
    }
  }
}

function start(client) {
  if (timer) return;
  timer = setInterval(() => { try { sweep(client); } catch { /* ignore */ } }, TICK_MS);
}
function stop() { if (timer) { clearInterval(timer); timer = null; } }

module.exports = { start, stop, sweep };
