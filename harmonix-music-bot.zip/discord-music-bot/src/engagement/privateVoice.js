'use strict';

const { getConfig, setConfig } = require('../db');

// Stores the link between a private voice channel, its companion control
// text channel, and the current owner. Keyed by voice channel id.
function map(guildId) {
  return getConfig(guildId, 'pvc', {}) || {};
}
function setPair(guildId, voiceId, textId, ownerId) {
  const m = map(guildId);
  m[voiceId] = { textId, ownerId, panelMessageId: null };
  setConfig(guildId, 'pvc', m);
}
function setPanel(guildId, voiceId, panelMessageId) {
  const m = map(guildId);
  if (m[voiceId]) { m[voiceId].panelMessageId = panelMessageId; setConfig(guildId, 'pvc', m); }
}
function byVoice(guildId, voiceId) {
  const e = map(guildId)[voiceId];
  return e ? { voiceId, ...e } : null;
}
function byText(guildId, textId) {
  const m = map(guildId);
  for (const [voiceId, e] of Object.entries(m)) if (e.textId === textId) return { voiceId, ...e };
  return null;
}
function setOwner(guildId, voiceId, ownerId) {
  const m = map(guildId);
  if (m[voiceId]) { m[voiceId].ownerId = ownerId; setConfig(guildId, 'pvc', m); }
}
function removePair(guildId, voiceId) {
  const m = map(guildId);
  if (m[voiceId]) { delete m[voiceId]; setConfig(guildId, 'pvc', m); }
}
function listPairs(guildId) {
  return Object.entries(map(guildId)).map(([voiceId, e]) => ({ voiceId, ...e }));
}

/** On boot, delete any private channels left empty/orphaned by a restart. */
async function bootCleanup(client) {
  for (const guild of client.guilds.cache.values()) {
    for (const pair of listPairs(guild.id)) {
      const voice = await client.channels.fetch(pair.voiceId).catch(() => null);
      const empty = !voice || voice.members.filter((m) => !m.user.bot).size === 0;
      if (empty) {
        const text = await client.channels.fetch(pair.textId).catch(() => null);
        removePair(guild.id, pair.voiceId);
        if (text) await text.delete('Private VC cleanup (boot)').catch(() => {});
        if (voice) await voice.delete('Private VC cleanup (boot)').catch(() => {});
      }
    }
  }
}

module.exports = { setPair, setPanel, byVoice, byText, setOwner, removePair, listPairs, bootCleanup };
