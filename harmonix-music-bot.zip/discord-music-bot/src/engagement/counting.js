'use strict';

const { getConfig, setConfig } = require('../db');
const achievements = require('./achievements');

function getState(guildId) {
  const s = getConfig(guildId, 'counting', {}) || {};
  return { channelId: s.channelId || null, current: s.current || 0, lastUser: s.lastUser || null, best: s.best || 0 };
}
function save(guildId, s) {
  setConfig(guildId, 'counting', s);
  return s;
}
function setChannel(guildId, channelId) {
  const s = getState(guildId);
  s.channelId = channelId || null;
  s.current = 0;
  s.lastUser = null;
  return save(guildId, s);
}

/** Process a message in the counting channel. Returns true if it handled it. */
async function handle(message) {
  const s = getState(message.guild.id);
  if (!s.channelId || message.channel.id !== s.channelId) return false;

  const m = String(message.content).trim().match(/^-?\d+/);
  if (!m) return false; // not a number — ignore chatter
  const num = parseInt(m[0], 10);
  const expected = s.current + 1;

  if (num === expected && message.author.id !== s.lastUser) {
    s.current = expected;
    s.lastUser = message.author.id;
    const record = expected > s.best;
    if (record) s.best = expected;
    save(message.guild.id, s);
    await message.react(record ? '🏆' : '✅').catch(() => {});

    const unlocked = achievements.checkCounting(message.guild.id, message.author.id, expected);
    if (unlocked.length) {
      achievements.announce(message.client, { guildId: message.guild.id, userId: message.author.id, channel: message.channel, defs: unlocked });
    }
    return true;
  }

  // Wrong number or same person twice in a row → reset.
  const doublePost = num === expected && message.author.id === s.lastUser;
  s.current = 0;
  s.lastUser = null;
  save(message.guild.id, s);
  await message.react('❌').catch(() => {});
  const why = doublePost ? 'You can’t count twice in a row!' : `That should have been **${expected}**.`;
  await message.channel.send(`❌ ${message.author} broke the count! ${why} Start again from **1**.`).catch(() => {});
  return true;
}

module.exports = { getState, setChannel, handle };
