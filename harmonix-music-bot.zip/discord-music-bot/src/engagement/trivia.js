'use strict';

const { EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const levels = require('./levels');

const DEFAULT_QUESTION_MS = 25000; // normal time to answer before the answer is revealed
const SPEED_QUESTION_MS = 8000; // speed-round default
const MIN_QUESTION_MS = 5000;
const MAX_QUESTION_MS = 120000;
const QUESTION_MS = DEFAULT_QUESTION_MS; // back-compat export
const INACTIVITY_MS = 120000; // stop if nobody chats in the channel for this long
const REWARD = { easy: 15, medium: 25, hard: 40 };
const SPEED_BONUS = 1.5; // XP multiplier for answering in the first 40% of the timer

const sessions = new Map(); // channelId -> session
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function normalize(s) {
  return String(s)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/^(the |a |an )/, '')
    .replace(/[^a-z0-9 ]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function prettyCategory(key) {
  return String(key || 'General').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function clampTimer(ms) {
  const n = Number(ms);
  if (!Number.isFinite(n)) return DEFAULT_QUESTION_MS;
  return Math.max(MIN_QUESTION_MS, Math.min(MAX_QUESTION_MS, Math.round(n)));
}

/** Some OpenTDB questions are unanswerable without the options shown
 *  ("Which of the following…") — skip those so free-text stays fair. */
function answerable(text) {
  return !/which of (the following|these)\b/i.test(String(text));
}

/** Fetch one free-text question from The Trivia API. `category` may be a
 *  category key, or a `tag:<name>` value for a more specific topic. */
async function fetchFromTriviaApi(category, difficulty) {
  let url = 'https://the-trivia-api.com/v2/questions?limit=1';
  if (category && category.startsWith('tag:')) url += `&tags=${encodeURIComponent(category.slice(4))}`;
  else if (category) url += `&categories=${encodeURIComponent(category)}`;
  if (difficulty) url += `&difficulties=${encodeURIComponent(difficulty)}`;
  const res = await fetch(url, { headers: { 'User-Agent': 'HarmonixBot' } });
  if (!res.ok) throw new Error(`Trivia API ${res.status}`);
  const data = await res.json();
  if (!Array.isArray(data) || !data.length) throw new Error('Trivia API empty');
  const q = data[0];
  return {
    question: typeof q.question === 'object' ? q.question.text : q.question,
    answer: q.correctAnswer,
    category: prettyCategory(q.category),
    difficulty: q.difficulty || 'medium',
  };
}

// OpenTDB rate-limits to ~1 request / 5s per IP, so we fetch a batch and serve
// from a per-category cache, refilling only when it runs dry.
const otdbCache = new Map(); // `${catId}|${difficulty}` -> shuffled questions[]

async function fetchFromOpenTdb(catId, difficulty) {
  const key = `${catId}|${difficulty || ''}`;
  let pool = otdbCache.get(key);
  if (!pool || !pool.length) {
    let url = `https://opentdb.com/api.php?amount=20&type=multiple&category=${catId}&encode=url3986`;
    if (difficulty) url += `&difficulty=${difficulty}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`OpenTDB ${res.status}`);
    const data = await res.json();
    if (data.response_code !== 0 || !Array.isArray(data.results) || !data.results.length) throw new Error('OpenTDB empty');
    pool = data.results
      .map((r) => ({
        question: decodeURIComponent(r.question),
        answer: decodeURIComponent(r.correct_answer),
        category: decodeURIComponent(r.category).replace(/^[^:]+:\s*/, ''),
        difficulty: r.difficulty || 'medium',
      }))
      .filter((q) => answerable(q.question));
    for (let i = pool.length - 1; i > 0; i -= 1) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    if (!pool.length) throw new Error('OpenTDB no answerable');
    otdbCache.set(key, pool);
  }
  return pool.shift();
}

// Each category value maps to its source(s). ttapi = The Trivia API category
// or tag; otdb = OpenTDB category id. Both present → questions pull from either.
const SOURCES = {
  general_knowledge: { ttapi: 'general_knowledge', otdb: 9 },
  science: { ttapi: 'science', otdb: 17 },
  film_and_tv: { ttapi: 'film_and_tv', otdb: 11 },
  music: { ttapi: 'music', otdb: 12 },
  history: { ttapi: 'history', otdb: 23 },
  geography: { ttapi: 'geography', otdb: 22 },
  arts_and_literature: { ttapi: 'arts_and_literature', otdb: 25 },
  sport_and_leisure: { ttapi: 'sport_and_leisure', otdb: 21 },
  society_and_culture: { ttapi: 'society_and_culture', otdb: null },
  food_and_drink: { ttapi: 'food_and_drink', otdb: null },
  'tag:video_games': { ttapi: 'tag:video_games', otdb: 15 },
  'tag:movies': { ttapi: 'tag:movies', otdb: 11 },
  'tag:marvel': { ttapi: 'tag:marvel', otdb: 29 },
  'tag:comics': { ttapi: 'tag:comics', otdb: 29 },
  'tag:harry_potter': { ttapi: 'tag:harry_potter', otdb: null },
  'tag:space': { ttapi: 'tag:space', otdb: null },
  'tag:mathematics': { ttapi: 'tag:mathematics', otdb: 19 },
  'tag:chemistry': { ttapi: 'tag:chemistry', otdb: 17 },
  'tag:physics': { ttapi: 'tag:physics', otdb: 17 },
  'tag:biology': { ttapi: 'tag:biology', otdb: 17 },
  'tag:animals': { ttapi: 'tag:animals', otdb: 27 },
  'tag:mythology': { ttapi: 'tag:mythology', otdb: 20 },
  'tag:football': { ttapi: 'tag:football', otdb: 21 },
  'tag:board_games': { ttapi: 'tag:board_games', otdb: 16 },
  'otdb:anime': { ttapi: null, otdb: 31 },
};

/** Fetch a question for the chosen category from whichever source(s) it has,
 *  trying them in random order so variety is spread across both. */
async function fetchQuestion({ category, difficulty } = {}) {
  const src = category ? SOURCES[category] : null;
  const providers = [];
  if (src) {
    if (src.ttapi) providers.push(() => fetchFromTriviaApi(src.ttapi, difficulty));
    if (src.otdb) providers.push(() => fetchFromOpenTdb(src.otdb, difficulty));
  } else if (category) {
    providers.push(() => fetchFromTriviaApi(category, difficulty)); // unknown value: treat as ttapi
  } else {
    providers.push(() => fetchFromTriviaApi(undefined, difficulty)); // no category: random
  }
  // shuffle so we don't always hit the same source first
  for (let i = providers.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [providers[i], providers[j]] = [providers[j], providers[i]];
  }
  let lastErr;
  for (const p of providers) {
    try { return await p(); } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error('No question available');
}

function isActive(channelId) {
  return sessions.has(channelId);
}

function clearTimers(s) {
  if (s) {
    if (s.qTimer) clearTimeout(s.qTimer);
    if (s.inactivityTimer) clearTimeout(s.inactivityTimer);
  }
}

function stop(channelId) {
  const s = sessions.get(channelId);
  clearTimers(s);
  sessions.delete(channelId);
  return s;
}

/** Reset the "channel went quiet" timer; called on every human message. */
function bumpActivity(client, channel) {
  const s = sessions.get(channel.id);
  if (!s) return;
  if (s.inactivityTimer) clearTimeout(s.inactivityTimer);
  s.inactivityTimer = setTimeout(async () => {
    const sess = stop(channel.id);
    const n = sess ? sess.correct : 0;
    await channel
      .send(`💤 Trivia paused — the channel went quiet.${n ? ` You answered **${n}** question${n === 1 ? '' : 's'} correctly this round.` : ''}\nStart again any time with \`/game trivia\`.`)
      .catch(() => {});
  }, INACTIVITY_MS);
}

function questionEmbed(session, data) {
  const secs = Math.round(session.questionMs / 1000);
  const speed = session.mode === 'speed';
  return new EmbedBuilder()
    .setColor(config.brand.color)
    .setAuthor({ name: `${speed ? '⚡ Speed Trivia' : '🧠 Trivia'} • ${data.category} (${data.difficulty})` })
    .setTitle(data.question)
    .setFooter({ text: `Type your answer in chat! ${secs}s per question${speed ? ' — answer fast for bonus XP!' : ''}` });
}

async function ask(client, channel) {
  const session = sessions.get(channel.id);
  if (!session) return;

  let data;
  for (let attempt = 0; attempt < 5 && sessions.has(channel.id); attempt += 1) {
    try {
      const d = await fetchQuestion(session.opts);
      const key = normalize(d.question);
      // Avoid repeating a question we've already asked this round.
      if (session.seen.has(key) && attempt < 4) continue;
      data = d;
      session.seen.add(key);
      if (session.seen.size > 400) session.seen.clear();
      break;
    } catch { await sleep(2000); }
  }
  if (!sessions.has(channel.id)) return; // stopped while fetching
  if (!data) {
    session.qTimer = setTimeout(() => ask(client, channel).catch(() => {}), 6000);
    return;
  }

  session.answer = data.answer;
  session.normAnswer = normalize(data.answer);
  session.difficulty = data.difficulty;
  session.questionStart = Date.now();
  session.token = (session.token || 0) + 1;
  const token = session.token;
  await channel.send({ embeds: [questionEmbed(session, data)] }).catch(() => {});
  session.qTimer = setTimeout(() => onTimeout(client, channel, token).catch(() => {}), session.questionMs);
}

async function start(client, channel, guildId, opts = {}) {
  if (sessions.has(channel.id)) return false;
  const mode = opts.mode === 'speed' ? 'speed' : 'normal';
  // Timer precedence: explicit timer > speed default > normal default.
  const questionMs = opts.questionMs
    ? clampTimer(opts.questionMs)
    : mode === 'speed' ? SPEED_QUESTION_MS : DEFAULT_QUESTION_MS;
  sessions.set(channel.id, {
    guildId,
    opts: { category: opts.category, difficulty: opts.difficulty },
    mode,
    questionMs,
    seen: new Set(),
    asked: 0,
    correct: 0,
    token: 0,
  });
  bumpActivity(client, channel);
  await ask(client, channel);
  return true;
}

/** Free-text matching on the normalized answer. */
function isCorrect(s, content) {
  if (!s.normAnswer) return false;
  return normalize(content) === s.normAnswer;
}

async function handleMessage(client, message) {
  const s = sessions.get(message.channel.id);
  if (!s || message.author.bot || !message.content) return;

  bumpActivity(client, message.channel); // any human message keeps the round alive

  if (!s.normAnswer || !isCorrect(s, message.content)) return;

  if (s.qTimer) clearTimeout(s.qTimer);
  s.normAnswer = null; // lock out double-credit until the next question loads
  s.asked += 1;
  s.correct += 1;

  let reward = REWARD[String(s.difficulty).toLowerCase()] || 20;
  // Speed bonus: answered within the first 40% of the timer.
  const elapsed = Date.now() - (s.questionStart || 0);
  const fast = s.mode === 'speed' && elapsed <= s.questionMs * 0.4;
  if (fast) reward = Math.round(reward * SPEED_BONUS);

  if (levels.getSettings(s.guildId).enabled) levels.addXp(s.guildId, message.author.id, reward);
  {
    const ach = require('./achievements');
    const d = ach.unlock(s.guildId, message.author.id, 'trivia_win');
    const meta = ach.checkMeta(s.guildId, message.author.id);
    const unlocked = [d, ...meta].filter(Boolean);
    if (unlocked.length) ach.announce(client, { guildId: s.guildId, userId: message.author.id, channel: message.channel, defs: unlocked });
  }
  await message.reply({
    content: `✅ ${message.author} got it — **${s.answer}**! (+${reward} XP${fast ? ' ⚡ speed bonus' : ''})`,
    allowedMentions: { users: [message.author.id] },
  }).catch(() => {});
  await ask(client, message.channel);
}

/** A question went unanswered: reveal it and continue to the next one. */
async function onTimeout(client, channel, token) {
  const s = sessions.get(channel.id);
  if (!s || s.token !== token) return; // superseded
  s.asked += 1;
  s.normAnswer = null;
  await channel.send(`⏰ Time's up! The answer was **${s.answer}**. Here's the next one…`).catch(() => {});
  await ask(client, channel);
}

module.exports = {
  QUESTION_MS, DEFAULT_QUESTION_MS, SPEED_QUESTION_MS, MIN_QUESTION_MS, MAX_QUESTION_MS, INACTIVITY_MS, REWARD,
  normalize, fetchQuestion, fetchFromTriviaApi, fetchFromOpenTdb, answerable,
  isActive, stop, start, ask, handleMessage, onTimeout, bumpActivity, isCorrect, clampTimer,
};
