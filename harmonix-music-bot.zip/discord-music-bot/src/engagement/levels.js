'use strict';

/**
 * Leveling / XP. Uses the well-known curve where advancing from level L to L+1
 * costs 5·L² + 50·L + 100 XP. Pure math (xpForLevel / levelFromXp) is separated
 * so it can be unit-tested. State lives in the `levels` table; per-guild config
 * lives in guild_config under 'levels'.
 */

const { getDb, getConfig, setConfig } = require('../db');

const DEFAULTS = {
  enabled: false,
  announce: false, // announce level-ups in the channel where they happen
  cooldown: 60000, // ms between XP awards per user
  min: 15,
  max: 25,
  rewards: [], // [{ level, roleId }]
};

function getSettings(guildId) {
  const s = getConfig(guildId, 'levels', null);
  return s ? { ...DEFAULTS, ...s, rewards: s.rewards || [] } : { ...DEFAULTS };
}
function saveSettings(guildId, settings) {
  return setConfig(guildId, 'levels', settings);
}

// ── curve ────────────────────────────────────────────────────────
function xpToAdvance(level) {
  return 5 * level * level + 50 * level + 100;
}
/** Total cumulative XP required to *reach* a given level. */
function xpForLevel(level) {
  let total = 0;
  for (let l = 0; l < level; l++) total += xpToAdvance(l);
  return total;
}
/** Which level a given total XP corresponds to. */
function levelFromXp(xp) {
  let level = 0;
  let need = xpToAdvance(0);
  let acc = xp;
  while (acc >= need) {
    acc -= need;
    level += 1;
    need = xpToAdvance(level);
  }
  return level;
}
/** Progress within the current level: { have, need }. */
function levelProgress(xp) {
  const level = levelFromXp(xp);
  const base = xpForLevel(level);
  return { level, have: xp - base, need: xpToAdvance(level) };
}

// ── data ─────────────────────────────────────────────────────────
function getUser(guildId, userId) {
  return (
    getDb().prepare('SELECT * FROM levels WHERE guild_id = ? AND user_id = ?').get(guildId, userId) || {
      guild_id: guildId,
      user_id: userId,
      xp: 0,
      level: 0,
      last_msg_at: 0,
    }
  );
}

function setXp(guildId, userId, xp) {
  const level = levelFromXp(xp);
  getDb()
    .prepare(
      `INSERT INTO levels (guild_id, user_id, xp, level, last_msg_at)
       VALUES (?, ?, ?, ?, 0)
       ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = excluded.xp, level = excluded.level`
    )
    .run(guildId, userId, Math.max(0, xp), level);
  return { xp: Math.max(0, xp), level };
}

/**
 * Add (or subtract) XP without touching the message cooldown — used by trivia
 * rewards and admin tools. Returns { xp, oldLevel, newLevel, leveledUp }.
 */
function addXp(guildId, userId, delta) {
  const u = getUser(guildId, userId);
  const newXp = Math.max(0, u.xp + delta);
  const oldLevel = u.level;
  const newLevel = levelFromXp(newXp);
  getDb()
    .prepare(
      `INSERT INTO levels (guild_id, user_id, xp, level, last_msg_at)
       VALUES (@g, @u, @xp, @lvl, @last)
       ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = @xp, level = @lvl`
    )
    .run({ g: guildId, u: userId, xp: newXp, lvl: newLevel, last: u.last_msg_at });
  return { xp: newXp, oldLevel, newLevel, leveledUp: newLevel > oldLevel };
}

function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Award XP for a message, respecting cooldown. Returns null if on cooldown,
 * otherwise { amount, oldLevel, newLevel, leveledUp, xp }.
 */
function awardMessage(guildId, userId, settings = DEFAULTS, now = Date.now()) {
  const u = getUser(guildId, userId);
  if (now - u.last_msg_at < settings.cooldown) return null;
  const amount = rand(settings.min, settings.max);
  const newXp = u.xp + amount;
  const oldLevel = u.level;
  const newLevel = levelFromXp(newXp);
  getDb()
    .prepare(
      `INSERT INTO levels (guild_id, user_id, xp, level, last_msg_at)
       VALUES (@g, @u, @xp, @lvl, @now)
       ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = @xp, level = @lvl, last_msg_at = @now`
    )
    .run({ g: guildId, u: userId, xp: newXp, lvl: newLevel, now });
  return { amount, oldLevel, newLevel, leveledUp: newLevel > oldLevel, xp: newXp };
}

function top(guildId, limit = 10) {
  return getDb()
    .prepare('SELECT * FROM levels WHERE guild_id = ? ORDER BY xp DESC LIMIT ?')
    .all(guildId, limit);
}

function rankOf(guildId, userId) {
  const u = getUser(guildId, userId);
  const row = getDb()
    .prepare('SELECT COUNT(*) AS ahead FROM levels WHERE guild_id = ? AND xp > ?')
    .get(guildId, u.xp);
  return { rank: row.ahead + 1, ...u };
}

module.exports = {
  DEFAULTS, getSettings, saveSettings,
  xpToAdvance, xpForLevel, levelFromXp, levelProgress,
  getUser, setXp, addXp, awardMessage, top, rankOf,
};
