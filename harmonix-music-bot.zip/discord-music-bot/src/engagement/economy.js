'use strict';

const { getDb, getConfig, setConfig } = require('../db');

const DAY = 24 * 60 * 60 * 1000;
const HOUR = 60 * 60 * 1000;

// ── config ───────────────────────────────────────────────────────
function getCfg(guildId) {
  const c = getConfig(guildId, 'economy_config', null) || {};
  return {
    name: c.name || 'coins',
    symbol: c.symbol || '🪙',
    daily: c.daily != null ? c.daily : 200,
    workMin: c.workMin != null ? c.workMin : 50,
    workMax: c.workMax != null ? c.workMax : 250,
  };
}
function setCfg(guildId, patch) {
  setConfig(guildId, 'economy_config', { ...getCfg(guildId), ...patch });
  return getCfg(guildId);
}
function fmt(amount, cfg) {
  return `**${amount.toLocaleString()}** ${cfg.symbol}`;
}

// ── accounts ─────────────────────────────────────────────────────
function account(guildId, userId) {
  const db = getDb();
  db.prepare('INSERT OR IGNORE INTO economy (guild_id, user_id) VALUES (?, ?)').run(guildId, userId);
  return db.prepare('SELECT * FROM economy WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
}
function balance(guildId, userId) {
  return account(guildId, userId).balance;
}
function addBalance(guildId, userId, amount) {
  account(guildId, userId);
  getDb().prepare('UPDATE economy SET balance = MAX(0, balance + ?) WHERE guild_id = ? AND user_id = ?').run(amount, guildId, userId);
  return balance(guildId, userId);
}
function setBalance(guildId, userId, amount) {
  account(guildId, userId);
  getDb().prepare('UPDATE economy SET balance = ? WHERE guild_id = ? AND user_id = ?').run(Math.max(0, amount), guildId, userId);
  return balance(guildId, userId);
}
function top(guildId, limit = 10) {
  return getDb().prepare('SELECT user_id, balance FROM economy WHERE guild_id = ? AND balance > 0 ORDER BY balance DESC LIMIT ?').all(guildId, limit);
}

// ── daily / work ─────────────────────────────────────────────────
function claimDaily(guildId, userId) {
  const acc = account(guildId, userId);
  const cfg = getCfg(guildId);
  const now = Date.now();
  const since = now - acc.last_daily;
  if (acc.last_daily && since < DAY) return { ok: false, nextIn: DAY - since };
  const streak = acc.last_daily && since < 2 * DAY ? acc.streak + 1 : 1;
  const bonus = Math.min(streak - 1, 14) * 10;
  const amount = cfg.daily + bonus;
  getDb().prepare('UPDATE economy SET balance = balance + ?, last_daily = ?, streak = ? WHERE guild_id = ? AND user_id = ?').run(amount, now, streak, guildId, userId);
  return { ok: true, amount, streak, bonus, balance: balance(guildId, userId) };
}
function work(guildId, userId) {
  const acc = account(guildId, userId);
  const cfg = getCfg(guildId);
  const now = Date.now();
  const since = now - acc.last_work;
  if (acc.last_work && since < HOUR) return { ok: false, nextIn: HOUR - since };
  const amount = Math.floor(cfg.workMin + Math.random() * (cfg.workMax - cfg.workMin + 1));
  getDb().prepare('UPDATE economy SET balance = balance + ?, last_work = ? WHERE guild_id = ? AND user_id = ?').run(amount, now, guildId, userId);
  return { ok: true, amount, balance: balance(guildId, userId) };
}
function transfer(guildId, fromId, toId, amount) {
  if (amount <= 0) return { ok: false, reason: 'Amount must be positive.' };
  if (fromId === toId) return { ok: false, reason: 'You can’t pay yourself.' };
  if (balance(guildId, fromId) < amount) return { ok: false, reason: 'You don’t have enough.' };
  addBalance(guildId, fromId, -amount);
  addBalance(guildId, toId, amount);
  return { ok: true };
}

// ── shop ─────────────────────────────────────────────────────────
function listItems(guildId) {
  return getDb().prepare('SELECT * FROM economy_shop WHERE guild_id = ? ORDER BY price').all(guildId);
}
function getItemByName(guildId, name) {
  return getDb().prepare('SELECT * FROM economy_shop WHERE guild_id = ? AND LOWER(name) = LOWER(?)').get(guildId, name);
}
function addItem(guildId, name, price, roleId, description) {
  getDb().prepare('INSERT INTO economy_shop (guild_id, name, price, role_id, description) VALUES (?, ?, ?, ?, ?)').run(guildId, name, price, roleId || null, description || null);
}
function removeItemByName(guildId, name) {
  const info = getDb().prepare('DELETE FROM economy_shop WHERE guild_id = ? AND LOWER(name) = LOWER(?)').run(guildId, name);
  return info.changes > 0;
}

// ── gambling ─────────────────────────────────────────────────────
const REELS = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣'];
function slots(bet) {
  const r = [0, 0, 0].map(() => REELS[Math.floor(Math.random() * REELS.length)]);
  let mult = 0;
  if (r[0] === r[1] && r[1] === r[2]) {
    mult = r[0] === '7️⃣' ? 10 : r[0] === '💎' ? 7 : 5;
  } else if (r[0] === r[1] || r[1] === r[2] || r[0] === r[2]) {
    mult = 2;
  }
  const payout = bet * mult; // total returned (0 if lost)
  return { reels: r, mult, payout, net: payout - bet };
}
function coinflip(bet, side) {
  const result = Math.random() < 0.5 ? 'heads' : 'tails';
  const win = result === side;
  return { result, win, payout: win ? bet * 2 : 0, net: win ? bet : -bet };
}

module.exports = {
  DAY, HOUR, getCfg, setCfg, fmt, account, balance, addBalance, setBalance, top,
  claimDaily, work, transfer, listItems, getItemByName, addItem, removeItemByName,
  slots, coinflip,
};
