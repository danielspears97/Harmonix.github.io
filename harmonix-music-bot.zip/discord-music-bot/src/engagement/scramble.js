'use strict';

const WORDS = [
  'galaxy', 'puzzle', 'rhythm', 'voyage', 'quartz', 'wizard', 'falcon', 'orbit', 'cactus', 'dolphin',
  'glacier', 'harbor', 'jungle', 'lantern', 'meadow', 'nebula', 'pyramid', 'ribbon', 'sphinx', 'turtle',
  'velvet', 'walnut', 'anchor', 'breeze', 'comet', 'dragon', 'feather', 'gadget', 'horizon', 'island',
  'kettle', 'mosaic', 'oxygen', 'penguin', 'quiver', 'saffron', 'thunder', 'umbrella', 'volcano', 'whisper',
];

const sessions = new Map(); // channelId -> { word, scrambled }

function scramble(word) {
  let out = word;
  while (out === word) {
    out = word.split('').sort(() => Math.random() - 0.5).join('');
  }
  return out;
}

function start(channelId) {
  const word = WORDS[Math.floor(Math.random() * WORDS.length)];
  const state = { word, scrambled: scramble(word) };
  sessions.set(channelId, state);
  return state;
}
function active(channelId) {
  return sessions.get(channelId) || null;
}
function check(channelId, guess) {
  const s = sessions.get(channelId);
  if (s && guess.toLowerCase().trim() === s.word) {
    sessions.delete(channelId);
    return s.word;
  }
  return null;
}
function clear(channelId) {
  sessions.delete(channelId);
}

module.exports = { start, active, check, clear };
