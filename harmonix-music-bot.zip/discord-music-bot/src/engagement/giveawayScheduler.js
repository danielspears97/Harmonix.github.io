'use strict';

const giveaways = require('./giveaways');

async function endGiveaway(client, row) {
  giveaways.markEnded(row.message_id);
  const winners = giveaways.pickWinners(giveaways.entries(row.message_id), row.winners);

  const channel = await client.channels.fetch(row.channel_id).catch(() => null);
  if (!channel || !channel.isTextBased()) return;

  const message = await channel.messages.fetch(row.message_id).catch(() => null);
  if (message) {
    const ended = { ...row, ended: 1 };
    await message
      .edit({ embeds: [giveaways.buildEmbed(ended, giveaways.entryCount(row.message_id))], components: giveaways.buildComponents(ended) })
      .catch(() => {});
  }

  if (winners.length === 0) {
    await channel.send(`🎉 No valid entries for **${row.prize}** — no winner.`).catch(() => {});
  } else {
    const mentions = winners.map((id) => `<@${id}>`).join(', ');
    await channel
      .send({ content: `🎉 Congratulations ${mentions}! You won **${row.prize}**!`, allowedMentions: { users: winners } })
      .catch(() => {});
    const achievements = require('./achievements');
    for (const id of winners) {
      const d = achievements.unlock(row.guild_id, id, 'lucky');
      const unlocked = [d, ...achievements.checkMeta(row.guild_id, id)].filter(Boolean);
      if (unlocked.length) achievements.announce(client, { guildId: row.guild_id, userId: id, channel, defs: unlocked });
    }
  }
}

async function check(client) {
  try {
    for (const row of giveaways.listDue()) {
      await endGiveaway(client, row);
    }
  } catch (err) {
    console.error('[giveaways] scheduler error:', err.message);
  }
}

function start(client) {
  check(client); // catch any that expired while offline
  setInterval(() => check(client), 15000);
  console.log('[giveaways] scheduler started');
}

module.exports = { start, endGiveaway, check };
