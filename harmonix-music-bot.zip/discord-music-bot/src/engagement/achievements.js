'use strict';

const { getDb } = require('../db');

// ── exhaustive achievement catalogue ─────────────────────────────
// Every achievement here is reachable; the trigger that unlocks it is wired in
// trackStart (music), the level-up handler, the counting game, or voice XP.
const DEFS = [
  // Music — song-count milestones (tracks the member has had played)
  { key: 'first_song', emoji: '🎵', name: 'First Drop', desc: 'Play your first song.', group: 'Music' },
  { key: 'songs_10', emoji: '🎶', name: 'Warming Up', desc: 'Have 10 songs played.', group: 'Music' },
  { key: 'songs_25', emoji: '💿', name: 'Selector', desc: 'Have 25 songs played.', group: 'Music' },
  { key: 'songs_50', emoji: '📀', name: 'Crate Digger', desc: 'Have 50 songs played.', group: 'Music' },
  { key: 'songs_100', emoji: '🎧', name: 'Resident DJ', desc: 'Have 100 songs played.', group: 'Music' },
  { key: 'songs_250', emoji: '🎚️', name: 'Tastemaker', desc: 'Have 250 songs played.', group: 'Music' },
  { key: 'songs_500', emoji: '🏆', name: 'Headliner', desc: 'Have 500 songs played.', group: 'Music' },
  { key: 'songs_1000', emoji: '👑', name: 'Legend of the Decks', desc: 'Have 1,000 songs played.', group: 'Music' },
  // Music — flavour
  { key: 'night_owl', emoji: '🦉', name: 'Night Owl', desc: 'Queue a song between midnight and 5am.', group: 'Music' },
  { key: 'early_riser', emoji: '🌅', name: 'Early Riser', desc: 'Queue a song between 5am and 8am.', group: 'Music' },
  { key: 'eclectic', emoji: '🌈', name: 'Eclectic Taste', desc: 'Play from YouTube, Spotify, and SoundCloud.', group: 'Music' },
  { key: 'live_wire', emoji: '📡', name: 'Live Wire', desc: 'Play a live stream.', group: 'Music' },

  // Leveling
  { key: 'level_5', emoji: '⭐', name: 'Getting Started', desc: 'Reach level 5.', group: 'Leveling' },
  { key: 'level_10', emoji: '🌟', name: 'Regular', desc: 'Reach level 10.', group: 'Leveling' },
  { key: 'level_25', emoji: '💫', name: 'Veteran', desc: 'Reach level 25.', group: 'Leveling' },
  { key: 'level_50', emoji: '🏅', name: 'Elite', desc: 'Reach level 50.', group: 'Leveling' },
  { key: 'level_75', emoji: '🎖️', name: 'Champion', desc: 'Reach level 75.', group: 'Leveling' },
  { key: 'level_100', emoji: '🏆', name: 'Maxed Out', desc: 'Reach level 100.', group: 'Leveling' },

  // Voice
  { key: 'socialite', emoji: '🎙️', name: 'Socialite', desc: 'Earn XP hanging out in a voice call.', group: 'Voice' },

  // Counting game
  { key: 'counter', emoji: '🔢', name: 'Counter', desc: 'Add a correct number in the counting game.', group: 'Counting' },
  { key: 'count_50', emoji: '🖐️', name: 'Halfway There', desc: 'Help the count reach 50.', group: 'Counting' },
  { key: 'count_100', emoji: '💯', name: 'Centurion', desc: 'Help the count reach 100.', group: 'Counting' },
  { key: 'count_500', emoji: '🧮', name: 'Number Cruncher', desc: 'Help the count reach 500.', group: 'Counting' },

  // Activity & social
  { key: 'trivia_win', emoji: '🧠', name: 'Quiz Whiz', desc: 'Answer a trivia question correctly.', group: 'Activity' },
  { key: 'star_struck', emoji: '⭐', name: 'Star Struck', desc: 'Get one of your messages on the starboard.', group: 'Activity' },
  { key: 'lucky', emoji: '🍀', name: 'Lucky One', desc: 'Win a giveaway.', group: 'Activity' },

  // Command explorer (earned by using each part of the bot)
  { key: 'gamer', emoji: '🎮', name: 'Game Night', desc: 'Play a game.', group: 'Explorer' },
  { key: 'jester', emoji: '🤡', name: 'Class Clown', desc: 'Use a fun command.', group: 'Explorer' },
  { key: 'entrepreneur', emoji: '💰', name: 'Entrepreneur', desc: 'Use the economy.', group: 'Explorer' },
  { key: 'helper', emoji: '🧰', name: 'Toolbox', desc: 'Use a utility command.', group: 'Explorer' },
  { key: 'moderator', emoji: '🛡️', name: 'On Patrol', desc: 'Use a moderation command.', group: 'Explorer' },
  { key: 'social_butterfly', emoji: '🦋', name: 'Social Butterfly', desc: 'Use a community command.', group: 'Explorer' },
  { key: 'explorer', emoji: '🧭', name: 'Explorer', desc: 'Earn all six command badges.', group: 'Explorer' },

  // Meta
  { key: 'collector', emoji: '🗃️', name: 'Collector', desc: 'Unlock 15 other achievements.', group: 'Meta' },
];
const DEF_OF = Object.fromEntries(DEFS.map((d) => [d.key, d]));

function has(guildId, userId, key) {
  return !!getDb().prepare('SELECT 1 FROM achievements WHERE guild_id = ? AND user_id = ? AND key = ?').get(guildId, userId, key);
}

/** Unlock an achievement. Returns the definition if newly unlocked, else null. */
function unlock(guildId, userId, key) {
  if (!DEF_OF[key] || !userId) return null;
  const res = getDb()
    .prepare('INSERT OR IGNORE INTO achievements (guild_id, user_id, key, unlocked_at) VALUES (?, ?, ?, ?)')
    .run(guildId, userId, key, Date.now());
  return res.changes > 0 ? DEF_OF[key] : null;
}

function unlockedCount(guildId, userId) {
  return getDb().prepare('SELECT COUNT(*) AS n FROM achievements WHERE guild_id = ? AND user_id = ?').get(guildId, userId).n;
}

/** Capstone: unlock "Collector" once enough others are earned. */
function checkMeta(guildId, userId) {
  const out = [];
  if (unlockedCount(guildId, userId) >= 15) { const d = unlock(guildId, userId, 'collector'); if (d) out.push(d); }
  return out;
}

// Which achievement a command's module grants on first use.
const MODULE_ACH = { games: 'gamer', fun: 'jester', economy: 'entrepreneur', utility: 'helper', moderation: 'moderator', community: 'social_butterfly' };
const EXPLORER_KEYS = Object.values(MODULE_ACH);

function forModule(moduleKey) {
  return MODULE_ACH[moduleKey] || null;
}

/** Unlock "Explorer" once every command badge is earned. */
function checkExplorer(guildId, userId) {
  const owned = new Set(getDb().prepare('SELECT key FROM achievements WHERE guild_id = ? AND user_id = ?').all(guildId, userId).map((r) => r.key));
  if (EXPLORER_KEYS.every((k) => owned.has(k))) return unlock(guildId, userId, 'explorer');
  return null;
}

function checkSongMilestones(guildId, userId, count) {
  const out = [];
  for (const [n, key] of [[1, 'first_song'], [10, 'songs_10'], [25, 'songs_25'], [50, 'songs_50'], [100, 'songs_100'], [250, 'songs_250'], [500, 'songs_500'], [1000, 'songs_1000']]) {
    if (count >= n) { const d = unlock(guildId, userId, key); if (d) out.push(d); }
  }
  return out;
}

function checkLevel(guildId, userId, level) {
  const out = [];
  for (const [n, key] of [[5, 'level_5'], [10, 'level_10'], [25, 'level_25'], [50, 'level_50'], [75, 'level_75'], [100, 'level_100']]) {
    if (level >= n) { const d = unlock(guildId, userId, key); if (d) out.push(d); }
  }
  return out.concat(checkMeta(guildId, userId));
}

/** Counting milestones. `number` is the value just reached correctly. */
function checkCounting(guildId, userId, number) {
  const out = [];
  const d0 = unlock(guildId, userId, 'counter'); if (d0) out.push(d0);
  for (const [n, key] of [[50, 'count_50'], [100, 'count_100'], [500, 'count_500']]) {
    if (number >= n) { const d = unlock(guildId, userId, key); if (d) out.push(d); }
  }
  return out.concat(checkMeta(guildId, userId));
}

function list(guildId, userId) {
  const rows = getDb().prepare('SELECT key FROM achievements WHERE guild_id = ? AND user_id = ?').all(guildId, userId);
  const owned = new Set(rows.map((r) => r.key));
  return DEFS.map((d) => ({ ...d, unlocked: owned.has(d.key) }));
}

function leaderboard(guildId, limit = 15) {
  return getDb()
    .prepare(
      "SELECT user_id, COUNT(*) AS count, MAX(unlocked_at) AS latest FROM achievements WHERE guild_id = ? GROUP BY user_id ORDER BY count DESC, latest ASC LIMIT ?"
    )
    .all(guildId, limit);
}

function stats(guildId) {
  const rows = getDb().prepare('SELECT key, COUNT(*) AS n FROM achievements WHERE guild_id = ? GROUP BY key').all(guildId);
  const out = {};
  for (const r of rows) out[r.key] = r.n;
  return out;
}

/** Announce newly-unlocked achievements per the guild's configured mode
 *  ('channel' | 'dm' | 'specific' | 'off'). `channel` is the contextual
 *  channel where the unlock happened (may be null for voice). */
async function announce(client, { guildId, userId, channel, defs }) {
  if (!client || !userId || !defs || !defs.length) return;
  let setting;
  try { setting = require('../server/guildSettings').getAchievementAnnounce(guildId); } catch { setting = { mode: 'channel' }; }
  if (setting.mode === 'off') return;
  const badges = defs.map((d) => `**${d.name}** ${d.emoji}`).join(' · ');

  if (setting.mode === 'dm') {
    try { const u = await client.users.fetch(userId); await u.send(`🏆 You unlocked ${badges}`); } catch { /* DMs closed */ }
    return;
  }
  let target = channel;
  if (setting.mode === 'specific') {
    target = setting.channelId
      ? (client.channels.cache.get(setting.channelId) || await client.channels.fetch(setting.channelId).catch(() => null))
      : channel;
  }
  if (target && target.isTextBased?.()) {
    target.send({ content: `🏆 <@${userId}> unlocked ${badges}`, allowedMentions: { users: [userId] } }).catch(() => {});
  }
}

module.exports = { DEFS, has, unlock, checkMeta, checkSongMilestones, checkLevel, checkCounting, forModule, checkExplorer, announce, list, leaderboard, stats };
