'use strict';

const { getDb, getConfig, setConfig } = require('../db');

// ── join-to-create voice settings ────────────────────────────────
function getVoiceSettings(guildId) {
  const s = getConfig(guildId, 'tempvoice', null) || {};
  return { categoryId: s.categoryId || null, privateHubId: s.privateHubId || null };
}
function setVoiceSettings(guildId, patch) {
  setConfig(guildId, 'tempvoice', { ...getVoiceSettings(guildId), ...patch });
  return getVoiceSettings(guildId);
}

// ── channel records ──────────────────────────────────────────────
function record(channelId, guildId, kind, ownerId, expiresAt = null) {
  getDb()
    .prepare('INSERT OR REPLACE INTO temp_channels (channel_id, guild_id, kind, owner_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(channelId, guildId, kind, ownerId, expiresAt, Date.now());
}
function remove(channelId) {
  getDb().prepare('DELETE FROM temp_channels WHERE channel_id = ?').run(channelId);
}
function get(channelId) {
  return getDb().prepare('SELECT * FROM temp_channels WHERE channel_id = ?').get(channelId);
}
function isTemp(channelId, kind) {
  const row = get(channelId);
  return !!row && (!kind || row.kind === kind);
}
function getDueText(now) {
  return getDb().prepare("SELECT * FROM temp_channels WHERE kind = 'text' AND expires_at IS NOT NULL AND expires_at <= ?").all(now);
}
function listVoice(guildId) {
  return getDb().prepare("SELECT * FROM temp_channels WHERE guild_id = ? AND kind = 'voice'").all(guildId);
}

let started = false;

/** Periodically delete expired text channels, and clean orphaned temp voice. */
function start(client) {
  if (started) return;
  started = true;

  const sweep = async () => {
    // expired text channels
    for (const row of getDueText(Date.now())) {
      const ch = await client.channels.fetch(row.channel_id).catch(() => null);
      if (ch) await ch.delete('Temporary channel expired').catch(() => {});
      remove(row.channel_id);
    }
  };

  // boot cleanup: remove empty temp voice channels left behind by a restart
  const bootCleanup = async () => {
    for (const guild of client.guilds.cache.values()) {
      for (const row of listVoice(guild.id)) {
        const ch = await client.channels.fetch(row.channel_id).catch(() => null);
        if (!ch) { remove(row.channel_id); continue; }
        if (ch.members && ch.members.filter((m) => !m.user.bot).size === 0) {
          await ch.delete('Empty temp voice channel (boot cleanup)').catch(() => {});
          remove(row.channel_id);
        }
      }
    }
  };

  bootCleanup().catch(() => {});
  sweep().catch(() => {});
  setInterval(() => sweep().catch(() => {}), 30 * 1000);
  console.log('[tempchannels] scheduler started');
}

module.exports = { getVoiceSettings, setVoiceSettings, record, remove, get, isTemp, getDueText, listVoice, start };
