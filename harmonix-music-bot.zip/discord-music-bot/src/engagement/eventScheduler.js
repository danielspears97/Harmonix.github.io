'use strict';

const events = require('./events');

const TICK_MS = 30 * 1000;

// A slow tick must not overlap the next one, or the same event gets posted twice.
let ticking = false;

async function tick(client) {
  if (ticking) return;
  ticking = true;
  try {
    await runTick(client);
  } finally {
    ticking = false;
  }
}

async function runTick(client) {
  // post events whose scheduled post time has arrived
  for (const ev of events.duePosts()) {
    // Claim it before sending: two ticks (or a restart mid-send) can otherwise
    // both see posted = 0 and post the same event twice.
    if (!events.claimForPost(ev.id)) continue;
    const channel = await client.channels.fetch(ev.channel_id).catch(() => null);
    if (!channel || !channel.isTextBased?.()) { events.markRemoved(ev.id); continue; }
    const msg = await channel
      .send({ embeds: [events.buildEmbed(ev)], components: events.buildComponents(ev) })
      .catch(() => null);
    if (msg) events.setMessage(ev.id, msg.id);
    else {
      // Couldn't post (no permission in that channel). It stays claimed, so we
      // don't retry it every 30 seconds forever.
      events.markRemoved(ev.id);
      console.warn(`[events] couldn't post event #${ev.id} in ${ev.channel_id} — check my permissions there`);
    }
  }

  // take down events past their removal time
  for (const ev of events.dueRemovals()) {
    events.markRemoved(ev.id);

    // Recurring events immediately schedule their next occurrence.
    if (ev.repeat_mode) {
      const nextStart = events.nextOccurrence(ev.start_at, ev.repeat_mode);
      if (nextStart) {
        const keepFor = ev.remove_at ? ev.remove_at - ev.start_at : 24 * 60 * 60 * 1000;
        events.create({
          guildId: ev.guild_id,
          channelId: ev.channel_id,
          creatorId: ev.creator_id,
          name: ev.name,
          description: ev.description,
          imageUrl: ev.image_url,
          startAt: nextStart,
          postAt: Date.now(), // post the next one straight away
          removeAt: nextStart + keepFor,
          reactions: ev.reactions,
          repeatMode: ev.repeat_mode,
        });
      }
    }

    if (!ev.message_id) continue;
    const channel = await client.channels.fetch(ev.channel_id).catch(() => null);
    if (!channel) continue;
    const msg = await channel.messages.fetch(ev.message_id).catch(() => null);
    if (msg) await msg.delete().catch(() => {});
  }
}

function start(client) {
  setInterval(() => tick(client).catch(() => {}), TICK_MS);
  setTimeout(() => tick(client).catch(() => {}), 8000);
  console.log('[events] scheduler started');
}

// Re-render an event message after an RSVP changes.
async function refresh(client, ev) {
  if (!ev.message_id) return;
  const channel = await client.channels.fetch(ev.channel_id).catch(() => null);
  if (!channel) return;
  const msg = await channel.messages.fetch(ev.message_id).catch(() => null);
  if (msg) await msg.edit({ embeds: [events.buildEmbed(ev)], components: events.buildComponents(ev) }).catch(() => {});
}

module.exports = { start, tick, refresh };
