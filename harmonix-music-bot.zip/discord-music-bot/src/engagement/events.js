'use strict';

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getDb, getConfig, setConfig } = require('../db');
const { config } = require('../../config');

// ── storage ──────────────────────────────────────────────────────
function create(data) {
  const info = getDb().prepare(`
    INSERT INTO events (guild_id, channel_id, creator_id, name, description, image_url, start_at, post_at, remove_at, reactions, repeat_mode)
    VALUES (@guildId, @channelId, @creatorId, @name, @description, @imageUrl, @startAt, @postAt, @removeAt, @reactions, @repeatMode)
  `).run({
    guildId: data.guildId,
    channelId: data.channelId,
    creatorId: data.creatorId,
    name: data.name,
    description: data.description || null,
    imageUrl: data.imageUrl || null,
    startAt: data.startAt,
    postAt: data.postAt,
    removeAt: data.removeAt || null,
    reactions: JSON.stringify(data.reactions || []),
    repeatMode: data.repeatMode || null,
  });
  return get(info.lastInsertRowid);
}
function get(id) {
  const row = getDb().prepare('SELECT * FROM events WHERE id = ?').get(id);
  return row ? hydrate(row) : null;
}
function hydrate(row) {
  return { ...row, reactions: JSON.parse(row.reactions || '[]') };
}
/** Atomically claim an event for posting. Returns false if another tick (or
 *  a restart mid-send) already took it, which stops duplicate posts. */
function claimForPost(id) {
  return getDb().prepare('UPDATE events SET posted = 1 WHERE id = ? AND posted = 0').run(id).changes > 0;
}
function setMessage(id, messageId) {
  getDb().prepare('UPDATE events SET message_id = ?, posted = 1 WHERE id = ?').run(messageId, id);
}
function markRemoved(id) {
  getDb().prepare('UPDATE events SET removed = 1 WHERE id = ?').run(id);
}
function duePosts() {
  return getDb().prepare('SELECT * FROM events WHERE posted = 0 AND post_at <= ? ORDER BY post_at').all(Date.now()).map(hydrate);
}
function dueRemovals() {
  return getDb().prepare('SELECT * FROM events WHERE posted = 1 AND removed = 0 AND remove_at IS NOT NULL AND remove_at <= ?')
    .all(Date.now()).map(hydrate);
}
function upcomingForGuild(guildId) {
  return getDb().prepare('SELECT * FROM events WHERE guild_id = ? AND removed = 0 AND start_at >= ? ORDER BY start_at LIMIT 25')
    .all(guildId, Date.now() - 3600000).map(hydrate);
}
function remove(id, guildId) {
  return getDb().prepare('DELETE FROM events WHERE id = ? AND guild_id = ?').run(id, guildId).changes > 0;
}

// ── time format ──────────────────────────────────────────────────
// How to read an ambiguous numeric date like 08/14/2026 vs 14/08/2026.
const TIME_FORMATS = {
  mdy: { label: 'US — month/day/year (8/14/2026)', order: ['m', 'd', 'y'], example: '8/14/2026 7:30pm' },
  dmy: { label: 'EU — day/month/year (14/08/2026)', order: ['d', 'm', 'y'], example: '14/08/2026 19:30' },
  ymd: { label: 'ISO — year-month-day (2026-08-14)', order: ['y', 'm', 'd'], example: '2026-08-14 19:30' },
};
function getTimeFormat(guildId) {
  const v = getConfig(guildId, 'event_time_format', 'mdy');
  return TIME_FORMATS[v] ? v : 'mdy';
}
function setTimeFormat(guildId, fmt) {
  if (!TIME_FORMATS[fmt]) return getTimeFormat(guildId);
  setConfig(guildId, 'event_time_format', fmt);
  return fmt;
}

/** Parse a start time in the user's timezone. Accepts a relative offset
 *  (+2h30m), an ISO-ish date, or a numeric date read per the guild's format. */
function parseWhen(input, tz = 'UTC', fmt = 'mdy') {
  const s = String(input || '').trim();
  if (!s) return null;

  // relative: +2h30m / 90m / 3d
  const rel = s.match(/^\+?\s*(?:(\d+)\s*d)?\s*(?:(\d+)\s*h)?\s*(?:(\d+)\s*m)?$/i);
  if (rel && (rel[1] || rel[2] || rel[3])) {
    const ms = (Number(rel[1] || 0) * 86400 + Number(rel[2] || 0) * 3600 + Number(rel[3] || 0) * 60) * 1000;
    if (ms > 0) return Date.now() + ms;
  }

  // pull off a time portion if present
  let datePart = s;
  let hh = 0;
  let mm = 0;
  const tm = s.match(/(\d{1,2}):(\d{2})\s*(am|pm)?|(\d{1,2})\s*(am|pm)/i);
  if (tm) {
    if (tm[1] !== undefined) {
      hh = Number(tm[1]); mm = Number(tm[2]);
      const ap = (tm[3] || '').toLowerCase();
      if (ap === 'pm' && hh < 12) hh += 12;
      if (ap === 'am' && hh === 12) hh = 0;
    } else {
      hh = Number(tm[4]);
      const ap = (tm[5] || '').toLowerCase();
      if (ap === 'pm' && hh < 12) hh += 12;
      if (ap === 'am' && hh === 12) hh = 0;
    }
    datePart = s.slice(0, tm.index).trim();
  }

  // numeric date → apply the configured field order
  let y;
  let mo;
  let d;
  const nums = datePart.match(/^(\d{1,4})[/\-.](\d{1,2})(?:[/\-.](\d{2,4}))?$/);
  if (nums) {
    const order = TIME_FORMATS[fmt] ? TIME_FORMATS[fmt].order : TIME_FORMATS.mdy.order;
    const parts = [nums[1], nums[2], nums[3]].filter((x) => x !== undefined).map(Number);
    // A 4-digit leading value is unambiguously a year regardless of format.
    const eff = String(nums[1]).length === 4 ? ['y', 'm', 'd'] : order;
    const map = {};
    eff.forEach((k, i) => { if (parts[i] !== undefined) map[k] = parts[i]; });
    if (map.y === undefined) map.y = new Date().getUTCFullYear();
    if (map.y < 100) map.y += 2000;
    // Be forgiving: if the configured order yields an impossible month but the
    // swapped reading works (e.g. 14/08 typed while set to US format), use it.
    if (map.m > 12 && map.d <= 12) { const t = map.m; map.m = map.d; map.d = t; }
    y = map.y; mo = map.m; d = map.d;
  } else if (datePart) {
    // natural language ("Aug 14", "August 14 2026") — require a real month name
    // so random words don't silently parse as January 1st.
    if (!/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i.test(datePart) || !/\d/.test(datePart)) return null;
    const probe = new Date(`${datePart} ${new Date().getUTCFullYear()}`);
    const parsed = Number.isNaN(probe.getTime()) ? new Date(datePart) : probe;
    if (Number.isNaN(parsed.getTime())) return null;
    y = parsed.getFullYear(); mo = parsed.getMonth() + 1; d = parsed.getDate();
  } else {
    // time only → today (or tomorrow if it already passed)
    const now = new Date();
    y = now.getUTCFullYear(); mo = now.getUTCMonth() + 1; d = now.getUTCDate();
  }
  if (!mo || !d || mo > 12 || d > 31) return null;

  // Build the instant as if the wall-clock time were UTC, then shift by the
  // zone's offset so it lands on the user's actual local time.
  const naive = Date.UTC(y, mo - 1, d, hh, mm, 0);
  let ts = naive;
  try {
    const local = new Date(naive).toLocaleString('en-US', { timeZone: tz });
    const utc = new Date(naive).toLocaleString('en-US', { timeZone: 'UTC' });
    ts = naive + (new Date(utc).getTime() - new Date(local).getTime());
  } catch { /* unknown tz → treat as UTC */ }

  // A bare time that already passed today means tomorrow.
  if (!datePart && ts <= Date.now()) ts += 86400000;
  return ts;
}

// ── recurrence ───────────────────────────────────────────────────
// Presets plus free-form intervals. A custom repeat is stored canonically as
// "<unit>:<n>" — d:3 = every 3 days, w:2 = every 2 weeks, and so on.
const REPEAT = {
  daily: { label: 'Every day', unit: 'd', n: 1 },
  every2d: { label: 'Every 2 days', unit: 'd', n: 2 },
  every3d: { label: 'Every 3 days', unit: 'd', n: 3 },
  weekly: { label: 'Every week', unit: 'w', n: 1 },
  biweekly: { label: 'Every 2 weeks', unit: 'w', n: 2 },
  every3w: { label: 'Every 3 weeks', unit: 'w', n: 3 },
  monthly: { label: 'Every month', unit: 'm', n: 1 },
  every2m: { label: 'Every 2 months', unit: 'm', n: 2 },
  quarterly: { label: 'Every 3 months', unit: 'm', n: 3 },
  every6m: { label: 'Every 6 months', unit: 'm', n: 6 },
  yearly: { label: 'Every year', unit: 'y', n: 1 },
};

const UNIT_NAME = { d: 'day', w: 'week', m: 'month', y: 'year' };

/** Resolve a stored repeat value (preset key or "d:5") to its rule. */
function repeatRule(mode) {
  if (!mode) return null;
  if (REPEAT[mode]) return REPEAT[mode];
  const m = String(mode).match(/^([dwmy]):(\d+)$/);
  if (!m) return null;
  const n = Number(m[2]);
  const unit = m[1];
  if (!n || n < 1) return null;
  return { label: n === 1 ? `Every ${UNIT_NAME[unit]}` : `Every ${n} ${UNIT_NAME[unit]}s`, unit, n };
}

/** Accept presets, plain words, or free-form input like "every 5 days" / "3w".
 *  Returns a canonical repeat value, or null for "no repeat". */
function parseRepeat(input) {
  const s = String(input || '').trim().toLowerCase();
  if (!s || ['none', 'no', 'off', 'never', "don't repeat", 'once'].includes(s)) return null;
  if (REPEAT[s]) return s;

  const words = {
    day: 'daily', daily: 'daily', everyday: 'daily',
    week: 'weekly', weekly: 'weekly',
    fortnight: 'biweekly', fortnightly: 'biweekly', biweekly: 'biweekly',
    month: 'monthly', monthly: 'monthly',
    quarter: 'quarterly', quarterly: 'quarterly',
    year: 'yearly', yearly: 'yearly', annually: 'yearly', annual: 'yearly',
  };
  const plain = s.replace(/^every\s+/, '').replace(/s$/, '');
  if (words[plain]) return words[plain];
  if (words[s]) return words[s];

  // "every 3 days", "3d", "2 weeks", "every 6 months"
  const m = s.match(/^(?:every\s+)?(\d+)\s*(d|day|days|w|week|weeks|m|month|months|y|year|years)$/);
  if (m) {
    const n = Math.min(365, Math.max(1, Number(m[1])));
    const unit = m[2][0];
    // collapse to a preset when one matches exactly, so labels stay friendly
    for (const [key, r] of Object.entries(REPEAT)) {
      if (r.unit === unit && r.n === n) return key;
    }
    return `${unit}:${n}`;
  }
  return null;
}

/** Next start time for a recurring event, always in the future. */
function nextOccurrence(startAt, mode) {
  const rule = repeatRule(mode);
  if (!rule) return null;
  const d = new Date(startAt);
  let guard = 0;
  do {
    if (rule.unit === 'd') d.setUTCDate(d.getUTCDate() + rule.n);
    else if (rule.unit === 'w') d.setUTCDate(d.getUTCDate() + rule.n * 7);
    else if (rule.unit === 'm') d.setUTCMonth(d.getUTCMonth() + rule.n);
    else d.setUTCFullYear(d.getUTCFullYear() + rule.n);
    guard += 1;
  } while (d.getTime() <= Date.now() && guard < 500); // skip any missed runs
  return d.getTime();
}

// ── RSVPs (single choice per user — like picking one poll option) ──
function setRsvp(eventId, userId, emoji) {
  const db = getDb();
  const prior = db.prepare('SELECT emoji FROM event_rsvps WHERE event_id = ? AND user_id = ?').get(eventId, userId);
  // clear any existing vote first, so a user can never hold two answers
  db.prepare('DELETE FROM event_rsvps WHERE event_id = ? AND user_id = ?').run(eventId, userId);
  if (prior && prior.emoji === emoji) return { status: 'removed' }; // clicking the same choice un-RSVPs
  db.prepare('INSERT INTO event_rsvps (event_id, user_id, emoji) VALUES (?, ?, ?)').run(eventId, userId, emoji);
  return { status: prior ? 'changed' : 'set', emoji };
}
function rsvpCounts(eventId) {
  const rows = getDb().prepare('SELECT emoji, COUNT(*) AS n FROM event_rsvps WHERE event_id = ? GROUP BY emoji').all(eventId);
  const out = {};
  for (const r of rows) out[r.emoji] = r.n;
  return out;
}
function rsvpUsers(eventId, emoji) {
  return getDb().prepare('SELECT user_id FROM event_rsvps WHERE event_id = ? AND emoji = ?').all(eventId, emoji).map((r) => r.user_id);
}

// ── presentation ─────────────────────────────────────────────────
const MAX_NAMES = 8; // list this many per option, then "+N more"
const clamp = (s, n) => {
  const t = String(s ?? '');
  return t.length <= n ? t : `${t.slice(0, n - 1)}…`;
};

/** "Repeats every week - next on 14 Aug" (blank for one-off events). */
function repeatLine(ev) {
  const rule = repeatRule(ev.repeat_mode);
  if (!rule) return '';
  const next = nextOccurrence(ev.start_at, ev.repeat_mode);
  const when = next ? `  \u00b7  next on <t:${Math.floor(next / 1000)}:D>` : '';
  return `\uD83D\uDD01  Repeats ${rule.label.toLowerCase()}${when}`;
}

function buildEmbed(ev) {
  const counts = rsvpCounts(ev.id);
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  const start = Math.floor(ev.start_at / 1000);
  const live = Date.now() >= ev.start_at;

  // Clamp the user's description on its own, so the time and repeat lines
  // below it can never be pushed past the embed's character limit.
  const meta = [
    `🕒  <t:${start}:F>`,
    `⏳  <t:${start}:R>`,
    repeatLine(ev),
  ].filter(Boolean).join('\n');
  const body = ev.description ? `${clamp(ev.description, 4096 - meta.length - 4)}\n\n` : '';

  const embed = new EmbedBuilder()
    .setColor(live ? 0x57f287 : config.brand.color)
    .setAuthor({ name: live ? '📅  Event  ·  happening now' : '📅  Event' })
    .setTitle(clamp(ev.name || 'Event', 256))
    .setDescription(`${body}${meta}`);

  if (ev.image_url) embed.setImage(ev.image_url);

  // One field per RSVP option, showing who picked it (mentions render as
  // names in embeds without pinging anyone).
  if (ev.reactions.length) {
    for (const r of ev.reactions) {
      const ids = rsvpUsers(ev.id, r.emoji);
      const shown = ids.slice(0, MAX_NAMES).map((id) => `<@${id}>`).join(', ');
      const extra = ids.length > MAX_NAMES ? ` *+${ids.length - MAX_NAMES} more*` : '';
      embed.addFields({
        name: clamp(`${r.emoji}  ${r.label} — ${ids.length}`, 256),
        value: clamp(ids.length ? `${shown}${extra}` : '*nobody yet*', 1024),
        inline: true,
      });
    }
  }

  embed.setFooter({ text: `Event #${ev.id}  ·  ${total} responded  ·  one pick each, click again to clear` });
  embed.setTimestamp(ev.start_at);
  return embed;
}
function buildComponents(ev) {
  if (!ev.reactions.length) return [];
  const counts = rsvpCounts(ev.id);
  const rows = [];
  let row = new ActionRowBuilder();
  ev.reactions.forEach((r, i) => {
    if (i > 0 && i % 5 === 0) { rows.push(row); row = new ActionRowBuilder(); }
    const n = counts[r.emoji] || 0;
    row.addComponents(
      new ButtonBuilder()
        .setCustomId(`event:rsvp:${ev.id}:${i}`)
        .setLabel(`${r.label}${n ? ` · ${n}` : ''}`.slice(0, 40))
        .setEmoji(r.emoji)
        .setStyle(n ? ButtonStyle.Primary : ButtonStyle.Secondary)
    );
  });
  rows.push(row);
  return rows.slice(0, 5);
}

module.exports = {
  TIME_FORMATS, getTimeFormat, setTimeFormat, parseWhen,
  REPEAT, repeatRule, parseRepeat, nextOccurrence, repeatLine,
  create, get, claimForPost, setMessage, markRemoved, duePosts, dueRemovals, upcomingForGuild, remove,
  setRsvp, rsvpCounts, rsvpUsers, buildEmbed, buildComponents,
};
