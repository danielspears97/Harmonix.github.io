'use strict';
// In-memory cache of the last deleted message per channel (best effort).
const last = new Map();
function remember(channelId, data) { last.set(channelId, data); }
function recall(channelId) { return last.get(channelId) || null; }
module.exports = { remember, recall };
