'use strict';

const { getConfig, setConfig } = require('../db');

const MAX_ROLES = 25;

function all(guildId) {
  return getConfig(guildId, 'rolemenus', {}) || {};
}
function save(guildId, map) {
  setConfig(guildId, 'rolemenus', map);
}
function create(guildId, data) {
  const map = all(guildId);
  const id = 'rm' + Date.now().toString(36) + Math.floor(Math.random() * 1000).toString(36);
  map[id] = { channelId: data.channelId, messageId: data.messageId || null, title: data.title, description: data.description || null, roles: [] };
  save(guildId, map);
  return id;
}
function get(guildId, id) {
  return all(guildId)[id] || null;
}
function setMessageId(guildId, id, messageId) {
  const map = all(guildId);
  if (map[id]) { map[id].messageId = messageId; save(guildId, map); }
}
function addRole(guildId, id, role) {
  const map = all(guildId);
  const menu = map[id];
  if (!menu) return { ok: false, reason: 'Menu not found.' };
  if (menu.roles.length >= MAX_ROLES) return { ok: false, reason: `A menu can hold at most ${MAX_ROLES} roles.` };
  if (menu.roles.some((r) => r.roleId === role.roleId)) return { ok: false, reason: 'That role is already in the menu.' };
  menu.roles.push(role);
  save(guildId, map);
  return { ok: true };
}
function removeRole(guildId, id, roleId) {
  const map = all(guildId);
  const menu = map[id];
  if (!menu) return false;
  const before = menu.roles.length;
  menu.roles = menu.roles.filter((r) => r.roleId !== roleId);
  save(guildId, map);
  return before !== menu.roles.length;
}
function removeMenu(guildId, id) {
  const map = all(guildId);
  if (!map[id]) return false;
  delete map[id];
  save(guildId, map);
  return true;
}
function list(guildId) {
  return Object.entries(all(guildId)).map(([id, m]) => ({ id, ...m }));
}

module.exports = { MAX_ROLES, all, create, get, setMessageId, addRole, removeRole, removeMenu, list };
