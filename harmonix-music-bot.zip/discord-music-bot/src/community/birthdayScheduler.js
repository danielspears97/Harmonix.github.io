'use strict';

const { EmbedBuilder } = require('discord.js');
const birthdays = require('./birthdays');
const { config } = require('../../config');

const HOUR = 60 * 60 * 1000;

async function runOnce(client) {
  const now = new Date();
  const month = now.getMonth() + 1;
  const day = now.getDate();
  const dateStr = `${now.getFullYear()}-${month}-${day}`;

  for (const guild of client.guilds.cache.values()) {
    const cfg = birthdays.getCfg(guild.id);
    if (!cfg.channelId) continue;
    const todays = birthdays.todayIn(guild.id, month, day);

    // Maintain the birthday role: grant to today's people, strip from others.
    if (cfg.roleId) {
      const role = guild.roles.cache.get(cfg.roleId);
      const me = guild.members.me;
      if (role && me && me.permissions.has('ManageRoles') && role.position < me.roles.highest.position) {
        const todayIds = new Set(todays.map((b) => b.user_id));
        for (const b of todays) {
          const m = await guild.members.fetch(b.user_id).catch(() => null);
          if (m && !m.roles.cache.has(role.id)) await m.roles.add(role.id, 'Birthday').catch(() => {});
        }
        for (const m of role.members.values()) {
          if (!todayIds.has(m.id)) await m.roles.remove(role.id, 'Birthday over').catch(() => {});
        }
      }
    }

    // Announce once per day.
    if (todays.length && cfg.lastAnnounced !== dateStr) {
      const channel = await client.channels.fetch(cfg.channelId).catch(() => null);
      if (channel && channel.isTextBased()) {
        const mentions = todays.map((b) => `<@${b.user_id}>`).join(', ');
        const embed = new EmbedBuilder()
          .setColor(config.brand.color)
          .setTitle('🎂 Happy Birthday!')
          .setDescription(`Everyone wish ${mentions} a happy birthday today! 🎉🥳`);
        await channel.send({ content: mentions, embeds: [embed], allowedMentions: { users: todays.map((b) => b.user_id) } }).catch(() => {});
      }
      birthdays.setCfg(guild.id, { lastAnnounced: dateStr });
    }
  }
}

function start(client) {
  runOnce(client).catch(() => {});
  setInterval(() => runOnce(client).catch(() => {}), HOUR);
  console.log('[birthdays] scheduler started');
}

module.exports = { start, runOnce };
