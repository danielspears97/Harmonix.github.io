'use strict';
const { getDb } = require('../db');

function set(guildId, userId, reason) {
  getDb()
    .prepare('INSERT INTO afk (guild_id, user_id, reason, since) VALUES (?, ?, ?, ?) ON CONFLICT(guild_id, user_id) DO UPDATE SET reason = excluded.reason, since = excluded.since')
    .run(guildId, userId, reason || null, Date.now());
}
function get(guildId, userId) {
  return getDb().prepare('SELECT * FROM afk WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
}
function clear(guildId, userId) {
  return getDb().prepare('DELETE FROM afk WHERE guild_id = ? AND user_id = ?').run(guildId, userId).changes > 0;
}
module.exports = { set, get, clear };
