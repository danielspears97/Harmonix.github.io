'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { config } = require('../../config');
const { getDb, getConfig, setConfig, deleteConfig } = require('../db');

function getChannel(guildId) {
  return getConfig(guildId, 'suggestions_channel', null);
}
function setChannel(guildId, channelId) {
  return setConfig(guildId, 'suggestions_channel', channelId);
}
function disable(guildId) {
  deleteConfig(guildId, 'suggestions_channel');
}

function create(guildId, channelId, messageId, authorId, text) {
  getDb()
    .prepare('INSERT INTO suggestions (message_id, guild_id, channel_id, author_id, text) VALUES (?, ?, ?, ?, ?)')
    .run(messageId, guildId, channelId, authorId, text);
}
function get(messageId) {
  return getDb().prepare('SELECT * FROM suggestions WHERE message_id = ?').get(messageId);
}

function vote(messageId, userId, v) {
  const db = getDb();
  const existing = db.prepare('SELECT vote FROM suggestion_votes WHERE message_id = ? AND user_id = ?').get(messageId, userId);
  if (existing && existing.vote === v) {
    db.prepare('DELETE FROM suggestion_votes WHERE message_id = ? AND user_id = ?').run(messageId, userId); // toggle off
  } else {
    db.prepare(
      'INSERT INTO suggestion_votes (message_id, user_id, vote) VALUES (?, ?, ?) ON CONFLICT(message_id, user_id) DO UPDATE SET vote = excluded.vote'
    ).run(messageId, userId, v);
  }
}
function counts(messageId) {
  const rows = getDb().prepare('SELECT vote, COUNT(*) AS n FROM suggestion_votes WHERE message_id = ? GROUP BY vote').all(messageId);
  let up = 0, down = 0;
  for (const r of rows) (r.vote === 1 ? (up = r.n) : (down = r.n));
  return { up, down };
}

function buildEmbed(authorTag, text, c) {
  return new EmbedBuilder()
    .setColor(config.brand.color)
    .setAuthor({ name: `💡 Suggestion from ${authorTag}` })
    .setDescription(text)
    .setFooter({ text: `👍 ${c.up}   👎 ${c.down}` });
}
function buildComponents() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('sug:up').setEmoji('👍').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('sug:down').setEmoji('👎').setStyle(ButtonStyle.Danger)
    ),
  ];
}

module.exports = { getChannel, setChannel, disable, create, get, vote, counts, buildEmbed, buildComponents };
