'use strict';

const { getDb, getConfig, setConfig } = require('../db');

const MONTHS = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS_IN_MONTH = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function validDate(month, day) {
  return month >= 1 && month <= 12 && day >= 1 && day <= DAYS_IN_MONTH[month];
}
function set(guildId, userId, month, day, year) {
  getDb().prepare('INSERT OR REPLACE INTO birthdays (guild_id, user_id, month, day, year) VALUES (?, ?, ?, ?, ?)').run(guildId, userId, month, day, year || null);
}
function remove(guildId, userId) {
  return getDb().prepare('DELETE FROM birthdays WHERE guild_id = ? AND user_id = ?').run(guildId, userId).changes > 0;
}
function get(guildId, userId) {
  return getDb().prepare('SELECT * FROM birthdays WHERE guild_id = ? AND user_id = ?').get(guildId, userId);
}
function forGuild(guildId) {
  return getDb().prepare('SELECT * FROM birthdays WHERE guild_id = ?').all(guildId);
}
function todayIn(guildId, month, day) {
  return getDb().prepare('SELECT * FROM birthdays WHERE guild_id = ? AND month = ? AND day = ?').all(guildId, month, day);
}

function getCfg(guildId) {
  const c = getConfig(guildId, 'birthday_config', null) || {};
  return { channelId: c.channelId || null, roleId: c.roleId || null, lastAnnounced: c.lastAnnounced || null };
}
function setCfg(guildId, patch) {
  setConfig(guildId, 'birthday_config', { ...getCfg(guildId), ...patch });
  return getCfg(guildId);
}
function fmt(b) {
  return `${MONTHS[b.month]} ${b.day}${b.year ? `, ${b.year}` : ''}`;
}

module.exports = { MONTHS, validDate, set, remove, get, forGuild, todayIn, getCfg, setCfg, fmt };
