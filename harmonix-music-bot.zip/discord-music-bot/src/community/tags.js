'use strict';
const { getDb } = require('../db');

function get(guildId, name) {
  return getDb().prepare('SELECT * FROM tags WHERE guild_id = ? AND name = ?').get(guildId, name.toLowerCase());
}
function set(guildId, name, content, by) {
  getDb()
    .prepare(
      `INSERT INTO tags (guild_id, name, content, created_by, uses) VALUES (?, ?, ?, ?, 0)
       ON CONFLICT(guild_id, name) DO UPDATE SET content = excluded.content`
    )
    .run(guildId, name.toLowerCase(), content, by);
}
function del(guildId, name) {
  return getDb().prepare('DELETE FROM tags WHERE guild_id = ? AND name = ?').run(guildId, name.toLowerCase()).changes > 0;
}
function list(guildId) {
  return getDb().prepare('SELECT name FROM tags WHERE guild_id = ? ORDER BY name ASC').all(guildId).map((r) => r.name);
}
function use(guildId, name) {
  getDb().prepare('UPDATE tags SET uses = uses + 1 WHERE guild_id = ? AND name = ?').run(guildId, name.toLowerCase());
}
module.exports = { get, set, del, list, use };
