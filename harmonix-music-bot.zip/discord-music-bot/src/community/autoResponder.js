'use strict';

const { getConfig, setConfig } = require('../db');

const MAX = 50;

function list(guildId) {
  return getConfig(guildId, 'autoresponders', []) || [];
}
function save(guildId, arr) {
  setConfig(guildId, 'autoresponders', arr);
}
function add(guildId, trigger, response, match = 'contains') {
  const arr = list(guildId);
  if (arr.length >= MAX) return { ok: false, reason: `Limit of ${MAX} auto-responders reached.` };
  const id = arr.reduce((m, t) => Math.max(m, t.id), 0) + 1;
  arr.push({ id, trigger: trigger.toLowerCase(), response, match });
  save(guildId, arr);
  return { ok: true, id };
}
function remove(guildId, idOrTrigger) {
  const arr = list(guildId);
  const before = arr.length;
  const key = String(idOrTrigger).toLowerCase();
  const next = arr.filter((t) => String(t.id) !== key && t.trigger !== key);
  save(guildId, next);
  return before - next.length;
}
function match(guildId, content) {
  const text = content.toLowerCase();
  for (const t of list(guildId)) {
    if (t.match === 'exact' && text.trim() === t.trigger) return t.response;
    if (t.match === 'startswith' && text.startsWith(t.trigger)) return t.response;
    if ((!t.match || t.match === 'contains') && text.includes(t.trigger)) return t.response;
  }
  return null;
}

module.exports = { MAX, list, add, remove, match };
