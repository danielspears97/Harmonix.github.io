'use strict';

const { getConfig, setConfig } = require('../db');

function all(guildId) {
  return getConfig(guildId, 'stickies', {}) || {};
}
function get(guildId, channelId) {
  return all(guildId)[channelId] || null;
}
function set(guildId, channelId, content) {
  const map = all(guildId);
  map[channelId] = { content, lastId: null };
  setConfig(guildId, 'stickies', map);
}
function updateLastId(guildId, channelId, lastId) {
  const map = all(guildId);
  if (map[channelId]) { map[channelId].lastId = lastId; setConfig(guildId, 'stickies', map); }
}
function remove(guildId, channelId) {
  const map = all(guildId);
  if (!map[channelId]) return false;
  delete map[channelId];
  setConfig(guildId, 'stickies', map);
  return true;
}
function list(guildId) {
  return Object.keys(all(guildId));
}

module.exports = { all, get, set, updateLastId, remove, list };
