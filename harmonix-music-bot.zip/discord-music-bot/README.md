# 🎵 Harmonix — A Well-Made Discord Music Bot

Harmonix is a production-style Discord music bot built on **discord.js v14** and **Lavalink v4**. It plays from **YouTube, Spotify, and SoundCloud**, supports **autoplay** and **24/7** playback, drops a **persistent control panel** with buttons into a channel you set up with `/setup`, and ships with a real-time **web dashboard** so you can drive playback from a browser.

Every command works as a **slash command** *and* as a classic **text command** with a configurable per-server prefix (default `!`, e.g. `!play`, `!mod ban @user`). Set it with `/server prefix` or in the dashboard. (Text commands can't be ephemeral, so those replies post publicly, and interactive buttons/menus still need to be clicked.)

Everything you control on Discord stays in sync with the dashboard (and vice-versa) because both talk to a single shared player controller.

---

## ⚠️ Read this first — Terms of Service

Streaming audio from YouTube and Spotify through a Discord bot **violates those platforms' Terms of Service**. This is the same activity that got large public bots like Groovy and Rythm shut down in 2021. A few honest notes:

- **Spotify** does not stream raw audio to third parties. Harmonix (via the LavaSrc plugin) reads the track's *metadata* from the Spotify API and then plays a **matching/mirrored source** (typically YouTube). The match is usually but not always perfect.
- Running this bot is fine for **personal, private, small-server use**. Do **not** operate it as a large public bot — you risk API bans and takedowns.
- You are responsible for how you use this. It's provided for educational and personal use.

SoundCloud is supported directly and is the least legally fraught of the three.

---

## ✨ Features

### What you asked for
- **Music playback** from a name search or a direct link.
- **YouTube** support (videos, playlists, YouTube Music) via the youtube-source plugin.
- **Spotify** support (tracks, albums, playlists) via LavaSrc metadata → mirrored audio.
- **SoundCloud** support (tracks, search) natively.
- **Autoplay** — when enabled, Harmonix keeps a **rolling buffer of up to 5 upcoming tracks**, topping it back up every time a song starts or is skipped, **and on a short timer whenever the queue dips below 5** (also when the queue runs dry), based on what just played.
- **24/7 mode** — the bot stays in the voice channel even when the queue is empty and the channel is empty.
- **Online dashboard** — a browser console to search, queue, and control playback in real time.
- **Dedicated control channel** created/registered with **`/setup`**, containing a live now-playing panel with **pause, stop, skip (forward), previous (backward)** and many more buttons.

### Extras added to make it nicer
- **Type-to-play in the panel channel** — just send a song name or link in the control channel and Harmonix queues it, then tidies up the message.
- **Live, self-updating now-playing panel** with album art, a progress bar, source badge, and requester.
- **Full transport on both Discord buttons *and* the dashboard**: play/pause, skip, previous, stop, shuffle, loop (off → track → queue), volume ± / slider (0–150%), seek (click the dashboard progress bar), autoplay toggle, 24/7 toggle, clear queue, disconnect.
- **Queue management** — view the queue, remove a specific track, clear it, shuffle it.
- **Audio filters** — `/filter <type>` applies bass boost, nightcore, vaporwave, 8D, karaoke, treble, or lowpass (or clears them) in real time via Lavalink.
- **DJ role & vote-skip** — `/dj set @Role` restricts the disruptive controls (skip, stop, clear, remove, filter) to a DJ role (admins always allowed); everyone else uses `/voteskip`, which skips once a majority of listeners in the channel agree (and skips instantly if you're alone).
- **Saved playlists** — `/playlist save <name>` snapshots the current queue; `/playlist load <name>` queues it back up later. Per-user, with `list`, `show`, and `delete`.
- **Persistent storage (SQLite)** — guild settings, and (as more modules land) all bot data live in a local SQLite database via `better-sqlite3`. An existing `data/guilds.json` from older builds is imported automatically on first run.
- **Smart voice handling** — leaves after a configurable idle timeout when alone (unless 24/7), follows you if the bot is moved, and tears down cleanly if force-disconnected.
- **Optional password gate** on the dashboard.
- **Server manager (dashboard)** — a hamburger menu (top-left, for users with **Manage Server**) opens a small menu — **Music Console**, **Command Manager**, **Server Settings**, **Mod Cases**, **Leveling**, **Command Stats**, **Config**, **Live Log**. The Command Manager lists **every individual command** (each subcommand, e.g. `/fun joke`, `/mod ban`, `/game hangman start`) **grouped into collapsible categories** with a search box. Each command has an **on/off switch**, a **segmented control** — *Everywhere / Only in… / Block in…* — with **clickable channel chips**, and a **minimum power-level** selector (L0/L1/L2); category headers summarise what you've changed ("2 off · 1 limited"). Server Settings holds the **auto-delete timer** for the bot's replies and the **trivia channel** (cleared hourly). Music stays the landing page; the settings are also available as `/server autodelete` and `/server triviachannel`, and every rule is enforced by the bot before a command runs.
- **Role power levels** — in the Command Manager you can mark roles as **power level 1 or 2** (a member's level is the highest of their roles; server admins are always 2). Any command set to level 1 or 2 then requires a member at or above that level — layered on top of the on/off and channel rules, and enforced for both slash and text commands.
- **Dashboard admin views** — **Mod Cases** shows recent moderation cases (action, target, moderator, reason, time); **Leveling** is a live leaderboard with an inline **XP editor** (set a member's XP and save); **Command Stats** charts the most-used commands with totals; **Config** edits welcome/goodbye, autorole, and starboard right in the browser; and **Live Log** streams server events in real time (mirrors the `/mod logging` channel). All Manage-Server-gated.
- **Slash commands *and* buttons** for every common action, with friendly ephemeral replies.
- **One-command Lavalink** via Docker Compose.

### Moderation & server management
- **Full moderation suite** — warn, kick, ban (works even on users who left), unban, timeout, and remove-timeout, each gated behind the matching Discord permission with role-hierarchy safety checks (can’t action the owner, someone above you, or above the bot).
- **Persistent case system** — every action is recorded as a numbered case (per-server), so `/warnings <user>` shows a member’s full history and `/case <#>` / `/reason <#>` view and edit individual cases. Survives restarts (SQLite).
- **Mod-log channel** — point `/modlog set #channel` and every action is posted as a tidy embed.
- **Event logging** — `/mod logging set #channel` turns on a full server audit feed: message **deletions** and **edits** (with before/after), member **joins** (with account age) and **leaves** (with roles held), **nickname** and **role** changes, **voice** join/leave/move, and **bans/unbans**. Each event type can be toggled individually with `/mod logging toggle`, and `/mod logging status` shows the current setup.
- **Ticket system** — `/mod ticket setup` (category, staff role, transcript-log channel) then `/mod ticket panel` posts an **Open a ticket** button anyone can click. Each ticket is a private channel only the opener and staff can see; staff can **Claim** it, and **Close** saves a full text **transcript** (DM'd to the opener and posted to the log channel) before deleting the channel. One open ticket per user, with `/mod ticket add`/`remove` to pull extra people in or out. Needs the **Manage Channels** permission.
- **Anti-raid** — `/mod antiraid enable` watches the join rate; if more than *threshold* members join inside the *window* (both tunable via `/mod antiraid config`), it auto-**kicks or times out** new joins for 60 seconds and posts an alert. An optional **minimum-account-age** gate blocks brand-new accounts on sight. Needs **Kick Members** / **Moderate Members**.
- **Verification gate** — `/mod verify setup @Role` posts a panel with a **Verify** button that grants the role on click (with an optional account-age requirement), so you can keep unverified members walled off. Needs **Manage Roles** with the bot's role above the verified role.
- **Timed punishments** — `/mod tempban <user> <duration>` bans now and **auto-unbans** when the time's up; `/mod mute <user> <duration>` applies a managed **Muted** role (auto-created and locked down across channels on first use) and **auto-unmutes** on expiry, with `/mod unmute` to lift it early. Durations accept `30m`, `2h`, `7d`, `1w`; everything survives restarts (a scheduler re-checks every 30s).
- **Warn auto-escalation** — `/mod warnthreshold add <count> <action>` makes warnings escalate automatically: e.g. 3 warns → timeout, 5 → kick, 7 → ban. The action fires the moment a warning lands on a configured count, and is itself recorded as a case.
- **Channel tools** — `/purge` (bulk-delete, optionally filtered to one user) and `/slowmode`.
- **AutoMod** — configurable filters for Discord invites, links, mention-spam, excessive caps, fast message-spam, and a custom blocked-word list (with word-boundary matching to avoid false positives). Staff and exempt roles bypass it; violations are deleted and logged.
- **Reaction roles** — button-based self-assignable roles. `/reactionrole create` posts a panel, `/reactionrole add` attaches a role button; clicking toggles the role.
- **Welcome & goodbye messages** with `{user} {username} {server} {membercount}` placeholders, and **autorole** to assign a role automatically on join.

### Engagement
- **Leveling / XP** — members earn XP for chatting (with an anti-spam cooldown). `/rank` shows level, XP, and a progress bar; `/leaderboard` ranks the server. Configurable level-up announcements and **role rewards** at chosen levels.
- **Polls** — `/poll create` posts a live, button-driven poll (single or multiple choice) with bars and percentages that update as people vote; `/poll end` closes it.
- **Giveaways** — `/giveaway start 1h "Prize" winners:2` posts an entry button and automatically draws winners when the timer ends (even after a restart). `/giveaway end` and `/giveaway reroll` included.
- **Temporary channels** — `/engage tempvoice setup #hub` enables **join-to-create** voice: joining the hub spawns a **private, locked, owner-only** voice channel plus a companion **control text channel** whose panel has dropdowns to **allow**/**kick** members and buttons to **rename**, set a **user limit**, **lock/unlock** (the panel updates live to show the current state), **claim** (if the owner leaves), or **delete**. Everything cleans up automatically once the channel empties. `/engage temptext 2h [name] [private]` creates a **temporary text channel** that auto-deletes when the timer runs out — handy for events, raids, or one-off discussions. Both survive restarts and clean themselves up.
- **Economy** — a full per-server currency. Members `/economy daily` (with a streak bonus), `/economy work` on a cooldown, `/economy give` to each other, and check `/economy balance` / `/economy leaderboard`. Spend it in a configurable **shop** (`/economy shop list`/`buy`, with items that can grant roles) or gamble it on **slots** and **coinflip**. Admins set the currency name/symbol and payout rates (`/economy config`), stock the shop (`/economy shop additem`), and adjust balances (`/economy admin`). All balances persist in SQLite.
- **Auto-responder** — `/server autoresponder add <trigger> <response>` makes the bot auto-reply to keywords (contains / exact / starts-with matching), with `list` and `remove`.
- **Sticky messages** — `/server sticky set <message>` keeps a message pinned to the bottom of a channel: as people chat, the bot quietly reposts it so it's always the most recent message (debounced to avoid spam). `/server sticky remove` clears it.
- **Birthdays** — members save theirs with `/community birthday set` (year optional and kept private); a daily check announces the day's birthdays in a configured channel and can grant a temporary **birthday role**. `/community birthday list` shows what's coming up.
- **Role menus** — `/server rolemenu create` posts a dropdown of self-assignable roles; `addrole`/`removerole` manage the options. Picking an option **toggles** that role for the member (add if they don't have it, remove if they do), with an ephemeral confirmation — no reactions to manage.
- **Trivia** — `/game trivia` runs **continuous** trivia in a channel: players **type** their answers (no buttons), the bot recognises the correct one, awards XP, and immediately asks the next question. Powered by **The Trivia API** with **typeable, free-text** questions (you just type the answer — no multiple choice). Pulls from **two sources** (The Trivia API + OpenTDB) for a much larger question pool, with a per-round no-repeat filter. Choose a broad **category** or a specific **topic** (video games, anime, Marvel, space, chemistry, mythology, football…), a **difficulty** (easy/medium/hard), a **custom timer** (5–120s per question), or **⚡ speed mode** (8s rounds with bonus XP for fast answers). If a question goes unanswered it **reveals the answer and moves on** — it only stops when you run `/game trivia` again or the **channel goes quiet** (no messages for a couple of minutes), regardless of whether answers were right. Set a dedicated trivia channel with `/server triviachannel` and it's auto-cleared every hour.
- **NSFW images** — `/nsfw [category]` posts adult (anime) images across many categories (hentai, waifu, neko, ass, milf, oral, ecchi, oppai, uniform, selfies, …). Each category tries **several sources** (waifu.im → purrbot → waifu.pics) with a per-request timeout, so a flaky/blocked source rolls over to the next instead of failing or repeating. **Only works in channels flagged age-restricted (NSFW)** — the command is itself marked age-restricted and refuses to run anywhere else.
- **Starboard** — react to a message with ⭐ (configurable emoji/threshold) and once it passes the threshold it’s featured in your starboard channel, with a live-updating star count.

### Utility
- **Reminders** — `/util reminder set 2h take a break`, plus `list` and `cancel`. The bot **DMs you** when it's due (falling back to the channel only if your DMs are closed), and reminders survive restarts.
- **Translate** — `/translate` between languages with auto source-detection.
- **Weather** — `/weather <place>` shows current conditions (temperature, feels-like, humidity, wind).
- **RSS / Atom feeds** — `/feed add <url>` subscribes a channel; new posts are announced automatically (checked every ~5 minutes). `/feed list` and `/feed remove` included.

### Reference, fun & games
A grab-bag of keyless/free-API commands and local games:
- **Reference:** `/define`, `/wiki`, `/country`, `/convert` (currency, ECB rates), `/crypto`, `/forecast` (3-day, Open-Meteo).
- **Fun:** `/fun` bundles random jokes, facts, advice, dog/cat pics, xkcd, quotes, the live ISS position, NASA’s picture of the day, and more as subcommands.
- **Games:** `/game` (8ball, rps, coinflip, roll, draw), plus `/pokemon`, and `/hangman` (per-channel game).
- **Geeky:** `/mcstatus` (Minecraft server), `/github` (user/repo), `/anime`, `/qr` (QR code generator).

### Community, utilities & extras
- **Custom tags** (`/tag`) — server-defined saved snippets recalled on demand.
- **AFK** (`/afk`) — auto-replies when you’re pinged, clears when you return.
- **Snipe** (`/snipe`) — show the last deleted message in a channel.
- **Info suite** — `/userinfo`, `/serverinfo`, `/roleinfo`, `/avatar`, `/membercount`.
- **Suggestions** (`/suggest` + `/suggestions set`) — up/down-vote buttons in a suggestions channel.
- **Dev & text tools** — `/tools` groups `timestamp`, `math`, `base64`, `hash`, `password`, `color`, `choose`, `mock`, `emojify`, `ascii`, and `reverse` as subcommands.
- **More keyless fun** — folded into `/fun`: `iss` (live Space Station position), `apod` (NASA picture of the day), `quote`, `catfact`, `affirmation`, `chucknorris`, `guessage`. Standalone `/recipe` and `/cocktail` round it out.
- **More games** — `/whosthat` (Who’s That Pokémon?), `/scramble` (first to unscramble wins), `/wordle` (your own per-channel game).

---

## 🧩 How it fits together

```
Discord  ──▶ slash commands / buttons ─┐
                                        ├──▶ controller.js ──▶ Lavalink (audio) ──▶ Voice
Browser  ──▶ dashboard (Socket.IO)  ───┘          │
                                                  └──▶ event bus ──▶ panel + dashboard stay in sync
```

- `controller.js` is the single source of truth for every player action.
- A shared event **bus** notifies the Discord panel and the dashboard whenever state changes, so all surfaces stay consistent.
- **Lavalink** is a separate Java process that does the actual audio fetching/streaming.

---

## ✅ Prerequisites

1. **Node.js 18+** (`node -v`).
2. **A Discord bot application** — from the [Discord Developer Portal](https://discord.com/developers/applications):
   - Create an application → **Bot** → copy the **token**.
   - Copy the **Application (client) ID** from **General Information**.
   - Under **Bot**, enable the **Message Content Intent** (needed for type-to-play in the panel channel) and the **Server Members Intent** (needed for welcome/goodbye messages and autorole).
   - Invite it with the **`bot`** and **`applications.commands`** scopes. For music it needs at least *View Channels, Send Messages, Embed Links, Manage Channels* (for `/setup`), *Connect, Speak*. For the moderation features add *Kick Members, Ban Members, Moderate Members, Manage Messages, Manage Roles* — or simply grant it a moderator role positioned **above** the members it will act on.
3. **A Lavalink v4 server.** Easiest path is **Docker** (included). Otherwise you need **Java 17+** and the Lavalink jar.
4. *(Optional, for Spotify links)* **Spotify API credentials** — create an app at the [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) to get a Client ID + Secret.

---

## 🚀 Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure the bot
```bash
cp .env.example .env
```
Open `.env` and fill in at minimum `DISCORD_TOKEN` and `CLIENT_ID`. See the [Configuration](#-configuration-env) table below.

### 3. Configure & start Lavalink

Harmonix's audio comes from Lavalink. Pick **one** of the following.

**Option A — Docker (recommended):**
```bash
docker compose up -d        # starts Lavalink on localhost:2333
docker compose logs -f      # watch it boot (first run downloads plugins)
```

**Option B — Manual:**
- Download the latest **Lavalink.jar** (v4) from the [Lavalink releases](https://github.com/lavalink-devs/Lavalink/releases).
- Put it next to `lavalink/application.yml`, then run it from that folder:
  ```bash
  cd lavalink && java -jar Lavalink.jar
  ```

Either way, **edit `lavalink/application.yml`**:
- Set `lavalink.server.password` and make it match `LAVALINK_PASSWORD` in `.env`.
- For **Spotify**, paste your `clientId` / `clientSecret` under `plugins.lavasrc.spotify`.

Wait until the logs say the node is **ready** before starting the bot.

### 4. Register slash commands
```bash
npm run deploy
```
If `GUILD_ID` is set in `.env`, commands register to that one server instantly (best for testing). With no `GUILD_ID`, they register globally (can take up to ~1 hour to show up).

### 5. (Optional) Enable Discord login on the dashboard
For the dashboard to use Discord OAuth2 (so each user only controls servers they manage):

1. In the [Developer Portal](https://discord.com/developers/applications) → your app → **OAuth2**, copy the **Client Secret** into `CLIENT_SECRET` in `.env`.
2. On the same page, add a **Redirect** that exactly matches your `OAUTH_REDIRECT_URI` — for local use that's `http://localhost:3000/auth/callback`.
3. Set `SESSION_SECRET` in `.env` to any long random string.

Skip this and the dashboard runs in local mode (optional `DASHBOARD_PASSWORD`). Storage needs no setup — the SQLite database is created automatically under `data/` on first run.

### 6. Start Harmonix
```bash
npm start
```
You should see the bot log in, the Lavalink node connect, and (if enabled) the dashboard URL.

---

## 🎛️ Usage

### Set up the control panel
In your server, run:
```
/setup            → creates a #🎵-music channel and posts the live panel
/setup #channel   → uses an existing channel instead
```
The panel is a persistent message with three rows of buttons that update themselves as playback changes.

### Play something
- **Slash:** `/play <song name or URL>` (YouTube / Spotify / SoundCloud links all work).
- **In the panel channel:** just type a song name or paste a link — Harmonix queues it and cleans up your message.
- **Dashboard:** use the search box.

> You must be in a voice channel to start playback. After that, anyone can use the buttons/dashboard.

### Control panel buttons
| Row | Buttons |
|-----|---------|
| 1 | ⏮ Previous · ⏯ Pause/Resume · ⏭ Skip · ⏹ Stop |
| 2 | 🔉 Vol − · 🔊 Vol + · 🔁 Loop (off→track→queue) · 🔀 Shuffle |
| 3 | ♾ Autoplay · 🕒 24/7 · 📜 Queue · 🧹 Clear |

(Plus a link button to the dashboard when it's enabled.)

### Slash commands
| Command | What it does |
|---------|--------------|
| `/setup [channel]` | Create/register the control-panel channel |
| `/play <query>` | Search or load a track/playlist and queue it |
| `/pause` · `/resume` | Pause or resume playback |
| `/skip` | Skip to the next track |
| `/previous` | Go back to the previous track |
| `/stop` | Stop and clear the queue |
| `/leave` | Disconnect from voice |
| `/nowplaying` | Show the current track with a progress bar |
| `/queue` | Show the upcoming queue |
| `/volume <0-150>` | Set the volume |
| `/loop [off\|track\|queue]` | Set or cycle the loop mode |
| `/shuffle` | Shuffle the queue |
| `/seek <time>` | Jump to a position (`90`, `1:30`, or `1:02:03`) |
| `/remove <position>` | Remove a track from the queue by position |
| `/clear` | Clear the queue |
| `/autoplay` | Toggle autoplay |
| `/247` | Toggle 24/7 mode |
| `/help` | List everything |

### Moderation commands
Each command requires the matching Discord permission and is hidden from members who don’t have it.

| Command | Permission | What it does |
|---------|-----------|--------------|
| `/warn <user> [reason]` | Moderate Members | Warn a member; logged as a case (and DM’d if possible) |
| `/warnings <user>` | Moderate Members | Show a member’s full moderation history |
| `/case <#>` | Moderate Members | View a single case |
| `/reason <#> <text>` | Moderate Members | Edit the reason on a case |
| `/kick <user> [reason]` | Kick Members | Kick a member |
| `/ban <user> [reason] [delete_days]` | Ban Members | Ban a user (also works by ID if they’ve left) |
| `/unban <user_id> [reason]` | Ban Members | Lift a ban |
| `/timeout <user> <duration> [reason]` | Moderate Members | Timeout (e.g. `10m`, `1h`, `1d`; max 28d) |
| `/untimeout <user> [reason]` | Moderate Members | Remove a timeout |
| `/purge <amount> [user]` | Manage Messages | Bulk-delete up to 100 recent messages |
| `/slowmode <seconds> [channel]` | Manage Channels | Set a channel’s slowmode |
| `/modlog set\|disable\|status` | Manage Server | Configure where cases are posted |
| `/automod status\|rule\|exempt\|words` | Manage Server | Configure message filters (invites, links, mentions, caps, spam, words) |

### Server-management commands

| Command | Permission | What it does |
|---------|-----------|--------------|
| `/welcome set\|test\|disable\|status` | Manage Server | Welcome message for new members |
| `/goodbye set\|test\|disable\|status` | Manage Server | Farewell message when members leave |
| `/autorole set\|disable\|status` | Manage Server | Auto-assign a role on join |
| `/reactionrole create\|add\|remove\|list` | Manage Roles | Button-based self-assignable roles |
| `/starboard set\|disable\|status` | Manage Server | Feature ⭐-reacted messages in a channel |

### Engagement commands

| Command | Permission | What it does |
|---------|-----------|--------------|
| `/rank [user]` | Everyone | Show level, XP, and progress |
| `/leaderboard` | Everyone | Top members by XP |
| `/levels enable\|disable\|announce\|setxp\|reward` | Manage Server | Configure leveling & role rewards |
| `/poll create\|end` | Everyone (end: creator/mod) | Live button polls |
| `/giveaway start\|end\|reroll` | Manage Server | Timed giveaways with auto-draw |
| `/trivia [category] [difficulty]` | Everyone | Timed trivia question (correct answers earn XP) |

### Utility commands

| Command | Permission | What it does |
|---------|-----------|--------------|
| `/reminder set\|list\|cancel` | Everyone | Personal reminders |
| `/translate <text> [to] [from]` | Everyone | Translate text between languages |
| `/weather <location>` | Everyone | Current weather for a place |
| `/feed add\|remove\|list` | Manage Server | RSS/Atom feed announcements |

### Reference, fun & games

| Command | What it does |
|---------|--------------|
| `/define <word>` | Dictionary definition |
| `/wiki <query>` | Wikipedia summary |
| `/country <name>` | Country facts (flag, capital, population…) |
| `/convert <amt> <from> <to>` | Currency conversion (ECB rates) |
| `/crypto <coin>` | Crypto price & 24h change |
| `/forecast <place>` | 3-day weather forecast |
| `/dadjoke` · `/joke` · `/fact` · `/advice` · `/inspire` · etc. | Now subcommands of `/fun` |
| `/dog` · `/cat` · `/xkcd [n]` | Subcommands of `/fun` |
| `/8ball` · `/rps` · `/coinflip` · `/roll [dice]` · `/draw [n]` | Subcommands of `/game` (local, no API) |
| `/pokemon <name>` · `/hangman start\|guess\|quit` | Pokédex lookup; channel hangman |
| `/mcstatus <addr>` · `/github <user\|owner/repo>` · `/anime <title>` · `/qr <text>` | Minecraft status, GitHub, anime, QR codes |

### Community & utility commands

| Command | Permission | What it does |
|---------|-----------|--------------|
| `/tag get\|add\|delete\|list` | Add/delete: Manage Messages | Saved server snippets |
| `/afk [reason]` | Everyone | Set yourself away |
| `/snipe` | Everyone | Show the last deleted message |
| `/suggest <text>` · `/suggestions set\|disable` | Suggest: everyone | Suggestions with vote buttons |
| `/userinfo` · `/serverinfo` · `/roleinfo` · `/avatar` · `/membercount` | Everyone | Info lookups |
| `/tools timestamp\|math\|base64\|hash\|password\|color` | Everyone | Dev & text utilities |
| `/tools choose\|mock\|emojify\|ascii\|reverse` | Everyone | Text toys |
| `/fun` (jokes, facts, pics, iss, apod, quote, …) · `/recipe` · `/cocktail` | Everyone | Keyless-API fun |
| `/whosthat` · `/scramble` · `/wordle` | Everyone | More games |

Greeting templates support `{user}` (mention), `{username}`, `{server}`, and `{membercount}`.

### Dashboard
If `DASHBOARD_ENABLED=true`, open **http://localhost:3000** (or your configured port). You can:
- Log in with Discord (when OAuth is configured) and pick any server you manage.
- See live now-playing with art, progress, and badges.
- Use full transport, the volume slider, and click the progress bar to seek.
- Search/queue tracks, remove items, clear, shuffle, toggle autoplay/24-7, and disconnect.

**Authentication has two modes:**

- **Discord OAuth2 (recommended).** Set `CLIENT_SECRET` (and ideally `SESSION_SECRET`) in `.env` and add a redirect URI in the Developer Portal (see setup step below). Users log in with Discord and can only see/control servers where they have the **Manage Server** permission *and* the bot is present. This is the safe way to expose the dashboard.
- **Local mode (fallback).** If `CLIENT_SECRET` is not set, the dashboard runs locally with an optional `DASHBOARD_PASSWORD` gate (blank = open). Intended for trusted, local-only use.

> Because the dashboard needs to know which voice channel to join, **start the first track from Discord**. After that the dashboard can queue freely.
>
> In local mode there's no per-user scoping — anyone who reaches the page controls every server the bot is in. Use OAuth (or at least a password) before exposing it beyond localhost, and ideally keep it behind your own HTTPS proxy.

---

## 🔧 Configuration (`.env`)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `DISCORD_TOKEN` | ✅ | — | Your bot token |
| `CLIENT_ID` | ✅ | — | Application (client) ID |
| `GUILD_ID` | — | — | If set, slash commands register to this guild instantly |
| `LAVALINK_HOST` | — | `127.0.0.1` | Lavalink host |
| `LAVALINK_PORT` | — | `2333` | Lavalink port |
| `LAVALINK_PASSWORD` | — | `youshallnotpass` | Must match `application.yml` |
| `LAVALINK_SECURE` | — | `false` | Use `true` for wss/https nodes |
| `DASHBOARD_ENABLED` | — | `true` | Turn the web dashboard on/off |
| `DASHBOARD_PORT` | — | `3000` | Dashboard port |
| `CLIENT_SECRET` | — | _(empty)_ | App's OAuth2 secret. **Set this to enable Discord login** on the dashboard |
| `OAUTH_REDIRECT_URI` | — | `http://localhost:<port>/auth/callback` | Must exactly match a redirect URI in the Developer Portal |
| `SESSION_SECRET` | — | _(random)_ | Signs session cookies; set a long random string so restarts don't log users out |
| `DASHBOARD_PASSWORD` | — | _(empty)_ | Local-mode only (when `CLIENT_SECRET` unset): optional password gate |
| `DATABASE_PATH` | — | `./data/harmonix.db` | Override the SQLite database file location |
| `DEFAULT_VOLUME` | — | `60` | Starting volume (1–100) |
| `LEAVE_TIMEOUT_SECONDS` | — | `60` | Idle seconds before leaving an empty channel (ignored in 24/7) |

---

## 🛠️ Troubleshooting

- **Slash commands don't appear** → run `npm run deploy`. Global commands can take up to an hour; set `GUILD_ID` for instant updates while testing.
- **"No results" / nothing plays** → make sure Lavalink is running and **connected** (check the bot console for `node "main-node" connected`). Confirm `LAVALINK_PASSWORD` matches `application.yml`.
- **Spotify links don't resolve** → add your Spotify `clientId`/`clientSecret` in `application.yml` under `plugins.lavasrc.spotify` and restart Lavalink.
- **YouTube errors (403 / sign-in required)** → update the youtube-source plugin version in `application.yml`, or configure its `oauth` section. YouTube changes often; keeping plugins current matters.
- **Bot won't type-to-play in the panel channel** → enable the **Message Content Intent** in the Developer Portal. (AutoMod content filters also rely on this intent.)
- **Welcome/goodbye or autorole not firing** → enable the **Server Members Intent** in the Developer Portal. For autorole, also make sure the bot's role sits **above** the role it's assigning.
- **A moderation command says it can't act on someone** → the target is the owner, or has a role equal/higher than yours or the bot's. Move the bot's role higher and check it has Kick/Ban/Moderate/Manage permissions.
- **Bot joins but is silent** → check the bot has **Connect** and **Speak** permissions in that voice channel.
- **Plugin versions** → the versions pinned in `application.yml` were current at authoring time; if Lavalink fails to load a plugin, bump it to the latest release.

---

## 📁 Project structure

```
discord-music-bot/
├─ index.js                 # entrypoint — wires everything together
├─ deploy-commands.js       # registers slash commands
├─ config.js                # env loading + validation
├─ docker-compose.yml       # one-command Lavalink
├─ .env.example
├─ lavalink/
│  └─ application.yml        # Lavalink v4 config (plugins, password, Spotify)
└─ src/
   ├─ bot/                   # client + lavalink manager setup
   ├─ commands/              # all slash commands
   ├─ events/                # gateway + interaction handlers
   ├─ handlers/              # control panel + button router
   ├─ lavalink/              # player (track) event handling
   ├─ dashboard/             # express + socket.io server (OAuth) and web UI
   ├─ db/                    # SQLite connection + schema + config helpers
   ├─ moderation/            # case store + mod-log + automod
   ├─ server/                # welcome/goodbye + autorole + reaction roles
   ├─ engagement/            # leveling, polls, giveaways, trivia, whosthat, scramble (+ schedulers)
   ├─ community/             # tags, afk, suggestions, snipe cache
   ├─ utility/               # reminders, feeds, weather/translate helpers (+ schedulers)
   ├─ utils/                 # bus, persistence, autoplay, formatting, guards, duration
   └─ controller.js          # the shared player controller (source of truth)
```

---

## 📦 Tech stack

- **discord.js v14** — Discord gateway & interactions
- **lavalink-client v2** + **Lavalink v4** — audio
- **youtube-source** & **LavaSrc** plugins — YouTube / Spotify / SoundCloud
- **Express** + **Socket.IO** + **express-session** — real-time dashboard with Discord OAuth2
- **better-sqlite3** — fast synchronous SQLite storage
- **rss-parser** — RSS/Atom feed parsing
- **mathjs** + **figlet** — `/math` evaluation and `/ascii` art

---

## 🗺️ Roadmap

Harmonix is being grown from a music bot into a full multipurpose bot. Done so far:

- ✅ **Foundations** — SQLite storage + Discord OAuth dashboard.
- ✅ **Moderation & server management** — cases, mod-log, warn/kick/ban/timeout, purge, slowmode, welcome/goodbye, autorole.
- ✅ **AutoMod & reaction roles** — invite/link/mention/caps/spam/word filters, and button-based self-assign roles.
- ✅ **Engagement** — leveling & leaderboard with role rewards, live polls, timed giveaways, trivia, and a starboard.
- ✅ **Utility** — reminders, translate, weather, and RSS/Atom feed announcements.

Every planned phase is now in, plus a large pack of reference/fun/games/geeky commands. To stay within Discord’s 100-top-level-command limit, the many small toy commands are grouped as subcommands (`/fun`, `/game`, `/tools`), leaving the bot at ~77 top-level commands with room to grow. Possible future additions: image-based rank cards (needs the native `canvas` library), application/ticket systems, and music-source niceties.

> **A note on the third-party APIs.** Several commands rely on free, keyless community services — translate (Google’s unofficial `gtx`), weather/forecast ([wttr.in](https://wttr.in) and [Open-Meteo](https://open-meteo.com)), trivia ([Open Trivia DB](https://opentdb.com)), plus dictionary, currency ([Frankfurter](https://frankfurter.dev)/ECB), [CoinGecko](https://coingecko.com), Wikipedia, [PokéAPI](https://pokeapi.co), [Jikan](https://jikan.moe), GitHub (60 req/hr unauthenticated), and assorted joke/fact/image endpoints. They’re free and need no keys, but can rate-limit or change without notice. Every command **fails gracefully** when its service is unavailable; swap in keyed providers if you need production reliability.

Music can be toggled off, so Harmonix is useful (and shareable) as a pure utility/moderation bot too.

Made to be readable and hackable. Have fun — and keep it private. 🎧

## Music-only mode (a second "Harmonix2" bot)

Set `MUSIC_ONLY=true` to run a stripped instance that loads only the music commands and skips every other feature and background handler. To run it alongside the full bot: use a separate Discord application (its own `DISCORD_TOKEN` and `CLIENT_ID`), set `MUSIC_ONLY=true`, and point `DATABASE_PATH` at a different file so it keeps its own settings — including its own music-request channel, which you pick by running `/setup` on that bot. You can pin music to a single voice channel with `/voicelock set #channel` (or the dashboard's Server Settings → "Lock music to voice channel").

## Quality-of-life settings

Server Settings on the dashboard (all auto-saved) now include: **DJ-only mode** (only the DJ role can skip/stop/clear), **command reply visibility** (default / always public / always private, set server-wide *or* per-command in the Command Manager — a per-command choice overrides the server default), **queue guardrails** (max queue length, max song length, max songs per user), **custom gate messages** (override the disabled / needs-level / wrong-channel texts; `{level}` is substituted), **level-up by DM** instead of in-channel, and an **XP-ignored channels** list. The music player also shows **queue position + ETA** when you add a song, **warns on duplicates**, and lets the **requester skip their own song** even in DJ-only mode. Members can set a personal timezone with `/timezone set` so `/timezone show` reports their local time.

## New: recaps, achievements, health & module toggles

- **Server Wrapped** — `/wrapped` shows a recap (top tracks, top DJs, peak listening hour, most active members); `/wrapped scope:me` gives your personal stats. Powered by a new play-history log.
- **Achievements** — unlockable badges (songs played, level milestones, night-owl, counting). View with `/achievements`; unlocks surface in `/play`, level-ups, and the counting game.
- **`/status`** — uptime, gateway ping, memory, server/player counts, and Lavalink node state. A live version is also shown on the dashboard's Server Settings page.
- **Feature modules** — turn whole areas (Music, Moderation, Leveling, Economy, NSFW, …) on/off per server from the dashboard. Disabled modules block their commands and silence their events.
- **Voice XP** — optional: earn XP per minute spent in a voice call with others.
- **Counting game** — set a counting channel on the dashboard; members count up by 1, wrong numbers reset it, milestones are celebrated.
- **Crossfade / fade-in** — a configurable fade-in on each track start to soften transitions. (True overlapping crossfade isn't possible with a single Lavalink player; this is a fade-in.)
- **Now-playing presence** — the bot's Discord status shows the current track while playing.
- **Play next** — `/play <song> next:true` adds to the front of the queue.
- **Drag-to-reorder** — drag queue items in the dashboard Music Console to reorder them.

## Lockdown, achievements dashboard & easier gating

- **Lockdown** — `/mod lockdown [channel] [reason]` locks a single channel (or every channel if you omit one) by denying members SendMessages; `/mod unlock [channel]` restores it. Needs Manage Channels.
- **Achievements dashboard** — a new 🏆 **Achievements** tab shows a server leaderboard (who's unlocked the most) and a badge grid with how many members hold each one.
- **Easier command gating** — each category in the Command Manager now has **Set all** buttons to enable/disable or set a power level (L0/L1/L2) for the whole group in one click, with an inline legend (L0 = everyone, L1 = trusted, L2 = staff/admin).

## Dashboard access is now per-permission

The dashboard no longer grants all-or-nothing management access. Each section requires a specific Discord permission, so a member with limited perms only sees the parts they're trusted with:

- **Command Manager, Server Settings (incl. feature toggles), Config pages, Leveling** → require **Manage Server** (or Administrator/owner).
- **Mod Cases, Achievements** → any moderator permission (Moderate Members, Manage Messages, Kick, or Ban).
- **Command Stats, Live Log** → **View Audit Log** or Manage Server.
- **Music Console** → any member who shares the server with the bot.

Administrators and the server owner get everything. Enforcement happens on the server (each socket action is permission-checked) as well as in the UI (menu items hide), so a moderator can't change command gating or feature toggles even by crafting requests. Saves are filtered field-by-field: a user with only settings access can't alter command gates and vice-versa.

## Achievements overhaul + player refresh

- **Achievements now fire reliably.** Song achievements are awarded on track *start* (the moment it plays), so they unlock no matter how the song was queued — `/play`, the request channel, the dashboard, or play-next. Unlocks are announced in the music text channel.
- **34 achievements** across Music (8 song-count milestones + Night Owl, Early Riser, Eclectic Taste, Live Wire), Leveling (levels 5/10/25/50/75/100), Voice (Socialite), Counting (Counter, 50/100/500), and a Collector capstone.
- **Player refresh.** The now-playing card now leads with large, full-width cover art; the six inline stat fields were consolidated into a single meta line + footer so the art is the focal point and the control buttons sit clearly below it. The Dashboard button now uses your public URL instead of localhost.

- **34 achievements** now span Music, Leveling, Voice, Counting, plus Activity (trivia wins, starboard, giveaway wins) and an Explorer set earned by using each feature area (games, fun, economy, utility, moderation, community) — across more of the bot. The dashboard badge grid is grouped by category.

## Achievement messages & channel settings

- **Achievement announcements are configurable.** A new Server Settings option controls what happens when any achievement unlocks: post **in the channel where it happened** (default), **DM the member**, post in a **specific channel**, or turn them **off**. Every unlock — music, leveling, counting, trivia, starboard, giveaways, voice, command-explorer — now routes through this one setting.
- **Channel pickers** added to Server Settings for: music request channel (posts the now-playing panel), event log, mod-log, ticket transcripts, suggestions, and birthday announcements — all in one place, auto-saved, alongside the existing trivia/counting/music-lock pickers.

## Music player fixes

- **Stop now fully stops.** Hitting Stop sets a guard that blocks autoplay/queue top-up from refilling, clears the queue, and **disconnects the bot from voice** — unless **24/7 mode** is on, in which case it stays put silently. (Previously autoplay would re-queue ~5 tracks a few seconds after stopping.)
- **Now-playing queue** shows up to **5 upcoming tracks** with an "…and N more" line and the total count, instead of only 3.
- **Per-server status.** Because Discord only allows one global presence per bot, the status now shows the song only when a single server is playing; with multiple it reads "music in N servers", and reverts to the default when idle.
- **Larger cover art.** The now-playing card and `/nowplaying` use full-width album art (Discord's largest embed image), with the surrounding text trimmed so the art is the focal point.

## Making commands appear in every server (important)

If slash commands only show up in one server, it's because they were registered **guild-scoped** (instant, but that one server only) instead of **global** (all servers). That happens when `GUILD_ID` is set in `.env`.

**Fix:** run

```
npm run deploy:global
```

This registers all commands globally for every server the bot is in (and clears the leftover guild-scoped copies so you don't get duplicates). Global commands can take **up to ~1 hour** to appear the first time, then they're in every current and future server automatically.

Deploy commands:
- `npm run deploy:global` — all servers (use this for production)
- `npm run deploy:guild` — only the `GUILD_ID` server, instant (use while developing)
- `npm run deploy:clear` — remove every registered command
- `npm run deploy` — auto: guild if `GUILD_ID` is set, else global

**Also check the invite:** the bot must be invited with the `applications.commands` scope or slash commands stay hidden regardless of how they're registered. On startup the bot now logs a correct invite URL — re-invite each server with that link if needed.

## One-command launcher

Instead of starting Lavalink, the tunnel, deploy, and the bot separately, run everything at once:

- **Windows:** double-click **`start.bat`** (or run it in a terminal)
- **macOS/Linux:** `./start.sh`
- **Any OS:** `npm run launch`  (or `node run.js`)

What it does, in order: makes sure the **Docker engine** is running (launches Docker Desktop and waits, on Windows/macOS) → brings up **Lavalink** (`docker compose up -d`) and waits until it's reachable → starts a **Cloudflare quick-tunnel** and captures its public URL → **registers slash commands** → **starts the bot** with `PUBLIC_URL` set to the tunnel URL → streams Lavalink + bot + tunnel logs into one window.

Because the quick-tunnel URL changes every run, the launcher prints the exact **OAuth redirect** to register in the Discord Developer Portal (`<tunnel-url>/auth/callback`) — set that so dashboard login works. It passes `PUBLIC_URL` to the bot automatically, so you don't have to edit `.env` each time.

Flags:
- `npm run launch:local` or `node run.js --no-tunnel` — skip the tunnel (local-only dashboard)
- `node run.js --no-deploy` — skip registering commands
- `node run.js --no-logs` — don't stream Lavalink logs
- `node run.js --deploy global` — force a global command deploy on launch

Ctrl+C stops the bot and the tunnel. Lavalink keeps running (it's a detached container); stop it with `docker compose down`. Requirements: Docker Desktop, Node, and (for the tunnel) `cloudflared` on your PATH.

## Autoplay & 24/7 reset on disconnect

When the bot leaves or is disconnected from a voice channel (manual disconnect, `/leave`, stop, inactivity timeout, or being kicked), **autoplay and 24/7 are now turned off automatically** and the control-panel buttons update to their off state — previously they stayed lit green after the bot was gone.

## Composer, config backup & reaction-role builder

- **Composer** (new dashboard tab, ✏️): build a message or rich embed with a **live preview** — title, description, accent color, author, image, thumbnail, footer — and post it to any channel. Switch the type to **Reaction-role panel** and add up to 5 role buttons (role + label + emoji); it posts the message and wires up the working button panel for you. So reaction roles (which already existed via `/server reactionrole`) are now fully buildable from the dashboard.
- **Config backup & transfer** (Server Settings → Backup): **Export** downloads this server's whole configuration as a JSON file; **Import** loads a file back in (with a confirmation). Great for backups or cloning a setup onto another server. Note: channel/role IDs are per-server, so re-check the pickers after importing into a different server.

Both the Composer and backup tools require the **Manage Server** capability, and every action is permission-checked server-side.

## Audit fixes

- **Counting game:** posting the correct number twice in a row now correctly says "You can't count twice in a row!" (a variable was reset before the check, so the wrong-number message showed instead).
- **Fade-in:** the volume fade timer is now cleared when the player is destroyed, so it can't keep firing against a disconnected player.
- **Composer:** posting a reaction-role panel with no text/embed now falls back to a default "Choose your roles" embed instead of failing with a misleading permissions error.
- **`/wrapped` and `/achievements`** are now guild-only (they crashed when used in DMs).
- **Stop reply** now says what actually happened: "…and left the channel" vs "…staying connected (24/7 is on)."

- **Music achievements no longer post in the music request channel.** When the announce mode is "post in the channel where it happened" and that channel is the music request/control channel, music unlocks are silent (still recorded and visible in `/achievements` and on the dashboard). DM, specific-channel, and off modes behave as configured — set a specific achievements channel if you want music unlocks announced somewhere.

## Silent mode (system tray)

Run the whole stack with no window at all, controlled from a tray icon in the hidden-icons area:

- **Double-click `start-silent.vbs`** (or run `npm run silent`).

The bot starts invisibly via the normal launcher (Docker + Lavalink + tunnel + deploy + bot), with all output streaming to `logs\bot.log`. A **Harmonix icon** appears in the system tray (click the ^ chevron by the clock). Right-click it for:

- **Show live logs** - opens a window tailing the log in real time. This window is just a viewer: close it whenever you like, the bot keeps running. (Double-clicking the tray icon does the same.)
- **Open dashboard** - opens the current tunnel URL (read live from the log), falling back to localhost.
- **Restart bot** - stops and relaunches the whole stack.
- **Exit (stop bot)** - stops the bot and tunnel and removes the icon. Lavalink keeps running as a Docker container; stop it with `docker compose down`.

The tray tooltip shows the bot's state, and flips to "STOPPED" if the bot process ever dies so you notice.

**Start on login (optional):** press Win+R, run `shell:startup`, and put a shortcut to `start-silent.vbs` there.

Note: silent mode is Windows-only (it uses the Windows tray). If PowerShell's execution policy blocks it, the launcher already passes `-ExecutionPolicy Bypass`; if Windows flags the files as downloaded, right-click each -> Properties -> Unblock.

## Dashboard redesign: sidebar navigation & control-room theme

The dashboard has a new shell. The hamburger dropdown is gone, replaced by a **persistent sidebar** with grouped navigation — Music, Manage (Commands, Server Settings, Welcome & More, Composer), Community (Leveling, Achievements, Mod Cases), and Insights (Command Stats, Live Log). The active view is highlighted with a coral indicator, sections you lack permission for disappear (including their group labels), and a live online/offline dot sits in the sidebar footer. On mobile the sidebar becomes a slide-in drawer behind the ☰ button.

Visually it's now the coral / cream / rose "control room" look: Poppins display headings, Space Grotesk body text, film-grain texture, wider layout, hover lift on cards, and themed scrollbars. Every control, panel, and setting works exactly as before — this pass changed the shell and skin, not the plumbing.

## Overview page, mini-player & quick-jump

- **Overview** — a new home view (top of the sidebar, managers only) showing the server at a glance: members, tracks and listeners this week, commands used, badges unlocked, and gateway ping, plus the week's top track and quick-jump buttons into Composer, Commands, Settings, and Achievements. It also flags how many feature modules are turned off.
- **Mini-player** — while you're on any management view, a floating pill in the bottom-right shows what's playing with play/pause and skip; click the title to jump back to the Music Console. It appears only when music is playing and you're not already on the Console.
- **Ctrl+K quick-jump** — press Ctrl+K (Cmd+K on Mac) anywhere for a filterable palette of every view you have access to; type, Enter, you're there. Esc closes.

## Design pass: clearer structure

A UX refinement of the existing screens (no new features): Server Settings subsections are now distinct **section cards** with stacked, labeled fields and hairline separators instead of one flat grid of pills; buttons follow one language (outline secondary, coral primary); Command Manager categories are bordered cards with a rotating chevron, count badge, zebra rows, and a sticky search box; keyboard focus is visible everywhere; and empty states are friendlier.

## Dashboard CSS rebuilt from scratch

The stylesheet was accumulating conflicting overrides from many incremental passes, which is why the composer and other areas looked patchy. It's now a single coherent system rewritten from the ground up (~460 lines): unified control sizing (one input/button height everywhere), coral reserved only for active nav / primary actions / focus / progress, and consistent section-card rhythm across every screen.

The **Composer** was the worst offender and is fully restructured: fields are grouped into labeled cards (Destination · Embed · Role buttons), compact fields sit two-per-row, and the live preview renders on a proper Discord-like stage. Settings render as clean section cards, the Command Manager categories, mod cases, leveling, achievements, config cards, overview, mini-player, palette, and login screen all share the same visual language. Every class and element ID was coverage-checked so nothing renders unstyled.

## Command Manager redesign + fixes

- **Fixed:** the Command Stats bars are visible again (the CSS targeted the wrong element), and the command search box is no longer white (it had no input type).
- **Command Manager is redesigned around progressive disclosure.** Each command row now shows only the essentials at a glance: an on/off switch, the command name with a **plain-English state line** ("Everyone · everywhere", "Staff only · blocked in 2 channels", "Disabled — hidden from /help"), and power-level buttons relabeled from L0/L1/L2 to **Everyone / Trusted / Staff**. The advanced controls — where it works (Everywhere / Only in / Block in + channel picker) and reply visibility — are tucked behind a ⚙ button per command and expand only when you need them. The state line updates live as you change settings, so a long list stays readable instead of overwhelming.
